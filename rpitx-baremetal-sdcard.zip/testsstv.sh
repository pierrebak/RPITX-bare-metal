# SSTV Martin 1 from a BMP picture (replaces snapsstv.sh, no camera / ImageMagick)
bmp2rgb picture.bmp picture.rgb
pisstv picture.rgb picture.ft
rpitx -m RF -i picture.ft -f 50105
