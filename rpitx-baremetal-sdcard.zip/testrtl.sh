# RTL-SDR examples (dongle on a USB port, plugged before running)
#
# 1. check the dongle
rtl_test -t
#
# 2. relay: receive 145.500 MHz, retransmit on 50.500 MHz, squelch -40 dBFS
#    (both are amateur bands: licence required). Ctrl-C or Esc to stop.
rtl2tx -r 145.5M -f 50500 -q -40
#
# 3. record 10 s around 145.500 MHz (tuned rate/4 above), convert, replay
rtl_sdr -f 145560000 -s 240000 -n 2400000 capture.bin
rtl2iq -f 50500 capture.bin capture.wav
rpitx -m IQ -i capture.wav -f 50489
