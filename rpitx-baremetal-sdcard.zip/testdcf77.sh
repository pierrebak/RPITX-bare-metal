# DCF77 time frame on 77.5 kHz (fixed time coded in pidcf77, as in rpitx v1)
pidcf77 dcf.rfa
rpitx -m RFA -i dcf.rfa -f 77.5 -l
