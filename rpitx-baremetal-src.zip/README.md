# rpitx v1 en bare metal pour Raspberry Pi 1, avec RTL-SDR

Portage de **rpitx v1** (F5OEO, tag `v1`, 2018) sur Raspberry Pi 1 **sans Linux**, au-dessus
du framework bare metal [Circle](https://github.com/rsta2/circle), avec la prise en charge
des clés **RTL-SDR** (librtlsdr d'Osmocom) sur l'USB du Pi, les **modes de rpitx v2** (chirp,
peinture spectrale, POCSAG, Opera, RTTY, Morse, FreeDV, FM large bande) et l'équivalent de ses
menus **`easytest`** et **`rtlmenu`**, plus une **interface plein écran au clavier** (`tui`).

Le Pi démarre directement sur un petit shell (écran HDMI + clavier USB, ou liaison série).
Toutes les commandes de rpitx v1 s'utilisent avec les mêmes options que sous Linux :

```
rpitx:SD:/> pifm sampleaudio.wav fm.ft
rpitx:SD:/> rpitx -m RF -i fm.ft -f 433900 -l
rpitx:SD:/> rtl2tx -r 145.5M -f 50500 -q -40
rpitx:SD:/> tui
```

> **Émettre exige une autorisation** pour la fréquence utilisée et un **filtre passe-bande** :
> la sortie GPIO est un signal carré riche en harmoniques. rpitx n'a jamais été testé pour la
> conformité réglementaire (avertissement de l'auteur d'origine, repris ici).

---

## 1. État du portage : ce qui est vérifié et ce qui ne l'est pas

### Vérifié

| Vérification | Résultat |
|---|---|
| Compilation complète (`arm-none-eabi-gcc` 13.2, Circle 51.1.1, Pi 1) | `kernel.img` de 445 Ko, aucune référence non résolue |
| Démarrage sous QEMU (`-M raspi0`, même SoC BCM2835 que le Pi 1) | shell, carte SD FAT32, scripts, Ctrl-C : OK |
| Générateurs exécutés **sur cible ARM** (QEMU) comparés à rpitx v1 sous Linux + libsndfile | `pifm`, `piam`, `pissb`, `pifsq`, `pidcf77`, `pisstv` : sorties **identiques** (7 fichiers) |
| Mêmes générateurs, compilés sur PC avec ma couche WAV au lieu de libsndfile | identiques (WAV mono, stéréo, 24 bits) |
| `bmp2rgb` comparé à ImageMagick (`convert -depth 8`) | identique octet par octet |
| Modes repris de la v2 : programmes v2 d'origine compilés contre une fausse librpitx qui enregistre chaque échantillon, comparés aux fichiers du portage | POCSAG, Opera, RTTY, Morse, FreeDV : **identiques** échantillon par échantillon ; chirp à 6 Hz près (10 kS/s au lieu de 200 kS/s) ; spectre : même fréquence pour chaque pixel, luminosité corrélée à 0,99 avec l'image (0,74 pour la v2, qui réduit l'image à 4 couleurs) |
| Menus `easytest` et `rtlmenu` sous QEMU (émission remplacée par l'affichage de la commande) | les 15 entrées et les 4 entrées RTL lancent les bonnes commandes ; les 13 fichiers générés sur cible sont identiques à ceux du PC |
| Chaîne DSP RTL-SDR → IQ → calcul de fréquence de rpitx v1 (simulation, y compris le mode harmonique) | fréquence émise exacte (±0 Hz), réjection hors canal 56 à 71 dB |
| Mode FM → BLU de `rtl2tx` (simulation) | ton audio émis à la bonne fréquence, bande latérale inférieure atténuée de 56 à 77 dB |
| Interface plein écran `tui` sous QEMU, pilotée par la liaison série (rendu vérifié avec un émulateur de terminal VT100 et une capture de l'écran HDMI émulé) | navigation, pas de fréquence, saisie de fréquence (virgule acceptée), sélecteur de fichiers, sortie GPIO 4, lancement réussi (Morse) et en échec (fichier absent), retour au shell par Échap : OK ; accents affichés sur l'écran HDMI |
| Commandes lancées plusieurs fois de suite (QEMU) | sorties identiques à chaque fois (état des programmes restauré, voir § 9) |
| `getopt`, `strtod`, `strtol`, `qsort`, `sscanf` maison comparés à la glibc | identiques sur tous les cas (options de rpitx, rtl_sdr, rtl2tx) |

### Non vérifié (pas de matériel disponible pendant le portage)

- **L'émission radio réelle n'a jamais été testée** : QEMU n'émule ni le PWM, ni le
  gestionnaire d'horloges, ni une chaîne DMA cyclique. Le code DMA/PWM/GPCLK est celui de la v1,
  inchangé ; seules l'allocation mémoire, les adresses bus et la gestion du cache ont été adaptées.
- **Pilote USB RTL-SDR :** une clé V4 est reconnue et diffuse à 2 MS/s (voir ci-dessous) ; la
  réception réelle et `rtl2tx` ne sont pas encore validés.
- Les nouveaux modes n'ont jamais été décodés par un vrai récepteur (pager POCSAG, décodeur
  Opera, logiciel RTTY…) : seule l'identité avec les sorties de la v2 est vérifiée.
- La charge processeur du relais et du mode FM → BLU sur un Pi 1 n'a pas été mesurée.
- Seule la FM large bande sur 87,8 MHz a été essayée sur matériel (voir ci-dessous) ; les autres
  modes, les harmoniques au-dessus de 125 MHz et le RTL-SDR restent à essayer.

### Essai sur matériel (6 novembre 2026, Raspberry Pi 1 B)

- Avec le `dt-blob.bin` de rpitx v1, **le Pi ne démarrait pas** ; sans lui, il démarre. Le fichier
  n'est donc plus sur la carte et PLLD reste à 500 MHz (réglage par défaut du shell).
- `piwfm sampleaudio.wav` puis `rpitx -m RF -f 87800 -l` : réception parfaite sur un poste FM
  réglé sur 87,8 MHz. Cela valide le démarrage, le moteur DMA/PWM porté et la fréquence de PLLD.

- Clé **RTL-SDR Blog V4** branchée après le démarrage, `rtl_test` : la clé est reconnue
  (« RTL-SDR Blog V4 Detected », tuner R828D, lecture des chaînes USB correcte), mais toutes les
  écritures I2C vers le tuner étaient signalées en échec (« r82xx_write: i2c wr failed=0 »), le
  réglage du débit échouait, aucun échantillon n'était signalé et Ctrl-C ne rendait pas la main.
  - Cause trouvée : pour un transfert de contrôle sortant, le contrôleur USB du Pi ne compte pas
    les octets envoyés et Circle renvoie 0 ; librtlsdr compare ce nombre à la longueur écrite.
    `libusb_control_transfer` renvoie maintenant la longueur demandée (comme libusb et le pilote
    dwc2 de Linux), une erreur USB restant signalée comme telle.
  - Ctrl-C : Circle ne peut pas annuler une requête bulk en cours ; si la clé n'envoie rien,
    l'arrêt attendait indéfiniment. L'arrêt abandonne maintenant les requêtes après 3 s
    (tampons volontairement non libérés), et `rtl_test` affiche le débit reçu toutes les 5 s.
  - Les cinq « dwhci: Transaction failed (status 0xA) » avant « Found Rafael Micro R828D » sont
    normaux : librtlsdr interroge les adresses I2C des autres tuners, absents, et la clé répond
    par un refus (STALL) que Circle journalise.
  - Après correctif (même soir) : plus aucune erreur I2C, « Sampling at 2048000 S/s », puis
    « Receiving 2044 kS/s » : la clé V4 diffuse ses échantillons à plein débit sur l'USB du Pi 1
    (une seule perte, « lost at least 52 bytes », au démarrage du flux). La qualité de réception,
    l'arrêt par Ctrl-C avec le nouveau noyau et `rtl2tx` restent à essayer.
- Avec la clé branchée **au démarrage**, le Pi reste figé. Hypothèse non vérifiée :
  alimentation insuffisante (clé V4 : 250 à 270 mA typiques selon sa fiche technique ; ports USB
  du Pi 1 B d'origine limités à 140 mA, entrée à 700 mA). À essayer avec un hub USB alimenté.

Les essais suivants sont à faire avec la même prudence (charge fictive, récepteur à côté pour
contrôler la fréquence et le spectre).

### Ctrl-C inopérant et overruns du transpondeur large (signalés le 6 novembre, modifs du 7)

**Overruns de `rtl2tx -m wide`.** Le tampon de réception (1 s) déborde : l'émission consomme
moins de 250 000 échantillons par seconde. Deux causes possibles, non départagées faute de
mesure sur le Pi :

1. *processeur trop lent* (hypothèse la plus probable d'après le code) : le chemin IQ de rpitx v1
   coûtait par échantillon 4 appels `log()`, 2 `sqrt()`, 3 `round()`, 3 `fabs()` et 16 divisions
   en double (Circle compile avec `-fno-builtin` : `ln(87,7)` et `sqrt(2)` étaient recalculés à
   chaque échantillon), soit à 250 kS/s un budget de 2,8 k cycles par échantillon à 700 MHz,
   USB, DSP et contention du bus par le DMA compris ;
2. *cadence réelle du DMA différente de la nominale* : la durée d'un échantillon est un nombre
   entier de pas DMA calibrés au lancement (« Calibrate : ... DMA x ns:y ns »), d'où un écart de
   quelques %. Correction de la passation : la marge est bien déduite du nombre de pas
   (`NbF2 = PWMF_MARGIN/FREQ_MINI_TIMING`), l'écart de 25 % (5,3 µs au lieu de 4) n'est donc pas
   attendu ; reste l'arrondi (jusqu'à ±1 pas, environ ±4 % à 250 kS/s).

Modifications :
- chemin IQ optimisé **sans changer le résultat** : table de la compression (sur l'amplitude
  entière), table des phases (degrés entiers de l'arctangente v1), `sqrt(2)` constant, divisions
  ne dépendant que du diviseur ou de la calibration mémorisées. Vérifié sur PC : sortie DMA
  identique bit à bit sur 2,7 millions d'échantillons (`hosttest/run_iqpath.sh`, 3 mutations
  volontaires détectées). Gain réel sur le Pi : non mesuré ;
- `txbench [taux] [kHz]` : mesure sur le Pi, **sans émettre**, le temps du chemin IQ et du DSP de
  `rtl2tx`, et affiche la charge prévue (USB et contention du bus non comptées) ;
- mesures pendant l'émission : `rtl2tx` affiche toutes les 5 s une ligne
  `TX DMA x kS/s, taken y kS/s (nominal z), ratio r, CPU c%, DMA underruns u` (débit réel du DMA
  suivi par sa position, temps de calcul, nombre de fois où le DMA a rattrapé le processeur) ;
  `rpitx -m IQ|IQFLOAT` affiche la même chose toutes les 10 s ;
- `rtl2tx` adapte la cadence (toutes les variantes, désactivable par `-R 0`) : interpolation
  linéaire au rapport (débit clé / débit réel de l'émission) ; ce rapport vient du débit DMA mesuré
  après 200 ms, corrigé lentement d'après le remplissage filtré du tampon (l'USB livre par
  paquets de 16 ms, une correction directe modulerait la cadence). rpitx convertit alors les
  pas de phase en Hz à la cadence réelle (`pitx_iq_rate`) et le décalage de sortie (Fs/2 ou Fs/4
  de la cadence réelle) est compensé (`pitx_iq_offset_hz`) ; sans cela, rééchantillonner aurait
  décalé la porteuse. Les décalages de sortie sont appliqués après l'interpolation (une
  interpolation près de Fs/2 détruirait le signal). Vérifié en simulation : émission jouée à
  190, 241, 250 et 262 kS/s, clé décalée de +50 et −80 ppm : rapport juste, excursion de 75 kHz
  restituée, porteuse à ±1 Hz, aucun débordement, S/(B+D) de 39 à 47 dB (48 dB sans
  rééchantillonnage). Ne corrige pas le cas « processeur trop lent » : `rtl2tx` l'annonce alors
  (« the CPU does not keep up ») ;

**Ctrl-C.** Cause inconnue, non reproduite sous QEMU (où la console est la liaison série et où le
DMA réel ne tourne pas). Hypothèse principale, non vérifiée : sous la charge du DMA (priorité
maximale, panique 7), les transactions USB fractionnées vers le clavier (basse vitesse, derrière
le hub du Pi 1 B) échouent, et Circle 51.1.1 **abandonne** le clavier après 50 erreurs
consécutives (`lib/usb/usbhiddevice.cpp`, mode plug and play), sans rien afficher. Modifications :
- `patches/circle-usbhid-keep-retrying.patch` : Circle continue de réessayer et affiche une fois
  par salve « usbhid: Report endpoint errors (USB error n), retrying » ;
- variante `kernel_fiq.img` : Circle construit avec `USE_USB_FIQ` (l'option que Circle recommande
  quand les interruptions USB sont retardées ; Linux utilise aussi le FIQ pour l'USB du Pi 1).
  Pour l'essayer : `kernel=kernel_fiq.img` dans `config.txt`. Non essayée sur le matériel ;
- la première touche autre qu'Échap/Ctrl-C reçue pendant un outil affiche
  « [key received, Esc or Ctrl-C stops] » : preuve que le clavier répond encore ;
- `timeout s commande` arrête la commande au bout de s secondes comme Ctrl-C (l'émission
  s'arrête même si le clavier ne répond plus) ; dans un script, l'arrêt par `timeout` n'interrompt
  pas la suite (statut 124) ;
- correction au passage : un outil qui lisait le clavier (`fgets` sur stdin) perdait les touches,
  avalées par la scrutation de Ctrl-C.

- **bouton d'arrêt** (ajouté le 17 novembre, l'arrêt au clavier restant inopérant pendant
  l'émission sur le matériel) : un bouton-poussoir entre la broche 11 (GPIO 17, résistance de
  tirage interne activée) et la broche 9 (masse), appuyé au moins 30 ms, agit comme Ctrl-C dans
  tous les outils (lu par `bm_poll`, indépendant de l'USB). Non essayé sur le matériel.

Vérifié sous QEMU : démarrage des deux noyaux, `timeout` (sur `sleep` et sur un outil), Ctrl-C
par la liaison série, `txbench`. Sur le matériel : rien de tout cela.

---

## 2. Matériel

- Raspberry Pi 1 modèle B (cible principale). A, A+, B+ et Zero utilisent le même SoC BCM2835 et
  devraient fonctionner (non testé).
- Carte SD (FAT32).
- Antenne / sortie RF : **GPIO 18, broche 12** (ou GPIO 4, broche 7 avec `-c 1`), via un filtre.
- Console : écran HDMI + clavier USB (disposition FR par défaut, voir `cmdline.txt`),
  ou adaptateur série 3,3 V sur GPIO 14/15 (broches 8/10), 115200 bauds 8N1.
- Optionnel : clé RTL-SDR (RTL2832U + R820T/R820T2/R828D, E4000, FC0012, FC0013, FC2580 :
  toutes les clés reconnues par librtlsdr), branchée sur un port USB.

## 3. Préparer la carte SD

Copier le contenu du dossier `sdcard/` (archive `rpitx-baremetal-sdcard.zip`) à la racine d'une
carte formatée en FAT32 :

| Fichier | Rôle |
|---|---|
| `bootcode.bin`, `start.elf`, `fixup.dat`, `LICENCE.broadcom` | firmware du Pi (révision `0641c5b` utilisée par Circle 51.1.1) |
| `kernel.img` | rpitx bare metal |
| `config.txt`, `cmdline.txt` | configuration du firmware et de Circle (résolution, clavier) |
| `autoexec.txt` | commandes exécutées au démarrage |
| `test*.sh` | scripts d'essai de la v1 (inchangés) + `testsstv.sh`, `testdcf77.sh`, `testrtl.sh` |
| `sampleaudio.wav`, `picture.bmp` | fichiers d'essai |
| `freedv.rf` | fichier FreeDV 800XA pré-encodé de la v2 (`SAMPLE_FREEDV.rf`) |

## 4. Utilisation

Au démarrage, `autoexec.txt` est exécuté puis l'invite `rpitx:SD:/>` apparaît.
**Ctrl-C** (série ou clavier) ou **Échap** (clavier) arrête l'outil en cours ; l'émission est
toujours coupée (DMA, PWM et horloge arrêtés), quelle que soit la façon dont l'outil se termine.

### Outils rpitx v1 (mêmes options que sous Linux)

| Commande | Rôle |
|---|---|
| `rpitx -m IQ\|IQFLOAT\|RF\|RFA\|VFO -i fichier -f kHz [-l] [-p ppm] [-c 1] [-d n] [-w 1] [-r] [-a canal]` | émetteur |
| `pifm in.wav [out.ft]` | FM bande étroite (WAV 48 kHz) |
| `piam in.wav [out.rfa]` | AM |
| `pissb in.wav [out.wav]` | BLU (USB) en IQ |
| `pisstv image.rgb out.ft` | SSTV Martin 1 |
| `pifsq "texte" out.ft` | FSQ |
| `pidcf77 out.rfa` | trame horaire DCF77 (heure fixe, comme dans la v1) |
| `bmp2rgb image.bmp image.rgb` | **nouveau** : remplace ImageMagick pour préparer une image pour `pisstv` (BMP 24/32 bits, redimensionnée en 320×256) |

Les scripts de la v1 tournent sans modification : `sudo` et `./` sont ignorés.
`sh testfm.sh` (ou simplement `testfm.sh`) génère `fm.ft` puis émet sur 433,9 MHz.

### Modes repris de rpitx v2

La v2 émet directement depuis chaque programme ; ici chaque mode devient un générateur qui
écrit un fichier pour le moteur v1, puis `rpitx` l'émet.

| Commande | Rôle | Émission |
|---|---|---|
| `pichirp out.ft [largeur Hz] [période s]` | porteuse qui balaie ±largeur/2 (sinus) | `rpitx -m RF -i out.ft -f kHz -l` |
| `pispectrum image.rgb out.ft [excursion Hz]` | peinture spectrale (image visible sur une cascade) | `-m RF -l` |
| `piwfm [-t 50\|75] in.wav [out.ft]` | FM large bande mono, excursion 75 kHz, préaccentuation | `-m RF -l` |
| `pipocsag [-r 512\|1200\|2400] [-n] [-t n] out.ft "adresse:message"` | pager POCSAG (FSK ±4,5 kHz) | `-m RF` |
| `piopera INDICATIF mode out.rfa` | balise Opera (modes 0.5, 1, 2, 4, 8) | `-m RFA` |
| `pirtty out.ft décalage_Hz "texte"` | RTTY Baudot 45,45 bauds, shift 170 Hz | `-m RF` |
| `pimorse vitesse "texte" out.rfa` | Morse en tout-ou-rien (un symbole dure 1,25/vitesse s) | `-m RFA` |
| `pifreedv vco.rf out.ft [taux]` | rejoue un fichier FreeDV déjà modulé | `-m RF` |

### Interface plein écran `tui` (alias `menu`)

Tous les modes d'`easytest` et de `rtlmenu` sur un seul écran 80×24, utilisable sur l'écran HDMI
avec un clavier USB et sur un terminal série (VT100) :

| Touche | Action |
|---|---|
| Haut / Bas | choisir le mode (liste à gauche ; le détail et les commandes qui seront lancées à droite) |
| Gauche / Droite | baisser / monter la fréquence d'un pas |
| `+` / `-` (ou PgPréc / PgSuiv) | pas de 100 Hz, 1 kHz, 10 kHz, 100 kHz, 1 MHz ou 10 MHz |
| `m` | sur « RTL Récepteur » : mode de démodulation FM / AM / BLU USB / BLU LSB |
| `F` | saisir la fréquence en MHz (`87,8` ou `87.8`) |
| `E` | paramètres du mode : sélecteur des fichiers de la carte SD (`.wav`, `.bmp`/`.rgb`, `.rf`), texte du message, ou fréquence de réception et gain de la clé RTL-SDR |
| `S` (ou Tab) | sortie sur GPIO 18 (broche 12) ou GPIO 4 (broche 7, ajoute `-c 1`) |
| Entrée | émettre ; Échap ou Ctrl-C arrête et revient à l'écran |
| `Q` ou Échap | revenir au shell |

L'en-tête indique si la fréquence est émise en direct ou sur une harmonique (et laquelle). Les
commandes sont celles des menus ci-dessous ; elles s'affichent avant d'être lancées. En cas
d'échec (fichier absent...), le message d'erreur reste affiché jusqu'à l'appui d'une touche.
Fréquence, pas, paramètres, sortie et mode de réception sont **conservés d'un démarrage à l'autre**
dans `rpitx.cfg` (écrit sur la carte SD à chaque lancement). Cet écran s'ouvre au démarrage
(dernière ligne d'`autoexec.txt`, à retirer pour arriver sur l'invite).

### Menus `easytest` et `rtlmenu`

Équivalents texte des scripts `easytest.sh` et `rtlmenu.sh` de la v2 : on choisit la fréquence,
puis un numéro ; les questions (fichier, message, indicatif) proposent les mêmes valeurs par
défaut que la v2. Chaque commande est affichée avant d'être lancée (réutilisable telle quelle à
l'invite ou dans `autoexec.txt`), et Ctrl-C ou Échap revient au menu. Entrée seule réaffiche le
menu, `Q` le quitte.

`easytest` : 0 porteuse, 1 chirp, 2 peinture spectrale, 3 RfMyFace (indisponible : caméra),
4 FM large bande (sans RDS), 5 FM bande étroite, 6 BLU, 7 AM, 8 FreeDV, 9 SSTV, 10 POCSAG,
11 Opera, 12 RTTY, plus 13 Morse et 14 FSQ.

`rtlmenu` : 0 enregistrement (`record.iq`), 1 relecture sur la fréquence d'émission,
2 transpondeur (`rtl2tx`), 3 FM → BLU (`rtl2tx -m fm2ssb`), 4 changement des fréquences et du gain.

### Vérifier la réception sur PC (`pc/fmdemod.py`)

Sur le Pi : `rtl_sdr -f 100.3M -s 960000 -g 20 -n 9600000 radio.iq` (10 s, 19 Mo). Sur le PC
(Python 3 + numpy) : `python3 fmdemod.py radio.iq` affiche le niveau, le taux d'écrêtage du
convertisseur (saturation : gain trop fort) et les signaux les plus forts, puis démodule la FM
large bande vers `radio.iq.wav`. `--nfm` pour la FM bande étroite, `--rate 240000 --offset -60000`
pour un fichier de « RTL Enregistrer ». Vérifié sur des enregistrements synthétiques (ton de
1 kHz restitué, saturation détectée), pas encore sur un enregistrement du Pi.

### Commandes du shell

`ls`, `cd`, `pwd`, `cat`, `cp`, `mv`, `rm`, `mkdir`, `df`, `echo`, `sleep`, `clear`,
`sh script`, `set [plld 500|1000]`, `info`, `usb` (liste les clés RTL-SDR), `reboot`, `help`,
`timeout s commande` (arrêt au bout de s secondes, comme Ctrl-C), `txbench [taux] [kHz]` (temps de
calcul de la chaîne d'émission, sans émettre).
Flèches haut/bas : historique.

## 5. RTL-SDR

| Commande | Rôle |
|---|---|
| `rtl_test [-t] [-s taux] [-p]` | utilitaire d'origine de librtlsdr : test de la clé |
| `rtl_sdr -f Hz [-s taux] [-g dB] [-n échantillons] [-S] fichier` | utilitaire d'origine : enregistre l'IQ brut (uint8) sur la carte SD |
| `rtl2tx -r Hz -f kHz [-m relay\|fm2ssb] [options]` | **nouveau** : réception RTL-SDR et réémission rpitx en direct ; `fm2ssb` démodule la FM bande étroite et réémet la voix en BLU (comme `fm2ssb.sh` de la v2) |
| `rtl2iq [-f kHz] capture.bin sortie.wav` | **nouveau** : convertit une capture `rtl_sdr` en WAV IQ pour `rpitx -m IQ` |

Options de `rtl2tx` : `-r` fréquence de réception (Hz, suffixes `k`/`M` acceptés), `-f` fréquence
d'émission en kHz (comme `rpitx -f`), `-g` gain du tuner en dB (auto par défaut), `-P` correction
ppm de la clé, `-p` correction ppm de rpitx, `-m relay|fm2ssb|wide`, `-s 240000|288000`
(`wide` : 240000 à 300000, 250000 par défaut), `-w` demi-largeur du canal
(12000 Hz par défaut), `-G` gain fixe en dB (AGC par défaut), `-q` squelch en dBFS, `-c 1`
sortie GPIO 4, `-d` numéro de clé.

**Plan de fréquences** (vérifié en simulation, `hosttest/test_rtldsp.c`) :

1. la clé est accordée un quart de la fréquence d'échantillonnage **au-dessus** de la fréquence
   voulue (60 kHz à 240 kS/s) : son offset continu tombe hors du canal ;
2. le canal est ramené à 0 Hz, filtré (FIR passe-bas, 133 coefficients à 240 kS/s), décimé à 48 kS/s ;
3. il est ensuite décalé de **+12 kHz** : le mode IQ de rpitx v1 convertit l'incrément de phase
   en une fréquence comprise entre 0 et 48 kHz, si bien qu'une fréquence négative serait émise
   48 kHz trop haut. Le décalage garde tout le canal (±12 kHz) dans le positif, et la fréquence
   donnée à rpitx est abaissée de 11 kHz (12 kHz moins le décalage fixe de 1 kHz de la v1).

Pour une capture : enregistrer avec `rtl_sdr -f <voulue + taux/4> -s <taux>`, puis
`rtl2iq -f <kHz d'émission> capture.bin capture.wav`, qui affiche la commande `rpitx` exacte.
Voir `testrtl.sh`.

Au-dessus de 125 MHz (PLLD à 500 MHz), l'émission passe par une harmonique (voir § 7).

**Transpondeur large (`rtl2tx -m wide`, « RTL Transpondeur large » / choix 5 de `rtlmenu`)** :
l'équivalent du `transponder.sh` de la v2 (`rtl_sdr -s 250000 | sendiq -s 250000`), nécessaire pour
une radio FM (±75 kHz d'excursion) : la version ±12 kHz n'en gardait qu'une tranche, d'où un son
inexploitable (signalé sur le matériel avec NRJ 100,3 MHz). La clé est accordée sur la fréquence,
toute la bande de 250 kHz est passée sans filtre au mode IQ de rpitx v1 à 250 kS/s, après :
- un limiteur (amplitude constante, la phase est gardée) : seuls les signaux FM ou de phase sont
  correctement retransmis, pas l'AM ni la BLU ;
- un décalage de +Fs/2 (multiplication par (-1)^n), pour que toute la bande tienne dans la plage
  [0, Fs) du mode IQ de la v1 ; la fréquence donnée à rpitx est abaissée d'autant.

Vérifié en simulation : des tonalités de -90 à +110 kHz sortent à la bonne fréquence (aussi en
harmonique), et une FM de ±75 kHz modulée à 1 kHz est restituée avec un rapport signal/(bruit +
distorsion) d'environ 48 dB dans 15 kHz, limité par l'arctangente entière de la v1. Non vérifié :
la charge du processeur du Pi 1 à 250 kS/s (les compteurs `overruns`/`waits` affichés toutes les
5 s le montreront) et la qualité réelle (pas de fréquence du diviseur plus grossier à ce débit).

### Décodeur de capteurs 868 MHz FSK `rtl868` (ajouté le 18 novembre 2026)

`rtl868` reçoit les capteurs 868 MHz en **FSK** — LaCrosse « IT+ » (TX29, TX35) et compatibles —
que le décodeur OOK `rtl433` ne peut pas traiter. Il n'émet rien. Choix 8 de `rtlmenu` ou
« RTL Capteurs 868 » dans le menu plein écran. Options comme `rtl433` (`-f`, `-g`, `-R`, `-P`, `-d`).

Chaîne (`tools/rtl868.c` + `tools/fsk.c`) : clé à 250 kS/s accordée +62,5 kHz ; discriminateur de
fréquence (angle de z[n]·conj(z[n−1])) donnant la fréquence instantanée ; retrait du continu
(décalage d'accord) ; tranchage ; récupération d'horloge bit par PLL numérique resynchronisée sur
chaque transition ; recherche du mot de synchro 0x2DD4 ; assemblage des octets ; CRC-8 (poly 0x31).
La **démodulation** (récupération des octets + CRC) est validée de bout en bout sur signal
synthétique (`hosttest/test_fsk.c`). Le **découpage des champs LaCrosse** (id, température BCD −40 °C,
humidité) est fait d'après la doc et reste **à confirmer sur matériel** : si `-R` montre des trames
« CRC ok » mais rien n'est décodé, la trame brute permet de corriger le format. Inspiré de rtl_433.

### Décodeur de capteurs 433 MHz `rtl433` (ajouté le 18 novembre 2026)

`rtl433` reçoit et décode les capteurs sans fil 433 MHz (température, humidité) — stations
météo et sondes bon marché. Il **n'émet rien**. Aussi accessible par le choix 7 de `rtlmenu`
ou « RTL Capteurs 433 » dans le menu plein écran.
Options : `-f MHz` (défaut 433.92), `-g dB` gain fixe (sinon automatique), `-R` affiche aussi
les trames non reconnues (brut : nombre de bits, timings, hex), `-P ppm`, `-d` numéro de clé.

Chaîne (`tools/rtl433.c` + `tools/ook.c`) : clé à 250 kS/s accordée +62,5 kHz (signal hors de
la raie continue) ; amplitude I/Q (enveloppe) par approximation alpha-max+beta-min ; détecteur
d'impulsions OOK à seuil adaptatif (suit le bruit et le niveau) qui découpe en rafales ;
décodeurs par protocole. **Décodeurs fournis** : Nexus et ses clones (Digoo, Sencor, Froggit), TFA-Pool
(30.3160, PPM 28 bits), LaCrosse TX141-Bv2 / TX141TH-Bv2 (PWM en rafale) — PPM 36 bits, validé sur signaux synthétiques (`hosttest/test_ook.c`,
température négative et humidité comprises). Les autres capteurs s'ajoutent à partir d'une capture
`-R`. **Non vérifié sur le matériel** : réception réelle, sensibilité, calage du seuil en présence
de bruit. Inspiré de rtl_433 (GPL-2+, compatible GPL-3).

### Récepteur multimode `rtlfm` (FM/AM/BLU, ajouté le 17 novembre 2026, étendu le 19)

`rtlfm -f 105.1` : radio FM (bande 88–108 MHz), stéréo, son sur la prise jack 3,5 mm
(`-o hdmi` : son par le HDMI). Aussi accessible par « RTL Récepteur » dans le menu plein écran.
`-M fm|am|usb|lsb` choisit la démodulation : **AM** (radiodiffusion, bande aviation) et **BLU**
USB/LSB (radioamateurs HF) s'ajoutent à la FM. La plage d'accord va de **0,1 à 1700 MHz** : sous
~28,8 MHz la V4 reçoit la HF par sa conversion interne (sans échantillonnage direct), comme le
scanner. En AM/BLU la stéréo et le RDS sont coupés (CPU épargné).
Options : `-g dB` gain fixe (sinon AGC logiciel), `-m` mono, `-M mode`, `-e 75` désaccentuation des
Amériques (50 µs par défaut), `-v` volume, `-P ppm`, `-d` numéro de clé, `-B` mesure le temps de
calcul du démodulateur sur le Pi et quitte. `-T` (avec ou sans `-o hdmi`) essaie la sortie son seule, sans clé : 1 kHz à gauche, à droite puis des deux côtés, et affiche le débit réellement joué (aussi affiché pendant l'écoute : « son x kHz »).
Touches pendant l'écoute : ←/→ ±0,1 MHz, ↑/↓ (ou PgUp/PgDn) ±1 MHz, `+`/`-` volume, `m` muet,
`s` stéréo/mono, `g`/`G` gain −/+ (passe en manuel), `a` AGC, Échap, `q` ou Ctrl-C pour quitter.
Une ligne d'état (fréquence, niveau d'entrée en dBFS avec barre S-mètre, gain, STEREO/mono, niveau
du pilote, CPU, pertes) est mise à jour chaque seconde.

Réglages de la clé (choisis pour la RTL-SDR Blog V4) : 1,024 MS/s ; accord 256 kHz au-dessus de la
station (raie continue hors du canal) ; AGC du RTL2832 coupé ; gain du tuner en manuel, piloté par
un AGC logiciel (−12 dBFS visés, gain baissé dès que les 8 bits saturent), le fabricant déconseillant
l'AGC de FI sur la V4 ; 0 ppm (TCXO) ; bias-tee coupé ; pas d'échantillonnage direct. Le pilote
coupe déjà de lui-même les filtres coupe-bande FM de la V4 entre 85 et 112 MHz.

Chaîne (`tools/fmrx_dsp.c`, filtres de `tools/gen_fmrx_taps.py`) : permutation I/Q (−Fs/4 → 0),
deux demi-bandes en polyphase 1 024 → 512 → 256 kS/s, discriminateur atan2, PLL sur le pilote
19 kHz, démodulation L−R à 38 kHz, filtre 256 → 64 kHz, désaccentuation à 64 kHz, filtre 64 → 32
kHz (pilote atténué de 93 dB), matrice L/R. Le son est rééchantillonné au rythme réel de la sortie
(compense aussi un réglage PLLD faux). Sur PC (`hosttest/test_fmrx.c`, signaux synthétiques) :
S/(B+D) 68 dB en mono, séparation stéréo 35 dB, voisine 16 dB plus forte à 200 kHz : 51 dB,
désaccentuation à 0,4 dB de la théorie à 10 kHz. Coût estimé sur ARM1176 (comptage
d'instructions par émulation) : ~170 M instructions par seconde de signal en mono, soit environ un
tiers du processeur ; à mesurer sur le Pi avec `rtlfm -B`. **Non vérifié sur le matériel** : son
réel, charge réelle, changement de gain et de fréquence pendant la réception.

**AM et BLU** : au point bande de base 256 kHz (station centrée sur 0 Hz), l'AM est une détection
d'enveloppe (|z|) suivie d'un retrait du continu ; la BLU est démodulée par déphasage (filtre de
Hilbert sur Q : USB = I − H(Q), LSB = I + H(Q)). Un filtre de canal à 32 kHz resserre la bande
(passe-bande ~0,3–2,8 kHz en BLU, passe-bas ~4,5 kHz en AM). Dans le menu plein écran, la touche
`m` choisit le mode avant de lancer, et le pas d'accord descend à 100 Hz pour zéro-battre la BLU.
**Non vérifié sur le matériel** : qualité AM/BLU réelle, sens USB/LSB, niveaux.

Limites : le mode étroit traite un canal de ±18 kHz maximum ; taux d'enregistrement `rtl_sdr`
conseillé ≤ 1 MS/s (débit d'écriture de la carte SD, non mesuré).

### Scanner de bande `rtlscan` (ajouté le 18 novembre 2026)

`rtlscan 88 108` balaye une plage (MHz) et liste les signaux détectés avec leur niveau, leur
largeur et leur **type de modulation** reconnu automatiquement (AM, FM, BLU, CW, FSK, numérique).
La reconnaissance est **recoupée avec le plan de bande** France/Europe (`tools/bandplan.c`) pour
éviter les faux positifs : un service à modulation fixe (FM radiodiffusion, DAB, TETRA…) impose
son mode, ailleurs le classifieur (`tools/classify.c`) décide. Pour les stations FM, le **RDS**
est relevé si disponible et associé au nom. N'émet rien. Plage 0,1–1700 MHz (HF comprise).
« RTL Scanner » dans le menu plein écran. Options : `-g dB`, `-D` diagnostics, `-d` numéro de clé.

Chaîne (`tools/rtlscan.c`, `tools/fft.c`, `tools/scan.c`, `tools/classify.c`, `tools/bandplan.c`) :
clé à 1,024 MS/s, FFT 1024 avec fenêtre de Hann, plancher de bruit par percentile (histogramme),
détection par seuil + regroupement des raies ; pour chaque porteuse, accord puis rotation Fs/4 +
décimation avant classification ; AGC logiciel comme `rtlfm`. Classifieur validé sur signaux
synthétiques (`hosttest/test_classify.c` : AM/FM/CW/BLU/FSK/numérique). Partiellement confirmé sur
matériel (stations FM identifiées avec RDS, numérique vu en bande DAB).

### Cascade (waterfall) `rtlwf` (ajouté le 18 novembre 2026)

`rtlwf -f 100` affiche une cascade temps-fréquence (1 MHz de large) avec **échelle de fréquence**
et graduations. N'émet rien. « RTL Waterfall » dans le menu plein écran. Options : `-g dB`, `-d`.
Sortie automatique au bout de 60 s : le clavier ne passe pas pendant le streaming RTL sur le Pi 1,
l'USB étant saturé (limite matérielle, non contournable à peu de frais). Chaîne (`tools/rtlwf.c`,
`tools/fft.c`) : 1,024 MS/s, FFT 1024, dégradé de couleurs, affichage circulaire.

## 6. Différences de comportement avec rpitx v1 sous Linux

- `-i -` (lecture sur l'entrée standard, tubes) n'existe pas : utiliser un fichier ou `rtl2tx`.
- Pas de NTP : la correction d'horloge vient uniquement de `-p`. **Bug v1 corrigé** : la valeur
  `-p` donnée par l'utilisateur était remplacée par la valeur NTP (test inversé dans `pitx_run`).
- Ouvrir un fichier en écriture le tronque toujours (la v1 ouvrait sans `O_TRUNC` : sous Linux,
  regénérer un fichier plus court laissait des octets en trop à la fin).
- Le canal DMA est attribué par Circle parmi ceux laissés à l'ARM par le firmware (au lieu d'être
  deviné selon la version du noyau Linux) ; `-a` force un canal s'il est libre.
- Non porté : module Python (`src/python`), `snapsstv.sh` (caméra + ImageMagick, remplacé par
  `testsstv.sh` et `bmp2rgb`), `install.sh`.

Par rapport aux modes de la v2 :

- **Peinture spectrale** : la v2 module 4 niveaux d'amplitude ; le mode RF de la v1 n'a que
  porteuse/silence, les gris sont donc rendus par tramage (pixel allumé 1/3 ou 2/3 du temps).
- **Chirp** : fréquence mise à jour 10 000 fois par seconde au lieu de 200 000.
- **FmRds** : la v2 construit un multiplex stéréo à 228 kS/s avec la sous-porteuse RDS à 57 kHz,
  hors de portée du moteur v1 ; remplacé par de la FM large bande mono sans RDS (`piwfm`).
- **RfMyFace** : nécessite la caméra du Pi, sans pilote ici.
- **FreeDV** : comme la v2, rejoue un fichier déjà modulé (aucun codec embarqué).
- **rtlmenu** : choix 0 à 3 sur un canal de ±12 kHz ; le transpondeur large (choix 5) retransmet
  250 kHz comme la v2 (voir § 5).
- Erreurs de la v2 évitées : caractère sans code Morse ou Baudot (plantage en v2), texte RTTY
  limité à 43 caractères (débordement de tampon en v2).

## 7. Fréquence de PLLD (`dt-blob.bin`) et harmoniques

rpitx v1 suppose PLLD à 1 GHz, réglé par son `dt-blob.bin`. Avec le firmware actuel, ce fichier
empêche le Pi 1 B de démarrer : il n'est plus fourni, PLLD reste à 500 MHz et c'est la valeur par
défaut du shell (`set plld 500`, vérifié sur matériel à 87,8 MHz). `set plld 1000` ne sert que si
l'on remet un `dt-blob.bin` qui fonctionne (fichier d'origine dans `rpitx/orig/`).

Au-dessus de PLLD/4 (125 MHz avec PLLD à 500 MHz), le signal est une harmonique impaire. La
v1 divisait la fréquence deux fois par le rang H : la fondamentale était à F/H² et le signal
voulu sur l'harmonique H² (la 25e à 434 MHz), avec en plus un décalage de 1000·(H−1) Hz en
mode IQ. **Ce portage corrige ce point** (`pitx_SetTuneFrequency` dans `RpiTx.c`) : la
fondamentale est à F/H et le signal sur l'**harmonique H**, H fois plus fort (1/H de la
fondamentale pour un signal carré au lieu de 1/H²), sans décalage en IQ.

| Fréquence | v1 d'origine | ce portage | gain (calcul) |
|---|---|---|---|
| 145,5 MHz | 9e harmonique (−19 dB) | 3e (−9,5 dB) | +9,5 dB |
| 434 MHz | 25e harmonique (−28 dB) | 5e (−14 dB) | +14 dB |
| 750 MHz | 49e harmonique (−34 dB) | 7e (−17 dB) | +17 dB |

Ces niveaux sont théoriques (signal carré parfait) et n'ont pas été mesurés ; les fronts réels
de la sortie GPIO atténuent encore les harmoniques élevées.

## 8. Compilation

Prérequis : `gcc-arm-none-eabi` (testé avec 13.2.1), `make`, `git`.

```sh
git clone https://github.com/rsta2/circle            # testé : Circle 51.1.1 (7a81e1b)
cd circle
git apply ../rpitx-baremetal/patches/circle-usb-devicefactory-hook.patch
git apply ../rpitx-baremetal/patches/circle-usbhid-keep-retrying.patch
./configure -r 1 --keymap FR        # variante kernel_fiq.img : ajouter -d USE_USB_FIQ
./makeall
make -C addon/fatfs && make -C addon/SDCard
cd ../rpitx-baremetal
make CIRCLEHOME=../circle            # -> kernel.img
make CIRCLEHOME=../circle sdcard     # -> dossier sdcard/ complet
```

Le patch Circle (9 lignes) ajoute un point d'accroche faible `UserUSBDeviceFactory()` dans la
fabrique de pilotes USB, pour que l'application fournisse son pilote RTL2832U. Le second empêche
Circle d'abandonner le clavier après 50 erreurs (voir § 1). `kernel_fiq.img` : même source,
Circle configuré avec `-d USE_USB_FIQ` dans une seconde copie de Circle, puis
`make CIRCLEHOME=<cette copie>` et renommer `kernel.img`.

Tests sur PC (gcc, g++, libsndfile-dev, sox, ImageMagick, python3) :
`hosttest/run_all.sh <dépôt rpitx au tag v1> <dépôt rpitx sur master (v2)>` (comprend la
comparaison bit à bit du chemin IQ avec `hosttest/ref/RpiTx_before_optim.c` et les essais de
l'adaptation de cadence).

## 9. Organisation du code

| Dossier | Contenu |
|---|---|
| `rpitx/` | cœur rpitx v1 porté (`RpiTx.c`, chaque modification marquée `BAREMETAL`), couche matérielle (`RpiDma.c`, `RpiGpio.c`), générateurs v1 **non modifiés** ; `orig/` : fichiers v1 d'origine pour comparaison |
| `rtlsdr/` | librtlsdr (commit `797f814`) : pilotes de tuners non modifiés ; dans `librtlsdr.c`, tampons DMA alignés + 3 fonctions ajoutées (flux non bloquant) ; `libusb_circle.cpp` : pilote USB RTL2832U et sous-ensemble de libusb sur Circle ; `utils/` : `rtl_sdr` et `rtl_test` d'origine |
| `rpitx/v2/` | modes repris de rpitx v2 : `pipocsag.c` et `piopera.c` convertis mécaniquement depuis la v2 (codage inchangé, seule la sortie change), les autres réécrits d'après le code v2 ; `bm_rfwrite.h` écrit les fichiers .ft/.rfa |
| `tools/` | émission : `rtl2tx`, `rtl2iq`, `rtldsp` (DSP, relais et FM → BLU), `bmp2rgb`. Réception : `rtlfm` + `fmrx_dsp` (FM/AM/BLU + `rds`), `rtlscan` (scanner) avec `fft`, `scan`, `classify`, `bandplan`, `rtlwf` (cascade), `rtl433` + `ook` (capteurs 433 OOK), `rtl868` + `fsk` (capteurs 868 FSK) |
| `compat/` | mini libc : fichiers sur FatFs, `printf`, `getopt`, signaux (Ctrl-C → `SIGINT`), `exit()` qui revient au shell, lecteur/écrivain WAV compatible libsndfile |
| `kernel/` | noyau Circle, shell, menus `easytest` / `rtlmenu` (`menus.cpp`), interface plein écran (`tui.cpp`) |
| `boot/` | fichiers de la carte SD |
| `hosttest/` | tests sur PC |
| `patches/` | patch Circle |

Choix techniques principaux :

- **Mémoire DMA** : les 3,6 Mo de blocs de contrôle sont en RAM normale (cache activé) ; le cache
  de données L1 (16 Ko) est entièrement nettoyé après chaque rafale, avant que le DMA ne relise.
  Les adresses bus utilisent l'alias L2 du GPU, comme les pilotes DMA de Circle.
- **Pas de threads** : la réception USB du RTL-SDR est traitée par un crochet de scrutation
  appelé pendant les attentes de la boucle d'émission de rpitx.
- **USB** : une seule requête en vol par point de terminaison (le pilote DWC de Circle ne
  sérialise pas lui-même), la suivante est lancée depuis l'interruption de fin de transfert.
- **État global** : il n'y a pas de nouveau processus entre deux commandes. Les variables
  globales et `static` des programmes portés (générateurs v1 et v2, `rtl_sdr`, `rtl_test`) sont
  regroupées à l'édition des liens entre deux marqueurs (`compat/progstate_*.c`), copiées au
  démarrage et restaurées avant chaque commande ; le cœur rpitx remet les siennes à zéro dans
  `pitx_reset_state()`. Sans cela, le générateur BLU gardait l'état de ses filtres d'une
  exécution à l'autre, et `rtl_sdr` restait arrêté après un premier Ctrl-C.

## 10. Licences

- rpitx v1 : GPL v2 ou ultérieure (Evariste Courjaud F5OEO).
- rpitx v2 (modes repris) : GPL v3 (F5OEO). Le codeur POCSAG est sous licence MIT (Galen
  Alderson, voir `rpitx/v2/LICENSE-pocsag`). Le codeur Opera porte les mentions de copyright
  F4GCB, 7L1RLL et F5OEO, sans licence propre dans le fichier : il est distribué avec la v2.
- `freedv.rf` : fichier d'exemple du dépôt rpitx v2.
- librtlsdr : GPL v2 ou ultérieure (Osmocom et contributeurs), voir `rtlsdr/COPYING-librtlsdr`.
- Circle : GPL v3 (Rene Stange). L'ensemble lié (`kernel.img`) est donc distribué sous **GPL v3**.
- Code nouveau de ce portage : GPL v3 ou ultérieure.
- Firmware Raspberry Pi : licence Broadcom (`LICENCE.broadcom`), redistribuable avec le Pi.
