#!/usr/bin/env python3
"""
fmdemod.py - check an RTL-SDR recording made on the bare metal Pi (rtl_sdr)

Reads a raw rtl_sdr file (unsigned 8 bit I/Q), prints the signal level, the
clipping rate (ADC saturation: tuner gain too high) and the strongest signals,
then demodulates broadcast FM (wide band, 50 us de-emphasis, mono) to a 48 kHz
WAV file you can listen to.

On the Pi (10 s at 960 kS/s, about 19 MB):
    rtl_sdr -f 100.3M -s 960000 -g 20 -n 9600000 nrj.iq
On the PC (Python 3 + numpy):
    python3 fmdemod.py nrj.iq
    python3 fmdemod.py nrj.iq --rate 960000 --offset 0 --out nrj.wav

--offset: frequency of the station relative to the frequency given to rtl_sdr
-f, in Hz (0 if rtl_sdr was tuned on the station). The "RTL Enregistrer" entry
of the menus records at 240 kS/s tuned 60 kHz above: --rate 240000
--offset -60000 (too narrow for broadcast FM, fine for narrow FM: --nfm).

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later
version.
"""
import argparse
import sys
import wave

import numpy as np


def lowpass(cutoff, rate, ntaps):
    n = np.arange(ntaps) - (ntaps - 1) / 2
    h = np.sinc(2 * cutoff / rate * n) * np.hamming(ntaps)
    return h / h.sum()


def fir_decimate(x, h, decim):
    """y[m] = sum_k h[k] x[m*decim + k], only at the kept samples"""
    nout = (len(x) - len(h)) // decim
    y = np.zeros(nout, dtype=x.dtype)
    for k, hk in enumerate(h):
        y += hk * x[k:k + nout * decim:decim]
    return y


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("file", help="raw rtl_sdr file (u8 I/Q)")
    ap.add_argument("--rate", type=float, default=960000, help="sample rate (default 960000)")
    ap.add_argument("--offset", type=float, default=0, help="station offset in Hz (default 0)")
    ap.add_argument("--out", help="output WAV (default: file name + .wav)")
    ap.add_argument("--nfm", action="store_true", help="narrow band FM (+/-5 kHz) instead of broadcast FM")
    ap.add_argument("--skip", type=float, default=0.1, help="seconds skipped at the start (default 0.1)")
    args = ap.parse_args()

    raw = np.fromfile(args.file, dtype=np.uint8)
    raw = raw[: len(raw) // 2 * 2]
    rate = args.rate
    skip = int(args.skip * rate) * 2
    raw = raw[skip:]
    if len(raw) < 2 * rate * 0.2:
        sys.exit("File too short (less than 0.2 s at this rate)")

    # ---- level and saturation
    clipped = np.mean((raw == 0) | (raw == 255)) * 100
    x = (raw[0::2].astype(np.float32) - 127.5) + 1j * (raw[1::2].astype(np.float32) - 127.5)
    x /= 127.5
    level = 10 * np.log10(np.mean(np.abs(x) ** 2) + 1e-12)
    peak = np.max(np.abs(raw.astype(np.int16) - 127.5)) / 127.5
    print(f"{len(x) / rate:.1f} s at {rate:.0f} S/s")
    print(f"Mean level {level:.1f} dBFS, peak {peak * 100:.0f} % of full scale, clipped samples {clipped:.2f} %")
    if clipped > 0.1:
        print("  -> ADC saturation: lower the gain (rtl_sdr -g 10 or 20)")
    elif level < -35:
        print("  -> weak signal: antenna or gain (rtl_sdr -g 30 or more)")
    else:
        print("  -> level OK")

    # ---- strongest signals (averaged spectrum)
    nfft = 4096
    nseg = min(len(x) // nfft, 200)
    seg = x[: nseg * nfft].reshape(nseg, nfft) * np.hanning(nfft)
    spec = np.fft.fftshift(np.mean(np.abs(np.fft.fft(seg, axis=1)) ** 2, axis=0))
    freqs = np.fft.fftshift(np.fft.fftfreq(nfft, 1 / rate))
    spec_db = 10 * np.log10(spec + 1e-20)
    floor = np.median(spec_db)
    order = np.argsort(spec_db)[::-1]
    shown = []
    for i in order:
        if all(abs(freqs[i] - f) > rate / 40 for f in shown):
            shown.append(freqs[i])
        if len(shown) == 3:
            break
    print("Strongest signals (relative to the rtl_sdr frequency, dB above the noise floor):")
    for f in shown:
        i = np.argmin(abs(freqs - f))
        print(f"  {f / 1000:+8.1f} kHz  {spec_db[i] - floor:5.1f} dB")

    # ---- FM demodulation
    t = np.arange(len(x)) / rate
    x = x * np.exp(-2j * np.pi * args.offset * t).astype(np.complex64)
    if args.nfm:
        bw, dev = 8000, 5000
    else:
        bw, dev = 100000, 75000
    # first decimation to about 4 x bandwidth
    # (largest ratio giving an integer multiple of 48 kHz, if any)
    dmax = max(1, int(rate // (4 * bw)))
    d1 = next((d for d in range(dmax, 0, -1) if (rate / d) % 48000 == 0), dmax)
    y = fir_decimate(x, lowpass(bw, rate, 129).astype(np.float32), d1)
    rate1 = rate / d1
    ph = np.angle(y[1:] * np.conj(y[:-1]))
    audio = ph * rate1 / (2 * np.pi * dev)          # 1.0 = nominal deviation

    # second decimation to 48 kHz (integer ratio, otherwise nearest)
    d2 = max(1, int(round(rate1 / 48000)))
    a = fir_decimate(audio.astype(np.float32), lowpass(15000 if not args.nfm else 3500, rate1, 255).astype(np.float32), d2)
    out_rate = int(round(rate1 / d2))

    if not args.nfm:
        # 50 us de-emphasis (Europe), first order IIR
        alpha = 1 - np.exp(-1 / (out_rate * 50e-6))
        b = np.empty_like(a)
        acc = 0.0
        for i, v in enumerate(a):
            acc += alpha * (v - acc)
            b[i] = acc
        a = b

    a -= np.mean(a)
    gain = 0.5 / (np.percentile(np.abs(a), 99.9) + 1e-9)
    pcm = np.clip(a * gain * 32767, -32767, 32767).astype(np.int16)

    out = args.out or args.file + ".wav"
    with wave.open(out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(out_rate)
        w.writeframes(pcm.tobytes())
    print(f"{'NFM' if args.nfm else 'FM broadcast'} demodulated to {out} ({out_rate} Hz, {len(pcm) / out_rate:.1f} s)")


if __name__ == "__main__":
    main()
