//
// kernel.h - rpitx-baremetal kernel (Circle)
//
// Copyright (C) 2026 rpitx-baremetal contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
#ifndef _kernel_h
#define _kernel_h

#include <circle/actled.h>
#include <circle/koptions.h>
#include <circle/devicenameservice.h>
#include <circle/screen.h>
#include <circle/serial.h>
#include <circle/exceptionhandler.h>
#include <circle/interrupt.h>
#include <circle/timer.h>
#include <circle/logger.h>
#include <circle/usb/usbhcidevice.h>
#include <circle/usb/usbkeyboard.h>
#include <SDCard/emmc.h>
#include <fatfs/ff.h>
#include <circle/types.h>

enum TShutdownMode
{
	ShutdownNone,
	ShutdownHalt,
	ShutdownReboot
};

class CKernel
{
public:
	CKernel (void);
	~CKernel (void);

	boolean Initialize (void);

	TShutdownMode Run (void);

	static CKernel *Get (void)	{ return s_pThis; }

	// console
	void ConsoleWrite (const char *pBuffer, unsigned nLength);
	int ConsoleGetChar (void);		// -1 if none

	void UpdateUSB (void);			// plug and play, keyboard attach
	void DrawSplash (void);			// logo.bmp as a boot splash screen
	unsigned GetFreeKBytes (void);		// on the SD card

private:
	static void ConsoleWriteStub (const char *pBuffer, unsigned nLength);
	static int ConsoleGetCharStub (void);
	static void USBPollHook (void *pContext);	// sert le clavier USB depuis bm_poll
	static void KeyPressedHandler (const char *pString);
	static void KeyboardRemovedHandler (CDevice *pDevice, void *pContext);
	void PutInput (char ch);

private:
	// do not change this order
	CActLED			m_ActLED;
	CKernelOptions		m_Options;
	CDeviceNameService	m_DeviceNameService;
	CScreenDevice		m_Screen;
	CExceptionHandler	m_ExceptionHandler;
	CInterruptSystem	m_Interrupt;
	CSerialDevice		m_Serial;
	CTimer			m_Timer;
	CLogger			m_Logger;
	CUSBHCIDevice		m_USBHCI;
	CEMMCDevice		m_EMMC;
	FATFS			m_FileSystem;

	boolean			m_bScreenOK;
	u8			m_ucUTF8Lead;		// pending UTF-8 lead byte (screen)
	CUSBKeyboardDevice * volatile m_pKeyboard;

	// console input queue (keyboard handler runs in interrupt context)
	static const unsigned InputSize = 256;	// power of 2
	char			m_InputBuffer[InputSize];
	volatile unsigned	m_nInputIn;
	volatile unsigned	m_nInputOut;

	static CKernel *s_pThis;
};

#endif
