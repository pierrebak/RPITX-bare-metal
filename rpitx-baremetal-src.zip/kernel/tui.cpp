//
// tui.cpp - full screen keyboard interface for rpitx-baremetal ("tui")
//
// Copyright (C) 2026 rpitx-baremetal contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Same demos as "easytest" and "rtlmenu" (menus.cpp), driven by the arrow
// keys on a 80x24 VT100 layout. It works on the HDMI screen (Circle screen
// device, USB keyboard) and on a serial terminal at the same time. The
// strings are UTF-8; CKernel::ConsoleWrite converts them to Latin-1 for the
// screen font.
//
// The commands are run with CShell::RunCommand, so each one is printed
// before it runs and can be reused at the prompt or in autoexec.txt.
//
#include "tui.h"
#include "shell.h"
#include "kernel.h"
#include "../compat/bm_internal.h"
#include <bm_compat.h>
#include <circle/string.h>
#include <circle/util.h>
#include <circle/stdarg.h>
#include <circle/timer.h>
#include <fatfs/ff.h>

extern "C"
{
	int pitx_harmonic_for (double Frequency);
	double pitx_iq_set_frequency (double WantedHz, double ShiftHz);
	double strtod (const char *s, char **end);
	unsigned rtlsdr_get_device_count (void);
}

// date de compilation (__DATE__ = "Nov 17 2026") au format 17/11/2026 : permet de
// verifier quel noyau est sur la carte
static const char *BuildDate (void)
{
	static char Date[16];
	static const char Months[] = "JanFebMarAprMayJunJulAugSepOctNovDec";
	const char *d = __DATE__;
	unsigned nMonth = 1;
	for (unsigned i = 0; i < 12; i++)
	{
		if (strncmp (d, Months + 3 * i, 3) == 0)
		{
			nMonth = i + 1;
		}
	}
	unsigned nDay = (d[4] == ' ' ? 0 : d[4] - '0') * 10 + (d[5] - '0');
	CString String;
	String.Format ("%02u/%02u/%s", nDay, nMonth, d + 7);
	strncpy (Date, String, sizeof Date - 1);
	return Date;
}

#define PISSB_SHIFT_HZ		1000.0		// pissb: ssb_init (1000)
#define RTLDSP_RELAY_SHIFT_HZ	12000.0		// tools/rtldsp.h

#define COLUMNS		80
#define LIST_ROW	6			// first row of the mode list
#define LIST_ROWS	15			// visible modes
#define LIST_WIDTH	26
#define PANEL_COL	30			// right panel
#define PANEL_WIDTH	(COLUMNS - PANEL_COL)
#define MESSAGE_ROW	22
#define FOOTER_ROW	23

#define ESC_TIMEOUT_US	30000			// rest of an escape sequence
#define USB_POLL_US	100000

#define MIN_MHZ		0.005
#define MAX_MHZ		1500.0
#define RANGE_MIN_MHZ	0.130			// range of rpitx v1 (README)
#define RANGE_MAX_MHZ	750.0

#define MAX_COMMANDS	3
#define MAX_PARAM	128

enum TParam
{
	ParamNone,
	ParamWav,
	ParamPicture,
	ParamRF,
	ParamText,
	ParamRTL,				// receive frequency + gain
	ParamRTLPlay				// uses record.iq
};

enum TMode
{
	ModeCarrier, ModeChirp, ModeSpectrum, ModeWFM, ModeNFM, ModeSSB, ModeAM,
	ModeFreeDV, ModeSSTV, ModePocsag, ModeOpera, ModeRTTY, ModeMorse, ModeFSQ,
	ModeDCF77, ModeRTLRecord, ModeRTLPlay, ModeRTLRelay, ModeRTLWide, ModeRTLFM2SSB,
	ModeRTLRadio,
	ModeRTL433,
	ModeRTL868,
	ModeScan,
	ModeWaterfall,
	ModeCount
};

static const struct
{
	const char *pName;
	const char *pDescription;		// '\n' separated lines, < PANEL_WIDTH
	TParam Param;
	const char *pParamLabel;
	const char *pDefault;
	const char *pExtensions;		// for the file picker
}
s_Modes[ModeCount] =
{
	{"Porteuse", "Porteuse pure (rpitx -m VFO).", ParamNone, 0, "", 0},
	{"Chirp", "Porteuse qui balaie 100 kHz en 5 s.", ParamNone, 0, "", 0},
	{"Peinture spectrale", "Image dessinée dans le spectre (waterfall).\n"
	 "BMP, ou .rgb de 320 pixels de large.", ParamPicture, "Image", "picture.bmp", ".bmp.rgb"},
	{"WFM", "FM large bande (radiodiffusion), mono, sans RDS.\n"
	 "WAV 48 kHz.", ParamWav, "Fichier WAV", "sampleaudio.wav", ".wav"},
	{"NFM", "FM bande étroite. WAV 16 bits, 48 kHz, mono.", ParamWav, "Fichier WAV",
	 "sampleaudio.wav", ".wav"},
	{"BLU (USB)", "Bande latérale unique supérieure.\n"
	 "WAV 16 bits, 48 kHz, mono.", ParamWav, "Fichier WAV", "sampleaudio.wav", ".wav"},
	{"AM", "Modulation d'amplitude (qualité médiocre).\n"
	 "WAV 16 bits, 48 kHz, mono.", ParamWav, "Fichier WAV", "sampleaudio.wav", ".wav"},
	{"FreeDV", "Voix numérique 800XA, fichier .rf pré-encodé.", ParamRF, "Fichier .rf",
	 "freedv.rf", ".rf"},
	{"SSTV", "Image en SSTV Martin 1.\n"
	 "BMP, ou .rgb 320x256.", ParamPicture, "Image", "picture.bmp", ".bmp.rgb"},
	{"POCSAG", "Message pour récepteur de radiomessagerie.\n"
	 "Format ADRESSE:MESSAGE.", ParamText, "Message", "1234567:Hello world", 0},
	{"Opera", "Balise Opera (décodeur Opera nécessaire).", ParamText, "Indicatif", "F5OEO", 0},
	{"RTTY", "Radiotélétype 45,45 bauds.", ParamText, "Message", "HELLO WORLD FROM RPITX", 0},
	{"Morse", "Télégraphie (CW).", ParamText, "Message", "CQ CQ DE F5OEO", 0},
	{"FSQ", "Message FSQ (rpitx v1).", ParamText, "Message", "Hello from rpitx", 0},
	{"DCF77", "Trame horaire DCF77 (heure fixe codée dans\n"
	 "pidcf77, comme la v1). Fréquence fixe 77,5 kHz.", ParamNone, 0, "", 0},
	{"RTL Enregistrer", "Enregistre la réception de la clé RTL-SDR\n"
	 "dans record.iq. Durée réglable (touche d : 10/30/60 s),\n"
	 "coupure automatique.", ParamRTL, "Réception", "", 0},
	{"RTL Relire", "Réémet l'enregistrement record.iq.", ParamRTLPlay, 0, "", 0},
	{"RTL Transpondeur", "Réémet en direct un canal étroit de +/-12 kHz\n"
	 "reçu par la clé (FM bande étroite, BLU...).", ParamRTL, "Réception", "", 0},
	{"RTL Transpondeur large", "Réémet toute une bande de 250 kHz, comme la v2 :\n"
	 "radio FM (87,5-108 MHz)... Signaux FM seulement.", ParamRTL, "Réception", "", 0},
	{"RTL FM vers BLU", "Démodule la FM reçue et réémet la voix en BLU.", ParamRTL,
	 "Réception", "", 0},
	{"RTL Récepteur", "Écoute multimode FM / AM / BLU (touche m),\n"
	 "de la HF à l'UHF (0,1-1700 MHz). Son sur jack.\n"
	 "N'émet rien. Gain auto.\n"
	 "Fréquence : Gauche/Droite ou F ; pas PgUp/PgDn\n"
	 "(jusqu'à 100 Hz). Échap : retour au menu.", ParamNone, 0, "", 0},
	{"RTL Capteurs 433", "Décode les capteurs 433 MHz (température, humidité).\n"
	 "N'émet rien. -R affiche aussi les trames inconnues.\n"
	 "Échap : quitter.", ParamNone, 0, "", 0},
	{"RTL Capteurs 868", "Décode les capteurs 868 MHz FSK (LaCrosse IT+).\n"
	 "N'émet rien. Format à confirmer : -R affiche le brut.\n"
	 "Échap : quitter.", ParamNone, 0, "", 0},
	{"RTL Scanner", "Balaie +/-5 MHz autour de la fréquence et liste\n"
	 "les porteuses actives (niveau, SNR). N'émet rien.\n"
	 "Fréquence centrale : Gauche/Droite ou F ci-dessus.\n"
	 "Échap : quitter.", ParamNone, 0, "", 0},
	{"RTL Waterfall", "Spectre + waterfall temps réel (~0,9 MHz),\n"
	 "affichage HDMI. N'émet rien. Pendant : flèches\n"
	 "fréquence, +/- échelle, g/G gain, Échap quitter.", ParamNone, 0, "", 0},
};

static const double s_Steps[] = {0.0001, 0.001, 0.01, 0.1, 1.0, 10.0};
static const char *s_StepNames[] = {"100 Hz", "1 kHz", "10 kHz", "100 kHz", "1 MHz", "10 MHz"};
static const unsigned s_nSteps = sizeof s_Steps / sizeof s_Steps[0];

// kept for the session, like the menus
static double s_fMHz = 434.0;
static unsigned s_nStep = 3;		// defaut : 100 kHz (l'index 0 est 100 Hz maintenant)
static double s_fRxMHz = 434.0;
static double s_fRadioMHz = 100.0;		// RTL Radio FM : frequence d'ecoute
static double s_f433MHz = 433.92;		// RTL Capteurs 433 : frequence d'ecoute
static double s_f868MHz = 868.30;		// RTL Capteurs 868 : frequence d'ecoute
static double s_fScanMHz = 100.0;		// RTL Scanner : frequence centrale
static double s_fWfMHz = 100.0;			// RTL Waterfall : frequence centrale
static int    s_recSec = 30;			// RTL Enregistrer : duree (touche d : 10/30/60)
static int    s_nRadioMode = 0;			// RTL Radio : mode de demodulation (touche m)
#define RADIO_MODE_COUNT 4			// FM, AM, BLU USB, BLU LSB
static const char *s_RadioModeName[] = {"FM", "AM", "BLU USB", "BLU LSB"};
static const char *s_RadioModeOpt[]  = {" -m", " -M am", " -M usb", " -M lsb"};

// frequence modifiee par Gauche/Droite et F : celle d'ecoute pour la radio FM
static double &FreqOf (unsigned nMode)
{
	if (nMode == ModeRTLRadio) return s_fRadioMHz;
	if (nMode == ModeRTL433)   return s_f433MHz;
	if (nMode == ModeRTL868)   return s_f868MHz;
	if (nMode == ModeScan)     return s_fScanMHz;
	if (nMode == ModeWaterfall) return s_fWfMHz;
	return s_fMHz;
}
static int s_nGain = 0;			// 0: AGC (validé sur le matériel ; 35 dB saturait en FM)
static boolean s_bGPIO4 = FALSE;
static char s_Params[ModeCount][MAX_PARAM];
static boolean s_bParamsInit = FALSE;

// Circle's CString truncates %f instead of rounding (434.2 with "%.4f" gives
// "434.1999"): add half a unit of the last printed digit
static double R (double f, unsigned nDecimals)
{
	double fHalf = 0.5;
	while (nDecimals-- > 0)
	{
		fHalf /= 10.0;
	}
	return f >= 0 ? f + fHalf : f - fHalf;
}

// number of columns taken by an UTF-8 string
static unsigned DisplayWidth (const char *p)
{
	unsigned n = 0;
	for (; *p != '\0'; p++)
	{
		if (((u8) *p & 0xC0) != 0x80)
		{
			n++;
		}
	}
	return n;
}

// copies at most nColumns columns of pSource, then pads with spaces
static void FitString (char *pDest, unsigned nSize, const char *pSource, unsigned nColumns)
{
	unsigned nOut = 0, nCol = 0;
	const char *p = pSource;
	while (*p != '\0' && *p != '\n' && nOut < nSize - 1)
	{
		if (((u8) *p & 0xC0) != 0x80)
		{
			if (nCol == nColumns)
			{
				break;
			}
			nCol++;
		}
		pDest[nOut++] = *p++;
	}
	while (nCol < nColumns && nOut < nSize - 1)
	{
		pDest[nOut++] = ' ';
		nCol++;
	}
	pDest[nOut] = '\0';
}

static boolean HasExtension (const char *pName, const char *pExtensions)
{
	const char *pDot = 0;
	for (const char *p = pName; *p != '\0'; p++)
	{
		if (*p == '.')
		{
			pDot = p;
		}
	}
	if (pDot == 0)
	{
		return FALSE;
	}
	unsigned nLen = strlen (pDot);
	for (const char *p = pExtensions; *p != '\0'; )
	{
		const char *pNext = strchr (p + 1, '.');
		unsigned n = pNext != 0 ? (unsigned) (pNext - p) : strlen (p);
		if (n == nLen && strncasecmp (p, pDot, n) == 0)
		{
			return TRUE;
		}
		p += n;
	}
	return FALSE;
}

// the shell command lines of a mode (same as the menus), returns the count
static unsigned BuildCommands (unsigned nMode, CString *pCommands)
{
	CString Clock;
	if (s_bGPIO4)
	{
		Clock = " -c 1";
	}
	CString Gain;
	if (s_nGain > 0)
	{
		Gain.Format (" -g %d", s_nGain);
	}
	const char *pParam = s_Params[nMode];
	double fKHz = s_fMHz * 1000.0;
	unsigned n = 0;

	switch (nMode)
	{
	case ModeCarrier:
		pCommands[n++].Format ("rpitx -m VFO -f %.3f%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeChirp:
		pCommands[n++] = "pichirp chirp.ft 100000 5";
		pCommands[n++].Format ("rpitx -m RF -i chirp.ft -f %.3f -l%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeSpectrum:
	case ModeSSTV: {
		const char *pRGB = pParam;
		unsigned nLen = strlen (pParam);
		if (!(nLen > 4 && strcasecmp (pParam + nLen - 4, ".rgb") == 0))
		{
			pCommands[n++].Format ("bmp2rgb \"%s\" picture.rgb", pParam);
			pRGB = "picture.rgb";
		}
		if (nMode == ModeSpectrum)
		{
			pCommands[n++].Format ("pispectrum \"%s\" spectrum.ft 100000", pRGB);
			pCommands[n++].Format ("rpitx -m RF -i spectrum.ft -f %.3f -l%s", R (fKHz, 3),
					       (const char *) Clock);
		}
		else
		{
			pCommands[n++].Format ("pisstv \"%s\" sstv.ft", pRGB);
			pCommands[n++].Format ("rpitx -m RF -i sstv.ft -f %.3f%s", R (fKHz, 3), (const char *) Clock);
		}
		} break;

	case ModeWFM:
		pCommands[n++].Format ("piwfm \"%s\" wfm.ft", pParam);
		pCommands[n++].Format ("rpitx -m RF -i wfm.ft -f %.3f -l%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeNFM:
		pCommands[n++].Format ("pifm \"%s\" fm.ft", pParam);
		pCommands[n++].Format ("rpitx -m RF -i fm.ft -f %.3f -l%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeSSB:
		// pissb shifts its IQ by +1000 Hz, see pitx_iq_set_frequency
		pCommands[n++].Format ("pissb \"%s\" ssb.wav", pParam);
		pCommands[n++].Format ("rpitx -m IQ -i ssb.wav -f %.3f -l%s",
				       R (pitx_iq_set_frequency (fKHz * 1000.0, PISSB_SHIFT_HZ) / 1000.0, 3),
				       (const char *) Clock);
		break;

	case ModeAM:
		pCommands[n++].Format ("piam \"%s\" am.rfa", pParam);
		pCommands[n++].Format ("rpitx -m RFA -i am.rfa -f %.3f -l%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeFreeDV:
		pCommands[n++].Format ("pifreedv \"%s\" freedv.ft 400", pParam);
		pCommands[n++].Format ("rpitx -m RF -i freedv.ft -f %.3f%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModePocsag:
		pCommands[n++].Format ("pipocsag pocsag.ft \"%s\"", pParam);
		pCommands[n++].Format ("rpitx -m RF -i pocsag.ft -f %.3f%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeOpera:
		pCommands[n++].Format ("piopera \"%s\" 0.5 opera.rfa", pParam);
		pCommands[n++].Format ("rpitx -m RFA -i opera.rfa -f %.3f%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeRTTY:
		pCommands[n++].Format ("pirtty rtty.ft 1000 \"%s\"", pParam);
		pCommands[n++].Format ("rpitx -m RF -i rtty.ft -f %.3f%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeMorse:
		pCommands[n++].Format ("pimorse 10 \"%s\" morse.rfa", pParam);
		pCommands[n++].Format ("rpitx -m RFA -i morse.rfa -f %.3f%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeFSQ:
		pCommands[n++].Format ("pifsq \"%s\" fsq.ft", pParam);
		pCommands[n++].Format ("rpitx -m RF -i fsq.ft -f %.3f -l%s", R (fKHz, 3), (const char *) Clock);
		break;

	case ModeDCF77:
		pCommands[n++] = "pidcf77 dcf.rfa";
		pCommands[n++].Format ("rpitx -m RFA -i dcf.rfa -f 77.5 -l%s", (const char *) Clock);
		break;

	case ModeRTLRecord:
		// tuned 60 kHz (rate/4) above, as rtl2tx does, for rtl2iq ;
		// -n limite la capture a la duree choisie (coupure automatique)
		pCommands[n++].Format ("rtl_sdr -f %.0f -s 240000 -n %d%s record.iq",
				       R (s_fRxMHz * 1e6 + 60000, 0), 240000 * s_recSec,
				       (const char *) Gain);
		break;

	case ModeRTLPlay:
		pCommands[n++] = "rtl2iq record.iq record.wav";
		pCommands[n++].Format ("rpitx -m IQ -i record.wav -f %.3f%s",
				       R (pitx_iq_set_frequency (fKHz * 1000.0, RTLDSP_RELAY_SHIFT_HZ) / 1000.0, 3),
				       (const char *) Clock);
		break;

	case ModeRTLRelay:
		pCommands[n++].Format ("rtl2tx -r %.0f -f %.3f%s%s", R (s_fRxMHz * 1e6, 0), R (fKHz, 3),
				       (const char *) Gain, (const char *) Clock);
		break;

	case ModeRTLWide:
		pCommands[n++].Format ("rtl2tx -m wide -r %.0f -f %.3f%s%s", R (s_fRxMHz * 1e6, 0), R (fKHz, 3),
				       (const char *) Gain, (const char *) Clock);
		break;

	case ModeRTLFM2SSB:
		pCommands[n++].Format ("rtl2tx -m fm2ssb -r %.0f -f %.3f%s%s", R (s_fRxMHz * 1e6, 0), R (fKHz, 3),
				       (const char *) Gain, (const char *) Clock);
		break;

	case ModeRTLRadio:
		// gain automatique : le gain fixe des transpondeurs (35 dB) sature en FM
		pCommands[n++].Format ("rtlfm -f %.4f%s", R (s_fRadioMHz, 4), s_RadioModeOpt[s_nRadioMode]);
		break;

	case ModeRTL433:
		pCommands[n++].Format ("rtl433 -f %.4f", R (s_f433MHz, 4));
		break;

	case ModeRTL868:
		pCommands[n++].Format ("rtl868 -f %.4f", R (s_f868MHz, 4));
		break;

	case ModeScan:
	{
		double a = s_fScanMHz - 5.0, b = s_fScanMHz + 5.0;
		if (a < 0.5) a = 0.5;
		if (b > 1700.0) b = 1700.0;
		pCommands[n++].Format ("rtlscan -a %.3f -b %.3f", R (a, 3), R (b, 3));
		break;
	}

	case ModeWaterfall:
		pCommands[n++].Format ("rtlwf -f %.4f", R (s_fWfMHz, 4));
		break;
	}

	return n;
}

CTui::CTui (CShell *pShell)
:	m_pShell (pShell),
	m_nSelected (0),
	m_nFirstVisible (0),
	m_nLastEnter (0)
{
	m_Message[0] = '\0';

	if (!s_bParamsInit)
	{
		for (unsigned i = 0; i < ModeCount; i++)
		{
			strncpy (s_Params[i], s_Modes[i].pDefault, MAX_PARAM - 1);
			s_Params[i][MAX_PARAM - 1] = '\0';
		}
		s_bParamsInit = TRUE;
	}
}

void CTui::Write (const char *pString)
{
	BMConsoleWrite (pString);
}

void CTui::Printf (const char *pFormat, ...)
{
	va_list var;
	va_start (var, pFormat);
	CString String;
	String.FormatV (pFormat, var);
	va_end (var);
	Write (String);
}

void CTui::MoveTo (unsigned nRow, unsigned nColumn)
{
	Printf ("\x1b[%u;%uH", nRow, nColumn);
}

void CTui::Message (const char *pFormat, ...)
{
	va_list var;
	va_start (var, pFormat);
	CString String;
	String.FormatV (pFormat, var);
	va_end (var);
	strncpy (m_Message, String, sizeof m_Message - 1);
	m_Message[sizeof m_Message - 1] = '\0';
}

// -1 on timeout; keeps the USB plug and play running
int CTui::GetChar (unsigned nTimeoutUs)
{
	unsigned nStart = CTimer::GetClockTicks ();
	unsigned nLastUSB = nStart;
	for (;;)
	{
		int c = BMConsoleGetChar ();
		if (c >= 0)
		{
			return c;
		}
		unsigned nNow = CTimer::GetClockTicks ();
		if (nTimeoutUs != 0 && nNow - nStart >= nTimeoutUs)
		{
			return -1;
		}
		if (nNow - nLastUSB > USB_POLL_US)
		{
			CKernel::Get ()->UpdateUSB ();
			nLastUSB = nNow;
		}
	}
}

CTui::TKey CTui::ReadKey (char *pChar)
{
	for (;;)
	{
		int c = GetChar (0);
		*pChar = (char) c;

		switch (c)
		{
		case 0x03:			// Ctrl-C, or Esc key of the USB keyboard
			return KeyEscape;

		case '\r':
			m_nLastEnter = CTimer::GetClockTicks ();
			return KeyEnter;

		case '\n':			// "\r\n" from some terminals: one Enter
			if (CTimer::GetClockTicks () - m_nLastEnter < 50000)
			{
				continue;
			}
			return KeyEnter;

		case 0x08:
		case 0x7F:
			return KeyBackspace;

		case '\t':
			return KeyTab;

		case 0x1B: {
			int c2 = GetChar (ESC_TIMEOUT_US);
			if (c2 < 0)
			{
				return KeyEscape;	// lone Esc (serial terminal)
			}
			if (c2 != '[' && c2 != 'O')
			{
				continue;		// Alt+key: ignored
			}
			int c3 = GetChar (ESC_TIMEOUT_US);
			switch (c3)
			{
			case 'A':	return KeyUp;
			case 'B':	return KeyDown;
			case 'C':	return KeyRight;
			case 'D':	return KeyLeft;
			case 'H':	return KeyHome;
			case 'F':	return KeyEnd;
			default:
				break;
			}
			if (c3 >= '0' && c3 <= '9')
			{
				// "\x1b[5~": read up to the final character
				int nNumber = c3 - '0';
				int c4;
				while ((c4 = GetChar (ESC_TIMEOUT_US)) >= '0' && c4 <= '9')
				{
					nNumber = nNumber * 10 + c4 - '0';
				}
				if (c4 == '~')
				{
					switch (nNumber)
					{
					case 1: case 7:	return KeyHome;
					case 4: case 8:	return KeyEnd;
					case 5:		return KeyPageUp;
					case 6:		return KeyPageDown;
					}
				}
			}
			continue;			// unknown sequence (function keys...)
			}

		default:
			if ((u8) c >= 0x20)
			{
				return KeyChar;
			}
			continue;
		}
	}
}

void CTui::Draw (void)
{
	char Line[4 * COLUMNS];

	Write ("\x1b[?25l\x1b[0m\x1b[H\x1b[J");

	// title bar
	// titre : version du noyau (date, variante FIQ) et presence de la cle RTL-SDR
	CString Left, Right, Title;
	Left.Format (" rpitx bare metal   noyau du %s%s", BuildDate (),
#ifdef USE_USB_FIQ
		     " (FIQ)"
#else
		     ""
#endif
		     );
	Right = rtlsdr_get_device_count () > 0 ? "clé RTL-SDR : branchée " : "clé RTL-SDR : absente ";
	// largeur a l'ecran : les lettres accentuees prennent 2 octets en UTF-8
	unsigned nLeft = 0, nRight = 0;
	for (const char *p = Left; *p; p++) nLeft += (*p & 0xC0) != 0x80;
	for (const char *p = Right; *p; p++) nRight += (*p & 0xC0) != 0x80;
	Title = Left;
	for (unsigned i = nLeft + nRight; i < COLUMNS; i++)
	{
		Title.Append (" ");
	}
	Title.Append (Right);
	FitString (Line, sizeof Line, Title, COLUMNS);
	Printf ("\x1b[7m%s\x1b[0m", Line);

	// status
	double &fMHz = FreqOf (m_nSelected);
	int h = pitx_harmonic_for (fMHz * 1e6);
	MoveTo (2, 2);
	if (m_nSelected == ModeDCF77)
	{
		Write ("Fréquence : \x1b[1m77,5 kHz\x1b[0m (fixe pour DCF77)");
	}
	else
	{
		Printf ("Fréquence%s : \x1b[1m%.4f MHz\x1b[0m   pas : %s",
			(m_nSelected == ModeRTLRadio || m_nSelected == ModeRTL433
			 || m_nSelected == ModeRTL868 || m_nSelected == ModeScan || m_nSelected == ModeWaterfall) ? " d'écoute" : "",
			R (fMHz, 4), s_StepNames[s_nStep]);
	}
	MoveTo (2, 56);
	Printf ("PLLD : %d MHz", bm_plld_mhz);
	MoveTo (3, 2);
	if (m_nSelected == ModeDCF77)
	{
		Write ("Émission directe (fondamentale)");
	}
	else if (m_nSelected == ModeRTLRecord)
	{
		Printf ("Durée : \x1b[1m%d s\x1b[0m (touche d : 10/30/60) — coupure automatique", s_recSec);
	}
	else if (m_nSelected == ModeRTLRadio)
	{
		Printf ("Réception seulement — mode : \x1b[1m%s\x1b[0m (touche m)", s_RadioModeName[s_nRadioMode]);
	}
	else if (m_nSelected == ModeRTL433
		 || m_nSelected == ModeRTL868 || m_nSelected == ModeScan || m_nSelected == ModeWaterfall)
	{
		Write ("Réception seulement (clé RTL-SDR), aucune émission");
	}
	else if (h > 1)
	{
		Printf ("Harmonique %d de %.4f MHz : signal plus faible", h, R (fMHz / h, 4));
	}
	else
	{
		Write ("Émission directe (fondamentale)");
	}
	if (   m_nSelected != ModeDCF77 && m_nSelected != ModeRTLRadio
	    && m_nSelected != ModeRTL433 && m_nSelected != ModeRTL868
	    && m_nSelected != ModeScan && m_nSelected != ModeWaterfall
	    && (fMHz < RANGE_MIN_MHZ || fMHz > RANGE_MAX_MHZ))
	{
		Write ("  \x1b[1m[hors plage 130 kHz-750 MHz]\x1b[0m");
	}
	MoveTo (3, 56);
	Printf ("Sortie : GPIO %s", s_bGPIO4 ? "4 (br. 7)" : "18 (br. 12)");

	MoveTo (4, 1);
	for (unsigned i = 0; i < COLUMNS; i++)
	{
		Line[i] = '-';
	}
	Line[COLUMNS] = '\0';
	Write (Line);

	MoveTo (5, 2);
	Write ("\x1b[1mMode\x1b[0m");
	MoveTo (5, PANEL_COL);
	Write ("\x1b[1mDétails\x1b[0m");

	DrawList ();
	DrawDetails ();

	// footer
	MoveTo (FOOTER_ROW, 1);
	// arrows are not in the Latin-1 font: plain words instead
	FitString (Line, sizeof Line, " Haut/Bas : mode   Gauche/Droite : fréquence   +/- ou PgPréc/PgSuiv : pas",
		   COLUMNS - 1);
	Printf ("\x1b[7m%s\x1b[0m", Line);
	MoveTo (FOOTER_ROW + 1, 1);
	FitString (Line, sizeof Line, " Entrée : émettre  F : fréquence  E : paramètres  S : GPIO  "
		   "Q/Échap : quitter", COLUMNS - 1);
	Printf ("\x1b[7m%s\x1b[0m", Line);

	MoveTo (MESSAGE_ROW, 2);
	Write (m_Message);
}

void CTui::DrawList (void)
{
	if (m_nSelected < m_nFirstVisible)
	{
		m_nFirstVisible = m_nSelected;
	}
	if (m_nSelected >= m_nFirstVisible + LIST_ROWS)
	{
		m_nFirstVisible = m_nSelected - LIST_ROWS + 1;
	}

	char Line[4 * LIST_WIDTH];
	for (unsigned i = 0; i < LIST_ROWS; i++)
	{
		unsigned nMode = m_nFirstVisible + i;
		MoveTo (LIST_ROW + i, 1);
		if (nMode >= ModeCount)
		{
			FitString (Line, sizeof Line, "", LIST_WIDTH + 1);
			Write (Line);
			continue;
		}
		const char *pMore = " ";
		if (i == 0 && m_nFirstVisible > 0)
		{
			pMore = "^";
		}
		else if (i == LIST_ROWS - 1 && nMode < ModeCount - 1)
		{
			pMore = "v";
		}
		Write (pMore);
		FitString (Line, sizeof Line, s_Modes[nMode].pName, LIST_WIDTH - 2);
		if (nMode == m_nSelected)
		{
			Printf ("\x1b[7m %s \x1b[0m", Line);
		}
		else
		{
			Printf (" %s ", Line);
		}
	}
}

void CTui::DrawDetails (void)
{
	char Line[4 * COLUMNS];
	unsigned nRow = LIST_ROW;

	// clear the panel
	for (unsigned r = LIST_ROW; r < MESSAGE_ROW; r++)
	{
		MoveTo (r, PANEL_COL);
		Write ("\x1b[K");
	}

	MoveTo (nRow++, PANEL_COL);
	Printf ("\x1b[1m%s\x1b[0m", s_Modes[m_nSelected].pName);

	for (const char *p = s_Modes[m_nSelected].pDescription; *p != '\0'; )
	{
		FitString (Line, sizeof Line, p, PANEL_WIDTH - 1);
		MoveTo (nRow++, PANEL_COL);
		Write (Line);
		const char *pNext = strchr (p, '\n');
		if (pNext == 0)
		{
			break;
		}
		p = pNext + 1;
	}
	nRow++;

	CString String;
	switch (s_Modes[m_nSelected].Param)
	{
	case ParamNone:
		break;

	case ParamRTL:
		String.Format ("Réception : %.4f MHz", R (s_fRxMHz, 4));
		MoveTo (nRow++, PANEL_COL);
		Write (String);
		if (   m_nSelected == ModeRTLRelay || m_nSelected == ModeRTLWide
		    || m_nSelected == ModeRTLFM2SSB)
		{
			String.Format ("Émission  : %.4f MHz", R (s_fMHz, 4));
			MoveTo (nRow++, PANEL_COL);
			Write (String);
		}
		if (s_nGain > 0)
		{
			String.Format ("Gain clé : %d dB", s_nGain);
		}
		else
		{
			String = "Gain clé : automatique";
		}
		MoveTo (nRow++, PANEL_COL);
		Write (String);
		break;

	case ParamRTLPlay:
		MoveTo (nRow++, PANEL_COL);
		Write ("Fichier : record.iq (RTL Enregistrer)");
		break;

	default:
		String.Format ("%s : %s", s_Modes[m_nSelected].pParamLabel, s_Params[m_nSelected]);
		FitString (Line, sizeof Line, String, PANEL_WIDTH - 1);
		MoveTo (nRow++, PANEL_COL);
		Write (Line);
		break;
	}
	if (   s_Modes[m_nSelected].Param != ParamNone
	    && s_Modes[m_nSelected].Param != ParamRTLPlay)
	{
		MoveTo (nRow++, PANEL_COL);
		Write ("(touche E pour modifier)");
	}
	nRow++;

	MoveTo (nRow++, PANEL_COL);
	Write ("Commandes lancées par Entrée :");
	CString Commands[MAX_COMMANDS];
	unsigned nCommands = BuildCommands (m_nSelected, Commands);
	for (unsigned i = 0; i < nCommands && nRow < MESSAGE_ROW; i++)
	{
		// wrapped on two lines if needed
		const char *p = Commands[i];
		for (unsigned nPart = 0; nPart < 2 && *p != '\0' && nRow < MESSAGE_ROW; nPart++)
		{
			unsigned nWidth = PANEL_WIDTH - 3;
			unsigned nLen = strlen (p);
			if (nLen > nWidth)		// cut at the last space that fits
			{
				unsigned nCut = nWidth;
				while (nCut > nWidth / 2 && p[nCut] != ' ')
				{
					nCut--;
				}
				nLen = p[nCut] == ' ' ? nCut : nWidth;
			}
			char Part[COLUMNS];
			memcpy (Part, p, nLen);
			Part[nLen] = '\0';
			FitString (Line, sizeof Line, Part, nWidth);
			MoveTo (nRow++, PANEL_COL);
			Printf ("%s%s", nPart == 0 ? "+ " : "    ", Line);
			p += nLen;
			while (*p == ' ')
			{
				p++;
			}
		}
	}
}

// line editor on the message row; FALSE if cancelled
boolean CTui::EditLine (const char *pPrompt, char *pBuffer, unsigned nSize)
{
	unsigned nLen = strlen (pBuffer);
	unsigned nPromptWidth = DisplayWidth (pPrompt) + 3;
	if (nPromptWidth > COLUMNS / 2)
	{
		nPromptWidth = COLUMNS / 2;
	}
	unsigned nVisible = COLUMNS - 2 - nPromptWidth;

	// la valeur actuelle est pre-remplie (ex. "434.0000") : taper un premier
	// caractere la remplace (comme un champ selectionne), pour ne pas obtenir
	// "434.0000107,2". Effacer d'abord (retour arriere) edite la valeur telle quelle.
	boolean bFresh = TRUE;

	Write ("\x1b[?25h");
	for (;;)
	{
		// show the end of the text if it is too long
		const char *pShown = pBuffer;
		unsigned nWidth = DisplayWidth (pBuffer);
		while (nWidth >= nVisible)
		{
			pShown++;
			while (((u8) *pShown & 0xC0) == 0x80)
			{
				pShown++;
			}
			nWidth--;
		}
		MoveTo (MESSAGE_ROW, 1);
		Printf ("\x1b[K \x1b[1m%s :\x1b[0m %s", pPrompt, pShown);

		char ch;
		switch (ReadKey (&ch))
		{
		case KeyEnter:
			Write ("\x1b[?25l");
			return TRUE;

		case KeyEscape:
			Write ("\x1b[?25l");
			return FALSE;

		case KeyBackspace:
			bFresh = FALSE;
			// removes a whole UTF-8 character
			while (nLen > 0)
			{
				u8 c = (u8) pBuffer[--nLen];
				if ((c & 0xC0) != 0x80)
				{
					break;
				}
			}
			pBuffer[nLen] = '\0';
			break;

		case KeyChar:
			if (bFresh)			// premier caractere : remplace la valeur
			{
				nLen = 0;
				pBuffer[0] = '\0';
			}
			bFresh = FALSE;
			if (ch != '"' && nLen < nSize - 1)
			{
				pBuffer[nLen++] = ch;
				pBuffer[nLen] = '\0';
			}
			break;

		default:
			break;
		}
	}
}

// file picker in the right panel; FALSE if cancelled
boolean CTui::PickFile (const char *pExtensions, char *pBuffer, unsigned nSize)
{
	static const unsigned MaxFiles = 64;
	static char Files[MaxFiles][64];
	unsigned nFiles = 0;

	DIR Dir;
	FILINFO Info;
	if (f_opendir (&Dir, ".") == FR_OK)
	{
		while (   f_readdir (&Dir, &Info) == FR_OK && Info.fname[0] != '\0'
		       && nFiles < MaxFiles - 1)
		{
			if (   (Info.fattrib & (AM_DIR | AM_HID | AM_SYS)) == 0
			    && HasExtension (Info.fname, pExtensions)
			    && strlen (Info.fname) < sizeof Files[0])
			{
				strcpy (Files[nFiles++], Info.fname);
			}
		}
		f_closedir (&Dir);
	}
	strcpy (Files[nFiles++], "<saisir un nom>");

	unsigned nSelected = 0;
	for (unsigned i = 0; i < nFiles; i++)
	{
		if (strcmp (Files[i], pBuffer) == 0)
		{
			nSelected = i;
		}
	}

	const unsigned nRows = MESSAGE_ROW - LIST_ROW - 2;
	unsigned nFirst = 0;
	char Line[4 * COLUMNS];
	for (;;)
	{
		if (nSelected < nFirst)
		{
			nFirst = nSelected;
		}
		if (nSelected >= nFirst + nRows)
		{
			nFirst = nSelected - nRows + 1;
		}

		for (unsigned r = LIST_ROW; r < MESSAGE_ROW; r++)
		{
			MoveTo (r, PANEL_COL);
			Write ("\x1b[K");
		}
		MoveTo (LIST_ROW, PANEL_COL);
		Printf ("\x1b[1mFichiers %s de la carte SD\x1b[0m", pExtensions);
		for (unsigned i = 0; i < nRows && nFirst + i < nFiles; i++)
		{
			FitString (Line, sizeof Line, Files[nFirst + i], PANEL_WIDTH - 4);
			MoveTo (LIST_ROW + 2 + i, PANEL_COL);
			if (nFirst + i == nSelected)
			{
				Printf ("\x1b[7m %s \x1b[0m", Line);
			}
			else
			{
				Printf (" %s ", Line);
			}
		}
		MoveTo (MESSAGE_ROW, 1);
		Write ("\x1b[K Haut/Bas : choisir   Entrée : valider   Échap : annuler");

		char ch;
		switch (ReadKey (&ch))
		{
		case KeyUp:
			if (nSelected > 0)
			{
				nSelected--;
			}
			break;

		case KeyDown:
			if (nSelected < nFiles - 1)
			{
				nSelected++;
			}
			break;

		case KeyPageUp:
			nSelected = nSelected > nRows ? nSelected - nRows : 0;
			break;

		case KeyPageDown:
			nSelected = nSelected + nRows < nFiles ? nSelected + nRows : nFiles - 1;
			break;

		case KeyHome:
			nSelected = 0;
			break;

		case KeyEnd:
			nSelected = nFiles - 1;
			break;

		case KeyEnter:
			if (nSelected == nFiles - 1)		// type a name
			{
				char Name[MAX_PARAM];
				strncpy (Name, pBuffer, sizeof Name - 1);
				Name[sizeof Name - 1] = '\0';
				if (!EditLine ("Nom du fichier", Name, sizeof Name))
				{
					break;
				}
				strncpy (pBuffer, Name, nSize - 1);
			}
			else
			{
				strncpy (pBuffer, Files[nSelected], nSize - 1);
			}
			pBuffer[nSize - 1] = '\0';
			return TRUE;

		case KeyEscape:
			return FALSE;

		default:
			break;
		}
	}
}

static boolean ParseMHz (const char *pText, double *pMHz)
{
	// accepts a comma as decimal separator
	char Buffer[32];
	unsigned n = 0;
	for (const char *p = pText; *p != '\0' && n < sizeof Buffer - 1; p++)
	{
		Buffer[n++] = *p == ',' ? '.' : *p;
	}
	Buffer[n] = '\0';

	char *pEnd;
	double f = strtod (Buffer, &pEnd);
	while (*pEnd == ' ')
	{
		pEnd++;
	}
	if (pEnd == Buffer || *pEnd != '\0' || f < MIN_MHZ || f > MAX_MHZ)
	{
		return FALSE;
	}
	*pMHz = f;
	return TRUE;
}

boolean CTui::EditParameters (void)
{
	unsigned nMode = m_nSelected;
	char Buffer[MAX_PARAM];

	switch (s_Modes[nMode].Param)
	{
	case ParamNone:
	case ParamRTLPlay:
		Message ("Ce mode n'a pas de paramètre.");
		return FALSE;

	case ParamWav:
	case ParamPicture:
	case ParamRF:
		strcpy (Buffer, s_Params[nMode]);
		if (!PickFile (s_Modes[nMode].pExtensions, Buffer, sizeof Buffer))
		{
			return FALSE;
		}
		break;

	case ParamText:
		strcpy (Buffer, s_Params[nMode]);
		if (!EditLine (s_Modes[nMode].pParamLabel, Buffer, sizeof Buffer))
		{
			return FALSE;
		}
		break;

	case ParamRTL: {
		CString Default;
		Default.Format ("%.4f", R (s_fRxMHz, 4));
		strcpy (Buffer, Default);
		if (!EditLine ("Fréquence de réception en MHz", Buffer, 32))
		{
			return FALSE;
		}
		if (!ParseMHz (Buffer, &s_fRxMHz))
		{
			Message ("Fréquence invalide (de 0,005 à 1500 MHz).");
			return FALSE;
		}
		// transpondeurs : une 2e fréquence (émission). L'enregistrement et la
		// radio FM n'émettent pas : pas de 2e fréquence pour eux.
		if (   nMode == ModeRTLRelay || nMode == ModeRTLWide
		    || nMode == ModeRTLFM2SSB)
		{
			Default.Format ("%.4f", R (s_fMHz, 4));
			strcpy (Buffer, Default);
			if (!EditLine ("Fréquence d'émission en MHz", Buffer, 32))
			{
				return FALSE;
			}
			if (!ParseMHz (Buffer, &s_fMHz))
			{
				Message ("Fréquence invalide (de 0,005 à 1500 MHz).");
				return FALSE;
			}
		}
		Default.Format ("%d", s_nGain);
		strcpy (Buffer, Default);
		if (EditLine ("Gain de la clé en dB (0 = automatique, 1 à 50)", Buffer, 8))
		{
			int nGain = atoi (Buffer);
			s_nGain = nGain >= 0 && nGain <= 50 ? nGain : 0;
		}
		return TRUE;
		}
	}

	strcpy (s_Params[nMode], Buffer);
	return TRUE;
}

// Sauvegarde/restauration des reglages dans rpitx.cfg (racine de la SD).
// Format texte cle=valeur, une par ligne. Robuste : valeurs par defaut si le
// fichier manque ou est invalide (ParseMHz / bornes rejettent les valeurs folles).
void CTui::SaveSettings (void)
{
	FIL File;
	if (f_open (&File, "rpitx.cfg", FA_CREATE_ALWAYS | FA_WRITE) != FR_OK)
	{
		return;
	}
	CString s;
	s.Format ("mode=%u\nstep=%u\ngain=%d\nrec=%d\ngpio4=%d\nradiomode=%d\n"
		  "tx=%.4f\nrx=%.4f\nradio=%.4f\nf433=%.4f\nf868=%.4f\nscan=%.4f\nwf=%.4f\n",
		  m_nSelected, s_nStep, s_nGain, s_recSec, s_bGPIO4 ? 1 : 0, s_nRadioMode,
		  R (s_fMHz, 4), R (s_fRxMHz, 4), R (s_fRadioMHz, 4),
		  R (s_f433MHz, 4), R (s_f868MHz, 4), R (s_fScanMHz, 4), R (s_fWfMHz, 4));
	UINT bw;
	f_write (&File, (const char *) s, s.GetLength (), &bw);
	f_close (&File);
}

void CTui::LoadSettings (void)
{
	FIL File;
	if (f_open (&File, "rpitx.cfg", FA_READ) != FR_OK)
	{
		return;				// pas de fichier : valeurs par defaut
	}
	static char Buf[512];
	UINT br = 0;
	f_read (&File, Buf, sizeof Buf - 1, &br);
	f_close (&File);
	Buf[br] = '\0';

	char *p = Buf;
	while (*p != '\0')
	{
		char *key = p;
		char *e = p;
		while (*e != '\0' && *e != '\n')
		{
			e++;
		}
		char hadnl = *e;
		*e = '\0';
		char *v = key;
		while (*v != '\0' && *v != '=')
		{
			v++;
		}
		if (*v == '=')
		{
			*v++ = '\0';
			if (strcmp (key, "mode") == 0)
			{
				int x = atoi (v);
				if (x >= 0 && x < (int) ModeCount) m_nSelected = x;
			}
			else if (strcmp (key, "step") == 0)
			{
				int x = atoi (v);
				if (x >= 0 && x < (int) s_nSteps) s_nStep = x;
			}
			else if (strcmp (key, "gain") == 0)
			{
				int x = atoi (v);
				if (x >= 0 && x <= 50) s_nGain = x;
			}
			else if (strcmp (key, "rec") == 0)
			{
				int x = atoi (v);
				if (x == 10 || x == 30 || x == 60) s_recSec = x;
			}
			else if (strcmp (key, "gpio4") == 0) s_bGPIO4 = atoi (v) != 0;
			else if (strcmp (key, "radiomode") == 0)
			{
				int x = atoi (v);
				if (x >= 0 && x < RADIO_MODE_COUNT) s_nRadioMode = x;
			}
			else if (strcmp (key, "tx") == 0)    ParseMHz (v, &s_fMHz);
			else if (strcmp (key, "rx") == 0)    ParseMHz (v, &s_fRxMHz);
			else if (strcmp (key, "radio") == 0) ParseMHz (v, &s_fRadioMHz);
			else if (strcmp (key, "f433") == 0)  ParseMHz (v, &s_f433MHz);
			else if (strcmp (key, "f868") == 0)  ParseMHz (v, &s_f868MHz);
			else if (strcmp (key, "scan") == 0)  ParseMHz (v, &s_fScanMHz);
			else if (strcmp (key, "wf") == 0)    ParseMHz (v, &s_fWfMHz);
		}
		p = hadnl != '\0' ? e + 1 : e;
	}
}

void CTui::Launch (void)
{
	SaveSettings ();			// memorise les reglages au lancement d'un mode

	CString Commands[MAX_COMMANDS];
	unsigned nCommands = BuildCommands (m_nSelected, Commands);

	Write ("\x1b[0m\x1b[H\x1b[J\x1b[?25h");
	Printf ("\x1b[7m %s \x1b[0m  Échap, Ctrl-C ou bouton GPIO 17 (broches 11-9) pour arrêter\n\n",
		s_Modes[m_nSelected].pName);

	int nStatus = 0;
	for (unsigned i = 0; i < nCommands; i++)
	{
		bm_clear_stop ();
		nStatus = m_pShell->RunCommand ("%s", (const char *) Commands[i]);
		if (nStatus != 0 || bm_stop_requested ())
		{
			break;
		}
	}
	bm_clear_stop ();

	// discard the keys typed during the run
	while (BMConsoleGetChar () >= 0)
	{
		// nothing
	}

	if (nStatus != 0)
	{
		Printf ("\n\x1b[1mÉchec (code %d).\x1b[0m Une touche pour revenir au menu.", nStatus);
		char ch;
		ReadKey (&ch);
		Message ("Dernière commande en échec (code %d).", nStatus);
	}
	else
	{
		Message ("%s : terminé.", s_Modes[m_nSelected].pName);
	}
}

void CTui::Run (void)
{
	LoadSettings ();			// restaure les derniers reglages
	Draw ();

	for (;;)
	{
		char ch;
		TKey Key = ReadKey (&ch);
		m_Message[0] = '\0';

		if (Key == KeyChar)
		{
			switch (ch)
			{
			case 'q': case 'Q':	Key = KeyEscape;	break;
			case '+':		Key = KeyPageUp;	break;
			case '-':		Key = KeyPageDown;	break;
			case 'k': case 'K':	Key = KeyUp;		break;	// vi keys, for
			case 'j': case 'J':	Key = KeyDown;		break;	// keyboards without
			case 'h':		Key = KeyLeft;		break;	// arrows
			case 'l': case 'L':	Key = KeyRight;		break;
			default:		break;
			}
		}

		switch (Key)
		{
		case KeyEscape:
			Write ("\x1b[0m\x1b[H\x1b[J\x1b[?25h");
			return;

		case KeyUp:
			m_nSelected = m_nSelected > 0 ? m_nSelected - 1 : ModeCount - 1;
			break;

		case KeyDown:
			m_nSelected = m_nSelected < ModeCount - 1 ? m_nSelected + 1 : 0;
			break;

		case KeyHome:
			m_nSelected = 0;
			break;

		case KeyEnd:
			m_nSelected = ModeCount - 1;
			break;

		case KeyLeft:
		case KeyRight: {
			double &fMHz = FreqOf (m_nSelected);
			double f = fMHz + (Key == KeyRight ? 1 : -1) * s_Steps[s_nStep];
			f = (double) (long long) (f * 1e6 + (f > 0 ? 0.5 : -0.5)) / 1e6;	// no drift
			if (f < MIN_MHZ)
			{
				f = MIN_MHZ;
			}
			if (f > MAX_MHZ)
			{
				f = MAX_MHZ;
			}
			fMHz = f;
			} break;

		case KeyPageUp:
			if (s_nStep < s_nSteps - 1)
			{
				s_nStep++;
			}
			break;

		case KeyPageDown:
			if (s_nStep > 0)
			{
				s_nStep--;
			}
			break;

		case KeyTab:
			s_bGPIO4 = !s_bGPIO4;
			break;

		case KeyEnter:
			Launch ();
			break;

		case KeyChar:
			switch (ch)
			{
			case 'f': case 'F': {
				CString Default;
				double &fMHz = FreqOf (m_nSelected);
				Default.Format ("%.4f", R (fMHz, 4));
				char Buffer[32];
				strcpy (Buffer, Default);
				if (EditLine ((m_nSelected == ModeRTLRadio || m_nSelected == ModeRTL433
					       || m_nSelected == ModeRTL868 || m_nSelected == ModeScan || m_nSelected == ModeWaterfall)
							  ? "Fréquence d'écoute en MHz"
							  : "Fréquence d'émission en MHz",
					      Buffer, sizeof Buffer))
				{
					if (!ParseMHz (Buffer, &fMHz))
					{
						Message ("Fréquence invalide (de 0,005 à 1500 MHz).");
					}
				}
				} break;

			case 'e': case 'E':
				EditParameters ();
				break;

			case 's': case 'S':
				s_bGPIO4 = !s_bGPIO4;
				break;

			case 'd': case 'D':		// duree d'enregistrement : 10/30/60 s
				s_recSec = s_recSec == 10 ? 30 : s_recSec == 30 ? 60 : 10;
				break;

			case 'm': case 'M':		// RTL Radio : mode de demodulation FM/AM
				if (m_nSelected == ModeRTLRadio)
					s_nRadioMode = (s_nRadioMode + 1) % RADIO_MODE_COUNT;
				break;

			default:
				break;
			}
			break;

		default:
			break;
		}

		Draw ();
	}
}
