//
// shell.cpp - command line for rpitx-baremetal
//
// Copyright (C) 2026 rpitx-baremetal contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The command syntax is that of the Linux tools: "rpitx -m RF -i fm.ft -f
// 433900 -l" works as documented in the rpitx v1 README. "sudo" and a
// leading "./" are ignored so that the rpitx v1 test scripts run unchanged
// ("sh testfm.sh" or just "testfm.sh").
//
#include "shell.h"
#include "kernel.h"
#include "tui.h"
#include "../compat/bm_internal.h"
#include <bm_compat.h>
#include <circle/string.h>
#include <circle/util.h>
#include <circle/stdarg.h>
#include <circle/timer.h>
#include <circle/memory.h>
#include <circle/version.h>
#include <fatfs/ff.h>

// tools (C entry points)
extern "C"
{
	int rpitx_main (int argc, char **argv);
	int pifm_main (int argc, char **argv);
	int piam_main (int argc, char **argv);
	int pissb_main (int argc, char **argv);
	int pisstv_main (int argc, char **argv);
	int pifsq_main (int argc, char **argv);
	int pidcf77_main (int argc, char **argv);
	int rtl_sdr_main (int argc, char **argv);
	int rtl_test_main (int argc, char **argv);
	int rtl2tx_main (int argc, char **argv);
	int rtl2iq_main (int argc, char **argv);
	int rtlfm_main (int argc, char **argv);
	int rtl433_main (int argc, char **argv);
	int rtl868_main (int argc, char **argv);
	int rtlscan_main (int argc, char **argv);
	int rtlwf_main (int argc, char **argv);
	int txbench_main (int argc, char **argv);
	int bmp2rgb_main (int argc, char **argv);
	int pichirp_main (int argc, char **argv);
	int pispectrum_main (int argc, char **argv);
	int pipocsag_main (int argc, char **argv);
	int piopera_main (int argc, char **argv);
	int pirtty_main (int argc, char **argv);
	int pimorse_main (int argc, char **argv);
	int pifreedv_main (int argc, char **argv);
	int piwfm_main (int argc, char **argv);

	unsigned rtlsdr_get_device_count (void);
	const char *rtlsdr_get_device_name (unsigned index);
}

static const struct
{
	const char *pName;
	int (*pMain) (int, char **);
	const char *pHelp;
}
s_Tools[] =
{
	{"rpitx",	rpitx_main,	"transmit: -m IQ|IQFLOAT|RF|RFA|VFO -i file -f kHz [-l] [-p ppm] [-c 1]"},
	{"pifm",	pifm_main,	"in.wav (48 kHz) [out.ft]: narrow band FM for rpitx -m RF"},
	{"piam",	piam_main,	"in.wav (48 kHz) [out.rfa]: AM for rpitx -m RFA"},
	{"pissb",	pissb_main,	"in.wav (48 kHz mono) [out.wav]: SSB (USB) IQ for rpitx -m IQ"},
	{"pisstv",	pisstv_main,	"picture.rgb out.ft: SSTV Martin 1 for rpitx -m RF"},
	{"pifsq",	pifsq_main,	"\"text\" out.ft: FSQ for rpitx -m RF"},
	{"pidcf77",	pidcf77_main,	"out.rfa: DCF77 time frame for rpitx -m RFA"},
	{"bmp2rgb",	bmp2rgb_main,	"picture.bmp picture.rgb: prepare a picture for pisstv"},
	{"pichirp",	pichirp_main,	"out.ft [bw Hz] [period s]: moving carrier (v2 Chirp), rpitx -m RF -l"},
	{"pispectrum",	pispectrum_main, "picture.rgb out.ft [excursion Hz]: spectrum painting (v2), -m RF -l"},
	{"piwfm",	piwfm_main,	"in.wav [out.ft]: broadcast FM, mono, no RDS, for rpitx -m RF"},
	{"pipocsag",	pipocsag_main,	"out.ft \"addr:message\": pager (v2 pocsag), for rpitx -m RF"},
	{"piopera",	piopera_main,	"CALL mode out.rfa: Opera beacon (v2), for rpitx -m RFA"},
	{"pirtty",	pirtty_main,	"out.ft space_Hz \"text\": RTTY 45.45 bd (v2), for rpitx -m RF"},
	{"pimorse",	pimorse_main,	"rate \"text\" out.rfa: Morse CW (v2), for rpitx -m RFA"},
	{"pifreedv",	pifreedv_main,	"vco.rf out.ft [rate]: FreeDV VCO file (v2), for rpitx -m RF"},
	{"rtl_sdr",	rtl_sdr_main,	"-f Hz [-s rate] [-g dB] [-n samples] file: record RTL-SDR IQ"},
	{"rtl_test",	rtl_test_main,	"[-t] [-s rate] [-p]: test the RTL-SDR dongle"},
	{"rtl2tx",	rtl2tx_main,	"-r rx_Hz -f tx_kHz [...]: receive with RTL-SDR, retransmit"},
	{"rtlfm",	rtlfm_main,	"-f MHz [-o hdmi] [-m] [-g dB]: FM broadcast receiver (RTL-SDR), stereo"},
	{"rtl433",	rtl433_main,	"[-f MHz] [-R]: 433 MHz sensor decoder (temperature/humidity), RTL-SDR"},
	{"rtl868",	rtl868_main,	"[-f MHz] [-R]: 868 MHz FSK sensors (LaCrosse IT+), RTL-SDR"},
	{"rtlscan",	rtlscan_main,	"[-a MHz] [-b MHz] [-t dB]: band scanner / carrier detector, RTL-SDR"},
	{"rtlwf",	rtlwf_main,	"[-f MHz] [-g dB]: real-time waterfall + spectrum (HDMI), RTL-SDR"},
	{"rtl2iq",	rtl2iq_main,	"capture.bin out.wav: rtl_sdr capture -> IQ WAV for rpitx"},
	{"txbench",	txbench_main,	"[rate] [kHz]: CPU time of the transmit chain (no RF output)"},
	{0, 0, 0}
};

CShell::CShell (void)
:	m_nHistoryCount (0),
	m_bHistoryLoaded (FALSE),
	m_nLastStatus (0),
	m_bLineCancelled (FALSE)
{
}

// add a command to the in-memory ring (ignores an immediate repeat)
void CShell::PushHistory (const char *pLine)
{
	if (pLine[0] == '\0')
	{
		return;
	}
	if (   m_nHistoryCount > 0
	    && strcmp (m_History[(m_nHistoryCount - 1) % HistorySize], pLine) == 0)
	{
		return;				// same as the previous command
	}
	unsigned nSlot = m_nHistoryCount % HistorySize;
	strncpy (m_History[nSlot], pLine, MaxLine - 1);
	m_History[nSlot][MaxLine - 1] = '\0';
	m_nHistoryCount++;
	if (m_nHistoryCount >= 2 * HistorySize)		// keep the index small
	{
		m_nHistoryCount -= HistorySize;
	}
}

// read history.txt (one command per line) into the ring, then rewrite it
// trimmed to the last HistorySize commands so the file cannot grow forever
void CShell::LoadHistory (void)
{
	if (m_bHistoryLoaded)
	{
		return;
	}
	m_bHistoryLoaded = TRUE;

	FIL File;
	if (f_open (&File, "history.txt", FA_READ) == FR_OK)
	{
		char Line[MaxLine];
		unsigned nLen = 0;
		char ch;
		UINT nRead;
		while (f_read (&File, &ch, 1, &nRead) == FR_OK && nRead == 1)
		{
			if (ch == '\n' || ch == '\r')
			{
				Line[nLen] = '\0';
				if (nLen > 0)
				{
					PushHistory (Line);
				}
				nLen = 0;
			}
			else if (nLen < MaxLine - 1)
			{
				Line[nLen++] = ch;
			}
		}
		if (nLen > 0)
		{
			Line[nLen] = '\0';
			PushHistory (Line);
		}
		f_close (&File);
	}

	// rewrite the file with only the commands kept in the ring, oldest first
	if (f_open (&File, "history.txt", FA_CREATE_ALWAYS | FA_WRITE) == FR_OK)
	{
		unsigned nStart = m_nHistoryCount > HistorySize ? m_nHistoryCount - HistorySize : 0;
		for (unsigned i = nStart; i < m_nHistoryCount; i++)
		{
			const char *p = m_History[i % HistorySize];
			UINT nWritten;
			f_write (&File, p, strlen (p), &nWritten);
			f_write (&File, "\n", 1, &nWritten);
		}
		f_close (&File);
	}
}

// append one freshly typed command to history.txt
void CShell::SaveHistoryLine (const char *pLine)
{
	FIL File;
	if (f_open (&File, "history.txt", FA_OPEN_ALWAYS | FA_WRITE) != FR_OK)
	{
		return;
	}
	f_lseek (&File, f_size (&File));
	UINT nWritten;
	f_write (&File, pLine, strlen (pLine), &nWritten);
	f_write (&File, "\n", 1, &nWritten);
	f_close (&File);
}

void CShell::Print (const char *pFormat, ...)
{
	va_list var;
	va_start (var, pFormat);
	CString String;
	String.FormatV (pFormat, var);
	va_end (var);
	BMConsoleWrite (String);
}

void CShell::Run (void)
{
	// bannière couleur (pyfiglet « slant », caractères ASCII pour l'écran Latin-1)
	// L'écran d'accueil (image de l'antenne) est dessiné par CKernel::DrawSplash
	// avant d'arriver ici. Sur la console on met juste un titre coloré.
	Print ("\n\x1b[36m=== rpitx bare metal ===\x1b[0m\n");

	Print ("\nrpitx v1 bare metal for Raspberry Pi 1 (Circle %s)\n", CIRCLE_VERSION_STRING);
	Print ("Type \"help\" for the list of commands. Ctrl-C or Esc stops a transmission.\n");
	Print ("Transmitting requires a licence and a band-pass filter: you are responsible\n"
	       "for using rpitx legally.\n\n");

	FILINFO Info;
	if (f_stat ("autoexec.txt", &Info) == FR_OK)
	{
		Print ("Running autoexec.txt\n");
		if (!RunScript ("autoexec.txt", 0))
		{
			return;
		}
	}

	char Line[MaxLine];
	for (;;)
	{
		char Cwd[128];
		if (f_getcwd (Cwd, sizeof Cwd) != FR_OK)
		{
			strcpy (Cwd, "?");
		}
		Print ("rpitx:%s> ", Cwd);

		if (!ReadLine (Line, sizeof Line))
		{
			continue;
		}
		if (!Execute (Line, 0))
		{
			return;
		}
	}
}

// Line editor: printable characters, backspace, up / down history,
// Ctrl-C cancels the line. Keeps USB plug and play running while waiting.
// Redraws the tail of the line from the cursor, then puts the cursor back.
// Used after an insertion or a deletion inside the line.
static void RedrawTail (const char *pLine, unsigned nLen, unsigned nPos)
{
	BMConsoleWrite (pLine + nPos);			// tail from the cursor
	BMConsoleWrite (" ");				// erase the character left over
	for (unsigned i = nPos; i <= nLen; i++)		// back to the cursor (+1 for the space)
	{
		BMConsoleWrite ("\b");
	}
}

boolean CShell::ReadLine (char *pLine, unsigned nMax)
{
	LoadHistory ();

	unsigned nLen = 0;			// characters in the line
	unsigned nPos = 0;			// cursor position (0 .. nLen)
	int nHistory = m_nHistoryCount;
	unsigned nEscState = 0;			// 0 none, 1 after ESC, 2 after '['/'O'
	unsigned nEscNum = 0;			// number in sequences like "\x1b[3~"
	unsigned nLastUSB = CTimer::GetClockTicks ();

	pLine[0] = '\0';
	m_bLineCancelled = FALSE;

	for (;;)
	{
		int c = BMConsoleGetChar ();
		if (c < 0)
		{
			unsigned nNow = CTimer::GetClockTicks ();
			if (nNow - nLastUSB > 100000)
			{
				CKernel::Get ()->UpdateUSB ();
				nLastUSB = nNow;
			}
			continue;
		}

		if (nEscState == 1)
		{
			nEscState = (c == '[' || c == 'O') ? 2 : 0;
			nEscNum = 0;
			continue;
		}
		if (nEscState == 2)
		{
			if (c >= '0' && c <= '9')	// gather "3" of "\x1b[3~" etc.
			{
				nEscNum = nEscNum * 10 + (c - '0');
				continue;
			}
			nEscState = 0;

			// up / down : browse the history (replaces the whole line)
			if ((c == 'A' || c == 'B') && m_nHistoryCount > 0)
			{
				int nNew = nHistory + (c == 'A' ? -1 : 1);
				if (nNew < 0 || nNew > (int) m_nHistoryCount)
				{
					continue;
				}
				nHistory = nNew;
				while (nPos < nLen)	// cursor to the end first
				{
					char e[2] = {pLine[nPos++], '\0'};
					BMConsoleWrite (e);
				}
				while (nLen > 0)	// erase the line
				{
					BMConsoleWrite ("\b \b");
					nLen--;
				}
				if (nHistory < (int) m_nHistoryCount)
				{
					strncpy (pLine, m_History[nHistory % HistorySize], nMax - 1);
					pLine[nMax - 1] = '\0';
					nLen = strlen (pLine);
					BMConsoleWrite (pLine);
				}
				nPos = nLen;
				pLine[nLen] = '\0';
			}
			else if (c == 'D')		// left
			{
				if (nPos > 0)
				{
					nPos--;
					BMConsoleWrite ("\b");
				}
			}
			else if (c == 'C')		// right
			{
				if (nPos < nLen)
				{
					char e[2] = {pLine[nPos++], '\0'};
					BMConsoleWrite (e);
				}
			}
			else if (c == 'H' || (c == '~' && (nEscNum == 1 || nEscNum == 7)))	// Home
			{
				while (nPos > 0)
				{
					nPos--;
					BMConsoleWrite ("\b");
				}
			}
			else if (c == 'F' || (c == '~' && (nEscNum == 4 || nEscNum == 8)))	// End
			{
				while (nPos < nLen)
				{
					char e[2] = {pLine[nPos++], '\0'};
					BMConsoleWrite (e);
				}
			}
			else if (c == '~' && nEscNum == 3)	// Delete : remove char at cursor
			{
				if (nPos < nLen)
				{
					for (unsigned i = nPos; i < nLen; i++)
					{
						pLine[i] = pLine[i + 1];
					}
					nLen--;
					RedrawTail (pLine, nLen, nPos);
				}
			}
			continue;
		}

		switch (c)
		{
		case '\r':
		case '\n':
			while (nPos < nLen)		// cursor to the end before the newline
			{
				char e[2] = {pLine[nPos++], '\0'};
				BMConsoleWrite (e);
			}
			BMConsoleWrite ("\n");
			pLine[nLen] = '\0';
			if (nLen > 0)
			{
				PushHistory (pLine);
				SaveHistoryLine (pLine);
			}
			return nLen > 0;

		case 0x03:			// Ctrl-C
			BMConsoleWrite ("^C\n");
			m_bLineCancelled = TRUE;
			return FALSE;

		case 0x1B:
			nEscState = 1;
			break;

		case '\b':
		case 0x7F:			// backspace : remove the char before the cursor
			if (nPos > 0)
			{
				for (unsigned i = nPos - 1; i < nLen; i++)
				{
					pLine[i] = pLine[i + 1];
				}
				nLen--;
				nPos--;
				BMConsoleWrite ("\b");
				RedrawTail (pLine, nLen, nPos);
			}
			break;

		case 0x15:			// Ctrl-U : clear the whole line
			while (nPos < nLen)
			{
				char e[2] = {pLine[nPos++], '\0'};
				BMConsoleWrite (e);
			}
			while (nLen > 0)
			{
				BMConsoleWrite ("\b \b");
				nLen--;
			}
			nPos = 0;
			pLine[0] = '\0';
			break;

		default:			// printable : insert at the cursor
			if (c >= ' ' && c < 0x7F && nLen < nMax - 1)
			{
				for (unsigned i = nLen; i > nPos; i--)
				{
					pLine[i] = pLine[i - 1];
				}
				pLine[nPos] = (char) c;
				nLen++;
				pLine[nLen] = '\0';
				// echo from the cursor, then step back over the tail
				BMConsoleWrite (pLine + nPos);
				for (unsigned i = nPos + 1; i < nLen; i++)
				{
					BMConsoleWrite ("\b");
				}
				nPos++;
			}
			break;
		}
	}
}

// Splits on blanks, "double quotes" group words. Modifies pLine.
unsigned CShell::Tokenize (char *pLine, char **ppArgv)
{
	unsigned nArgs = 0;
	char *p = pLine;
	while (*p != '\0' && nArgs < MaxArgs - 1)
	{
		while (*p == ' ' || *p == '\t')
		{
			p++;
		}
		if (*p == '\0' || *p == '#')
		{
			break;
		}

		char *pOut = p;
		ppArgv[nArgs++] = pOut;
		boolean bQuoted = FALSE;
		while (*p != '\0' && (bQuoted || (*p != ' ' && *p != '\t')))
		{
			if (*p == '"')
			{
				bQuoted = !bQuoted;
				p++;
				continue;
			}
			*pOut++ = *p++;
		}
		if (*p != '\0')
		{
			p++;
		}
		*pOut = '\0';
	}
	ppArgv[nArgs] = 0;
	return nArgs;
}

boolean CShell::RunScript (const char *pFile, unsigned nDepth)
{
	if (nDepth > 4)
	{
		Print ("sh: scripts nested too deeply\n");
		return TRUE;
	}

	FIL File;
	if (f_open (&File, pFile, FA_READ | FA_OPEN_EXISTING) != FR_OK)
	{
		Print ("sh: cannot open %s\n", pFile);
		return TRUE;
	}

	char Line[MaxLine];
	while (f_gets (Line, sizeof Line, &File) != 0)
	{
		unsigned nLen = strlen (Line);
		while (nLen > 0 && (Line[nLen-1] == '\n' || Line[nLen-1] == '\r'))
		{
			Line[--nLen] = '\0';
		}
		unsigned nFirst = 0;
		while (Line[nFirst] == ' ' || Line[nFirst] == '\t')
		{
			nFirst++;
		}
		if (Line[nFirst] == '\0' || Line[nFirst] == '#')	// empty line or comment
		{
			continue;
		}

		Print ("+ %s\n", Line);
		if (!Execute (Line, nDepth + 1))
		{
			f_close (&File);
			return FALSE;
		}
		if (m_nLastStatus == 130 || bm_stop_requested ())	// stopped by Ctrl-C
		{
			Print ("sh: %s interrupted\n", pFile);
			break;
		}
	}

	f_close (&File);
	return TRUE;
}

static boolean EndsWith (const char *pString, const char *pSuffix)
{
	unsigned nLen = strlen (pString);
	unsigned nSuffix = strlen (pSuffix);
	return nLen >= nSuffix && strcmp (pString + nLen - nSuffix, pSuffix) == 0;
}

boolean CShell::Execute (char *pLine, unsigned nDepth)
{
	char *Argv[MaxArgs];
	unsigned nArgs = Tokenize (pLine, Argv);
	char **ppArgv = Argv;

	// compatibility with the rpitx v1 scripts
	while (nArgs > 0 && strcmp (ppArgv[0], "sudo") == 0)
	{
		ppArgv++;
		nArgs--;
	}
	if (nArgs == 0)
	{
		return TRUE;
	}
	if (strncmp (ppArgv[0], "./", 2) == 0)
	{
		ppArgv[0] += 2;
	}

	const char *pCmd = ppArgv[0];
	int argc = (int) nArgs;
	char **argv = ppArgv;

	if (strcmp (pCmd, "help") == 0 || strcmp (pCmd, "?") == 0)	CmdHelp ();
	else if (strcmp (pCmd, "ls") == 0 || strcmp (pCmd, "dir") == 0)	CmdLs (argc, argv);
	else if (strcmp (pCmd, "cd") == 0)	CmdCd (argc, argv);
	else if (strcmp (pCmd, "pwd") == 0)	CmdPwd ();
	else if (strcmp (pCmd, "rm") == 0)	CmdRm (argc, argv);
	else if (strcmp (pCmd, "mv") == 0)	CmdMv (argc, argv);
	else if (strcmp (pCmd, "cp") == 0)	CmdCp (argc, argv);
	else if (strcmp (pCmd, "mkdir") == 0)	CmdMkdir (argc, argv);
	else if (strcmp (pCmd, "cat") == 0)	CmdCat (argc, argv);
	else if (strcmp (pCmd, "df") == 0)	CmdDf ();
	else if (strcmp (pCmd, "set") == 0)	CmdSet (argc, argv);
	else if (strcmp (pCmd, "info") == 0)	CmdInfo ();
	else if (strcmp (pCmd, "easytest") == 0)	CmdEasytest ();
	else if (strcmp (pCmd, "rtlmenu") == 0)	CmdRtlmenu ();
	else if (strcmp (pCmd, "tui") == 0 || strcmp (pCmd, "menu") == 0)
	{
		CTui Tui (this);
		Tui.Run ();
	}
	else if (strcmp (pCmd, "clear") == 0)	BMConsoleWrite ("\x1b[H\x1b[J");
	else if (strcmp (pCmd, "echo") == 0)
	{
		for (int i = 1; i < argc; i++)
		{
			Print (i > 1 ? " %s" : "%s", argv[i]);
		}
		Print ("\n");
	}
	else if (strcmp (pCmd, "sleep") == 0)
	{
		unsigned nSeconds = argc > 1 ? atoi (argv[1]) : 1;
		uint64_t nEnd = bm_micros () + (uint64_t) nSeconds * 1000000;
		bm_clear_stop ();
		while (bm_micros () < nEnd && !bm_stop_requested ())
		{
			bm_poll ();
		}
	}
	else if (strcmp (pCmd, "timeout") == 0)
	{
		// timeout seconds command [args]: stops the command as Ctrl-C would
		// (transmission stopped even if the keyboard does not answer)
		if (argc < 3 || atoi (argv[1]) <= 0)
		{
			Print ("usage: timeout seconds command [arguments]\n");
			m_nLastStatus = 1;
			return TRUE;
		}
		char Line[MaxLine];
		unsigned nLen = 0;
		Line[0] = '\0';
		for (int i = 2; i < argc; i++)
		{
			boolean bQuote = strchr (argv[i], ' ') != 0;
			unsigned nArg = strlen (argv[i]);
			if (nLen + nArg + 4 >= sizeof Line)
			{
				break;
			}
			if (nLen > 0) Line[nLen++] = ' ';
			if (bQuote) Line[nLen++] = '"';
			memcpy (Line + nLen, argv[i], nArg);
			nLen += nArg;
			if (bQuote) Line[nLen++] = '"';
			Line[nLen] = '\0';
		}
		bm_clear_stop ();
		bm_set_deadline (bm_micros () + (uint64_t) atoi (argv[1]) * 1000000);
		boolean bResult = Execute (Line, nDepth);
		if (bm_timed_out () && bm_stop_requested ())
		{
			// expected end, not an interruption of the script (GNU status)
			bm_clear_stop ();
			m_nLastStatus = 124;
		}
		bm_set_deadline (0);
		return bResult;
	}
	else if (strcmp (pCmd, "usb") == 0)
	{
		CKernel::Get ()->UpdateUSB ();
		unsigned n = rtlsdr_get_device_count ();
		Print ("%u RTL-SDR dongle(s)\n", n);
		for (unsigned i = 0; i < n; i++)
		{
			Print ("  %u: %s\n", i, rtlsdr_get_device_name (i));
		}
	}
	else if (strcmp (pCmd, "reboot") == 0)
	{
		return FALSE;
	}
	else if (strcmp (pCmd, "sh") == 0)
	{
		if (argc < 2)
		{
			Print ("usage: sh script\n");
		}
		else
		{
			return RunScript (argv[1], nDepth);
		}
	}
	else if (EndsWith (pCmd, ".sh") || EndsWith (pCmd, ".txt"))
	{
		return RunScript (pCmd, nDepth);
	}
	else
	{
		unsigned i;
		for (i = 0; s_Tools[i].pName != 0; i++)
		{
			if (strcmp (pCmd, s_Tools[i].pName) == 0)
			{
				break;
			}
		}
		if (s_Tools[i].pName == 0)
		{
			Print ("%s: command not found (try \"help\")\n", pCmd);
			m_nLastStatus = 127;
			return TRUE;
		}

		CKernel::Get ()->UpdateUSB ();		// dongle plugged since the prompt
		uint64_t nStart = bm_micros ();
		m_nLastStatus = bm_run_tool (s_Tools[i].pMain, argc, argv);
		unsigned nMs = (unsigned) ((bm_micros () - nStart) / 1000);
		if (m_nLastStatus != 0)
		{
			Print ("[%s exited with status %d after %u.%03u s]\n", pCmd,
			       m_nLastStatus, nMs / 1000, nMs % 1000);
		}
	}

	return TRUE;
}

void CShell::CmdHelp (void)
{
	Print ("rpitx v1 tools (same options as on Linux, files on the SD card):\n");
	for (unsigned i = 0; s_Tools[i].pName != 0; i++)
	{
		Print ("  %-9s %s\n", s_Tools[i].pName, s_Tools[i].pHelp);
	}
	Print ("\nMenus: tui        full screen menu, arrow keys (alias: menu)\n"
	       "       easytest   demonstrations of all modes (like easytest.sh of rpitx v2)\n"
	       "       rtlmenu    RTL-SDR record / play / transponder / FM->SSB (rtlmenu.sh)\n");
	Print ("\nShell: ls cd pwd cat cp mv rm mkdir df echo sleep clear\n"
	       "       timeout s command       stops the command after s seconds (as Ctrl-C)\n"
	       "       sh script | script.sh   run commands from a file (autoexec.txt at boot)\n"
	       "       set [plld 500|1000]     PLLD frequency (500 by default, 1000 with dt-blob.bin)\n"
	       "       info  usb  reboot\n"
	       "Each tool prints its own help when started without arguments.\n"
	       "Ctrl-C (serial or keyboard) or Esc (keyboard) stops the running tool.\n");
}

void CShell::CmdLs (int argc, char **argv)
{
	const char *pPath = argc > 1 ? argv[1] : ".";
	DIR Dir;
	FILINFO Info;
	if (f_opendir (&Dir, pPath) != FR_OK)
	{
		Print ("ls: cannot open %s\n", pPath);
		return;
	}
	while (f_readdir (&Dir, &Info) == FR_OK && Info.fname[0] != '\0')
	{
		if (Info.fattrib & (AM_HID | AM_SYS))
		{
			continue;
		}
		if (Info.fattrib & AM_DIR)
		{
			Print ("%10s  %s/\n", "<dir>", Info.fname);
		}
		else
		{
			Print ("%10u  %s\n", (unsigned) Info.fsize, Info.fname);
		}
	}
	f_closedir (&Dir);
}

void CShell::CmdCd (int argc, char **argv)
{
	const char *pPath = argc > 1 ? argv[1] : "/";
	if (f_chdir (pPath) != FR_OK)
	{
		Print ("cd: %s: no such directory\n", pPath);
	}
}

void CShell::CmdPwd (void)
{
	char Cwd[128];
	if (f_getcwd (Cwd, sizeof Cwd) == FR_OK)
	{
		Print ("%s\n", Cwd);
	}
}

void CShell::CmdRm (int argc, char **argv)
{
	for (int i = 1; i < argc; i++)
	{
		if (f_unlink (argv[i]) != FR_OK)
		{
			Print ("rm: cannot remove %s\n", argv[i]);
		}
	}
}

void CShell::CmdMv (int argc, char **argv)
{
	if (argc != 3)
	{
		Print ("usage: mv from to\n");
		return;
	}
	f_unlink (argv[2]);
	if (f_rename (argv[1], argv[2]) != FR_OK)
	{
		Print ("mv: cannot rename %s\n", argv[1]);
	}
}

void CShell::CmdCp (int argc, char **argv)
{
	if (argc != 3)
	{
		Print ("usage: cp from to\n");
		return;
	}
	FIL In, Out;
	if (f_open (&In, argv[1], FA_READ | FA_OPEN_EXISTING) != FR_OK)
	{
		Print ("cp: cannot open %s\n", argv[1]);
		return;
	}
	if (f_open (&Out, argv[2], FA_WRITE | FA_CREATE_ALWAYS) != FR_OK)
	{
		Print ("cp: cannot create %s\n", argv[2]);
		f_close (&In);
		return;
	}
	static u8 Buffer[16384];
	UINT nRead, nWritten;
	while (f_read (&In, Buffer, sizeof Buffer, &nRead) == FR_OK && nRead > 0)
	{
		if (f_write (&Out, Buffer, nRead, &nWritten) != FR_OK || nWritten != nRead)
		{
			Print ("cp: write error\n");
			break;
		}
	}
	f_close (&Out);
	f_close (&In);
}

void CShell::CmdMkdir (int argc, char **argv)
{
	for (int i = 1; i < argc; i++)
	{
		if (f_mkdir (argv[i]) != FR_OK)
		{
			Print ("mkdir: cannot create %s\n", argv[i]);
		}
	}
}

void CShell::CmdCat (int argc, char **argv)
{
	for (int i = 1; i < argc; i++)
	{
		FIL File;
		if (f_open (&File, argv[i], FA_READ | FA_OPEN_EXISTING) != FR_OK)
		{
			Print ("cat: cannot open %s\n", argv[i]);
			continue;
		}
		char Line[MaxLine];
		while (f_gets (Line, sizeof Line, &File) != 0)
		{
			BMConsoleWrite (Line);
		}
		f_close (&File);
	}
}

void CShell::CmdDf (void)
{
	Print ("SD card: %u KB free\n", CKernel::Get ()->GetFreeKBytes ());
}

void CShell::CmdSet (int argc, char **argv)
{
	if (argc == 3 && strcmp (argv[1], "plld") == 0)
	{
		int nMHz = atoi (argv[2]);
		if (nMHz == 500 || nMHz == 1000)
		{
			bm_plld_mhz = nMHz;
		}
		else
		{
			Print ("set plld: 500 (no dt-blob.bin) or 1000 (rpitx dt-blob.bin)\n");
		}
	}
	else if (argc != 1)
	{
		Print ("usage: set [plld 500|1000]\n");
	}
	Print ("plld %d\n", bm_plld_mhz);
}

void CShell::CmdInfo (void)
{
	CMemorySystem *pMemory = CMemorySystem::Get ();
	Print ("Raspberry Pi 1 (BCM2835), Circle %s\n", CIRCLE_VERSION_STRING);
	Print ("Memory: %u MB, heap free: %u KB\n", pMemory->GetMemSize () / 0x100000,
	       (unsigned) (pMemory->GetHeapFreeSpace (HEAP_ANY) / 1024));
	Print ("PLLD: %d MHz\n", bm_plld_mhz);
	Print ("SD card: %u KB free\n", CKernel::Get ()->GetFreeKBytes ());
	Print ("RTL-SDR dongles: %u\n", rtlsdr_get_device_count ());
	Print ("Uptime: %u s\n", (unsigned) (bm_micros () / 1000000));
}
