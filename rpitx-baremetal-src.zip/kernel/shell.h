//
// shell.h - command line for rpitx-baremetal
//
// Copyright (C) 2026 rpitx-baremetal contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
#ifndef _shell_h
#define _shell_h

#include <circle/types.h>

class CShell
{
public:
	CShell (void);

	void Run (void);			// returns on "reboot"

	static const unsigned MaxLine = 256;
	static const unsigned MaxArgs = 32;
	static const unsigned HistorySize = 16;

	friend class CTui;			// tui.cpp uses RunCommand

private:
	boolean ReadLine (char *pLine, unsigned nMax);
	void PushHistory (const char *pLine);		// add to the in-memory ring
	void LoadHistory (void);			// read history.txt at boot
	void SaveHistoryLine (const char *pLine);	// append one command to history.txt
	boolean RunScript (const char *pFile, unsigned nDepth);
	boolean Execute (char *pLine, unsigned nDepth);	// FALSE: reboot requested
	unsigned Tokenize (char *pLine, char **ppArgv);

	void Print (const char *pFormat, ...);

	// built-in commands
	void CmdHelp (void);
	void CmdLs (int argc, char **argv);
	void CmdCd (int argc, char **argv);
	void CmdPwd (void);
	void CmdRm (int argc, char **argv);
	void CmdMv (int argc, char **argv);
	void CmdCp (int argc, char **argv);
	void CmdMkdir (int argc, char **argv);
	void CmdCat (int argc, char **argv);
	void CmdDf (void);
	void CmdSet (int argc, char **argv);
	void CmdInfo (void);

	// menus (menus.cpp): equivalents of easytest.sh and rtlmenu.sh (rpitx v2)
	void CmdEasytest (void);
	void CmdRtlmenu (void);
	boolean Ask (const char *pPrompt, const char *pDefault, char *pAnswer, unsigned nSize);
	boolean AskFrequency (const char *pPrompt, double *pMHz);
	int RunCommand (const char *pFormat, ...);

private:
	char m_History[HistorySize][MaxLine];
	unsigned m_nHistoryCount;
	boolean m_bHistoryLoaded;		// history.txt read once at boot
	int m_nLastStatus;
	boolean m_bLineCancelled;		// last ReadLine() ended with Ctrl-C
};

#endif
