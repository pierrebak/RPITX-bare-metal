//
// tui.h - full screen keyboard interface for rpitx-baremetal
//
// Copyright (C) 2026 rpitx-baremetal contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
#ifndef _tui_h
#define _tui_h

#include <circle/types.h>

class CShell;

class CTui
{
public:
	CTui (CShell *pShell);

	void Run (void);			// returns when the user quits

private:
	enum TKey
	{
		KeyNone,
		KeyUp,
		KeyDown,
		KeyLeft,
		KeyRight,
		KeyPageUp,
		KeyPageDown,
		KeyHome,
		KeyEnd,
		KeyEnter,
		KeyEscape,
		KeyBackspace,
		KeyTab,
		KeyChar
	};

	TKey ReadKey (char *pChar);
	int GetChar (unsigned nTimeoutUs);	// -1 on timeout

	void Draw (void);
	void DrawList (void);
	void DrawDetails (void);
	void Message (const char *pFormat, ...);

	boolean EditLine (const char *pPrompt, char *pBuffer, unsigned nSize);
	boolean PickFile (const char *pExtensions, char *pBuffer, unsigned nSize);
	boolean EditParameters (void);
	void Launch (void);
	void LoadSettings (void);		// rpitx.cfg : derniers reglages
	void SaveSettings (void);

	void Write (const char *pString);
	void Printf (const char *pFormat, ...);
	void MoveTo (unsigned nRow, unsigned nColumn);

private:
	CShell *m_pShell;
	unsigned m_nSelected;
	unsigned m_nFirstVisible;
	char m_Message[160];
	u64 m_nLastEnter;
};

#endif
