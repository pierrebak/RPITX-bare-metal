//
// kernel.cpp - rpitx-baremetal kernel (Circle)
//
// Copyright (C) 2026 rpitx-baremetal contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
#include "kernel.h"
#include "shell.h"
#include "../compat/bm_internal.h"
#include <bm_compat.h>
#include <circle/string.h>
#include <circle/util.h>
#include <circle/synchronize.h>
#include <circle/machineinfo.h>

#define DRIVE		"SD:"

LOGMODULE ("kernel");

CKernel *CKernel::s_pThis = 0;

CKernel::CKernel (void)
:	m_Screen (m_Options.GetWidth (), m_Options.GetHeight ()),
	m_Serial (&m_Interrupt),
	m_Timer (&m_Interrupt),
	// LogError : masque les avertissements (ex. "Transaction failed" USB,
	// des retries sans gravite affiches pendant la detection de la cle)
	m_Logger (LogError, &m_Timer),
	m_USBHCI (&m_Interrupt, &m_Timer, TRUE),	// plug and play
	m_EMMC (&m_Interrupt, &m_Timer, &m_ActLED),
	m_bScreenOK (FALSE),
	m_ucUTF8Lead (0),
	m_pKeyboard (0),
	m_nInputIn (0),
	m_nInputOut (0)
{
	s_pThis = this;
	m_ActLED.Blink (5);	// show we are alive
}

CKernel::~CKernel (void)
{
	s_pThis = 0;
}

boolean CKernel::Initialize (void)
{
	boolean bOK = m_Interrupt.Initialize ();	// first: the serial port uses IRQs

	m_bScreenOK = m_Screen.Initialize ();	// no HDMI display is not an error
	if (m_bScreenOK)
	{
		bm_fb_register (&m_Screen);	// dessin pixel pour les outils (waterfall)
	}

	if (bOK)
	{
		bOK = m_Serial.Initialize (115200);
	}

	if (bOK)
	{
		CDevice *pTarget = m_DeviceNameService.GetDevice (m_Options.GetLogDevice (), FALSE);
		if (pTarget == 0)
		{
			pTarget = m_bScreenOK ? (CDevice *) &m_Screen : (CDevice *) &m_Serial;
		}

		bOK = m_Logger.Initialize (pTarget);
	}

	if (bOK)
	{
		bOK = m_Timer.Initialize ();
	}

	if (bOK)
	{
		bOK = m_USBHCI.Initialize ();
	}

	if (bOK)
	{
		bOK = m_EMMC.Initialize ();
	}

	BMSetConsole (ConsoleWriteStub, ConsoleGetCharStub);
	BMSaveProgramState ();		// before any program runs

	return bOK;
}

TShutdownMode CKernel::Run (void)
{
	LOGNOTE ("Compile time: " __DATE__ " " __TIME__);

	FRESULT Result = f_mount (&m_FileSystem, DRIVE, 1);
	if (Result != FR_OK)
	{
		LOGPANIC ("Cannot mount the SD card FAT partition (%d)", (int) Result);
	}
	f_chdrive (DRIVE);
	f_chdir (DRIVE "/");

	UpdateUSB ();
	bm_add_poll_hook (USBPollHook, 0);	// le clavier USB est servi depuis bm_poll
						// (donc dans tous les outils, waterfall inclus)

	DrawSplash ();			// logo.bmp (antenne) en écran d'accueil

	CShell Shell;
	Shell.Run ();			// returns only for a reboot

	f_mount (0, DRIVE, 0);

	return ShutdownReboot;
}

// Affiche logo.bmp (BMP 24 bits non compressé) centré, puis attend ~1,8 s
// (une touche passe). L'image est dessinée pixel par pixel dans le framebuffer.
void CKernel::DrawSplash (void)
{
	if (!m_bScreenOK)
	{
		return;				// pas d'écran HDMI : rien à dessiner
	}

	FIL File;
	if (f_open (&File, "logo.bmp", FA_READ) != FR_OK)
	{
		return;				// pas de logo : on continue normalement
	}

	u8 Header[54];
	UINT nRead;
	if (   f_read (&File, Header, 54, &nRead) != FR_OK || nRead != 54
	    || Header[0] != 'B' || Header[1] != 'M')
	{
		f_close (&File);
		return;
	}
	u32 nDataOff = Header[10] | (Header[11] << 8) | (Header[12] << 16) | (Header[13] << 24);
	int nW = Header[18] | (Header[19] << 8) | (Header[20] << 16) | (Header[21] << 24);
	int nH = Header[22] | (Header[23] << 8) | (Header[24] << 16) | (Header[25] << 24);
	unsigned nBpp = Header[28] | (Header[29] << 8);
	if (nBpp != 24 || nW <= 0 || nH <= 0 || nW > 1024 || nH > 768)
	{
		f_close (&File);
		return;
	}

	unsigned nScreenW = m_Screen.GetWidth ();
	unsigned nScreenH = m_Screen.GetHeight ();

	// efface le framebuffer en noir (SetPixel direct : l'effacement par
	// séquence ANSI ne nettoie pas les pixels dessinés hors de la console)
	for (unsigned y = 0; y < nScreenH; y++)
	{
		for (unsigned x = 0; x < nScreenW; x++)
		{
			m_Screen.SetPixel (x, y, COLOR16 (0, 0, 0));
		}
	}

	int nOx = ((int) nScreenW - nW) / 2;
	int nOy = ((int) nScreenH - nH) / 2;
	if (nOx < 0) nOx = 0;
	if (nOy < 0) nOy = 0;

	unsigned nRowSize = (nW * 3 + 3) & ~3u;		// lignes BMP alignées sur 4 octets
	static u8 Row[1024 * 3 + 4];
	f_lseek (&File, nDataOff);

	for (int y = nH - 1; y >= 0; y--)		// BMP : stocké de bas en haut
	{
		if (f_read (&File, Row, nRowSize, &nRead) != FR_OK || nRead != nRowSize)
		{
			break;
		}
		int nPy = nOy + y;
		if (nPy < 0 || nPy >= (int) nScreenH)
		{
			continue;
		}
		for (int x = 0; x < nW; x++)
		{
			int nPx = nOx + x;
			if (nPx < 0 || nPx >= (int) nScreenW)
			{
				continue;
			}
			u8 b = Row[x * 3], g = Row[x * 3 + 1], r = Row[x * 3 + 2];
			m_Screen.SetPixel (nPx, nPy, COLOR16 (r >> 3, g >> 2, b >> 3));
		}
	}
	f_close (&File);

	for (unsigned t = 0; t < 1800; t += 20)		// ~1,8 s, une touche passe
	{
		if (ConsoleGetChar () >= 0)
		{
			break;
		}
		UpdateUSB ();
		m_Timer.MsDelay (20);
	}

	// efface l'image en noir, puis ramène le curseur de la console en haut
	for (unsigned y = 0; y < nScreenH; y++)
	{
		for (unsigned x = 0; x < nScreenW; x++)
		{
			m_Screen.SetPixel (x, y, COLOR16 (0, 0, 0));
		}
	}
	m_Screen.Write ("\x1b[H", 3);			// curseur en haut à gauche
}

void CKernel::USBPollHook (void *pContext)
{
	(void) pContext;
	// appele depuis bm_poll() ; on limite la cadence (plug-and-play + LEDs
	// sont inutiles a pleine vitesse) pour ne pas alourdir les boucles serrees
	static uint64_t last = 0;
	uint64_t now = bm_micros ();
	if (now - last < 15000)			// ~65 Hz max
	{
		return;
	}
	last = now;
	s_pThis->UpdateUSB ();
}

void CKernel::UpdateUSB (void)
{
	if (m_USBHCI.UpdatePlugAndPlay () && m_pKeyboard == 0)
	{
		m_pKeyboard = (CUSBKeyboardDevice *) m_DeviceNameService.GetDevice ("ukbd1", FALSE);
		if (m_pKeyboard != 0)
		{
			m_pKeyboard->RegisterRemovedHandler (KeyboardRemovedHandler);
			m_pKeyboard->RegisterKeyPressedHandler (KeyPressedHandler);
		}
	}

	if (m_pKeyboard != 0)
	{
		m_pKeyboard->UpdateLEDs ();
	}
}

unsigned CKernel::GetFreeKBytes (void)
{
	DWORD nFreeClusters;
	FATFS *pFS;
	if (f_getfree (DRIVE, &nFreeClusters, &pFS) != FR_OK)
	{
		return 0;
	}
	return (unsigned) ((u64) nFreeClusters * pFS->csize * 512 / 1024);
}

void CKernel::ConsoleWrite (const char *pBuffer, unsigned nLength)
{
	// The screen font is Latin-1: UTF-8 text (accents) is converted for it,
	// the serial terminal gets UTF-8 as is. The screen needs "\n", the serial
	// terminal wants "\r\n".
	if (m_bScreenOK)
	{
		char Latin1[128];
		unsigned nOut = 0;
		for (unsigned i = 0; i < nLength; i++)
		{
			if (nOut >= sizeof Latin1 - 2)		// room for 2 characters
			{
				m_Screen.Write (Latin1, nOut);
				nOut = 0;
			}

			u8 c = (u8) pBuffer[i];
			if (m_ucUTF8Lead != 0)			// a 2 byte sequence is pending
			{
				u8 ucLead = m_ucUTF8Lead;
				m_ucUTF8Lead = 0;
				if ((c & 0xC0) == 0x80)		// its second byte
				{
					Latin1[nOut++] = ucLead <= 0xC3
							 ? (char) (((ucLead & 0x03) << 6) | (c & 0x3F))
							 : '?';	// beyond Latin-1
					continue;
				}
				Latin1[nOut++] = '?';		// truncated sequence, c follows
			}

			if ((c & 0xE0) == 0xC0)			// 2 byte lead: wait for the next
			{
				m_ucUTF8Lead = c;
			}
			else if (c >= 0x80)			// longer sequences: not in Latin-1
			{
				if ((c & 0xC0) != 0x80)
				{
					Latin1[nOut++] = '?';
				}
			}
			else
			{
				Latin1[nOut++] = (char) c;
			}

		}
		if (nOut > 0)
		{
			m_Screen.Write (Latin1, nOut);
		}
	}

	unsigned nStart = 0;
	for (unsigned i = 0; i < nLength; i++)
	{
		if (pBuffer[i] == '\n')
		{
			m_Serial.Write (pBuffer + nStart, i - nStart);
			m_Serial.Write ("\r\n", 2);
			nStart = i + 1;
		}
	}
	if (nStart < nLength)
	{
		m_Serial.Write (pBuffer + nStart, nLength - nStart);
	}
}

void CKernel::PutInput (char ch)
{
	EnterCritical ();
	if (m_nInputIn - m_nInputOut < InputSize)
	{
		m_InputBuffer[m_nInputIn & (InputSize-1)] = ch;
		m_nInputIn++;
	}
	LeaveCritical ();
}

int CKernel::ConsoleGetChar (void)
{
	char ch;
	if (m_Serial.Read (&ch, 1) == 1)
	{
		return (unsigned char) ch;
	}

	int nResult = -1;
	EnterCritical ();
	if (m_nInputOut != m_nInputIn)
	{
		nResult = (unsigned char) m_InputBuffer[m_nInputOut & (InputSize-1)];
		m_nInputOut++;
	}
	LeaveCritical ();

	return nResult;
}

void CKernel::ConsoleWriteStub (const char *pBuffer, unsigned nLength)
{
	s_pThis->ConsoleWrite (pBuffer, nLength);
}

int CKernel::ConsoleGetCharStub (void)
{
	return s_pThis->ConsoleGetChar ();
}

void CKernel::KeyPressedHandler (const char *pString)
{
	// interrupt context
	if (strcmp (pString, "\x1b") == 0)
	{
		s_pThis->PutInput ('\x03');	// a lone Esc key stops like Ctrl-C
		return;
	}
	while (*pString != '\0')
	{
		s_pThis->PutInput (*pString++);
	}
}

void CKernel::KeyboardRemovedHandler (CDevice *pDevice, void *pContext)
{
	s_pThis->m_pKeyboard = 0;
}
