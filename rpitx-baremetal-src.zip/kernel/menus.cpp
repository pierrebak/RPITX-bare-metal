//
// menus.cpp - "easytest" and "rtlmenu", the menus of rpitx v2 (easytest.sh,
// rtlmenu.sh) for the bare metal rpitx v1
//
// Copyright (C) 2026 rpitx-baremetal contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The v2 scripts use whiptail dialogs and start each demo in the background
// until "OK" is pressed. Here the menu is text, each demo runs in the
// foreground and Ctrl-C (or Esc) stops it and comes back to the menu. Every
// command is printed before it runs, so it can be reused at the prompt or in
// autoexec.txt.
//
#include "shell.h"
#include "../compat/bm_internal.h"
#include <bm_compat.h>
#include <circle/string.h>
#include <circle/util.h>
#include <circle/stdarg.h>

extern "C"
{
	int pitx_harmonic_for (double Frequency);
	double pitx_iq_set_frequency (double WantedHz, double ShiftHz);
	double strtod (const char *s, char **end);
}

// frequency of the IQ samples relative to the wanted signal (see RpiTx.c)
#define PISSB_SHIFT_HZ		1000.0		// pissb: ssb_init (1000)
#define RTLDSP_RELAY_SHIFT_HZ	12000.0		// tools/rtldsp.h

// Circle's CString truncates %f instead of rounding (434.2 with "%.4f" gives
// "434.1999"): add half a unit of the last printed digit
static double R (double f, unsigned nDecimals)
{
	double fHalf = 0.5;
	while (nDecimals-- > 0)
	{
		fHalf /= 10.0;
	}
	return f >= 0 ? f + fHalf : f - fHalf;
}

boolean CShell::Ask (const char *pPrompt, const char *pDefault, char *pAnswer, unsigned nSize)
{
	if (pDefault[0] != '\0')
	{
		Print ("%s [%s]: ", pPrompt, pDefault);
	}
	else
	{
		Print ("%s: ", pPrompt);
	}
	char Line[MaxLine];
	if (!ReadLine (Line, sizeof Line))
	{
		if (m_bLineCancelled)
		{
			return FALSE;
		}
		Line[0] = '\0';
	}

	// remove the double quotes: the answer is put between quotes on a command line
	const char *pSource = Line[0] != '\0' ? Line : pDefault;
	unsigned n = 0;
	for (const char *p = pSource; *p != '\0' && n < nSize - 1; p++)
	{
		if (*p != '"')
		{
			pAnswer[n++] = *p;
		}
	}
	pAnswer[n] = '\0';

	return TRUE;
}

boolean CShell::AskFrequency (const char *pPrompt, double *pMHz)
{
	for (;;)
	{
		CString Default;
		Default.Format ("%.4f", R (*pMHz, 4));
		char Answer[32];
		if (!Ask (pPrompt, Default, Answer, sizeof Answer))
		{
			return FALSE;
		}
		char *pEnd;
		double f = strtod (Answer, &pEnd);
		if (pEnd != Answer && f >= 0.005 && f <= 1500.0)
		{
			*pMHz = f;
			return TRUE;
		}
		Print ("Frequency in MHz, e.g. 434.0 or 7.040\n");
	}
}

int CShell::RunCommand (const char *pFormat, ...)
{
	va_list var;
	va_start (var, pFormat);
	CString Command;
	Command.FormatV (pFormat, var);
	va_end (var);

	char Line[MaxLine];
	strncpy (Line, Command, sizeof Line - 1);
	Line[sizeof Line - 1] = '\0';

	Print ("+ %s\n", Line);
	m_nLastStatus = 0;
	Execute (Line, 1);
	return m_nLastStatus;
}

// prepares a 320 pixels wide RGB file from a BMP (or uses an .rgb as is)
static const char *PictureToRGB (CShell *pShell, const char *pFile, int (CShell::*pRun) (const char *, ...))
{
	unsigned nLen = strlen (pFile);
	if (nLen > 4 && strcasecmp (pFile + nLen - 4, ".rgb") == 0)
	{
		return pFile;
	}
	if ((pShell->*pRun) ("bmp2rgb \"%s\" picture.rgb", pFile) != 0)
	{
		return 0;
	}
	return "picture.rgb";
}

void CShell::CmdEasytest (void)
{
	static double s_fMHz = 434.0;		// kept for the session, like LAST_ITEM

	Print ("\nrpitx easytest (rpitx v2 menu, on the bare metal rpitx v1 engine)\n"
	       "Transmitting requires a licence and a band-pass filter on GPIO 18.\n");
	if (!AskFrequency ("Output frequency in MHz", &s_fMHz))
	{
		return;
	}

	for (;;)
	{
		double fKHz = s_fMHz * 1000.0;
		int h = pitx_harmonic_for (fKHz * 1000.0);

		Print ("\n=== Rpitx on %.4f MHz ===  (range 130 kHz - 750 MHz", R (s_fMHz, 4));
		if (h > 1)
		{
			Print (", here harmonic %d of %.3f MHz: weaker", h, R (s_fMHz / h, 3));
		}
		Print (")\n"
		       "  F  Set frequency\n"
		       "  0  Tune        Carrier\n"
		       "  1  Chirp       Moving carrier\n"
		       "  2  Spectrum    Spectrum painting (BMP picture)\n"
		       "  3  RfMyFace    Snap with Raspicam and RF paint: not available\n"
		       "  4  WFM         Broadcast FM, mono (v2 FmRds without RDS)\n"
		       "  5  NFM         Narrow band FM\n"
		       "  6  SSB         Upper side band modulation\n"
		       "  7  AM          Amplitude modulation (poor quality)\n"
		       "  8  FreeDV      Digital voice mode 800XA (pre-encoded file)\n"
		       "  9  SSTV        Martin 1 picture\n"
		       " 10  Pocsag      Pager message\n"
		       " 11  Opera       Like morse but needs the Opera decoder\n"
		       " 12  RTTY        Radioteletype\n"
		       " 13  Morse       CW (rpitx v2 morse)\n"
		       " 14  FSQ         FSQ message (rpitx v1)\n"
		       "  Q  Quit\n");

		char Choice[16];
		if (!Ask ("Choose your test (Q to quit)", "", Choice, sizeof Choice))
		{
			return;
		}
		if (Choice[0] == '\0')			// Enter alone: show the menu again
		{
			continue;
		}
		if (Choice[0] == 'q' || Choice[0] == 'Q')
		{
			return;
		}
		if (Choice[0] == 'f' || Choice[0] == 'F')
		{
			AskFrequency ("Output frequency in MHz", &s_fMHz);
			continue;
		}

		char *pEnd;
		int nItem = (int) strtoul (Choice, &pEnd, 10);
		if (pEnd == Choice || *pEnd != '\0' || nItem > 14)
		{
			Print ("Unknown choice\n");
			continue;
		}

		char File[128];
		char Text[160];
		bm_clear_stop ();

		switch (nItem)
		{
		case 0:
			Print ("Transmitting a carrier, Ctrl-C or Esc to stop\n");
			RunCommand ("rpitx -m VFO -f %.3f", R (fKHz, 3));
			break;

		case 1:
			if (RunCommand ("pichirp chirp.ft 100000 5") == 0)
			{
				RunCommand ("rpitx -m RF -i chirp.ft -f %.3f -l", R (fKHz, 3));
			}
			break;

		case 2:
			if (Ask ("Picture (BMP, or 320 pixels wide .rgb)", "picture.bmp", File, sizeof File))
			{
				const char *pRGB = PictureToRGB (this, File, &CShell::RunCommand);
				if (pRGB != 0 && RunCommand ("pispectrum \"%s\" spectrum.ft 100000", pRGB) == 0)
				{
					RunCommand ("rpitx -m RF -i spectrum.ft -f %.3f -l", R (fKHz, 3));
				}
			}
			break;

		case 3:
			Print ("Not available: needs the Raspberry Pi camera, which has no driver here.\n"
			       "Use 2 Spectrum with a BMP picture instead.\n");
			break;

		case 4:
			if (   Ask ("WAV file (48 kHz)", "sampleaudio.wav", File, sizeof File)
			    && RunCommand ("piwfm \"%s\" wfm.ft", File) == 0)
			{
				RunCommand ("rpitx -m RF -i wfm.ft -f %.3f -l", R (fKHz, 3));
			}
			break;

		case 5:
			if (   Ask ("WAV file (16 bit, 48 kHz, mono)", "sampleaudio.wav", File, sizeof File)
			    && RunCommand ("pifm \"%s\" fm.ft", File) == 0)
			{
				RunCommand ("rpitx -m RF -i fm.ft -f %.3f -l", R (fKHz, 3));
			}
			break;

		case 6:
			if (   Ask ("WAV file (16 bit, 48 kHz, mono)", "sampleaudio.wav", File, sizeof File)
			    && RunCommand ("pissb \"%s\" ssb.wav", File) == 0)
			{
				// pissb shifts its IQ by +1000 Hz, rpitx subtracts 1000 Hz (RpiTx.c)
				double fSet = pitx_iq_set_frequency (fKHz * 1000.0, PISSB_SHIFT_HZ) / 1000.0;
				RunCommand ("rpitx -m IQ -i ssb.wav -f %.3f -l", R (fSet, 3));
			}
			break;

		case 7:
			if (   Ask ("WAV file (16 bit, 48 kHz, mono)", "sampleaudio.wav", File, sizeof File)
			    && RunCommand ("piam \"%s\" am.rfa", File) == 0)
			{
				RunCommand ("rpitx -m RFA -i am.rfa -f %.3f -l", R (fKHz, 3));
			}
			break;

		case 8:
			if (   Ask ("FreeDV .rf file", "freedv.rf", File, sizeof File)
			    && RunCommand ("pifreedv \"%s\" freedv.ft 400", File) == 0)
			{
				RunCommand ("rpitx -m RF -i freedv.ft -f %.3f", R (fKHz, 3));
			}
			break;

		case 9:
			if (Ask ("Picture (BMP, or 320x256 .rgb)", "picture.bmp", File, sizeof File))
			{
				const char *pRGB = PictureToRGB (this, File, &CShell::RunCommand);
				if (pRGB != 0 && RunCommand ("pisstv \"%s\" sstv.ft", pRGB) == 0)
				{
					RunCommand ("rpitx -m RF -i sstv.ft -f %.3f", R (fKHz, 3));
				}
			}
			break;

		case 10:
			if (   Ask ("POCSAG message (ADDR:MESSAGE, \\n between messages)",
				    "1:YOURCALL\\n2: Hello world", Text, sizeof Text)
			    && RunCommand ("pipocsag pocsag.ft \"%s\"", Text) == 0)
			{
				RunCommand ("rpitx -m RF -i pocsag.ft -f %.3f", R (fKHz, 3));
			}
			break;

		case 11:
			if (   Ask ("Callsign", "F5OEO", Text, sizeof Text)
			    && RunCommand ("piopera \"%s\" 0.5 opera.rfa", Text) == 0)
			{
				RunCommand ("rpitx -m RFA -i opera.rfa -f %.3f", R (fKHz, 3));
			}
			break;

		case 12:
			if (   Ask ("RTTY message", "HELLO WORLD FROM RPITX", Text, sizeof Text)
			    && RunCommand ("pirtty rtty.ft 1000 \"%s\"", Text) == 0)
			{
				RunCommand ("rpitx -m RF -i rtty.ft -f %.3f", R (fKHz, 3));
			}
			break;

		case 13:
			if (   Ask ("Morse message", "CQ CQ DE F5OEO", Text, sizeof Text)
			    && RunCommand ("pimorse 10 \"%s\" morse.rfa", Text) == 0)
			{
				RunCommand ("rpitx -m RFA -i morse.rfa -f %.3f", R (fKHz, 3));
			}
			break;

		case 14:
			if (   Ask ("FSQ message", "Hello from rpitx", Text, sizeof Text)
			    && RunCommand ("pifsq \"%s\" fsq.ft", Text) == 0)
			{
				RunCommand ("rpitx -m RF -i fsq.ft -f %.3f -l", R (fKHz, 3));
			}
			break;
		}
	}
}

void CShell::CmdRtlmenu (void)
{
	static double s_fInMHz = 434.0;
	static double s_fOutMHz = 434.0;
	static int s_nGain = 0;		// 0: AGC

	Print ("\nrpitx with RTL-SDR (rpitx v2 rtlmenu, on the bare metal rpitx v1 engine)\n");

	boolean bSetup = TRUE;
	for (;;)
	{
		if (bSetup)
		{
			if (!AskFrequency ("RTL-SDR receive frequency in MHz", &s_fInMHz))
			{
				return;
			}
			char Gain[16];
			CString Default;
			Default.Format ("%d", s_nGain);
			if (!Ask ("RTL-SDR gain (0 = AGC, or 1-45 dB)", Default, Gain, sizeof Gain))
			{
				return;
			}
			s_nGain = atoi (Gain);
			if (s_nGain < 0 || s_nGain > 50)
			{
				s_nGain = 0;
			}
			if (!AskFrequency ("Transmit frequency in MHz", &s_fOutMHz))
			{
				return;
			}
			bSetup = FALSE;
		}

		CString Gain;
		if (s_nGain > 0)
		{
			Gain.Format (" -g %d", s_nGain);
		}
		double fOutKHz = s_fOutMHz * 1000.0;

		Print ("\n=== Rpitx with RTL-SDR: %.4f MHz -> %.4f MHz, gain %s ===\n"
		       "  0  Record        Record spectrum on %.4f MHz (record.iq, Ctrl-C to stop)\n"
		       "  1  Play          Replay the record on %.4f MHz\n"
		       "  2  Transponder   Transmit %.4f MHz to %.4f MHz\n"
		       "  3  FM->SSB       Transcode FM %.4f MHz to USB on %.4f MHz\n"
		       "  4  Set frequency Modify frequencies and gain\n"
		       "  5  Wide transp.  Transmit 250 kHz around %.4f MHz to %.4f MHz (FM broadcast)\n"
		       "  6  FM radio      Listen to %.4f MHz (FM broadcast, stereo, 3.5 mm jack)\n"
		       "  7  433 sensors   Decode 433 MHz temperature/humidity sensors (433.92 MHz)\n"
		       "  8  868 sensors   Decode 868 MHz FSK sensors (LaCrosse IT+, 868.30 MHz)\n"
		       "  9  Scanner       Scan +/-5 MHz around %.4f MHz, list active carriers\n"
		       "  w  Waterfall     Real-time spectrum + waterfall around %.4f MHz (HDMI)\n"
		       "  Q  Quit\n"
		       "Note: 0 to 3 process one channel of +/-12 kHz around the receive frequency;\n"
		       "5 retransmits the whole 250 kHz like the v2 transponder (FM signals only).\n",
		       R (s_fInMHz, 4), R (s_fOutMHz, 4), s_nGain > 0 ? (const char *) Gain + 4 : "AGC",
		       R (s_fInMHz, 4), R (s_fOutMHz, 4), R (s_fInMHz, 4), R (s_fOutMHz, 4),
		       R (s_fInMHz, 4), R (s_fOutMHz, 4), R (s_fInMHz, 4), R (s_fOutMHz, 4),
		       R (s_fInMHz, 4), R (s_fInMHz, 4), R (s_fInMHz, 4));

		char Choice[16];
		if (!Ask ("Choose your test (Q to quit)", "", Choice, sizeof Choice))
		{
			return;
		}
		bm_clear_stop ();

		switch (Choice[0])
		{
		case '\0':				// Enter alone: show the menu again
			break;

		case '0':
			// tuned 60 kHz (rate/4) above, as rtl2tx does, for rtl2iq
			Print ("Recording, Ctrl-C or Esc to stop\n");
			RunCommand ("rtl_sdr -f %.0f -s 240000%s record.iq",
				    R (s_fInMHz * 1e6 + 60000, 0), (const char *) Gain);
			break;

		case '1':
			if (RunCommand ("rtl2iq record.iq record.wav") == 0)
			{
				double fSet = pitx_iq_set_frequency (fOutKHz * 1000.0, RTLDSP_RELAY_SHIFT_HZ) / 1000.0;
				RunCommand ("rpitx -m IQ -i record.wav -f %.3f", R (fSet, 3));
			}
			break;

		case '2':
			RunCommand ("rtl2tx -r %.0f -f %.3f%s", R (s_fInMHz * 1e6, 0), R (fOutKHz, 3), (const char *) Gain);
			break;

		case '3':
			RunCommand ("rtl2tx -m fm2ssb -r %.0f -f %.3f%s", R (s_fInMHz * 1e6, 0), R (fOutKHz, 3),
				    (const char *) Gain);
			break;

		case '4':
			bSetup = TRUE;
			break;

		case '5':
			RunCommand ("rtl2tx -m wide -r %.0f -f %.3f%s", R (s_fInMHz * 1e6, 0), R (fOutKHz, 3),
				    (const char *) Gain);
			break;

		case '6':
			RunCommand ("rtlfm -f %.4f -m", R (s_fInMHz, 4));	// mono (plus leger), AGC logiciel
			break;

		case '7':
			RunCommand ("rtl433 -f 433.92");
			break;

		case '8':
			RunCommand ("rtl868 -f 868.30");
			break;

		case '9':
		{
			double a = s_fInMHz - 5.0, b = s_fInMHz + 5.0;
			if (a < 0.5) a = 0.5;
			if (b > 1700.0) b = 1700.0;
			RunCommand ("rtlscan -a %.3f -b %.3f", R (a, 3), R (b, 3));
			break;
		}

		case 'w':
		case 'W':
			RunCommand ("rtlwf -f %.4f", R (s_fInMHz, 4));
			break;

		case 'q':
		case 'Q':
			return;

		default:
			Print ("Unknown choice\n");
			break;
		}
	}
}
