//
// libusb_circle.cpp - libusb-1.0 subset for librtlsdr on Circle (bare metal)
//
// Copyright (C) 2026 rpitx-baremetal contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Contents
//  - CRTLSDRUSBDevice: Circle USB function driver claiming interface 0 of any
//    RTL2832U dongle known to librtlsdr. Registered through the weak hook
//    UserUSBDeviceFactory() added to Circle (patches/).
//  - the libusb API used by librtlsdr (see compat/include/libusb.h for the
//    semantics, in particular one request in flight per endpoint and
//    deferred cancellation).
//
#include <circle/usb/usbfunction.h>
#include <circle/usb/usbdevice.h>
#include <circle/usb/usbendpoint.h>
#include <circle/usb/usbhostcontroller.h>
#include <circle/usb/usbrequest.h>
#include <circle/usb/usbstring.h>
#include <circle/usb/usb.h>
#include <circle/synchronize.h>
#include <circle/logger.h>
#include <circle/string.h>
#include <circle/util.h>
#include <circle/alloc.h>
#include <circle/timer.h>
#include <bm_compat.h>
#include <libusb.h>

LOGMODULE ("rtlsdr");

extern "C" int rtlsdr_bm_is_known_device (uint16_t vid, uint16_t pid);

#define MAX_DEVICES		4
#define BOUNCE_SIZE		4096
#define COMPLETED_RING		64		// power of 2

enum TTransferState
{
	TransferIdle,				// not submitted, or callback done
	TransferQueued,				// waiting for the endpoint
	TransferActive,				// handed to the host controller
	TransferCompleted			// result available, callback pending
};

// ----------------------------------------------------------- USB function

class CRTLSDRUSBDevice : public CUSBFunction
{
public:
	CRTLSDRUSBDevice (CUSBFunction *pFunction);
	~CRTLSDRUSBDevice (void);

	boolean Configure (void);

	CUSBEndpoint *GetBulkIn (void) const	{ return m_pEndpointIn; }

private:
	CUSBEndpoint *m_pEndpointIn;
	int m_nSlot;
};

struct libusb_context
{
	int nDummy;
};

struct libusb_device
{
	CRTLSDRUSBDevice *pFunction;		// 0 when unplugged
	TUSBDeviceDescriptor Descriptor;
	unsigned nGeneration;			// changes when the slot is reused
	volatile unsigned nPending;		// bulk requests owned by the host controller
	libusb_device_handle * volatile pOwner;	// last opened handle
};

struct libusb_device_handle
{
	libusb_device *pDevice;
	unsigned nGeneration;
	struct libusb_transfer *pQueueHead;
	struct libusb_transfer *pQueueTail;
	struct libusb_transfer *pActive;
};

static libusb_device s_Devices[MAX_DEVICES];
static unsigned s_nGeneration = 0;

CRTLSDRUSBDevice::CRTLSDRUSBDevice (CUSBFunction *pFunction)
:	CUSBFunction (pFunction),
	m_pEndpointIn (0),
	m_nSlot (-1)
{
}

CRTLSDRUSBDevice::~CRTLSDRUSBDevice (void)
{
	if (m_nSlot >= 0)
	{
		s_Devices[m_nSlot].pFunction = 0;
		LOGNOTE ("RTL-SDR dongle removed");
	}

	delete m_pEndpointIn;
	m_pEndpointIn = 0;
}

boolean CRTLSDRUSBDevice::Configure (void)
{
	const TUSBEndpointDescriptor *pEndpointDesc;
	while ((pEndpointDesc = (TUSBEndpointDescriptor *) GetDescriptor (DESCRIPTOR_ENDPOINT)) != 0)
	{
		if (   (pEndpointDesc->bmAttributes & 0x3F) == 0x02		// Bulk
		    && (pEndpointDesc->bEndpointAddress & 0x80) == 0x80		// Input
		    && m_pEndpointIn == 0)
		{
			m_pEndpointIn = new CUSBEndpoint (GetDevice (), pEndpointDesc);
		}
	}

	if (m_pEndpointIn == 0)
	{
		ConfigurationError ("rtlsdr");
		return FALSE;
	}

	if (!CUSBFunction::Configure ())
	{
		LOGERR ("Cannot set interface");
		return FALSE;
	}

	for (int i = 0; i < MAX_DEVICES; i++)
	{
		if (s_Devices[i].pFunction == 0)
		{
			memcpy (&s_Devices[i].Descriptor, GetDevice ()->GetDeviceDescriptor (),
				sizeof (TUSBDeviceDescriptor));
			s_Devices[i].nGeneration = ++s_nGeneration;
			s_Devices[i].nPending = 0;
			s_Devices[i].pOwner = 0;
			s_Devices[i].pFunction = this;
			m_nSlot = i;

			LOGNOTE ("RTL-SDR dongle %04x:%04x ready (device #%d)",
				 (unsigned) s_Devices[i].Descriptor.idVendor,
				 (unsigned) s_Devices[i].Descriptor.idProduct, i);

			return TRUE;
		}
	}

	LOGWARN ("Too many RTL-SDR dongles");
	return FALSE;
}

// Hook called by Circle's USB device factory (weak symbol, see patches/)
CUSBFunction *UserUSBDeviceFactory (CUSBFunction *pParent, CString *pName)
{
	unsigned nVendor, nProduct;
	const char *p = (const char *) *pName;
	if (strncmp (p, "ven", 3) != 0)
	{
		return 0;
	}

	char *pEnd;
	nVendor = strtoul (p + 3, &pEnd, 16);
	if (*pEnd != '-')
	{
		return 0;
	}
	nProduct = strtoul (pEnd + 1, &pEnd, 16);
	if (*pEnd != '\0')
	{
		return 0;
	}

	if (   !rtlsdr_bm_is_known_device ((uint16_t) nVendor, (uint16_t) nProduct)
	    || pParent->GetInterfaceNumber () != 0)	// the SDR is interface 0
	{
		return 0;
	}

	return new CRTLSDRUSBDevice (pParent);
}

// ------------------------------------------------------------ helpers

static u8 *s_pBounce = 0;

static u8 *GetBounceBuffer (void)
{
	if (s_pBounce == 0)
	{
		s_pBounce = (u8 *) bm_dma_malloc (BOUNCE_SIZE);
	}
	return s_pBounce;
}

static CRTLSDRUSBDevice *GetFunction (libusb_device_handle *pHandle)
{
	if (   pHandle == 0
	    || pHandle->pDevice == 0
	    || pHandle->pDevice->nGeneration != pHandle->nGeneration)
	{
		return 0;
	}
	return pHandle->pDevice->pFunction;
}

static boolean IsDMAAligned (const void *p, unsigned nLength)
{
	return ((uintptr) p & 63) == 0 && (nLength & 31) == 0;
}

// ---------------------------------------------------------- enumeration

extern "C" int libusb_init (libusb_context **ctx)
{
	static libusb_context s_Context;
	if (ctx != 0)
	{
		*ctx = &s_Context;
	}
	return GetBounceBuffer () != 0 ? LIBUSB_SUCCESS : LIBUSB_ERROR_NO_MEM;
}

extern "C" void libusb_exit (libusb_context *ctx)
{
	(void) ctx;
}

extern "C" ssize_t libusb_get_device_list (libusb_context *ctx, libusb_device ***list)
{
	(void) ctx;
	libusb_device **pList = new libusb_device *[MAX_DEVICES + 1];
	int n = 0;
	for (int i = 0; i < MAX_DEVICES; i++)
	{
		if (s_Devices[i].pFunction != 0)
		{
			pList[n++] = &s_Devices[i];
		}
	}
	pList[n] = 0;
	*list = pList;
	return n;
}

extern "C" void libusb_free_device_list (libusb_device **list, int unref_devices)
{
	(void) unref_devices;
	delete [] list;
}

extern "C" int libusb_get_device_descriptor (libusb_device *dev,
					     struct libusb_device_descriptor *desc)
{
	const TUSBDeviceDescriptor *p = &dev->Descriptor;
	desc->bLength = p->bLength;
	desc->bDescriptorType = p->bDescriptorType;
	desc->bcdUSB = p->bcdUSB;
	desc->bDeviceClass = p->bDeviceClass;
	desc->bDeviceSubClass = p->bDeviceSubClass;
	desc->bDeviceProtocol = p->bDeviceProtocol;
	desc->bMaxPacketSize0 = p->bMaxPacketSize0;
	desc->idVendor = p->idVendor;
	desc->idProduct = p->idProduct;
	desc->bcdDevice = p->bcdDevice;
	desc->iManufacturer = p->iManufacturer;
	desc->iProduct = p->iProduct;
	desc->iSerialNumber = p->iSerialNumber;
	desc->bNumConfigurations = p->bNumConfigurations;
	return LIBUSB_SUCCESS;
}

extern "C" int libusb_open (libusb_device *dev, libusb_device_handle **handle)
{
	if (dev == 0 || dev->pFunction == 0)
	{
		return LIBUSB_ERROR_NO_DEVICE;
	}

	libusb_device_handle *pHandle = new libusb_device_handle;
	memset (pHandle, 0, sizeof *pHandle);
	pHandle->pDevice = dev;
	pHandle->nGeneration = dev->nGeneration;
	dev->pOwner = pHandle;
	*handle = pHandle;
	return LIBUSB_SUCCESS;
}

extern "C" void libusb_close (libusb_device_handle *handle)
{
	if (handle == 0)
	{
		return;
	}

	EnterCritical ();
	if (handle->pDevice != 0 && handle->pDevice->pOwner == handle)
	{
		handle->pDevice->pOwner = 0;
	}
	LeaveCritical ();

	// wait for a request still owned by the host controller (not for an
	// abandoned one: it completes only when the dongle sends data)
	uint64_t nStart = bm_micros ();
	while (   handle->pActive != 0
	       && !handle->pActive->bm_abandoned
	       && bm_micros () - nStart < 2000000)
	{
		DataMemBarrier ();
	}
	if (handle->pActive != 0)
	{
		// the completion routine still uses the handle
		LOGWARN ("Closing with a USB request still pending, handle leaked");
		return;
	}

	delete handle;
}

extern "C" libusb_device *libusb_get_device (libusb_device_handle *handle)
{
	return handle->pDevice;
}

extern "C" int libusb_claim_interface (libusb_device_handle *handle, int iface)
{
	(void) iface;
	return GetFunction (handle) != 0 ? LIBUSB_SUCCESS : LIBUSB_ERROR_NO_DEVICE;
}

extern "C" int libusb_release_interface (libusb_device_handle *handle, int iface)
{
	(void) handle; (void) iface;
	return LIBUSB_SUCCESS;
}

extern "C" int libusb_kernel_driver_active (libusb_device_handle *handle, int iface)
{
	(void) handle; (void) iface;
	return 0;				// there is no other driver
}

extern "C" int libusb_detach_kernel_driver (libusb_device_handle *handle, int iface)
{
	(void) handle; (void) iface;
	return LIBUSB_SUCCESS;
}

extern "C" int libusb_attach_kernel_driver (libusb_device_handle *handle, int iface)
{
	(void) handle; (void) iface;
	return LIBUSB_SUCCESS;
}

extern "C" int libusb_reset_device (libusb_device_handle *handle)
{
	(void) handle;
	return LIBUSB_ERROR_NOT_SUPPORTED;	// librtlsdr ignores the result
}

extern "C" int libusb_get_string_descriptor_ascii (libusb_device_handle *handle, uint8_t index,
						   unsigned char *data, int length)
{
	CRTLSDRUSBDevice *pFunction = GetFunction (handle);
	if (pFunction == 0)
	{
		return LIBUSB_ERROR_NO_DEVICE;
	}
	if (index == 0 || length <= 0)
	{
		return LIBUSB_ERROR_INVALID_PARAM;
	}

	CUSBString String (pFunction->GetDevice ());
	if (!String.GetFromDescriptor (index, String.GetLanguageID ()))
	{
		return LIBUSB_ERROR_IO;
	}

	const char *p = String.Get ();
	int n = 0;
	while (p[n] != '\0' && n < length - 1)
	{
		data[n] = (unsigned char) p[n];
		n++;
	}
	data[n] = '\0';
	return n;
}

// ------------------------------------------------------- sync transfers

extern "C" int libusb_control_transfer (libusb_device_handle *handle, uint8_t request_type,
					uint8_t request, uint16_t value, uint16_t index,
					unsigned char *data, uint16_t length, unsigned int timeout)
{
	(void) timeout;				// Circle control messages have no timeout

	CRTLSDRUSBDevice *pFunction = GetFunction (handle);
	if (pFunction == 0)
	{
		return LIBUSB_ERROR_NO_DEVICE;
	}
	if (length > BOUNCE_SIZE)
	{
		return LIBUSB_ERROR_INVALID_PARAM;
	}

	u8 *pBounce = GetBounceBuffer ();
	boolean bIn = (request_type & 0x80) != 0;
	if (!bIn && length > 0)
	{
		memcpy (pBounce, data, length);
	}

	int nResult = pFunction->GetHost ()->ControlMessage (pFunction->GetEndpoint0 (),
							     request_type, request, value, index,
							     pBounce, length);
	if (nResult < 0)
	{
		return LIBUSB_ERROR_IO;
	}

	if (bIn && nResult > 0)
	{
		memcpy (data, pBounce, nResult);
	}

	// OUT data stage: the DWHCI does not count the bytes sent (HCTSIZ.XferSize
	// is not decremented for OUT; the Linux dwc2 driver reports the requested
	// length too), so Circle returns 0. libusb returns the length sent and
	// librtlsdr checks it for the tuner I2C writes (r82xx_write: "i2c wr
	// failed=0"). A failed transfer (STALL...) is reported as an error above.
	if (!bIn)
	{
		return length;
	}

	return nResult;
}

extern "C" int libusb_bulk_transfer (libusb_device_handle *handle, unsigned char endpoint,
				     unsigned char *data, int length, int *transferred,
				     unsigned int timeout)
{
	CRTLSDRUSBDevice *pFunction = GetFunction (handle);
	if (pFunction == 0)
	{
		return LIBUSB_ERROR_NO_DEVICE;
	}
	if ((endpoint & 0x80) == 0 || length <= 0)
	{
		return LIBUSB_ERROR_NOT_SUPPORTED;	// only bulk IN is used
	}

	bm_poll ();					// Ctrl-C in rtl_sdr sync mode

	u8 *pBuffer = data;
	u8 *pAligned = 0;
	if (!IsDMAAligned (data, length))
	{
		pAligned = (u8 *) bm_dma_malloc (length);
		if (pAligned == 0)
		{
			return LIBUSB_ERROR_NO_MEM;
		}
		pBuffer = pAligned;
	}

	int nResult = pFunction->GetHost ()->Transfer (pFunction->GetBulkIn (), pBuffer,
						       length, timeout);
	if (nResult > 0 && pAligned != 0)
	{
		memcpy (data, pAligned, nResult);
	}
	bm_dma_free (pAligned);

	if (transferred != 0)
	{
		*transferred = nResult > 0 ? nResult : 0;
	}

	return nResult < 0 ? (timeout != 0 ? LIBUSB_ERROR_TIMEOUT : LIBUSB_ERROR_IO)
			   : LIBUSB_SUCCESS;
}

// ------------------------------------------------------ async transfers

static struct libusb_transfer *s_Completed[COMPLETED_RING];
static volatile unsigned s_nCompletedIn = 0;		// written with IRQs disabled
static volatile unsigned s_nCompletedOut = 0;

static void PushCompleted (struct libusb_transfer *t)	// IRQs disabled
{
	t->bm_state = TransferCompleted;
	s_Completed[s_nCompletedIn & (COMPLETED_RING-1)] = t;
	DataMemBarrier ();
	s_nCompletedIn++;
}

static void StartNext (libusb_device_handle *pHandle);	// IRQs disabled

static void CompletionStub (CUSBRequest *pURB, void *pParam, void *pContext)
{
	// interrupt context
	struct libusb_transfer *t = (struct libusb_transfer *) pParam;
	libusb_device_handle *pHandle = (libusb_device_handle *) pContext;
	libusb_device *pDevice = pHandle->pDevice;
	boolean bSameDevice = pDevice->nGeneration == pHandle->nGeneration;

	if (pURB->GetStatus ())
	{
		t->actual_length = (int) pURB->GetResultLength ();
		t->status = LIBUSB_TRANSFER_COMPLETED;
	}
	else
	{
		t->actual_length = 0;
		t->status = LIBUSB_TRANSFER_ERROR;
	}
	delete pURB;

	EnterCritical ();
	if (bSameDevice && pDevice->nPending > 0)
	{
		pDevice->nPending--;
	}
	pHandle->pActive = 0;
	if (t->bm_abandoned)
	{
		t->bm_state = TransferIdle;	// given up by its owner: not reported
	}
	else
	{
		PushCompleted (t);
	}
	StartNext (pHandle);
	// a request abandoned by a closed handle delays the current one
	libusb_device_handle *pOwner = pDevice->pOwner;
	if (bSameDevice && pOwner != 0 && pOwner != pHandle)
	{
		StartNext (pOwner);
	}
	LeaveCritical ();
}

static void StartNext (libusb_device_handle *pHandle)
{
	// one bulk request at a time per dongle, whatever the handle
	while (   pHandle->pActive == 0
	       && pHandle->pQueueHead != 0
	       && (   pHandle->pDevice->nGeneration != pHandle->nGeneration
		   || pHandle->pDevice->nPending == 0))
	{
		struct libusb_transfer *t = pHandle->pQueueHead;
		pHandle->pQueueHead = t->bm_next;
		if (pHandle->pQueueHead == 0)
		{
			pHandle->pQueueTail = 0;
		}
		t->bm_next = 0;

		CRTLSDRUSBDevice *pFunction = GetFunction (pHandle);
		if (pFunction == 0)
		{
			t->status = LIBUSB_TRANSFER_NO_DEVICE;
			t->actual_length = 0;
			PushCompleted (t);
			continue;
		}

		CUSBRequest *pURB = new CUSBRequest (pFunction->GetBulkIn (), t->buffer, t->length);
		pURB->SetCompletionRoutine (CompletionStub, t, pHandle);
		t->bm_state = TransferActive;
		pHandle->pActive = t;
		pHandle->pDevice->nPending++;

		if (!pFunction->GetHost ()->SubmitAsyncRequest (pURB))
		{
			delete pURB;
			pHandle->pDevice->nPending--;
			pHandle->pActive = 0;
			t->status = LIBUSB_TRANSFER_ERROR;
			t->actual_length = 0;
			PushCompleted (t);
		}
	}
}

extern "C" struct libusb_transfer *libusb_alloc_transfer (int iso_packets)
{
	(void) iso_packets;
	struct libusb_transfer *t = new struct libusb_transfer;
	memset (t, 0, sizeof *t);
	t->bm_state = TransferIdle;
	return t;
}

extern "C" void libusb_free_transfer (struct libusb_transfer *transfer)
{
	if (transfer == 0)
	{
		return;
	}
	if (transfer->bm_state != TransferIdle)
	{
		LOGWARN ("Freeing a transfer still in use, leaked");
		return;
	}
	delete transfer;
}

extern "C" int libusb_submit_transfer (struct libusb_transfer *t)
{
	libusb_device_handle *pHandle = t->dev_handle;
	CRTLSDRUSBDevice *pFunction = GetFunction (pHandle);
	if (pFunction == 0)
	{
		return LIBUSB_ERROR_NO_DEVICE;
	}
	if (   t->type != LIBUSB_TRANSFER_TYPE_BULK
	    || (t->endpoint & 0x80) == 0
	    || !IsDMAAligned (t->buffer, t->length))
	{
		return LIBUSB_ERROR_INVALID_PARAM;
	}
	if (t->bm_state != TransferIdle)
	{
		return LIBUSB_ERROR_BUSY;
	}

	EnterCritical ();
	t->bm_cancel = 0;
	t->bm_abandoned = 0;
	t->bm_next = 0;
	t->bm_state = TransferQueued;
	if (pHandle->pQueueTail != 0)
	{
		pHandle->pQueueTail->bm_next = t;
	}
	else
	{
		pHandle->pQueueHead = t;
	}
	pHandle->pQueueTail = t;
	StartNext (pHandle);
	LeaveCritical ();

	return LIBUSB_SUCCESS;
}

extern "C" int libusb_cancel_transfer (struct libusb_transfer *t)
{
	int nResult = LIBUSB_SUCCESS;
	libusb_device_handle *pHandle = t->dev_handle;

	EnterCritical ();
	switch (t->bm_state)
	{
	case TransferQueued: {
		// not yet started: unlink it and report it as cancelled
		struct libusb_transfer **pp = &pHandle->pQueueHead;
		struct libusb_transfer *pPrev = 0;
		while (*pp != 0 && *pp != t)
		{
			pPrev = *pp;
			pp = &(*pp)->bm_next;
		}
		if (*pp == t)
		{
			*pp = t->bm_next;
			if (pHandle->pQueueTail == t)
			{
				pHandle->pQueueTail = pPrev;
			}
		}
		t->bm_next = 0;
		t->bm_cancel = 1;
		t->actual_length = 0;
		PushCompleted (t);
		} break;

	case TransferActive:
		t->bm_cancel = 1;			// reported when it completes
		break;

	default:
		nResult = LIBUSB_ERROR_NOT_FOUND;
		break;
	}
	LeaveCritical ();

	return nResult;
}

extern "C" void libusb_bm_abandon_transfer (struct libusb_transfer *t)
{
	EnterCritical ();
	t->bm_abandoned = 1;
	if (t->bm_state == TransferQueued)
	{
		// not started: just unlink it
		libusb_device_handle *pHandle = t->dev_handle;
		struct libusb_transfer **pp = &pHandle->pQueueHead;
		struct libusb_transfer *pPrev = 0;
		while (*pp != 0 && *pp != t)
		{
			pPrev = *pp;
			pp = &(*pp)->bm_next;
		}
		if (*pp == t)
		{
			*pp = t->bm_next;
			if (pHandle->pQueueTail == t)
			{
				pHandle->pQueueTail = pPrev;
			}
		}
		t->bm_next = 0;
		t->bm_state = TransferIdle;
	}
	// TransferActive: ignored when it completes; TransferCompleted: skipped
	// by ProcessCompleted()
	LeaveCritical ();
}

static int ProcessCompleted (void)
{
	int nProcessed = 0;

	for (;;)
	{
		EnterCritical ();
		if (s_nCompletedOut == s_nCompletedIn)
		{
			LeaveCritical ();
			break;
		}
		struct libusb_transfer *t = s_Completed[s_nCompletedOut & (COMPLETED_RING-1)];
		s_nCompletedOut++;
		if (t->bm_cancel)
		{
			t->status = LIBUSB_TRANSFER_CANCELLED;
		}
		t->bm_state = TransferIdle;		// may be resubmitted by the callback
		boolean bAbandoned = t->bm_abandoned;
		LeaveCritical ();

		if (bAbandoned)
		{
			continue;			// its owner (and callback context) is gone
		}
		if (t->callback != 0)
		{
			(*t->callback) (t);
		}
		nProcessed++;
	}

	return nProcessed;
}

extern "C" int libusb_handle_events_timeout_completed (libusb_context *ctx, struct timeval *tv,
						       int *completed)
{
	(void) ctx;

	uint64_t nTimeout = tv != 0 ? (uint64_t) tv->tv_sec * 1000000 + tv->tv_usec : 0;
	uint64_t nStart = bm_micros ();

	for (;;)
	{
		if (ProcessCompleted () > 0)
		{
			return LIBUSB_SUCCESS;
		}
		if (completed != 0 && *completed)
		{
			return LIBUSB_SUCCESS;
		}
		if (bm_micros () - nStart >= nTimeout)
		{
			return LIBUSB_SUCCESS;		// timeout is not an error
		}

		bm_poll ();				// Ctrl-C, other polling work
	}
}

extern "C" int libusb_handle_events_timeout (libusb_context *ctx, struct timeval *tv)
{
	return libusb_handle_events_timeout_completed (ctx, tv, 0);
}

extern "C" int libusb_handle_events (libusb_context *ctx)
{
	struct timeval tv = {60, 0};
	return libusb_handle_events_timeout_completed (ctx, &tv, 0);
}

extern "C" const char *libusb_error_name (int errcode)
{
	switch (errcode)
	{
	case LIBUSB_SUCCESS:			return "LIBUSB_SUCCESS";
	case LIBUSB_ERROR_IO:			return "LIBUSB_ERROR_IO";
	case LIBUSB_ERROR_INVALID_PARAM:	return "LIBUSB_ERROR_INVALID_PARAM";
	case LIBUSB_ERROR_ACCESS:		return "LIBUSB_ERROR_ACCESS";
	case LIBUSB_ERROR_NO_DEVICE:		return "LIBUSB_ERROR_NO_DEVICE";
	case LIBUSB_ERROR_NOT_FOUND:		return "LIBUSB_ERROR_NOT_FOUND";
	case LIBUSB_ERROR_BUSY:			return "LIBUSB_ERROR_BUSY";
	case LIBUSB_ERROR_TIMEOUT:		return "LIBUSB_ERROR_TIMEOUT";
	case LIBUSB_ERROR_NO_MEM:		return "LIBUSB_ERROR_NO_MEM";
	case LIBUSB_ERROR_NOT_SUPPORTED:	return "LIBUSB_ERROR_NOT_SUPPORTED";
	default:				return "LIBUSB_ERROR_OTHER";
	}
}

extern "C" unsigned char *libusb_dev_mem_alloc (libusb_device_handle *handle, size_t length)
{
	(void) handle; (void) length;
	return 0;
}

extern "C" int libusb_dev_mem_free (libusb_device_handle *handle, unsigned char *buffer,
				    size_t length)
{
	(void) handle; (void) buffer; (void) length;
	return LIBUSB_ERROR_NOT_SUPPORTED;
}
