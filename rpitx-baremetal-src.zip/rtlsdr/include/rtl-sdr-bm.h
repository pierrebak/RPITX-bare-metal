/*
 * rtl-sdr-bm.h - rpitx-baremetal additions to librtlsdr (GPL-2.0-or-later)
 * See the end of librtlsdr.c.
 */
#ifndef RTL_SDR_BM_H
#define RTL_SDR_BM_H
#include <stdint.h>
#include "rtl-sdr.h"
#ifdef __cplusplus
extern "C" {
#endif
int rtlsdr_bm_is_known_device(uint16_t vid, uint16_t pid);
int rtlsdr_start_async(rtlsdr_dev_t *dev, rtlsdr_read_async_cb_t cb, void *ctx,
		       uint32_t buf_num, uint32_t buf_len);
int rtlsdr_poll_async(rtlsdr_dev_t *dev);
int rtlsdr_stop_async(rtlsdr_dev_t *dev);
#ifdef __cplusplus
}
#endif
#endif
