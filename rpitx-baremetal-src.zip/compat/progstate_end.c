/* see progstate_begin.c (rpitx-baremetal, GPL-3.0-or-later) */
char bm_progdata_end[4] = {1, 2, 3, 4};		/* .data */
char bm_progbss_end[4];				/* .bss */
