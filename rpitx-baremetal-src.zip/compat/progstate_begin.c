/*
 * progstate_begin.c / progstate_end.c - markers around the global data of
 * the ported programs (rpitx-baremetal, GPL-3.0-or-later).
 *
 * The linker places .data and .bss in command line order: these objects
 * are linked just before and just after the program objects (Makefile,
 * PROGRAM_OBJS), so [begin, end) covers exactly their global and static
 * variables. A copy is taken at boot and restored before each command,
 * like a fresh process on Linux (see bm_run_tool in posix.cpp).
 */
char bm_progdata_begin[4] = {1, 2, 3, 4};	/* .data */
char bm_progbss_begin[4];			/* .bss */
