//
// bm_internal.h - C++ side of the rpitx-baremetal runtime (kernel <-> compat)
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
#ifndef _bm_internal_h
#define _bm_internal_h

#include <circle/types.h>

// Console output (screen + serial) and non-blocking input (-1 = no char).
typedef void TBMConsoleWrite (const char *pBuffer, unsigned nLength);
typedef int TBMConsoleGetChar (void);

void BMSetConsole (TBMConsoleWrite *pWrite, TBMConsoleGetChar *pGetChar);

// Raw console access for the shell (no Ctrl-C processing).
void BMConsoleWrite (const char *pString);
int BMConsoleGetChar (void);

// Copy of the initial global state of the ported programs (call at boot).
void BMSaveProgramState (void);

// Called by the shell to run one command line (already split in argv).
extern "C" int bm_run_tool (int (*entry) (int, char **), int argc, char **argv);

#endif
