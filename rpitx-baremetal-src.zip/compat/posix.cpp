//
// posix.cpp - POSIX / stdio subset for rpitx-baremetal, built on Circle + FatFs
//
// Copyright (C) 2026 rpitx-baremetal contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Notes
// - This file must not include the compat C headers (stdio.h ...) because it
//   is compiled as C++ against Circle. The C prototypes are re-declared here
//   with extern "C" linkage and compatible types.
// - Files live on the FAT partition of the SD card ("SD:"), the current
//   directory is set by the shell (cd). Relative paths work as on Linux.
// - Deviation from POSIX, on purpose: open(O_WRONLY|O_CREAT) without O_APPEND
//   truncates the file. The rpitx generators open their output this way;
//   on Linux re-running them over a longer existing file leaves stale bytes
//   at the end, which on FAT would corrupt the .ft streams.
//
#include "bm_internal.h"
#include <bm_compat.h>
#include <circle/timer.h>
#include <circle/string.h>
#include <circle/util.h>
#include <circle/alloc.h>
#include <circle/stdarg.h>
#include <circle/synchronize.h>
#include <circle/bcm2835.h>
#include <circle/machineinfo.h>
#include <circle/gpiopin.h>
#include <fatfs/ff.h>

// ------------------------------------------------------------- C prototypes

struct bm_file
{
	int fd;
	int eof;
	int err;
};
typedef struct bm_file FILE;

struct bm_timespec { long tv_sec; long tv_nsec; };
struct bm_timeval { long tv_sec; long tv_usec; };
struct bm_stat { long st_size; unsigned st_mode; };
typedef void (*bm_sighandler_t) (int);
struct bm_sigaction { bm_sighandler_t sa_handler; unsigned long sa_mask; int sa_flags; void (*sa_restorer) (void); };

#define BM_SIG_DFL	((bm_sighandler_t) 0)
#define BM_SIG_IGN	((bm_sighandler_t) 1)
#define BM_SIGINT	2
#define BM_NSIG		65

#define BM_O_ACCMODE	0x0003
#define BM_O_RDONLY	0x0000
#define BM_O_WRONLY	0x0001
#define BM_O_RDWR	0x0002
#define BM_O_CREAT	0x0040
#define BM_O_EXCL	0x0080
#define BM_O_TRUNC	0x0200
#define BM_O_APPEND	0x0400

extern "C"
{
	int *__errno (void);
	int vsnprintf (char *buf, size_t n, const char *fmt, va_list ap);
	int printf (const char *fmt, ...);
	int fprintf (FILE *f, const char *fmt, ...);
	int sprintf (char *buf, const char *fmt, ...);
	int snprintf (char *buf, size_t n, const char *fmt, ...);
	int vprintf (const char *fmt, va_list ap);
	int vfprintf (FILE *f, const char *fmt, va_list ap);
	int vsprintf (char *buf, const char *fmt, va_list ap);
	int puts (const char *s);
	int fputs (const char *s, FILE *f);
	int putchar (int c);
	int fputc (int c, FILE *f);
	int fflush (FILE *f);
	void perror (const char *s);
	FILE *fopen (const char *path, const char *mode);
	FILE *fdopen (int fd, const char *mode);
	int fclose (FILE *f);
	size_t fread (void *p, size_t size, size_t n, FILE *f);
	size_t fwrite (const void *p, size_t size, size_t n, FILE *f);
	int fseek (FILE *f, long off, int whence);
	long ftell (FILE *f);
	void rewind (FILE *f);
	int feof (FILE *f);
	int ferror (FILE *f);
	int fileno (FILE *f);
	char *fgets (char *s, int n, FILE *f);
	int fgetc (FILE *f);
	int getchar (void);
	int remove (const char *path);
	int setvbuf (FILE *f, char *buf, int mode, size_t size);

	int open (const char *path, int flags, ...);
	int creat (const char *path, unsigned mode);
	int read (int fd, void *buf, size_t n);
	int write (int fd, const void *buf, size_t n);
	long lseek (int fd, long off, int whence);
	int close (int fd);
	int unlink (const char *path);
	int fsync (int fd);
	int ftruncate (int fd, long len);
	int isatty (int fd);
	int getpid (void);
	int stat (const char *path, struct bm_stat *st);
	int fstat (int fd, struct bm_stat *st);

	int usleep (unsigned us);
	unsigned sleep (unsigned s);
	int nanosleep (const struct bm_timespec *req, struct bm_timespec *rem);
	int clock_gettime (int id, struct bm_timespec *ts);
	int gettimeofday (struct bm_timeval *tv, void *tz);
	long time (long *t);
	long clock (void);

	bm_sighandler_t signal (int sig, bm_sighandler_t handler);
	int sigaction (int sig, const struct bm_sigaction *act, struct bm_sigaction *old);
	int sigemptyset (unsigned long *set);
	int raise (int sig);

	void exit (int status) __attribute__ ((noreturn));
	void _exit (int status) __attribute__ ((noreturn));
	void abort (void) __attribute__ ((noreturn));
	char *strerror (int e);

	int bm_plld_mhz = 500;		// firmware default; 1000 only with the rpitx dt-blob.bin
}

// ------------------------------------------------------------------ console

static TBMConsoleWrite *s_pConsoleWrite = 0;
static TBMConsoleGetChar *s_pConsoleGetChar = 0;

void BMSetConsole (TBMConsoleWrite *pWrite, TBMConsoleGetChar *pGetChar)
{
	s_pConsoleWrite = pWrite;
	s_pConsoleGetChar = pGetChar;
}

static void ConsoleWrite (const char *p, unsigned n)
{
	if (s_pConsoleWrite != 0 && n > 0)
	{
		(*s_pConsoleWrite) (p, n);
	}
}

void BMConsoleWrite (const char *pString)
{
	ConsoleWrite (pString, strlen (pString));
}

int BMConsoleGetChar (void)
{
	return s_pConsoleGetChar != 0 ? (*s_pConsoleGetChar) () : -1;
}

// --------------------------------------------------------------- formatting

// Circle's CString::FormatV supports %d %u %x %X %o %s %c %p %f with width,
// precision, '-', '0' and the l / ll modifiers. Map the remaining common
// conversions onto these.
static void TranslateFormat (const char *pIn, char *pOut, unsigned nOutSize)
{
	unsigned i = 0;
	while (*pIn != '\0' && i + 4 < nOutSize)
	{
		if (*pIn != '%')
		{
			pOut[i++] = *pIn++;
			continue;
		}

		pOut[i++] = *pIn++;			// '%'
		if (*pIn == '%')
		{
			pOut[i++] = *pIn++;
			continue;
		}

		// flags
		while (*pIn == '-' || *pIn == '0' || *pIn == '+' || *pIn == ' ' || *pIn == '#')
		{
			if (*pIn != '+' && *pIn != ' ')	// not supported: drop
			{
				pOut[i++] = *pIn;
			}
			pIn++;
		}
		// width / precision
		while ((*pIn >= '0' && *pIn <= '9') || *pIn == '.')
		{
			pOut[i++] = *pIn++;
		}
		// length modifiers
		while (*pIn == 'l' || *pIn == 'h' || *pIn == 'z' || *pIn == 'j' || *pIn == 't' || *pIn == 'L')
		{
			if (*pIn == 'l')
			{
				pOut[i++] = 'l';
			}
			pIn++;
		}
		// conversion
		char c = *pIn;
		if (c == '\0')
		{
			break;
		}
		pIn++;
		switch (c)
		{
		case 'i':			c = 'd'; break;
		case 'e': case 'E':
		case 'g': case 'G':
		case 'F':			c = 'f'; break;
		default:			break;
		}
		// "%lf" is a double like "%f", Circle would read a long long: drop 'l'
		if (c == 'f' && i > 0 && pOut[i-1] == 'l')
		{
			i--;
			if (i > 0 && pOut[i-1] == 'l')
			{
				i--;
			}
		}
		pOut[i++] = c;
	}
	pOut[i] = '\0';
}

int vsnprintf (char *buf, size_t n, const char *fmt, va_list ap)
{
	// the translation never makes the format longer
	unsigned nFormatSize = strlen (fmt) + 8;
	char *Format = new char[nFormatSize];
	TranslateFormat (fmt, Format, nFormatSize);

	CString String;
	String.FormatV (Format, ap);
	delete [] Format;

	size_t nLen = String.GetLength ();
	if (buf != 0 && n > 0)
	{
		size_t nCopy = nLen < n-1 ? nLen : n-1;
		memcpy (buf, (const char *) String, nCopy);
		buf[nCopy] = '\0';
	}

	return (int) nLen;
}

int vsprintf (char *buf, const char *fmt, va_list ap)
{
	return vsnprintf (buf, 0x7FFFFFFF, fmt, ap);
}

int sprintf (char *buf, const char *fmt, ...)
{
	va_list ap;
	va_start (ap, fmt);
	int n = vsprintf (buf, fmt, ap);
	va_end (ap);
	return n;
}

int snprintf (char *buf, size_t n, const char *fmt, ...)
{
	va_list ap;
	va_start (ap, fmt);
	int r = vsnprintf (buf, n, fmt, ap);
	va_end (ap);
	return r;
}

// ------------------------------------------------------------ file handles

#define FIRST_FILE_FD	3
#define MAX_FILES	16

struct TFileSlot
{
	boolean	bUsed;
	boolean	bOwnedByTool;
	FIL	File;
};

static TFileSlot s_Files[MAX_FILES];

static FILE s_StdIn  = {0, 0, 0};
static FILE s_StdOut = {1, 0, 0};
static FILE s_StdErr = {2, 0, 0};

extern "C"
{
	FILE *stdin  = &s_StdIn;
	FILE *stdout = &s_StdOut;
	FILE *stderr = &s_StdErr;
}

static boolean s_bToolActive = FALSE;
static volatile int s_nStopRequested = 0;	// Ctrl-C / Esc / timeout seen
static boolean s_bStdinReader = FALSE;	// fgetc (stdin) waiting: keys are its own

// Key capture (bm_key_capture): keys other than Ctrl-C are kept for the tool
// instead of being discarded by bm_poll ()
#define KEY_RING_SIZE	64
static boolean s_bKeyCapture = FALSE;
static int s_KeyRing[KEY_RING_SIZE];
static unsigned s_nKeyIn, s_nKeyOut;

static FIL *GetFile (int fd)
{
	int nIndex = fd - FIRST_FILE_FD;
	if (nIndex < 0 || nIndex >= MAX_FILES || !s_Files[nIndex].bUsed)
	{
		return 0;
	}
	return &s_Files[nIndex].File;
}

static int ErrnoFromFatFs (FRESULT Result)
{
	switch (Result)
	{
	case FR_OK:			return 0;
	case FR_NO_FILE:
	case FR_NO_PATH:		return 2;	// ENOENT
	case FR_EXIST:			return 17;	// EEXIST
	case FR_DENIED:
	case FR_WRITE_PROTECTED:	return 13;	// EACCES
	case FR_TOO_MANY_OPEN_FILES:	return 24;	// EMFILE
	case FR_INVALID_NAME:
	case FR_INVALID_PARAMETER:	return 22;	// EINVAL
	default:			return 5;	// EIO
	}
}

// File I/O is where the converters (pifm, pisstv ...) spend their time:
// check for Ctrl-C there, at most every 20 ms.
static void PollFromIO (void)
{
	static uint64_t s_nLastPoll = 0;
	uint64_t nNow = CTimer::GetClockTicks64 ();
	if (nNow - s_nLastPoll >= 20000)
	{
		s_nLastPoll = nNow;
		bm_poll ();
	}
}

int open (const char *path, int flags, ...)
{
	if (path == 0)
	{
		*__errno () = 22;
		return -1;
	}

	int nIndex;
	for (nIndex = 0; nIndex < MAX_FILES; nIndex++)
	{
		if (!s_Files[nIndex].bUsed)
		{
			break;
		}
	}
	if (nIndex >= MAX_FILES)
	{
		*__errno () = 24;
		return -1;
	}

	BYTE ucMode = 0;
	switch (flags & BM_O_ACCMODE)
	{
	case BM_O_RDONLY:	ucMode = FA_READ;		break;
	case BM_O_WRONLY:	ucMode = FA_WRITE;		break;
	default:		ucMode = FA_READ | FA_WRITE;	break;
	}

	if (flags & BM_O_CREAT)
	{
		if (flags & BM_O_EXCL)
		{
			ucMode |= FA_CREATE_NEW;
		}
		else if ((flags & BM_O_TRUNC) || !(flags & BM_O_APPEND))
		{
			ucMode |= FA_CREATE_ALWAYS;	// see note at top of file
		}
		else
		{
			ucMode |= FA_OPEN_ALWAYS;
		}
	}
	else if (flags & BM_O_TRUNC)
	{
		ucMode |= FA_CREATE_ALWAYS;
	}
	else
	{
		ucMode |= FA_OPEN_EXISTING;
	}

	FRESULT Result = f_open (&s_Files[nIndex].File, path, ucMode);
	if (Result != FR_OK)
	{
		*__errno () = ErrnoFromFatFs (Result);
		return -1;
	}

	if (flags & BM_O_APPEND)
	{
		f_lseek (&s_Files[nIndex].File, f_size (&s_Files[nIndex].File));
	}

	s_Files[nIndex].bUsed = TRUE;
	s_Files[nIndex].bOwnedByTool = s_bToolActive;

	return nIndex + FIRST_FILE_FD;
}

int creat (const char *path, unsigned mode)
{
	(void) mode;
	return open (path, BM_O_WRONLY | BM_O_CREAT | BM_O_TRUNC);
}

int read (int fd, void *buf, size_t n)
{
	if (fd == 0)
	{
		return 0;		// no binary stdin stream on bare metal: EOF
	}

	PollFromIO ();

	FIL *pFile = GetFile (fd);
	if (pFile == 0)
	{
		*__errno () = 9;
		return -1;
	}

	UINT nRead = 0;
	FRESULT Result = f_read (pFile, buf, n, &nRead);
	if (Result != FR_OK)
	{
		*__errno () = ErrnoFromFatFs (Result);
		return -1;
	}

	return (int) nRead;
}

int write (int fd, const void *buf, size_t n)
{
	if (fd == 1 || fd == 2)
	{
		ConsoleWrite ((const char *) buf, n);
		return (int) n;
	}

	PollFromIO ();

	FIL *pFile = GetFile (fd);
	if (pFile == 0)
	{
		*__errno () = 9;
		return -1;
	}

	UINT nWritten = 0;
	FRESULT Result = f_write (pFile, buf, n, &nWritten);
	if (Result != FR_OK)
	{
		*__errno () = ErrnoFromFatFs (Result);
		return -1;
	}
	if (nWritten < n)
	{
		*__errno () = 28;	// ENOSPC
	}

	return (int) nWritten;
}

long lseek (int fd, long off, int whence)
{
	FIL *pFile = GetFile (fd);
	if (pFile == 0)
	{
		*__errno () = 9;
		return -1;
	}

	long nBase = 0;
	switch (whence)
	{
	case 0:	nBase = 0;				break;	// SEEK_SET
	case 1:	nBase = (long) f_tell (pFile);		break;	// SEEK_CUR
	case 2:	nBase = (long) f_size (pFile);		break;	// SEEK_END
	default: *__errno () = 22;			return -1;
	}

	long nPos = nBase + off;
	if (nPos < 0)
	{
		*__errno () = 22;
		return -1;
	}

	FRESULT Result = f_lseek (pFile, (FSIZE_t) nPos);
	if (Result != FR_OK)
	{
		*__errno () = ErrnoFromFatFs (Result);
		return -1;
	}

	return nPos;
}

int close (int fd)
{
	if (fd >= 0 && fd < FIRST_FILE_FD)
	{
		return 0;
	}

	FIL *pFile = GetFile (fd);
	if (pFile == 0)
	{
		*__errno () = 9;
		return -1;
	}

	FRESULT Result = f_close (pFile);
	s_Files[fd - FIRST_FILE_FD].bUsed = FALSE;

	if (Result != FR_OK)
	{
		*__errno () = ErrnoFromFatFs (Result);
		return -1;
	}

	return 0;
}

int fsync (int fd)
{
	FIL *pFile = GetFile (fd);
	return pFile != 0 && f_sync (pFile) == FR_OK ? 0 : -1;
}

int ftruncate (int fd, long len)
{
	FIL *pFile = GetFile (fd);
	if (pFile == 0 || f_lseek (pFile, (FSIZE_t) len) != FR_OK || f_truncate (pFile) != FR_OK)
	{
		return -1;
	}
	return 0;
}

int unlink (const char *path)
{
	FRESULT Result = f_unlink (path);
	if (Result != FR_OK)
	{
		*__errno () = ErrnoFromFatFs (Result);
		return -1;
	}
	return 0;
}

int remove (const char *path)
{
	return unlink (path);
}

int stat (const char *path, struct bm_stat *st)
{
	FILINFO Info;
	FRESULT Result = f_stat (path, &Info);
	if (Result != FR_OK)
	{
		*__errno () = ErrnoFromFatFs (Result);
		return -1;
	}
	st->st_size = (long) Info.fsize;
	st->st_mode = (Info.fattrib & AM_DIR) ? 0040755 : 0100644;
	return 0;
}

int fstat (int fd, struct bm_stat *st)
{
	if (fd >= 0 && fd < FIRST_FILE_FD)
	{
		st->st_size = 0;
		st->st_mode = 0020666;		// character device
		return 0;
	}
	FIL *pFile = GetFile (fd);
	if (pFile == 0)
	{
		*__errno () = 9;
		return -1;
	}
	st->st_size = (long) f_size (pFile);
	st->st_mode = 0100644;
	return 0;
}

int isatty (int fd)
{
	return fd >= 0 && fd < FIRST_FILE_FD;
}

int getpid (void)
{
	return 1;
}

static void CloseToolFiles (void)
{
	for (unsigned i = 0; i < MAX_FILES; i++)
	{
		if (s_Files[i].bUsed && s_Files[i].bOwnedByTool)
		{
			f_close (&s_Files[i].File);
			s_Files[i].bUsed = FALSE;
		}
	}
}

// ----------------------------------------------------------------- stdio

static FILE *s_OpenStreams[MAX_FILES];

FILE *fdopen (int fd, const char *mode)
{
	(void) mode;
	if (fd >= 0 && fd < FIRST_FILE_FD)
	{
		return fd == 0 ? stdin : (fd == 1 ? stdout : stderr);
	}
	if (GetFile (fd) == 0)
	{
		return 0;
	}
	FILE *f = new FILE;
	f->fd = fd;
	f->eof = 0;
	f->err = 0;
	s_OpenStreams[fd - FIRST_FILE_FD] = f;
	return f;
}

FILE *fopen (const char *path, const char *mode)
{
	int flags;
	boolean bPlus = strchr (mode, '+') != 0;
	switch (mode[0])
	{
	case 'r': flags = bPlus ? BM_O_RDWR : BM_O_RDONLY;				break;
	case 'w': flags = (bPlus ? BM_O_RDWR : BM_O_WRONLY) | BM_O_CREAT | BM_O_TRUNC;	break;
	case 'a': flags = (bPlus ? BM_O_RDWR : BM_O_WRONLY) | BM_O_CREAT | BM_O_APPEND;	break;
	default:  *__errno () = 22; return 0;
	}

	int fd = open (path, flags);
	if (fd < 0)
	{
		return 0;
	}
	return fdopen (fd, mode);
}

int fclose (FILE *f)
{
	if (f == 0 || f == stdin || f == stdout || f == stderr)
	{
		return 0;
	}
	int r = close (f->fd);
	int nIndex = f->fd - FIRST_FILE_FD;
	if (nIndex >= 0 && nIndex < MAX_FILES && s_OpenStreams[nIndex] == f)
	{
		s_OpenStreams[nIndex] = 0;
	}
	delete f;
	return r;
}

static void FreeToolStreams (void)
{
	for (unsigned i = 0; i < MAX_FILES; i++)
	{
		if (s_OpenStreams[i] != 0 && !s_Files[i].bUsed)
		{
			delete s_OpenStreams[i];
			s_OpenStreams[i] = 0;
		}
	}
}

size_t fread (void *p, size_t size, size_t n, FILE *f)
{
	if (size == 0 || n == 0)
	{
		return 0;
	}
	if (f == stdin)
	{
		f->eof = 1;
		return 0;
	}
	int r = read (f->fd, p, size * n);
	if (r < 0)
	{
		f->err = 1;
		return 0;
	}
	if ((size_t) r < size * n)
	{
		f->eof = 1;
	}
	return (size_t) r / size;
}

size_t fwrite (const void *p, size_t size, size_t n, FILE *f)
{
	if (size == 0 || n == 0)
	{
		return 0;
	}
	int r = write (f->fd, p, size * n);
	if (r < 0)
	{
		f->err = 1;
		return 0;
	}
	return (size_t) r / size;
}

int fseek (FILE *f, long off, int whence)
{
	f->eof = 0;
	return lseek (f->fd, off, whence) < 0 ? -1 : 0;
}

long ftell (FILE *f)
{
	return lseek (f->fd, 0, 1);
}

void rewind (FILE *f)
{
	fseek (f, 0, 0);
	f->err = 0;
}

int feof (FILE *f)	{ return f->eof; }
int ferror (FILE *f)	{ return f->err; }
int fileno (FILE *f)	{ return f->fd; }

int setvbuf (FILE *f, char *buf, int mode, size_t size)
{
	(void) f; (void) buf; (void) mode; (void) size;
	return 0;
}

int fflush (FILE *f)
{
	if (f != 0 && f->fd >= FIRST_FILE_FD)
	{
		return fsync (f->fd);
	}
	return 0;
}

int vfprintf (FILE *f, const char *fmt, va_list ap)
{
	// the translation never makes the format longer
	unsigned nFormatSize = strlen (fmt) + 8;
	char *Format = new char[nFormatSize];
	TranslateFormat (fmt, Format, nFormatSize);

	CString String;
	String.FormatV (Format, ap);
	delete [] Format;

	return write (f->fd, (const char *) String, String.GetLength ());
}

int vprintf (const char *fmt, va_list ap)
{
	return vfprintf (stdout, fmt, ap);
}

int printf (const char *fmt, ...)
{
	va_list ap;
	va_start (ap, fmt);
	int n = vfprintf (stdout, fmt, ap);
	va_end (ap);
	return n;
}

int fprintf (FILE *f, const char *fmt, ...)
{
	va_list ap;
	va_start (ap, fmt);
	int n = vfprintf (f, fmt, ap);
	va_end (ap);
	return n;
}

int fputs (const char *s, FILE *f)
{
	return write (f->fd, s, strlen (s));
}

int puts (const char *s)
{
	fputs (s, stdout);
	return fputs ("\n", stdout);
}

int fputc (int c, FILE *f)
{
	char ch = (char) c;
	return write (f->fd, &ch, 1) == 1 ? (unsigned char) c : -1;
}

int putchar (int c)
{
	return fputc (c, stdout);
}

void perror (const char *s)
{
	if (s != 0 && *s != '\0')
	{
		fprintf (stderr, "%s: ", s);
	}
	fprintf (stderr, "%s\n", strerror (*__errno ()));
}

int fgetc (FILE *f)
{
	if (f == stdin)
	{
		// bm_poll () must not take the keys meant for this reader
		int c;
		s_bStdinReader = TRUE;
		while ((c = BMConsoleGetChar ()) < 0)
		{
			bm_poll ();
		}
		s_bStdinReader = FALSE;
		if (c == 0x03)
		{
			// Ctrl-C / Esc while reading: same as during the rest of a tool
			if (!s_nStopRequested)
			{
				s_nStopRequested = 1;
				ConsoleWrite ("^C\n", 3);
				if (s_bToolActive)
				{
					raise (BM_SIGINT);
				}
			}
			return -1;
		}
		return c == '\r' ? '\n' : c;
	}
	unsigned char ch;
	int r = read (f->fd, &ch, 1);
	if (r <= 0)
	{
		f->eof = 1;
		return -1;
	}
	return ch;
}

int getchar (void)
{
	return fgetc (stdin);
}

char *fgets (char *s, int n, FILE *f)
{
	int i = 0;
	while (i < n - 1)
	{
		int c = fgetc (f);
		if (c < 0)
		{
			break;
		}
		if (f == stdin)
		{
			char ch = (char) c;
			ConsoleWrite (&ch, 1);		// echo
		}
		s[i++] = (char) c;
		if (c == '\n')
		{
			break;
		}
	}
	if (i == 0)
	{
		return 0;
	}
	s[i] = '\0';
	return s;
}

// --------------------------------------------------------------------- time

uint64_t bm_micros (void)
{
	return CTimer::GetClockTicks64 ();
}

void bm_udelay (unsigned us)
{
	uint64_t nStart = bm_micros ();
	while (bm_micros () - nStart < us)
	{
		// spin
	}
}

void bm_sleep_us (unsigned us)
{
	uint64_t nStart = bm_micros ();
	do
	{
		bm_poll ();
	}
	while (bm_micros () - nStart < us);
}

int usleep (unsigned us)
{
	bm_sleep_us (us);
	return 0;
}

unsigned sleep (unsigned s)
{
	for (unsigned i = 0; i < s; i++)
	{
		bm_sleep_us (1000000);
	}
	return 0;
}

int nanosleep (const struct bm_timespec *req, struct bm_timespec *rem)
{
	bm_sleep_us ((unsigned) (req->tv_sec * 1000000 + req->tv_nsec / 1000));
	if (rem != 0)
	{
		rem->tv_sec = 0;
		rem->tv_nsec = 0;
	}
	return 0;
}

// No battery backed clock: the time base is the uptime of the board.
int clock_gettime (int id, struct bm_timespec *ts)
{
	(void) id;
	uint64_t us = bm_micros ();
	ts->tv_sec = (long) (us / 1000000);
	ts->tv_nsec = (long) (us % 1000000) * 1000;
	return 0;
}

int gettimeofday (struct bm_timeval *tv, void *tz)
{
	(void) tz;
	uint64_t us = bm_micros ();
	tv->tv_sec = (long) (us / 1000000);
	tv->tv_usec = (long) (us % 1000000);
	return 0;
}

long time (long *t)
{
	long s = (long) (bm_micros () / 1000000);
	if (t != 0)
	{
		*t = s;
	}
	return s;
}

long clock (void)
{
	return (long) bm_micros ();
}

// ------------------------------------------------------------------ signals

static bm_sighandler_t s_SignalHandler[BM_NSIG];

bm_sighandler_t signal (int sig, bm_sighandler_t handler)
{
	if (sig <= 0 || sig >= BM_NSIG)
	{
		return (bm_sighandler_t) -1;
	}
	bm_sighandler_t old = s_SignalHandler[sig];
	s_SignalHandler[sig] = handler;
	return old;
}

int sigaction (int sig, const struct bm_sigaction *act, struct bm_sigaction *old)
{
	if (sig <= 0 || sig >= BM_NSIG)
	{
		*__errno () = 22;
		return -1;
	}
	if (old != 0)
	{
		memset (old, 0, sizeof *old);
		old->sa_handler = s_SignalHandler[sig];
	}
	if (act != 0)
	{
		s_SignalHandler[sig] = act->sa_handler;
	}
	return 0;
}

int sigemptyset (unsigned long *set)
{
	*set = 0;
	return 0;
}

int raise (int sig)
{
	if (sig <= 0 || sig >= BM_NSIG)
	{
		return -1;
	}
	bm_sighandler_t handler = s_SignalHandler[sig];
	if (handler == BM_SIG_IGN)
	{
		return 0;
	}
	if (handler == BM_SIG_DFL)
	{
		exit (128 + sig);		// default action: terminate the tool
	}
	(*handler) (sig);
	return 0;
}

// --------------------------------------------------------- polling, Ctrl-C

#define MAX_POLL_HOOKS	4

static struct
{
	bm_poll_hook_t	pHook;
	void		*pContext;
}
s_PollHooks[MAX_POLL_HOOKS];

static boolean s_bInPoll = FALSE;
static uint64_t s_nDeadline = 0;	// bm_set_deadline (), 0 = none
static boolean s_bTimedOut = FALSE;	// the deadline stopped the command
static unsigned s_nKeysInTool = 0;	// keys received while a tool runs
static boolean s_bKeyHintShown = FALSE;

int bm_add_poll_hook (bm_poll_hook_t hook, void *ctx)
{
	for (int i = 0; i < MAX_POLL_HOOKS; i++)
	{
		if (s_PollHooks[i].pHook == 0)
		{
			s_PollHooks[i].pContext = ctx;
			s_PollHooks[i].pHook = hook;
			return i;
		}
	}
	return -1;
}

void bm_remove_poll_hook (int id)
{
	if (id >= 0 && id < MAX_POLL_HOOKS)
	{
		s_PollHooks[id].pHook = 0;
		s_PollHooks[id].pContext = 0;
	}
}

int bm_stop_requested (void)
{
	return s_nStopRequested;
}

void bm_clear_stop (void)
{
	s_nStopRequested = 0;
}

// Stop button: a push button between GPIO 17 (pin 11) and GND (pin 9) acts
// like Ctrl-C. It does not depend on the USB keyboard, which may stop
// answering while rpitx transmits (DMA at top priority).
#define STOP_BUTTON_GPIO	17
#define STOP_BUTTON_MS		30		// held at least this long

static boolean StopButtonPressed (void)
{
	static CGPIOPin *s_pPin = 0;
	static uint64_t s_nLowSince = 0;

	if (s_pPin == 0)
	{
		s_pPin = new CGPIOPin (STOP_BUTTON_GPIO, GPIOModeInputPullUp);
		return FALSE;
	}
	if (s_pPin->Read () != LOW)
	{
		s_nLowSince = 0;
		return FALSE;
	}
	uint64_t nNow = bm_micros ();
	if (s_nLowSince == 0)
	{
		s_nLowSince = nNow;
		return FALSE;
	}
	return nNow - s_nLowSince >= STOP_BUTTON_MS * 1000;
}

void bm_poll (void)
{
	if (s_bInPoll)
	{
		return;
	}
	s_bInPoll = TRUE;

	for (int i = 0; i < MAX_POLL_HOOKS; i++)
	{
		if (s_PollHooks[i].pHook != 0)
		{
			(*s_PollHooks[i].pHook) (s_PollHooks[i].pContext);
		}
	}

	boolean bInterrupt = FALSE;
	boolean bOtherKey = FALSE;
	int c;
	while (!s_bStdinReader && (c = BMConsoleGetChar ()) >= 0)
	{
		if (s_bToolActive)
		{
			s_nKeysInTool++;
		}
		if (c == 0x03)			// Ctrl-C (the kernel maps a lone ESC key to it)
		{
			bInterrupt = TRUE;
		}
		else if (s_bKeyCapture)
		{
			if (s_nKeyIn - s_nKeyOut < KEY_RING_SIZE)
			{
				s_KeyRing[s_nKeyIn++ % KEY_RING_SIZE] = c;
			}
		}
		else
		{
			bOtherKey = TRUE;	// discarded
		}
	}

	if (s_bToolActive && StopButtonPressed ())
	{
		bInterrupt = TRUE;
	}

	boolean bTimeout = FALSE;
	if (s_nDeadline != 0 && bm_micros () >= s_nDeadline)
	{
		s_nDeadline = 0;
		bTimeout = TRUE;
		s_bTimedOut = TRUE;
	}

	s_bInPoll = FALSE;

	if (bOtherKey && s_bToolActive && !s_bKeyHintShown)
	{
		// shows that the keyboard still works while transmitting
		s_bKeyHintShown = TRUE;
		BMConsoleWrite ("[key received, Esc or Ctrl-C stops]\n");
	}

	if ((bInterrupt || bTimeout) && !s_nStopRequested)
	{
		s_nStopRequested = 1;
		if (bTimeout)
		{
			BMConsoleWrite ("[timeout]\n");
		}
		else
		{
			ConsoleWrite ("^C\n", 3);
		}
		if (s_bToolActive)
		{
			raise (BM_SIGINT);
		}
	}
}

void bm_set_deadline (uint64_t nMicros)
{
	s_nDeadline = nMicros;
	s_bTimedOut = FALSE;
}

int bm_timed_out (void)
{
	return s_bTimedOut;
}

void bm_key_capture (int on)
{
	s_bKeyCapture = on ? TRUE : FALSE;
	s_nKeyIn = s_nKeyOut = 0;
}

static int KeyPop (void)
{
	return s_nKeyIn != s_nKeyOut ? s_KeyRing[s_nKeyOut++ % KEY_RING_SIZE] : -1;
}

// The keyboard driver sends the whole escape sequence of a special key at
// once (a lone Esc key is turned into Ctrl-C by the kernel), a serial
// terminal sends it within a few ms: both are complete when ESC is read.
int bm_getkey (void)
{
	bm_poll ();
	int c = KeyPop ();
	if (c != 0x1B)
	{
		return c;
	}
	if (s_nKeyIn == s_nKeyOut)
	{
		bm_udelay (3000);
		bm_poll ();
	}
	int c1 = KeyPop ();
	if (c1 != '[' && c1 != 'O')
	{
		return c1 < 0 ? 0x1B : c1;
	}
	char Seq[8];
	unsigned n = 0;
	int k;
	while ((k = KeyPop ()) >= 0 && n < sizeof Seq - 1)
	{
		Seq[n++] = (char) k;
		if (k >= 0x40 && k <= 0x7E)	// final byte
		{
			break;
		}
	}
	Seq[n] = '\0';
	if (n == 1)
	{
		switch (Seq[0])
		{
		case 'A':	return BM_KEY_UP;
		case 'B':	return BM_KEY_DOWN;
		case 'C':	return BM_KEY_RIGHT;
		case 'D':	return BM_KEY_LEFT;
		case 'H':	return BM_KEY_HOME;
		case 'F':	return BM_KEY_END;
		}
	}
	else if (n == 2 && Seq[1] == '~')
	{
		switch (Seq[0])
		{
		case '1':	return BM_KEY_HOME;
		case '4':	return BM_KEY_END;
		case '5':	return BM_KEY_PGUP;
		case '6':	return BM_KEY_PGDN;
		}
	}
	return BM_KEY_OTHER;
}

unsigned bm_keys_in_tool (void)
{
	return s_nKeysInTool;
}

// -------------------------------------------------------------- tool runner

static void *s_JumpBuffer[5];
static volatile int s_nExitStatus;

#define MAX_CLEANUPS	8
static bm_cleanup_t s_Cleanup[MAX_CLEANUPS];
static unsigned s_nCleanups = 0;

void bm_add_cleanup (bm_cleanup_t fn)
{
	for (unsigned i = 0; i < s_nCleanups; i++)
	{
		if (s_Cleanup[i] == fn)
		{
			return;
		}
	}
	if (s_nCleanups < MAX_CLEANUPS)
	{
		s_Cleanup[s_nCleanups++] = fn;
	}
}

void exit (int status)
{
	if (s_bToolActive)
	{
		s_nExitStatus = status;
		__builtin_longjmp (s_JumpBuffer, 1);
	}

	BMConsoleWrite ("\nexit() outside of a tool, system halted\n");
	for (;;)
	{
		DataSyncBarrier ();
	}
}

void _exit (int status)
{
	exit (status);
}

void abort (void)
{
	BMConsoleWrite ("abort()\n");
	exit (134);
}

// ---------------------------------------------------- program global state

extern "C"
{
	extern char bm_progdata_begin[], bm_progdata_end[];
	extern char bm_progbss_begin[], bm_progbss_end[];
}

static u8 *s_pProgDataCopy = 0;
static unsigned s_nProgDataSize = 0;

// Taken once at boot, before any program has run.
void BMSaveProgramState (void)
{
	s_nProgDataSize = (unsigned) (bm_progdata_end - bm_progdata_begin);
	s_pProgDataCopy = new u8[s_nProgDataSize];
	memcpy (s_pProgDataCopy, bm_progdata_begin, s_nProgDataSize);
}

// Initial values of the globals and statics of the ported programs, as for
// a new process on Linux (the generators keep filter states, "do_exit"
// flags ... in static variables).
static void RestoreProgramState (void)
{
	if (s_pProgDataCopy != 0)
	{
		memcpy (bm_progdata_begin, s_pProgDataCopy, s_nProgDataSize);
	}
	memset (bm_progbss_begin, 0, bm_progbss_end - bm_progbss_begin);
}

static int RunToolGuarded (bm_main_t entry, int argc, char **argv)
{
	if (__builtin_setjmp (s_JumpBuffer) == 0)
	{
		s_nExitStatus = (*entry) (argc, argv);
	}
	return s_nExitStatus;
}

extern "C" int optind;

int bm_run_tool (bm_main_t entry, int argc, char **argv)
{
	if (s_bToolActive)
	{
		return -1;			// tools do not nest
	}

	optind = 0;				// full getopt reset
	RestoreProgramState ();
	s_nStopRequested = 0;
	s_bStdinReader = FALSE;
	s_nKeysInTool = 0;
	s_bKeyHintShown = FALSE;
	bm_key_capture (0);
	s_nCleanups = 0;
	s_bToolActive = TRUE;

	int nStatus = RunToolGuarded (entry, argc, argv);

	s_bToolActive = FALSE;

	// whatever happened: stop RF / DMA / USB streaming
	while (s_nCleanups > 0)
	{
		bm_cleanup_t fn = s_Cleanup[--s_nCleanups];
		(*fn) ();
	}

	for (int i = 0; i < MAX_POLL_HOOKS; i++)
	{
		bm_remove_poll_hook (i);
	}
	for (int i = 0; i < BM_NSIG; i++)
	{
		s_SignalHandler[i] = BM_SIG_DFL;
	}
	CloseToolFiles ();
	FreeToolStreams ();
	bm_key_capture (0);
	s_nStopRequested = 0;
	s_bStdinReader = FALSE;

	return nStatus;
}

// ------------------------------------------------------- hardware helpers

uint32_t bm_bus_address (const volatile void *p)
{
	return BUS_ADDRESS ((uintptr) p);
}

void *bm_bus_to_arm (uint32_t bus)
{
	return (void *) (uintptr) (bus & ~0xC0000000);
}

void bm_clean_dcache (void)
{
	CleanDataCache ();		// whole L1 data cache, includes a DSB
}

void bm_clean_dcache_range (const volatile void *p, uint32_t len)
{
	CleanAndInvalidateDataCacheRange ((u32) (uintptr) p, len);
}

void *bm_alloc_aligned (size_t size, size_t align)
{
	u8 *p = (u8 *) malloc (size + align);
	if (p == 0)
	{
		return 0;
	}
	uintptr addr = ((uintptr) p + align - 1) & ~((uintptr) align - 1);
	return (void *) addr;
}

unsigned bm_alloc_dma_channel (int forced)
{
	static unsigned s_nChannel = DMA_CHANNEL_NONE;

	if (forced > 0)
	{
		// explicit request (rpitx -a): allocate it once, reuse afterwards
		static unsigned s_nForced[16] = {0};
		if (forced < 15 && s_nForced[forced] == 0)
		{
			unsigned nChannel = CMachineInfo::Get ()->AllocateDMAChannel ((unsigned) forced);
			if (nChannel == DMA_CHANNEL_NONE)
			{
				return 0xFF;
			}
			s_nForced[forced] = 1;
		}
		return (unsigned) forced;
	}

	if (s_nChannel == DMA_CHANNEL_NONE)
	{
		s_nChannel = CMachineInfo::Get ()->AllocateDMAChannel (DMA_CHANNEL_NORMAL);
	}
	return s_nChannel == DMA_CHANNEL_NONE ? 0xFF : s_nChannel;
}

uint32_t bm_peripheral_base (void)
{
	return ARM_IO_BASE;
}

// DMA safe buffers: aligned on a cache line and padded to whole cache lines,
// so that cache maintenance by the USB driver never touches other data.
extern "C" void *bm_dma_malloc (size_t size)
{
	const uintptr nAlign = 64;
	size_t nPadded = (size + nAlign - 1) & ~(nAlign - 1);
	u8 *pRaw = (u8 *) malloc (nPadded + nAlign + sizeof (void *));
	if (pRaw == 0)
	{
		return 0;
	}
	uintptr nAddr = ((uintptr) pRaw + sizeof (void *) + nAlign - 1) & ~(nAlign - 1);
	((void **) nAddr)[-1] = pRaw;
	return (void *) nAddr;
}

extern "C" void bm_dma_free (void *p)
{
	if (p != 0)
	{
		free (((void **) p)[-1]);
	}
}

/* ---- affichage graphique (framebuffer) ----------------------------- */
#include <circle/screen.h>

static CScreenDevice *s_pFbScreen = 0;

extern "C" void bm_fb_register (void *pScreen)
{
	s_pFbScreen = (CScreenDevice *) pScreen;
}

extern "C" int bm_fb_width (void)
{
	return s_pFbScreen != 0 ? (int) s_pFbScreen->GetWidth () : 0;
}

extern "C" int bm_fb_height (void)
{
	return s_pFbScreen != 0 ? (int) s_pFbScreen->GetHeight () : 0;
}

extern "C" void bm_fb_pixel (int x, int y, unsigned color)
{
	if (s_pFbScreen != 0 && x >= 0 && y >= 0)
	{
		s_pFbScreen->SetPixel ((unsigned) x, (unsigned) y, (TScreenColor) color);
	}
}

extern "C" unsigned bm_fb_color (int r, int g, int b)
{
	return (unsigned) COLOR16 (r >> 3, g >> 2, b >> 3);
}
