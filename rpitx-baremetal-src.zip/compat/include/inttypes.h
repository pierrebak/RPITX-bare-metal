#ifndef _BM_INTTYPES_H
#define _BM_INTTYPES_H
#include <stdint.h>
#define PRId32 "ld"
#define PRIu32 "lu"
#define PRIx32 "lx"
#define PRId64 "lld"
#define PRIu64 "llu"
#endif
