/* rpitx-baremetal minimal libc headers (GPL-3.0-or-later) */
#ifndef _BM_ERRNO_H
#define _BM_ERRNO_H
#ifdef __cplusplus
extern "C" {
#endif
int *__errno (void);
#define errno (*__errno ())
#define EPERM 1
#define ENOENT 2
#define EINTR 4
#define EIO 5
#define EBADF 9
#define EAGAIN 11
#define ENOMEM 12
#define EACCES 13
#define EBUSY 16
#define EEXIST 17
#define ENODEV 19
#define EINVAL 22
#define EMFILE 24
#define ENOSPC 28
#define ERANGE 34
#define ENOSYS 38
#define ETIMEDOUT 110
#ifdef __cplusplus
}
#endif
#endif
