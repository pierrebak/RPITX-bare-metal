/* rpitx-baremetal minimal libc headers (GPL-3.0-or-later) */
#ifndef _BM_SYS_TYPES_H
#define _BM_SYS_TYPES_H
#include <stddef.h>
#include <stdint.h>
typedef int ssize_t;
typedef long off_t;
typedef unsigned int mode_t;
typedef int pid_t;
typedef long time_t;
typedef long suseconds_t;
typedef unsigned int useconds_t;
typedef long clock_t;
#endif
