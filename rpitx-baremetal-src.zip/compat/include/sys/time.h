/* rpitx-baremetal minimal libc headers (GPL-3.0-or-later) */
#ifndef _BM_SYS_TIME_H
#define _BM_SYS_TIME_H
#include <time.h>
#ifdef __cplusplus
extern "C" {
#endif
struct timeval { time_t tv_sec; suseconds_t tv_usec; };
struct timezone { int tz_minuteswest, tz_dsttime; };
int gettimeofday (struct timeval *tv, void *tz);
#ifdef __cplusplus
}
#endif
#endif
