/* rpitx-baremetal: no virtual memory, kept so that original includes compile */
#ifndef _BM_SYS_MMAN_H
#define _BM_SYS_MMAN_H
#endif
