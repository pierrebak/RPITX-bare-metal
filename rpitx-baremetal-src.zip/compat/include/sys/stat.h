/* rpitx-baremetal minimal libc headers (GPL-3.0-or-later) */
#ifndef _BM_SYS_STAT_H
#define _BM_SYS_STAT_H
#include <sys/types.h>
struct stat { off_t st_size; mode_t st_mode; };
#define S_IRUSR 0400
#define S_IWUSR 0200
#ifdef __cplusplus
extern "C" {
#endif
int stat (const char *path, struct stat *st);
int fstat (int fd, struct stat *st);
#ifdef __cplusplus
}
#endif
#endif
