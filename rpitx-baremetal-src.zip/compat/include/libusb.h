/*
 * libusb.h - Subset of the libusb-1.0 API implemented on Circle's USB stack
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Only what librtlsdr needs. Semantics follow libusb:
 *  - asynchronous transfers complete (callback called) only from
 *    libusb_handle_events*(), in thread context;
 *  - transfers submitted to one endpoint are executed in order, one at a
 *    time (the DWC host controller driver of Circle does not serialise
 *    concurrent requests to the same endpoint itself);
 *  - libusb_cancel_transfer() cannot abort a request already handed to the
 *    host controller: such a transfer completes with status CANCELLED when
 *    the device answers (the RTL2832U streams continuously, so quickly).
 */
#ifndef _BM_LIBUSB_H
#define _BM_LIBUSB_H

#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>
#include <sys/time.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LIBUSB_CALL
#define LIBUSB_API_VERSION 0x01000100	/* no zero-copy (dev_mem) API path */

typedef struct libusb_context libusb_context;
typedef struct libusb_device libusb_device;
typedef struct libusb_device_handle libusb_device_handle;

struct libusb_device_descriptor {
	uint8_t  bLength;
	uint8_t  bDescriptorType;
	uint16_t bcdUSB;
	uint8_t  bDeviceClass;
	uint8_t  bDeviceSubClass;
	uint8_t  bDeviceProtocol;
	uint8_t  bMaxPacketSize0;
	uint16_t idVendor;
	uint16_t idProduct;
	uint16_t bcdDevice;
	uint8_t  iManufacturer;
	uint8_t  iProduct;
	uint8_t  iSerialNumber;
	uint8_t  bNumConfigurations;
};

enum libusb_error {
	LIBUSB_SUCCESS = 0,
	LIBUSB_ERROR_IO = -1,
	LIBUSB_ERROR_INVALID_PARAM = -2,
	LIBUSB_ERROR_ACCESS = -3,
	LIBUSB_ERROR_NO_DEVICE = -4,
	LIBUSB_ERROR_NOT_FOUND = -5,
	LIBUSB_ERROR_BUSY = -6,
	LIBUSB_ERROR_TIMEOUT = -7,
	LIBUSB_ERROR_OVERFLOW = -8,
	LIBUSB_ERROR_PIPE = -9,
	LIBUSB_ERROR_INTERRUPTED = -10,
	LIBUSB_ERROR_NO_MEM = -11,
	LIBUSB_ERROR_NOT_SUPPORTED = -12,
	LIBUSB_ERROR_OTHER = -99
};

enum libusb_transfer_status {
	LIBUSB_TRANSFER_COMPLETED,
	LIBUSB_TRANSFER_ERROR,
	LIBUSB_TRANSFER_TIMED_OUT,
	LIBUSB_TRANSFER_CANCELLED,
	LIBUSB_TRANSFER_STALL,
	LIBUSB_TRANSFER_NO_DEVICE,
	LIBUSB_TRANSFER_OVERFLOW
};

enum libusb_endpoint_direction {
	LIBUSB_ENDPOINT_OUT = 0x00,
	LIBUSB_ENDPOINT_IN = 0x80
};

enum libusb_request_type {
	LIBUSB_REQUEST_TYPE_STANDARD = (0x00 << 5),
	LIBUSB_REQUEST_TYPE_CLASS = (0x01 << 5),
	LIBUSB_REQUEST_TYPE_VENDOR = (0x02 << 5),
	LIBUSB_REQUEST_TYPE_RESERVED = (0x03 << 5)
};

enum libusb_transfer_type {
	LIBUSB_TRANSFER_TYPE_CONTROL = 0,
	LIBUSB_TRANSFER_TYPE_ISOCHRONOUS = 1,
	LIBUSB_TRANSFER_TYPE_BULK = 2,
	LIBUSB_TRANSFER_TYPE_INTERRUPT = 3
};

struct libusb_transfer;
typedef void (LIBUSB_CALL *libusb_transfer_cb_fn) (struct libusb_transfer *transfer);

struct libusb_transfer {
	libusb_device_handle *dev_handle;
	uint8_t flags;
	unsigned char endpoint;
	unsigned char type;
	unsigned int timeout;
	enum libusb_transfer_status status;
	int length;
	int actual_length;
	libusb_transfer_cb_fn callback;
	void *user_data;
	unsigned char *buffer;
	int num_iso_packets;
	/* bare metal private state */
	volatile int bm_state;
	volatile int bm_cancel;
	volatile int bm_abandoned;	/* owner gave it up: never reported */
	struct libusb_transfer *bm_next;
};

int libusb_init (libusb_context **ctx);
void libusb_exit (libusb_context *ctx);
ssize_t libusb_get_device_list (libusb_context *ctx, libusb_device ***list);
void libusb_free_device_list (libusb_device **list, int unref_devices);
int libusb_get_device_descriptor (libusb_device *dev, struct libusb_device_descriptor *desc);
int libusb_open (libusb_device *dev, libusb_device_handle **handle);
void libusb_close (libusb_device_handle *handle);
libusb_device *libusb_get_device (libusb_device_handle *handle);
int libusb_claim_interface (libusb_device_handle *handle, int iface);
int libusb_release_interface (libusb_device_handle *handle, int iface);
int libusb_kernel_driver_active (libusb_device_handle *handle, int iface);
int libusb_detach_kernel_driver (libusb_device_handle *handle, int iface);
int libusb_attach_kernel_driver (libusb_device_handle *handle, int iface);
int libusb_reset_device (libusb_device_handle *handle);
int libusb_get_string_descriptor_ascii (libusb_device_handle *handle, uint8_t index,
					unsigned char *data, int length);
int libusb_control_transfer (libusb_device_handle *handle, uint8_t request_type,
			     uint8_t request, uint16_t value, uint16_t index,
			     unsigned char *data, uint16_t length, unsigned int timeout);
int libusb_bulk_transfer (libusb_device_handle *handle, unsigned char endpoint,
			  unsigned char *data, int length, int *transferred,
			  unsigned int timeout);

struct libusb_transfer *libusb_alloc_transfer (int iso_packets);
void libusb_free_transfer (struct libusb_transfer *transfer);
int libusb_submit_transfer (struct libusb_transfer *transfer);
int libusb_cancel_transfer (struct libusb_transfer *transfer);
int libusb_handle_events_timeout_completed (libusb_context *ctx, struct timeval *tv,
					    int *completed);
int libusb_handle_events_timeout (libusb_context *ctx, struct timeval *tv);
int libusb_handle_events (libusb_context *ctx);

/* bare metal: Circle cannot abort a bulk request already handed to the host
   controller (no timeout for bulk). If it never completes (dongle not
   streaming), the owner gives the transfer up with this call: it will never
   be reported, and the transfer and its buffer must be leaked (not freed),
   because the USB DMA may still write into the buffer. */
void libusb_bm_abandon_transfer (struct libusb_transfer *transfer);
const char *libusb_error_name (int errcode);

unsigned char *libusb_dev_mem_alloc (libusb_device_handle *handle, size_t length);
int libusb_dev_mem_free (libusb_device_handle *handle, unsigned char *buffer, size_t length);

static inline void libusb_fill_bulk_transfer (struct libusb_transfer *transfer,
	libusb_device_handle *dev_handle, unsigned char endpoint,
	unsigned char *buffer, int length, libusb_transfer_cb_fn callback,
	void *user_data, unsigned int timeout)
{
	transfer->dev_handle = dev_handle;
	transfer->endpoint = endpoint;
	transfer->type = LIBUSB_TRANSFER_TYPE_BULK;
	transfer->timeout = timeout;
	transfer->buffer = buffer;
	transfer->length = length;
	transfer->user_data = user_data;
	transfer->callback = callback;
}

/* bare metal: DMA safe (cache line aligned) buffers for USB transfers */
void *bm_dma_malloc (size_t size);
void bm_dma_free (void *p);

#ifdef __cplusplus
}
#endif

#endif
