/* rpitx-baremetal minimal libc headers (GPL-3.0-or-later) */
#ifndef _BM_UNISTD_H
#define _BM_UNISTD_H
#include <sys/types.h>
#ifdef __cplusplus
extern "C" {
#endif
#define STDIN_FILENO 0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2
ssize_t read (int fd, void *buf, size_t n);
ssize_t write (int fd, const void *buf, size_t n);
off_t lseek (int fd, off_t off, int whence);
int close (int fd);
int unlink (const char *path);
int usleep (useconds_t us);
unsigned sleep (unsigned s);
int isatty (int fd);
pid_t getpid (void);
int fsync (int fd);
int ftruncate (int fd, off_t len);
extern char *optarg;
extern int optind, opterr, optopt;
int getopt (int argc, char * const argv[], const char *optstring);
#ifdef __cplusplus
}
#endif
#endif
