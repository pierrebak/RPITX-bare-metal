/* rpitx-baremetal: signals. Only SIGINT is ever raised: by Ctrl-C or ESC on the
   console, from bm_poll(), in thread context. (GPL-3.0-or-later) */
#ifndef _BM_SIGNAL_H
#define _BM_SIGNAL_H
#ifdef __cplusplus
extern "C" {
#endif
typedef void (*sighandler_t) (int);
typedef int sig_atomic_t;
typedef unsigned long sigset_t;
#define SIG_DFL ((sighandler_t) 0)
#define SIG_IGN ((sighandler_t) 1)
#define SIG_ERR ((sighandler_t) -1)
#define SIGHUP 1
#define SIGINT 2
#define SIGQUIT 3
#define SIGILL 4
#define SIGABRT 6
#define SIGFPE 8
#define SIGKILL 9
#define SIGSEGV 11
#define SIGPIPE 13
#define SIGALRM 14
#define SIGTERM 15
#define NSIG 65
struct sigaction { sighandler_t sa_handler; sigset_t sa_mask; int sa_flags; void (*sa_restorer) (void); };
sighandler_t signal (int sig, sighandler_t handler);
int sigaction (int sig, const struct sigaction *act, struct sigaction *old);
int sigemptyset (sigset_t *set);
int raise (int sig);
#ifdef __cplusplus
}
#endif
#endif
