/* rpitx-baremetal minimal libc headers (GPL-3.0-or-later) */
#ifndef _BM_TIME_H
#define _BM_TIME_H
#include <sys/types.h>
#ifdef __cplusplus
extern "C" {
#endif
struct timespec { time_t tv_sec; long tv_nsec; };
struct tm { int tm_sec, tm_min, tm_hour, tm_mday, tm_mon, tm_year, tm_wday, tm_yday, tm_isdst; };
typedef int clockid_t;
#define CLOCK_REALTIME 0
#define CLOCK_MONOTONIC 1
#define CLOCKS_PER_SEC 1000000
time_t time (time_t *t);
clock_t clock (void);
int clock_gettime (clockid_t id, struct timespec *ts);
int nanosleep (const struct timespec *req, struct timespec *rem);
struct tm *gmtime (const time_t *t);
struct tm *localtime (const time_t *t);
time_t mktime (struct tm *tm);
#ifdef __cplusplus
}
#endif
#endif
