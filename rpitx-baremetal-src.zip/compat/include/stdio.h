/* rpitx-baremetal minimal libc headers (GPL-3.0-or-later) */
#ifndef _BM_STDIO_H
#define _BM_STDIO_H
#include <stddef.h>
#include <stdarg.h>
#include <sys/types.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct bm_file FILE;
extern FILE *stdin, *stdout, *stderr;
#define EOF (-1)
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#define BUFSIZ 1024
int printf (const char *fmt, ...) __attribute__ ((format (printf, 1, 2)));
int fprintf (FILE *f, const char *fmt, ...) __attribute__ ((format (printf, 2, 3)));
int sprintf (char *buf, const char *fmt, ...) __attribute__ ((format (printf, 2, 3)));
int snprintf (char *buf, size_t n, const char *fmt, ...) __attribute__ ((format (printf, 3, 4)));
int vprintf (const char *fmt, va_list ap);
int vfprintf (FILE *f, const char *fmt, va_list ap);
int vsprintf (char *buf, const char *fmt, va_list ap);
int vsnprintf (char *buf, size_t n, const char *fmt, va_list ap);
int puts (const char *s);
int fputs (const char *s, FILE *f);
int putchar (int c);
int fputc (int c, FILE *f);
#define putc fputc
int fflush (FILE *f);
void perror (const char *s);
FILE *fopen (const char *path, const char *mode);
FILE *fdopen (int fd, const char *mode);
int fclose (FILE *f);
size_t fread (void *p, size_t size, size_t n, FILE *f);
size_t fwrite (const void *p, size_t size, size_t n, FILE *f);
int fseek (FILE *f, long off, int whence);
long ftell (FILE *f);
void rewind (FILE *f);
int feof (FILE *f);
int ferror (FILE *f);
int fileno (FILE *f);
char *fgets (char *s, int n, FILE *f);
int fgetc (FILE *f);
#define getc fgetc
int getchar (void);
int remove (const char *path);
int setvbuf (FILE *f, char *buf, int mode, size_t size);
#define _IONBF 2
#define _IOLBF 1
#define _IOFBF 0
int sscanf (const char *s, const char *fmt, ...);
#ifdef __cplusplus
}
#endif
#endif
