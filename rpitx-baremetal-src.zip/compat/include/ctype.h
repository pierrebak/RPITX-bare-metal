/* rpitx-baremetal minimal libc headers (GPL-3.0-or-later) */
#ifndef _BM_CTYPE_H
#define _BM_CTYPE_H
static inline int isdigit (int c) { return c >= '0' && c <= '9'; }
static inline int isxdigit (int c) { return isdigit (c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
static inline int isupper (int c) { return c >= 'A' && c <= 'Z'; }
static inline int islower (int c) { return c >= 'a' && c <= 'z'; }
static inline int isalpha (int c) { return isupper (c) || islower (c); }
static inline int isalnum (int c) { return isalpha (c) || isdigit (c); }
static inline int isspace (int c) { return c == ' ' || (c >= '\t' && c <= '\r'); }
static inline int isprint (int c) { return c >= 0x20 && c < 0x7F; }
static inline int isgraph (int c) { return c > 0x20 && c < 0x7F; }
static inline int iscntrl (int c) { return (c >= 0 && c < 0x20) || c == 0x7F; }
static inline int ispunct (int c) { return isgraph (c) && !isalnum (c); }
static inline int toupper (int c) { return islower (c) ? c - 32 : c; }
static inline int tolower (int c) { return isupper (c) ? c + 32 : c; }
#endif
