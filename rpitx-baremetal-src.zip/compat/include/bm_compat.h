/*
 * bm_compat.h - Bare metal runtime services used by the ported C code
 *
 * rpitx-baremetal: port of rpitx v1 (F5OEO) to Raspberry Pi 1 without Linux.
 * The functions below are implemented in compat/posix.cpp on top of Circle.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#ifndef BM_COMPAT_H
#define BM_COMPAT_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- time ---------------------------------------------------------- */
uint64_t bm_micros (void);		/* free running 1 MHz system timer */
void     bm_udelay (unsigned us);	/* busy wait, does not poll */
void     bm_sleep_us (unsigned us);	/* waits and keeps polling (stop key, USB) */

/* ---- console / stop handling --------------------------------------- */
/* Called often by long running loops: handles Ctrl-C / ESC, pumps USB
   streaming. If Ctrl-C was pressed and a SIGINT handler is installed the
   handler is called (from this thread, never from an interrupt). */
void bm_poll (void);
int  bm_stop_requested (void);		/* 1 after Ctrl-C/ESC until cleared */
void bm_clear_stop (void);
/* bm_poll() acts as if Ctrl-C was pressed once bm_micros() reaches
   this value (0: no deadline). Used by the shell command "timeout". */
void bm_set_deadline (uint64_t micros);
int  bm_timed_out (void);		/* 1 if the deadline was reached */
unsigned bm_keys_in_tool (void);	/* keys received during the last tool */

/* Interactive tools: with capture on, bm_poll () keeps the keys (except
   Ctrl-C / Esc, which still stop the tool) for bm_getkey () instead of
   discarding them. Capture is turned off when the tool ends. */
void bm_key_capture (int on);
int  bm_getkey (void);			/* -1: no key; char, or BM_KEY_* */
#define BM_KEY_UP	0x101
#define BM_KEY_DOWN	0x102
#define BM_KEY_LEFT	0x103
#define BM_KEY_RIGHT	0x104
#define BM_KEY_PGUP	0x105
#define BM_KEY_PGDN	0x106
#define BM_KEY_HOME	0x107
#define BM_KEY_END	0x108
#define BM_KEY_OTHER	0x1FF

/* ---- audio output (compat/audio.cpp) ------------------------------- */
/* Stereo 16 bit output on the 3.5 mm jack (PWM) or HDMI. The device is
   stopped when the tool ends. Returns 0, or -1 on error. */
int  bm_audio_open (unsigned rate, int hdmi, unsigned queue_ms);
unsigned bm_audio_space (void);		/* frames that can be written now */
unsigned bm_audio_queued (void);	/* frames waiting to be played */
int  bm_audio_write (const int16_t *lr, unsigned frames);	/* frames written */
void bm_audio_close (void);
void bm_audio_info (char *buf, unsigned size);	/* diagnostic text */

/* ---- polling hooks ------------------------------------------------- */
typedef void (*bm_poll_hook_t) (void *ctx);
int  bm_add_poll_hook (bm_poll_hook_t hook, void *ctx);	/* returns id */
void bm_remove_poll_hook (int id);

/* ---- peripherals / memory ------------------------------------------ */
uint32_t bm_bus_address (const volatile void *p);	/* ARM address -> VC bus */
void    *bm_bus_to_arm (uint32_t bus);
void     bm_clean_dcache (void);		/* write back whole L1 D-cache */
void     bm_clean_dcache_range (const volatile void *p, uint32_t len);
void    *bm_alloc_aligned (size_t size, size_t align);	/* never freed */
unsigned bm_alloc_dma_channel (int forced);		/* 0xFF if none */
uint32_t bm_peripheral_base (void);			/* 0x20000000 on Pi 1 */

/* ---- tool runner --------------------------------------------------- */
/* exit() inside a tool returns to the shell through this mechanism */
typedef int (*bm_main_t) (int argc, char **argv);
int bm_run_tool (bm_main_t entry, int argc, char **argv);

/* Cleanup functions run when the current tool ends, however it ends
   (return, exit(), Ctrl-C). Used to guarantee that DMA / RF output and
   USB streaming are stopped before returning to the shell. */
typedef void (*bm_cleanup_t) (void);
void bm_add_cleanup (bm_cleanup_t fn);

/* ---- affichage graphique (framebuffer HDMI) ------------------------ */
/* Dessin direct a l'ecran pour les outils graphiques (waterfall...).
   Couleur au format 5-6-5 (voir bm_fb_color). bm_fb_width () vaut 0 si
   aucun ecran n'est disponible. */
int      bm_fb_width (void);
int      bm_fb_height (void);
void     bm_fb_pixel (int x, int y, unsigned color);
unsigned bm_fb_color (int r, int g, int b);	/* r,g,b 0..255 -> 5-6-5 */
void     bm_fb_register (void *screen);		/* appele par le kernel (CScreenDevice*) */

/* ---- global settings (shell command "set") ------------------------- */
extern int bm_plld_mhz;		/* PLLD frequency, 1000 with the rpitx dt-blob */

#ifdef __cplusplus
}
#endif

#endif
