/* rpitx-baremetal: minimal libsndfile compatible API for WAV files.
   Implements what rpitx v1 generators use. (GPL-3.0-or-later) */
#ifndef _BM_SNDFILE_H
#define _BM_SNDFILE_H
#include <stdint.h>
#include <sys/types.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef long long sf_count_t;
typedef struct SNDFILE_tag SNDFILE;
typedef struct {
	sf_count_t frames;
	int samplerate;
	int channels;
	int format;
	int sections;
	int seekable;
} SF_INFO;
#define SFM_READ 0x10
#define SFM_WRITE 0x20
#define SFM_RDWR 0x30
#define SF_FORMAT_WAV		0x010000
#define SF_FORMAT_PCM_S8	0x0001
#define SF_FORMAT_PCM_16	0x0002
#define SF_FORMAT_PCM_24	0x0003
#define SF_FORMAT_PCM_32	0x0004
#define SF_FORMAT_PCM_U8	0x0005
#define SF_FORMAT_FLOAT		0x0006
#define SF_FORMAT_SUBMASK	0x0000FFFF
#define SF_FORMAT_TYPEMASK	0x0FFF0000
SNDFILE *sf_open (const char *path, int mode, SF_INFO *info);
int sf_close (SNDFILE *f);
const char *sf_strerror (SNDFILE *f);
sf_count_t sf_readf_float (SNDFILE *f, float *p, sf_count_t frames);
sf_count_t sf_read_float (SNDFILE *f, float *p, sf_count_t items);
sf_count_t sf_readf_short (SNDFILE *f, short *p, sf_count_t frames);
sf_count_t sf_read_short (SNDFILE *f, short *p, sf_count_t items);
sf_count_t sf_writef_float (SNDFILE *f, const float *p, sf_count_t frames);
sf_count_t sf_write_float (SNDFILE *f, const float *p, sf_count_t items);
sf_count_t sf_writef_short (SNDFILE *f, const short *p, sf_count_t frames);
sf_count_t sf_write_short (SNDFILE *f, const short *p, sf_count_t items);
sf_count_t sf_seek (SNDFILE *f, sf_count_t frames, int whence);
#ifdef __cplusplus
}
#endif
#endif
