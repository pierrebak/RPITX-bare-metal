/* rpitx-baremetal minimal libc headers (GPL-3.0-or-later) */
#ifndef _BM_STDLIB_H
#define _BM_STDLIB_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1
#define RAND_MAX 0x7FFFFFFF
void *malloc (size_t n);
void *calloc (size_t n, size_t s);
void *realloc (void *p, size_t n);
void free (void *p);
void exit (int status) __attribute__ ((noreturn));
void _exit (int status) __attribute__ ((noreturn));
void abort (void) __attribute__ ((noreturn));
int atexit (void (*fn) (void));
int atoi (const char *s);
long atol (const char *s);
double atof (const char *s);
long strtol (const char *s, char **end, int base);
unsigned long strtoul (const char *s, char **end, int base);
long long strtoll (const char *s, char **end, int base);
unsigned long long strtoull (const char *s, char **end, int base);
double strtod (const char *s, char **end);
float strtof (const char *s, char **end);
int abs (int x);
long labs (long x);
int rand (void);
void srand (unsigned seed);
void qsort (void *base, size_t n, size_t size, int (*cmp) (const void *, const void *));
char *getenv (const char *name);
int system (const char *cmd);
typedef struct { int quot, rem; } div_t;
div_t div (int n, int d);
#ifdef __cplusplus
}
#endif
#endif
