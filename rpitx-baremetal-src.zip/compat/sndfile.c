/*
 * sndfile.c - Minimal libsndfile replacement (RIFF/WAVE only)
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Supported: reading PCM U8/S16/S24/S32 and IEEE float32 WAV (incl.
 * WAVE_FORMAT_EXTENSIBLE), writing PCM S16 or float32 WAV.
 * Conversions follow libsndfile's normalised float convention:
 * PCM16 <-> float uses a scale of 0x8000 when reading and 0x7FFF when
 * writing, with clipping.
 */
#include <sndfile.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <math.h>

struct SNDFILE_tag {
	int fd;
	int mode;
	SF_INFO info;
	int bytes_per_sample;
	int is_float;
	long data_offset;
	long data_bytes;	/* read: size of data chunk */
	long pos_bytes;		/* read: bytes consumed in data chunk */
	long written_bytes;	/* write */
};

static const char *s_last_error = "No error";

const char *sf_strerror (SNDFILE *f)
{
	(void) f;
	return s_last_error;
}

static uint32_t rd32 (const unsigned char *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((uint32_t) p[3] << 24); }
static uint16_t rd16 (const unsigned char *p) { return (uint16_t) (p[0] | (p[1] << 8)); }
static void wr32 (unsigned char *p, uint32_t v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }
static void wr16 (unsigned char *p, uint16_t v) { p[0] = v; p[1] = v >> 8; }

static int read_exact (int fd, void *p, int n)
{
	return read (fd, p, n) == n;
}

static SNDFILE *open_read (const char *path, SF_INFO *info)
{
	int fd = open (path, O_RDONLY);
	if (fd < 0) { s_last_error = "System error : No such file or directory."; return 0; }

	unsigned char h[12];
	if (!read_exact (fd, h, 12) || memcmp (h, "RIFF", 4) != 0 || memcmp (h + 8, "WAVE", 4) != 0) {
		s_last_error = "File contains data in an unknown format (only WAV is supported).";
		close (fd);
		return 0;
	}

	int have_fmt = 0, fmt_tag = 0, channels = 0, bits = 0;
	uint32_t rate = 0;
	for (;;) {
		unsigned char ch[8];
		if (!read_exact (fd, ch, 8)) {
			s_last_error = "WAV file has no data chunk.";
			close (fd);
			return 0;
		}
		uint32_t size = rd32 (ch + 4);
		if (memcmp (ch, "fmt ", 4) == 0) {
			unsigned char fmt[40];
			uint32_t n = size < sizeof fmt ? size : sizeof fmt;
			if (!read_exact (fd, fmt, n)) break;
			fmt_tag = rd16 (fmt);
			channels = rd16 (fmt + 2);
			rate = rd32 (fmt + 4);
			bits = rd16 (fmt + 14);
			if (fmt_tag == 0xFFFE && n >= 26)	/* WAVE_FORMAT_EXTENSIBLE */
				fmt_tag = rd16 (fmt + 24);
			if (size > n) lseek (fd, size - n, SEEK_CUR);
			have_fmt = 1;
		} else if (memcmp (ch, "data", 4) == 0) {
			if (!have_fmt) break;
			SNDFILE *f = calloc (1, sizeof *f);
			f->fd = fd;
			f->mode = SFM_READ;
			f->data_offset = lseek (fd, 0, SEEK_CUR);
			f->data_bytes = size;
			long file_size = lseek (fd, 0, SEEK_END);
			if (f->data_offset + f->data_bytes > file_size || size == 0 || size == 0xFFFFFFFF)
				f->data_bytes = file_size - f->data_offset;	/* streamed / truncated file */
			lseek (fd, f->data_offset, SEEK_SET);
			f->bytes_per_sample = bits / 8;
			f->is_float = (fmt_tag == 3);
			if (!((fmt_tag == 1 && (bits == 8 || bits == 16 || bits == 24 || bits == 32)) ||
			      (fmt_tag == 3 && bits == 32)) || channels < 1) {
				s_last_error = "Unsupported WAV encoding (PCM 8/16/24/32 bit or float32 only).";
				close (fd);
				free (f);
				return 0;
			}
			memset (info, 0, sizeof *info);
			info->samplerate = rate;
			info->channels = channels;
			info->frames = f->data_bytes / (f->bytes_per_sample * channels);
			info->sections = 1;
			info->seekable = 1;
			info->format = SF_FORMAT_WAV | (f->is_float ? SF_FORMAT_FLOAT :
				bits == 8 ? SF_FORMAT_PCM_U8 : bits == 16 ? SF_FORMAT_PCM_16 :
				bits == 24 ? SF_FORMAT_PCM_24 : SF_FORMAT_PCM_32);
			f->info = *info;
			return f;
		} else {
			lseek (fd, size + (size & 1), SEEK_CUR);	/* skip unknown chunk */
		}
	}
	s_last_error = "Malformed WAV header.";
	close (fd);
	return 0;
}

static void write_header (SNDFILE *f, uint32_t data_bytes)
{
	unsigned char h[44];
	int bps = f->bytes_per_sample;
	memcpy (h, "RIFF", 4);
	wr32 (h + 4, 36 + data_bytes);
	memcpy (h + 8, "WAVEfmt ", 8);
	wr32 (h + 16, 16);
	wr16 (h + 20, f->is_float ? 3 : 1);
	wr16 (h + 22, f->info.channels);
	wr32 (h + 24, f->info.samplerate);
	wr32 (h + 28, f->info.samplerate * f->info.channels * bps);
	wr16 (h + 32, f->info.channels * bps);
	wr16 (h + 34, bps * 8);
	memcpy (h + 36, "data", 4);
	wr32 (h + 40, data_bytes);
	lseek (f->fd, 0, SEEK_SET);
	write (f->fd, h, 44);
}

static SNDFILE *open_write (const char *path, SF_INFO *info)
{
	if (info->channels < 1 || info->samplerate < 1) {
		s_last_error = "Bad SF_INFO for writing.";
		return 0;
	}
	int fd = open (path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
	if (fd < 0) { s_last_error = "System error : cannot create file."; return 0; }
	SNDFILE *f = calloc (1, sizeof *f);
	f->fd = fd;
	f->mode = SFM_WRITE;
	f->info = *info;
	f->is_float = ((info->format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT);
	f->bytes_per_sample = f->is_float ? 4 : 2;
	f->info.format = SF_FORMAT_WAV | (f->is_float ? SF_FORMAT_FLOAT : SF_FORMAT_PCM_16);
	write_header (f, 0);
	f->data_offset = 44;
	return f;
}

SNDFILE *sf_open (const char *path, int mode, SF_INFO *info)
{
	if (mode == SFM_READ) return open_read (path, info);
	if (mode == SFM_WRITE) return open_write (path, info);
	s_last_error = "SFM_RDWR is not supported.";
	return 0;
}

int sf_close (SNDFILE *f)
{
	if (f == 0) return 0;
	if (f->mode == SFM_WRITE) {
		write_header (f, (uint32_t) f->written_bytes);
	}
	close (f->fd);
	free (f);
	return 0;
}

/* Read up to 'items' samples as float into p. */
#define CHUNK 1024
static sf_count_t read_items_float (SNDFILE *f, float *p, sf_count_t items)
{
	if (f == 0 || f->mode != SFM_READ) return 0;
	int bps = f->bytes_per_sample;
	long remain = (f->data_bytes - f->pos_bytes) / bps;
	if (items > remain) items = remain;
	sf_count_t done = 0;
	unsigned char buf[CHUNK * 4];
	while (done < items) {
		int n = (int) ((items - done) < CHUNK ? (items - done) : CHUNK);
		int got = read (f->fd, buf, n * bps);
		if (got <= 0) break;
		n = got / bps;
		f->pos_bytes += n * bps;
		for (int i = 0; i < n; i++) {
			const unsigned char *s = buf + i * bps;
			float v;
			if (f->is_float) {
				uint32_t u = rd32 (s);
				memcpy (&v, &u, 4);
			} else if (bps == 1) {
				v = ((int) s[0] - 128) / 128.0f;
			} else if (bps == 2) {
				v = (int16_t) rd16 (s) / 32768.0f;
			} else if (bps == 3) {
				int32_t x = (int32_t) ((s[0] << 8) | (s[1] << 16) | ((uint32_t) s[2] << 24));
				v = x / 2147483648.0f;
			} else {
				v = (int32_t) rd32 (s) / 2147483648.0f;
			}
			p[done + i] = v;
		}
		done += n;
	}
	return done;
}

sf_count_t sf_read_float (SNDFILE *f, float *p, sf_count_t items)
{
	return read_items_float (f, p, items);
}

sf_count_t sf_readf_float (SNDFILE *f, float *p, sf_count_t frames)
{
	if (f == 0) return 0;
	return read_items_float (f, p, frames * f->info.channels) / f->info.channels;
}

static short float_to_short (float v)
{
	float x = v * 32767.0f;
	if (x > 32767.0f) return 32767;
	if (x < -32768.0f) return -32768;
	return (short) lrintf (x);	/* round half to even, like libsndfile */
}

sf_count_t sf_read_short (SNDFILE *f, short *p, sf_count_t items)
{
	float tmp[CHUNK];
	sf_count_t done = 0;
	while (done < items) {
		sf_count_t n = items - done < CHUNK ? items - done : CHUNK;
		sf_count_t got = read_items_float (f, tmp, n);
		if (got <= 0) break;
		for (sf_count_t i = 0; i < got; i++) {
			/* PCM16 sources are returned unchanged */
			float x = tmp[i] * 32768.0f;
			p[done + i] = x > 32767.0f ? 32767 : x < -32768.0f ? -32768 : (short) x;
		}
		done += got;
	}
	return done;
}

sf_count_t sf_readf_short (SNDFILE *f, short *p, sf_count_t frames)
{
	if (f == 0) return 0;
	return sf_read_short (f, p, frames * f->info.channels) / f->info.channels;
}

sf_count_t sf_write_float (SNDFILE *f, const float *p, sf_count_t items)
{
	if (f == 0 || f->mode != SFM_WRITE) return 0;
	unsigned char buf[CHUNK * 4];
	sf_count_t done = 0;
	while (done < items) {
		int n = (int) ((items - done) < CHUNK ? (items - done) : CHUNK);
		for (int i = 0; i < n; i++) {
			if (f->is_float) {
				uint32_t u;
				memcpy (&u, &p[done + i], 4);
				wr32 (buf + 4 * i, u);
			} else {
				wr16 (buf + 2 * i, (uint16_t) float_to_short (p[done + i]));
			}
		}
		int bytes = n * f->bytes_per_sample;
		int w = write (f->fd, buf, bytes);
		if (w <= 0) break;
		f->written_bytes += w;
		done += w / f->bytes_per_sample;
		if (w < bytes) break;
	}
	return done;
}

sf_count_t sf_writef_float (SNDFILE *f, const float *p, sf_count_t frames)
{
	if (f == 0) return 0;
	return sf_write_float (f, p, frames * f->info.channels) / f->info.channels;
}

sf_count_t sf_write_short (SNDFILE *f, const short *p, sf_count_t items)
{
	float tmp[CHUNK];
	sf_count_t done = 0;
	while (done < items) {
		sf_count_t n = items - done < CHUNK ? items - done : CHUNK;
		for (sf_count_t i = 0; i < n; i++) tmp[i] = p[done + i] / 32767.0f;
		sf_count_t w = sf_write_float (f, tmp, n);
		done += w;
		if (w < n) break;
	}
	return done;
}

sf_count_t sf_writef_short (SNDFILE *f, const short *p, sf_count_t frames)
{
	if (f == 0) return 0;
	return sf_write_short (f, p, frames * f->info.channels) / f->info.channels;
}

sf_count_t sf_seek (SNDFILE *f, sf_count_t frames, int whence)
{
	if (f == 0 || f->mode != SFM_READ) return -1;
	long frame_bytes = f->bytes_per_sample * f->info.channels;
	long target;
	if (whence == SEEK_SET) target = frames * frame_bytes;
	else if (whence == SEEK_CUR) target = f->pos_bytes + frames * frame_bytes;
	else target = f->data_bytes + frames * frame_bytes;
	if (target < 0 || target > f->data_bytes) return -1;
	f->pos_bytes = target;
	lseek (f->fd, f->data_offset + target, SEEK_SET);
	return target / frame_bytes;
}
