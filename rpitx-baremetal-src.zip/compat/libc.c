/*
 * libc.c - Small, self-contained C library functions for rpitx-baremetal
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Functions that Circle already provides (memcpy, strlen, strcmp, atoi,
 * strtoul, malloc ...) are NOT redefined here.
 */
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <getopt.h>
#include <stdint.h>

/* ------------------------------------------------------------------ errno */

/* __errno() is provided by Circle (lib/sysinit.cpp) */

/* ---------------------------------------------------------------- strings */

char *strrchr (const char *s, int c)
{
	const char *last = 0;
	for (;; s++) {
		if (*s == (char) c) last = s;
		if (*s == '\0') return (char *) last;
	}
}

void *memchr (const void *p, int c, size_t n)
{
	const unsigned char *q = p;
	while (n--) {
		if (*q == (unsigned char) c) return (void *) q;
		q++;
	}
	return 0;
}

char *strdup (const char *s)
{
	size_t n = strlen (s) + 1;
	char *d = malloc (n);
	if (d) memcpy (d, s, n);
	return d;
}

size_t strspn (const char *s, const char *a)
{
	size_t n = 0;
	while (s[n] && strchr (a, s[n])) n++;
	return n;
}

size_t strcspn (const char *s, const char *r)
{
	size_t n = 0;
	while (s[n] && !strchr (r, s[n])) n++;
	return n;
}

char *strtok (char *s, const char *d)
{
	static char *save;
	return strtok_r (s, d, &save);
}

char *strerror (int e)
{
	switch (e) {
	case 0: return "Success";
	case ENOENT: return "No such file or directory";
	case EIO: return "I/O error";
	case EBADF: return "Bad file descriptor";
	case ENOMEM: return "Out of memory";
	case EACCES: return "Permission denied";
	case EBUSY: return "Device busy";
	case EEXIST: return "File exists";
	case ENODEV: return "No such device";
	case EINVAL: return "Invalid argument";
	case EMFILE: return "Too many open files";
	case ENOSPC: return "No space left on device";
	case ETIMEDOUT: return "Timed out";
	default: return "Unknown error";
	}
}

/* ------------------------------------------------------------ conversions */

int abs (int x) { return x < 0 ? -x : x; }
long labs (long x) { return x < 0 ? -x : x; }
div_t div (int n, int d) { div_t r; r.quot = n / d; r.rem = n % d; return r; }

long long strtoll (const char *s, char **end, int base)
{
	while (isspace ((unsigned char) *s)) s++;
	int neg = 0;
	if (*s == '-') { neg = 1; s++; }
	else if (*s == '+') s++;
	unsigned long long v = strtoull (s, end, base);
	return neg ? -(long long) v : (long long) v;
}

long strtol (const char *s, char **end, int base)
{
	return (long) strtoll (s, end, base);
}

long atol (const char *s) { return strtol (s, 0, 10); }

/* Decimal floating point parser: sign, digits, '.', digits, exponent.
   Accurate enough for command line arguments (frequencies, ppm ...). */
double strtod (const char *s, char **end)
{
	const char *p = s;
	while (isspace ((unsigned char) *p)) p++;
	int neg = 0;
	if (*p == '-') { neg = 1; p++; }
	else if (*p == '+') p++;

	double v = 0.0;
	int digits = 0;
	while (isdigit ((unsigned char) *p)) { v = v * 10.0 + (*p - '0'); p++; digits++; }
	/* the comma is accepted as decimal separator when a digit follows it
	   ("96,3": French keyboards, the keypad gives a comma) */
	if (*p == '.' || (*p == ',' && isdigit ((unsigned char) p[1]))) {
		p++;
		double scale = 0.1;
		while (isdigit ((unsigned char) *p)) { v += (*p - '0') * scale; scale *= 0.1; p++; digits++; }
	}
	if (digits == 0) {			/* no conversion */
		if (end) *end = (char *) s;
		return 0.0;
	}
	if (*p == 'e' || *p == 'E') {
		const char *q = p + 1;
		int eneg = 0, e = 0, edigits = 0;
		if (*q == '-') { eneg = 1; q++; }
		else if (*q == '+') q++;
		while (isdigit ((unsigned char) *q)) { e = e * 10 + (*q - '0'); q++; edigits++; }
		if (edigits) {
			double f = 1.0, b = 10.0;
			while (e) { if (e & 1) f *= b; b *= b; e >>= 1; }
			v = eneg ? v / f : v * f;
			p = q;
		}
	}
	if (end) *end = (char *) p;
	return neg ? -v : v;
}

float strtof (const char *s, char **end) { return (float) strtod (s, end); }
double atof (const char *s) { return strtod (s, 0); }

/* ---------------------------------------------------------------- random */

static uint32_t s_rand_state = 1;
int rand (void)
{
	s_rand_state = s_rand_state * 1103515245u + 12345u;
	return (int) ((s_rand_state >> 1) & RAND_MAX);
}
void srand (unsigned seed) { s_rand_state = seed ? seed : 1; }

/* ----------------------------------------------------------------- qsort */

static void swap_bytes (char *a, char *b, size_t n)
{
	while (n--) { char t = *a; *a++ = *b; *b++ = t; }
}

void qsort (void *base, size_t n, size_t size, int (*cmp) (const void *, const void *))
{
	/* insertion sort for small arrays, otherwise simple quicksort */
	char *b = base;
	if (n < 2) return;
	if (n < 16) {
		for (size_t i = 1; i < n; i++)
			for (size_t j = i; j > 0 && cmp (b + (j - 1) * size, b + j * size) > 0; j--)
				swap_bytes (b + (j - 1) * size, b + j * size, size);
		return;
	}
	swap_bytes (b, b + (n / 2) * size, size);	/* middle element as pivot */
	size_t last = 0;
	for (size_t i = 1; i < n; i++)
		if (cmp (b + i * size, b) < 0)
			swap_bytes (b + (++last) * size, b + i * size, size);
	swap_bytes (b, b + last * size, size);
	qsort (b, last, size, cmp);
	qsort (b + (last + 1) * size, n - last - 1, size, cmp);
}

/* ------------------------------------------------------------- environment */

char *getenv (const char *name) { (void) name; return 0; }
int system (const char *cmd) { (void) cmd; return -1; }
int atexit (void (*fn) (void)) { (void) fn; return 0; }

/* ---------------------------------------------------------------- getopt */
/* POSIX getopt. The shell resets optind to 0 before each tool, which
   (like glibc) also resets the internal scanning position. */

char *optarg;
int optind = 1, opterr = 1, optopt;
static int s_optpos;

int getopt (int argc, char * const argv[], const char *optstring)
{
	if (optind == 0) { optind = 1; s_optpos = 0; }
	optarg = 0;
	if (s_optpos == 0) {
		if (optind >= argc || argv[optind] == 0 || argv[optind][0] != '-' || argv[optind][1] == '\0')
			return -1;
		if (strcmp (argv[optind], "--") == 0) { optind++; return -1; }
		s_optpos = 1;
	}
	const char *arg = argv[optind];
	int c = (unsigned char) arg[s_optpos++];
	const char *spec = (*optstring == ':') ? optstring + 1 : optstring;
	const char *p = (c != ':') ? strchr (spec, c) : 0;
	if (p == 0) {
		optopt = c;
		if (opterr && *optstring != ':')
			fprintf (stderr, "%s: invalid option -- '%c'\n", argv[0], c);
		if (arg[s_optpos] == '\0') { optind++; s_optpos = 0; }
		return '?';
	}
	if (p[1] == ':') {
		if (arg[s_optpos] != '\0') {
			optarg = (char *) &arg[s_optpos];
		} else if (p[2] == ':') {
			optarg = 0;			/* optional argument absent */
		} else if (optind + 1 < argc) {
			optarg = argv[++optind];
		} else {
			optopt = c;
			optind++; s_optpos = 0;
			if (*optstring == ':') return ':';
			if (opterr) fprintf (stderr, "%s: option requires an argument -- '%c'\n", argv[0], c);
			return '?';
		}
		optind++; s_optpos = 0;
	} else if (arg[s_optpos] == '\0') {
		optind++; s_optpos = 0;
	}
	return c;
}

int getopt_long (int argc, char * const argv[], const char *optstring,
		 const struct option *longopts, int *longindex)
{
	(void) longopts; (void) longindex;
	return getopt (argc, argv, optstring);
}

/* ---------------------------------------------------------------- sscanf */
/* Minimal: %d %i %u %x %ld %lu %f %lf %s %c and literal characters. */
#include <stdarg.h>
int sscanf (const char *s, const char *fmt, ...)
{
	va_list ap;
	va_start (ap, fmt);
	int n = 0;
	while (*fmt) {
		if (isspace ((unsigned char) *fmt)) {
			while (isspace ((unsigned char) *s)) s++;
			fmt++;
			continue;
		}
		if (*fmt != '%') {
			if (*s != *fmt) break;
			s++; fmt++;
			continue;
		}
		fmt++;
		int is_long = 0;
		while (*fmt == 'l' || *fmt == 'h') { if (*fmt == 'l') is_long = 1; fmt++; }
		char conv = *fmt++;
		if (conv != 'c') while (isspace ((unsigned char) *s)) s++;
		char *end;
		if (conv == 'd' || conv == 'i' || conv == 'u' || conv == 'x') {
			int base = (conv == 'x') ? 16 : (conv == 'i' ? 0 : 10);
			long v = strtol (s, &end, base);
			if (end == s) break;
			if (is_long) *va_arg (ap, long *) = v; else *va_arg (ap, int *) = (int) v;
			s = end; n++;
		} else if (conv == 'f' || conv == 'g' || conv == 'e') {
			double v = strtod (s, &end);
			if (end == s) break;
			if (is_long) *va_arg (ap, double *) = v; else *va_arg (ap, float *) = (float) v;
			s = end; n++;
		} else if (conv == 's') {
			char *d = va_arg (ap, char *);
			if (!*s) break;
			while (*s && !isspace ((unsigned char) *s)) *d++ = *s++;
			*d = '\0'; n++;
		} else if (conv == 'c') {
			if (!*s) break;
			*va_arg (ap, char *) = *s++; n++;
		} else {
			break;
		}
	}
	va_end (ap);
	return n;
}
