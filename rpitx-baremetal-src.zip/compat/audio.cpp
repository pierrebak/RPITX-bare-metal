//
// audio.cpp - audio output for the tools (bm_audio_*, see bm_compat.h)
//
// rpitx-baremetal: port of rpitx v1 (F5OEO) to Raspberry Pi 1 without Linux.
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Circle's sound devices in queue mode: the tool writes interleaved stereo
// int16 frames, the DMA interrupt takes them from the queue. The device
// object stays allocated between tools (its DMA channel and buffers too) and
// is only rebuilt when the output or the rate changes.
//
// PWM output (3.5 mm jack): Circle derives the PWM clock from PLLD assuming
// 500 MHz. With the rpitx dt-blob.bin PLLD runs at 1000 MHz ("set plld 1000")
// and everything would play twice too fast: the requested rate is scaled
// back so that the real rate is the one asked for.
//
#include "bm_internal.h"
#include <bm_compat.h>
#include <circle/interrupt.h>
#include <circle/timer.h>
#include <circle/sound/pwmsoundbasedevice.h>
#include <circle/sound/hdmisoundbasedevice.h>
#include <circle/machineinfo.h>
#include <circle/gpiopin.h>
#include <circle/memio.h>
#include <circle/bcm2835.h>
#include <circle/string.h>
#include <circle/util.h>

static CSoundBaseDevice *s_pSound = 0;
static int s_nHDMI = -1;
static unsigned s_nRate = 0;
static unsigned s_nQueueMs = 0;
static unsigned s_nPLLD = 0;
static boolean s_bCleanupSet = FALSE;

static void StopSound (void)
{
	if (s_pSound != 0 && s_pSound->IsActive ())
	{
		s_pSound->Cancel ();
		uint64_t nStart = bm_micros ();
		while (s_pSound->IsActive () && bm_micros () - nStart < 200000)
		{
			// Cancel takes effect at the end of the current chunk
		}
	}
}

static void AudioCleanup (void)
{
	StopSound ();
	s_bCleanupSet = FALSE;
}

extern "C" int bm_audio_open (unsigned nRate, int nHDMI, unsigned nQueueMs)
{
	nHDMI = nHDMI ? 1 : 0;
	if (nQueueMs < 20)
	{
		nQueueMs = 20;
	}

	StopSound ();

	if (   s_pSound == 0 || s_nHDMI != nHDMI || s_nRate != nRate
	    || s_nQueueMs != nQueueMs || s_nPLLD != (unsigned) bm_plld_mhz)
	{
		delete s_pSound;
		s_pSound = 0;

		CInterruptSystem *pInterrupt = CInterruptSystem::Get ();
		if (nHDMI)
		{
			s_pSound = new CHDMISoundBaseDevice (pInterrupt, nRate);
		}
		else
		{
			// 2048 words per chunk: 32 ms at 32 kHz, the interrupt rate
			// stays low while the receiver keeps the CPU busy
			unsigned nAsked = (unsigned) ((uint64_t) nRate * 500 / bm_plld_mhz);
			s_pSound = new CPWMSoundBaseDevice (pInterrupt, nAsked, 2048);
		}
		if (s_pSound == 0)
		{
			return -1;
		}
		if (!s_pSound->AllocateQueue (nQueueMs))
		{
			delete s_pSound;
			s_pSound = 0;
			return -1;
		}
		s_pSound->SetWriteFormat (SoundFormatSigned16, 2);
		s_nHDMI = nHDMI;
		s_nRate = nRate;
		s_nQueueMs = nQueueMs;
		s_nPLLD = (unsigned) bm_plld_mhz;
	}

	if (!s_pSound->Start ())
	{
		return -1;
	}
	if (!nHDMI)
	{
		// les broches de la prise sont mises en ALT0 (PWM) a la creation du
		// peripherique, qui est garde d'un outil a l'autre : on le reimpose
		CMachineInfo *pInfo = CMachineInfo::Get ();
		unsigned Pins[2] = {pInfo->GetGPIOPin (GPIOPinAudioLeft),
				    pInfo->GetGPIOPin (GPIOPinAudioRight)};
		for (unsigned i = 0; i < 2; i++)
		{
			uintptr nReg = ARM_GPIO_GPFSEL0 + 4 * (Pins[i] / 10);
			unsigned nShift = 3 * (Pins[i] % 10);
			write32 (nReg, (read32 (nReg) & ~(7 << nShift)) | (4 << nShift));
		}
	}
	if (!s_bCleanupSet)
	{
		s_bCleanupSet = TRUE;
		bm_add_cleanup (AudioCleanup);
	}
	return 0;
}

// Circle : GetQueueFramesAvail () = trames EN ATTENTE dans la file (et non la
// place libre) ; la file garde un octet libre, d'ou le -1
extern "C" unsigned bm_audio_space (void)
{
	if (s_pSound == 0)
	{
		return 0;
	}
	unsigned nSize = s_pSound->GetQueueSizeFrames ();
	unsigned nQueued = s_pSound->GetQueueFramesAvail ();
	return nQueued + 1 < nSize ? nSize - nQueued - 1 : 0;
}

extern "C" unsigned bm_audio_queued (void)
{
	return s_pSound != 0 ? s_pSound->GetQueueFramesAvail () : 0;
}

extern "C" int bm_audio_write (const int16_t *pLR, unsigned nFrames)
{
	if (s_pSound == 0)
	{
		return 0;
	}
	int nBytes = s_pSound->Write (pLR, nFrames * 2 * sizeof (int16_t));
	return nBytes > 0 ? nBytes / (int) (2 * sizeof (int16_t)) : 0;
}

extern "C" void bm_audio_close (void)
{
	StopSound ();
}

// Diagnostic (rtlfm -T) : modele detecte, broches de la prise jack et leur
// fonction reelle (registres GPFSEL), registres du PWM
static unsigned PinFunction (unsigned nPin)
{
	u32 nReg = read32 (ARM_GPIO_GPFSEL0 + 4 * (nPin / 10));
	return (nReg >> (3 * (nPin % 10))) & 7;
}

extern "C" void bm_audio_info (char *pBuffer, unsigned nSize)
{
	static const char *Func[8] = {"entree", "sortie", "ALT5", "ALT4", "ALT0", "ALT1", "ALT2", "ALT3"};
	CMachineInfo *pInfo = CMachineInfo::Get ();
	unsigned nLeft = pInfo->GetGPIOPin (GPIOPinAudioLeft);
	unsigned nRight = pInfo->GetGPIOPin (GPIOPinAudioRight);
	CString Msg;
	Msg.Format ("%s (rev. %06x) : gauche GPIO %u en %s, droite GPIO %u en %s, "
		    "PWM CTL %08x RNG %u/%u STA %08x",
		    pInfo->GetMachineName (), pInfo->GetRevisionRaw (),
		    nLeft, Func[PinFunction (nLeft)], nRight, Func[PinFunction (nRight)],
		    read32 (ARM_PWM_CTL), read32 (ARM_PWM_RNG1), read32 (ARM_PWM_RNG2),
		    read32 (ARM_PWM_STA));
	strncpy (pBuffer, Msg, nSize - 1);
	pBuffer[nSize - 1] = '\0';
}
