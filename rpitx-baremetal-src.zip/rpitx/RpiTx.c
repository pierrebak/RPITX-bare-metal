/*
 
   <rpitx is a software which use the GPIO of Raspberry Pi to transmit HF>

    Copyright (C) 2015  Evariste COURJAUD F5OEO (evaristec@gmail.com)

    Transmitting on HF band is surely not permitted without license (Hamradio for example).
    Usage of this software is not the responsability of the author.
	
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
   
   Thanks to first test of RF with Pifm by Oliver Mattos and Oskar Weigl 	
   INSPIRED BY THE IMPLEMENTATION OF PIFMDMA by Richard Hirst <richardghirst@gmail.com>  December 2012
   Helped by a code fragment by PE1NNZ (http://pe1nnz.nl.eu.org/2013/05/direct-ssb-generation-on-pll.html)

   ---------------------------------------------------------------------------
   rpitx-baremetal (2026): port of this file to the Raspberry Pi 1 without
   Linux (Circle runtime). Every change is marked "BAREMETAL". Summary:
    - no mmap/mailbox/pthread/NTP: see RpiDma.c, RpiGpio.c, compat/;
    - the L1 data cache is cleaned before the DMA engine reads new data;
    - main() is rpitx_main(), called by the shell; all global state is
      re-initialised at each run (no new process between two commands);
    - sleeping polls the console (Ctrl-C / ESC raises SIGINT -> terminate())
      and the USB streaming used by rtl2tx;
    - v1 bug fixed: the -p ppm value given by the user was replaced by the
      (zero) NTP value; it is now used. There is no NTP on bare metal;
    - PLLD frequency comes from the "plld" setting (1000 MHz with the
      rpitx dt-blob.bin, as in v1);
    - "inline" functions made "static inline" (C99 inline semantics);
    - above PLLD/4 the signal is the harmonic H of F/H, not H*H of F/(H*H)
      (see pitx_SetTuneFrequency), and the IQ offset no longer depends on H.
   ---------------------------------------------------------------------------
 */

/* ================== TODO =====================	
Optimize CPU on PWMFrequency
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <getopt.h>
#include "RpiGpio.h"
#include "RpiDma.h"
#include <bm_compat.h>	// BAREMETAL

#include "RpiTx.h"

#define AMP_BYPAD

//Minimum Time in us to sleep
// BAREMETAL: no scheduler latency, keep a small margin for the work done
// while waiting (USB streaming, SD card reads)
#define KERNEL_GRANULARITY 2000 



#define PROGRAM_VERSION "0.2-baremetal"

#define PLL_FREQ_500MHZ		500000000	// PLLD is running at 500MHz
#define PLL_500MHZ 		0x6

//#define PLL_FREQ_1GHZ             1000000000	//PLLC = 1GHZ
//#define PLL_1GHZ			0x5

// BAREMETAL: PLLD frequency taken from the "plld" setting (1000 MHz by default,
// which requires the rpitx dt-blob.bin on the SD card, as on Linux)
#define PLL_FREQ_1GHZ             ((uint32_t)bm_plld_mhz*1000000UL)	//PLL = 1GHZ
#define PLL_1GHZ			0x6     //PLLD = 1GHZ ONLY AFTER APLYINg DT-BLOB.BIN !!!! WARNING !!!


#define PLLFREQ_192             19200000	//PLLA = 19.2MHZ
#define PLL_192			0x1

#define HEADER_SIZE 44

// DMA TIMING : depends on Pi Model : Calibration is better
#define FREQ_DELAY_TIME 0
int FREQ_MINI_TIMING=157;
int PWMF_MARGIN = 1120; //A Margin for now at 1us with PCM ->OK
int globalppmpll=0;

typedef unsigned char 	uchar;      // 8 bit
typedef unsigned short	uint16;     // 16 bit
typedef unsigned int	uint;       // 32 bits

//F5OEO Variable
uint32_t PllFreq500MHZ;
uint32_t PllFreq1GHZ;
uint32_t PllFreq19MHZ;

uint32_t PllUsed;
char PllNumber;
double TuneFrequency=62500000;
unsigned char FreqDivider=2;
int DmaSampleBurstSize=1000;
int NUM_SAMPLES=NUM_SAMPLES_MAX;
int Randomize=0;

uint32_t GlobalTabPwmFrequency[50];

//End F5OEO

char EndOfApp=0;
unsigned char loop_mode_flag=0;
char *FileName = 0;
int FileInHandle = -1; //Handle in Transport Stream File
int useStdin = 0;

static void udelay(int us)
{
	bm_udelay(us);	// BAREMETAL: register settle delays, busy wait
}

static void stop_dma(void)
{
	
	if (FileInHandle != -1) {
		close(FileInHandle);
		FileInHandle = -1;
	}
	if (dma_reg) {
		//Stop Main DMA
		//STop DMA
		dma_reg[DMA_CS+DMA_CHANNEL*0x40] |= DMA_CS_ABORT;
		udelay(100);
		dma_reg[DMA_CS+DMA_CHANNEL*0x40]&= ~DMA_CS_ACTIVE;
		dma_reg[DMA_CS+DMA_CHANNEL*0x40] |= DMA_CS_RESET;
		udelay(100);
		

		//printf("Reset DMA Done\n");
		clk_reg[GPCLK_CNTL] = 0x5A << 24  | 0 << 9 | 1 << 4 | 6; //NO MASH !!!
		udelay(500);
		gpio_reg[GPFSEL0] = (gpio_reg[GPFSEL0] & ~(7 << 12)) | (0 << 12); //DISABLE CLOCK -
		clk_reg[PWMCLK_CNTL] = 0x5A000006 | (0 << 9) ;
		udelay(500);	
		clk_reg[PCMCLK_CNTL] = 0x5A000006;	
		udelay(500);
		//printf("Resetpcm Done\n");
		pwm_reg[PWM_DMAC] = 0;
		udelay(100);
		pwm_reg[PWM_CTL] = PWMCTL_CLRF;
		udelay(100);
		//printf("Reset pwm Done\n");
	}
	// BAREMETAL: the DMA memory is kept for the next run (no mailbox)
}

static void terminate(int dummy)
{
	stop_dma();
	//munmap(virtbase,NUM_PAGES * PAGE_SIZE); 
	printf("END OF PiTx\n");
	exit(1);
}

static void fatal(char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	vfprintf(stderr, fmt, ap);
	va_end(ap);
	terminate(0);
}

void setSchedPriority(int priority) 
{
	//In order to get the best timing at a decent queue size, we want the kernel to avoid interrupting us for long durations.
	//This is done by giving our process a high priority. Note, must run as super-user for this to work.
	(void) priority;	// BAREMETAL: single thread, nothing to do

}

// BAREMETAL: transmit statistics (see RpiTx.h), printed every 10 s in the
// IQ modes unless pitx_quiet_stats is set (rtl2tx prints its own line)
volatile pitx_stats_t pitx_stats;
int pitx_quiet_stats=0;
double pitx_iq_rate=0;		// BAREMETAL: see RpiTx.h
double pitx_iq_offset_hz=0;

static void pitx_print_stats(int SampleRate)
{
	uint64_t now=bm_micros();
	uint64_t dt=now-pitx_stats.start_us;
	if(dt==0) return;
	printf("TX: DMA %.1f kS/s (nominal %.1f), CPU %u%%, DMA underruns %u\n",
		(double)pitx_stats.dma_samples*1000.0/(double)dt, SampleRate/1000.0,
		(unsigned)(pitx_stats.busy_us*100/dt), (unsigned)pitx_stats.underruns);
}

uint32_t DelayFromSampleRate=0;
int Instrumentation=0;
int UsePCMClk=0;
uint32_t Originfsel=0;

int SetupGpioClock(uint32_t SymbolRate,double TuningFrequency)
{
	char MASH=1;
	 	
	if(UsePCMClk==0) TuningFrequency=TuningFrequency*2;	
	if((TuningFrequency>=100e6)&&(TuningFrequency<=150e6))
	{
		MASH=2;
	}
	if(TuningFrequency<100e6)
	{
		MASH=3;
	}
	
	printf("MASH %d Freq PLL# %d\n",MASH,PllNumber);
	Originfsel=gpio_reg[GPFSEL0]; // Warning carefull if FSEL is used after !!!!!!!!!!!!!!!!!!!!
	if(UsePCMClk==1)
			gpio_reg[GPFSEL0] = (Originfsel & ~(7 << 12)) | (4 << 12); //ENABLE CLOCK ON GPIO CLK

		
	// ------------------- MAKE MAX OUTPUT CURRENT FOR GPIO -----------------------
	char OutputPower=7;
	pad_gpios_reg[PADS_GPIO_0] = 0x5a000000 + (OutputPower&0x7) + (1<<4) + (0<<3); // Set output power for I/Q GPIO18/GPIO19 

#ifdef USE_PCM
	//------------------- Init PCM ------------------
	pcm_reg[PCM_CS_A] = 1;				// Disable Rx+Tx, Enable PCM block
	udelay(100);
	clk_reg[PCMCLK_CNTL] = 0x5A000000|PLL_1GHZ;		// Source=PLLC (1GHHz) STOP PLL
	udelay(1000);
	static uint32_t FreqDividerPCM;
	static uint32_t FreqFractionnalPCM;
	int NbStepPCM = 25; // Should not exceed 1000 : 
	
	FreqDividerPCM=(int) ((double)PllFreq1GHZ/(SymbolRate*NbStepPCM/**PwmNumberStep*/));
	FreqFractionnalPCM=4096.0 * (((double)PllFreq1GHZ/(SymbolRate*NbStepPCM/**PwmNumberStep*/))-FreqDividerPCM);
	
	printf("SampleRate=%d\n",SymbolRate);
	if((FreqDividerPCM>4096)||(FreqDividerPCM<2)) printf("Warning : SampleRate is not valid\n"); 
	clk_reg[PCMCLK_DIV] = 0x5A000000 | ((FreqDividerPCM)<<12) | FreqFractionnalPCM;
	udelay(1000);
	//printf("Div PCM %d FracPCM %d\n",FreqDividerPCM,FreqFractionnalPCM);
	
	 DelayFromSampleRate=(1e9/(SymbolRate));
			
	pcm_reg[PCM_TXC_A] = 0<<31 | 1<<30 | 0<<20 | 0<<16; // 1 channel, 8 bits
	udelay(100);
	
	//printf("Nb PCM STEP (<1000):%d\n",NbStepPCM);
	pcm_reg[PCM_MODE_A] = (NbStepPCM-1)<<10; // SHOULD NOT EXCEED 1000 !!!
	udelay(100);
	pcm_reg[PCM_CS_A] |= 1<<4 | 1<<3;		// Clear FIFOs
	udelay(100);
	pcm_reg[PCM_DREQ_A] = 64<<24 | /*64<<8 |*/ 64<<8 ;		//TX Fifo PCM=64 DMA Req when one slot is free?
	udelay(100);
	pcm_reg[PCM_CS_A] |= 1<<9;			// Enable DMA
	udelay(1000);
	clk_reg[PCMCLK_CNTL] = 0x5A000010 |(1 << 9)| PLL_1GHZ	/*PLL_1GHZ*/;		// Source=PLLC and enable
	udelay(100);
	pcm_reg[PCM_CS_A] |= 1<<2; //START TX PCM
#endif
	// FIN PCM

	//INIT PWM in Serial Mode : WE USE PWM OUPUT
	if(UsePCMClk==0)
	{
		gpioSetMode(18, 2); /* set to ALT5, PWM1 : RF On PIN */	

		pwm_reg[PWM_CTL] = 0;
		clk_reg[PWMCLK_CNTL] = 0x5A000000 | (MASH << 9) |PllNumber/*PLL_1GHZ*/ ;
		udelay(300);
		clk_reg[PWMCLK_DIV] = 0x5A000000 | (2<<12); //WILL BE UPDATED BY DMA
		udelay(300);
		clk_reg[PWMCLK_CNTL] = 0x5A000010 | (MASH << 9) | PllNumber /*PLL_1GHZ*/; //MASH3 : A TESTER SI MIEUX en MASH1
		//MASH 3 doesnt seem work above 80MHZ, back to MASH1
		pwm_reg[PWM_RNG1] = 32;// 250 -> 8KHZ
		udelay(100);
		pwm_reg[PWM_RNG2] = 32;// 32 Mandatory for Serial Mode without gap
	
		pwm_reg[PWM_FIFO]=0xAAAAAAAA;
		pwm_reg[PWM_DMAC] = PWMDMAC_ENAB | PWMDMAC_THRSHLD;
		udelay(100);
		pwm_reg[PWM_CTL] = PWMCTL_CLRF;
		udelay(100);
		pwm_reg[PWM_CTL] =   PWMCTL_USEF1| PWMCTL_MODE1| PWMCTL_PWEN1|PWMCTL_RPTL1; //PWM0 in Repeat mode 
	}
	// FIN INIT PWM

	//******************* INIT CLK MODE : WE OUTPUT CLK INSTEAD OF PWM OUTPUT
	if(UsePCMClk==1)
	{
		clk_reg[GPCLK_CNTL] = 0x5A000000 | (MASH << 9) |PllNumber/*PLL_1GHZ*/ ;
		udelay(300);
		clk_reg[GPCLK_DIV] = 0x5A000000 | (2<<12); //WILL BE UPDATED BY DMA !! CAREFUL NOT DIVIDE BY 2 LIKE PWM
		udelay(300);
		clk_reg[GPCLK_CNTL] = 0x5A000010 | (MASH << 9) | PllNumber /*PLL_1GHZ*/; //MASH3 : A TESTER SI MIEUX en MASH1
	}


	ctl = (struct control_data_s *)virtbase; // Struct ctl is mapped to the memory allocated by RpiDMA (Mailbox)
	dma_cb_t *cbp = ctl->cb;

	uint32_t phys_pwm_fifo_addr = 0x7e20c000 + 0x18;//PWM Fifo
	uint32_t phys_pwm_range_addr = 0x7e20c000 + 0x10;//PWM Range
	uint32_t phys_clock_div_addr = 0x7e101074;//CLOCK Frequency Setting
	uint32_t phys_pwm_clock_div_addr = 0x7e1010a4; //CLK PWM
	uint32_t phys_gpio_set_addr = 0x7e20001c;
	uint32_t phys_gpio_clear_addr = 0x7e200028;
	uint32_t dummy_gpio = 0x7e20b000;
	uint32_t phys_pcm_fifo_addr = 0x7e203004;
	uint32_t phys_gpio_pads_addr =0x7e10002c;		      
	uint32_t phys_pcm_clock =     0x7e10109c ;
	uint32_t phys_pcm_clock_div_addr = 0x7e10109c;//CLOCK Frequency Setting
	
	uint32_t phys_gpfsel = 0x7E200000 ; 
	int samplecnt;
	
		
	for (samplecnt = 0; samplecnt <  NUM_SAMPLES ; samplecnt++)
	{
		

//@0				
		//Set Amplitude by writing to PWM_SERIAL via PADS	
		cbp->info = 0;//BCM2708_DMA_NO_WIDE_BURSTS | BCM2708_DMA_WAIT_RESP  ;
		cbp->src = mem_virt_to_phys(&ctl->sample[samplecnt].Amplitude1);
		cbp->dst = phys_gpio_pads_addr;
		cbp->length = 4;
		cbp->stride = 0;
		cbp->next = mem_virt_to_phys(cbp + 1);		
		cbp++;
//@1				
		//Set Amplitude by writing to PWM_SERIAL via Patern	
		cbp->info = 0;//BCM2708_DMA_NO_WIDE_BURSTS | BCM2708_DMA_WAIT_RESP  ;
		cbp->src = mem_virt_to_phys(&ctl->sample[samplecnt].Amplitude2); 
		if(UsePCMClk==0) 
			cbp->dst = phys_pwm_fifo_addr;
		if(UsePCMClk==1) 
			cbp->dst = phys_gpfsel; 				
		cbp->length = 4;
		cbp->stride = 0;
		cbp->next = mem_virt_to_phys(cbp + 1); 
		cbp++;
//2
		//Set PWMFrequency
		cbp->info =/*BCM2708_DMA_NO_WIDE_BURSTS*/ BCM2708_DMA_SRC_INC|BCM2708_DMA_NO_WIDE_BURSTS;
		// BCM2708_DMA_WAIT_RESP : without 160ns, with 300ns
		cbp->src = mem_virt_to_phys(&ctl->sample[samplecnt].FrequencyTab[0]);
		if(UsePCMClk==0)		
			cbp->dst = phys_pwm_clock_div_addr;
		if(UsePCMClk==1)		
			cbp->dst = phys_clock_div_addr;
		cbp->length = 4; //Be updated by main DMA
		cbp->stride = 0;
		cbp->next = mem_virt_to_phys(cbp + 1); 
		cbp++;
	}
			
	cbp--;
	cbp->next = mem_virt_to_phys((void*)virtbase);
			

	// ------------------------------ END DMA INIT ---------------------------------
	
	dma_reg[DMA_CS+DMA_CHANNEL*0x40] = BCM2708_DMA_RESET;
	udelay(1000);
	dma_reg[DMA_CS+DMA_CHANNEL*0x40] = BCM2708_DMA_INT | BCM2708_DMA_END;
	udelay(100);
	dma_reg[DMA_CONBLK_AD+DMA_CHANNEL*0x40]=mem_virt_to_phys((void *)virtbase );
	udelay(100);
	dma_reg[DMA_DEBUG+DMA_CHANNEL*0x40] = 7; // clear debug error flags
	udelay(100);

	bm_clean_dcache();	// BAREMETAL: control blocks visible to the DMA engine
	
	return 1;		
}

#define ln(x) (log(x)/log(2.718281828459045235f))

static double s_prev_phase = 0;	// BAREMETAL: see IQToFreqAmp
static char s_ShowInfo = 1;	// BAREMETAL: see FrequencyAmplitudeToRegister

int arctan2(int y, int x) // Should be replaced with fast_atan2 from rtl_fm
{
	int abs_y = abs(y);
	int angle;
	if((x==0)&&(y==0)) return 0;
	if(x >= 0){
		angle = 45 - 45 * (x - abs_y) / ((x + abs_y)==0?1:(x + abs_y));
	} else {
		angle = 135 - 45 * (x + abs_y) / ((abs_y - x)==0?1:(abs_y - x));
	}
	return (y < 0) ? -angle : angle; // negate if in quad III or IV
}

void IQToFreqAmp(int I,int Q,double *Frequency,int *Amp,double SampleRate)	// BAREMETAL: double rate (pitx_iq_rate), same result for an int
{
	double phase;
	// BAREMETAL: file scope (s_prev_phase) so that it is reset at each run
	#define prev_phase s_prev_phase
	
	// BAREMETAL: sqrt(2) is not folded by the compiler (-fno-builtin); the
	// literal is the correctly rounded value, so the result is unchanged
	*Amp=round(sqrt( I*I + Q*Q)/1.41421356237309504880);
	//*Amp=*Amp*3; // Amp*5 pour la voix !! To be tested more
	if(*Amp>32767)
	{
		printf("!");
		*Amp=32767; //Overload
	}

	// BAREMETAL: arctan2() returns whole degrees in [-180, 180]: table of the
	// same expression, filled once (identical values, no division per sample)
	static double s_phase_tab[361];
	static char s_phase_init=0;
	if(!s_phase_init)
	{
		int a;
		for(a=-180;a<=180;a++) s_phase_tab[a+180]=M_PI + ((float)a) * M_PI/180.0f;
		s_phase_init=1;
	}
	phase = s_phase_tab[arctan2(I,Q)+180];
	double dp = phase - prev_phase;
	if(dp < 0) dp = dp + 2*M_PI;
    
	*Frequency = dp*SampleRate/(2.0f*M_PI);
	prev_phase = phase;
	//printf("I=%d Q=%d Amp=%d Freq=%d\n",I,Q,*Amp,*Frequency);
	#undef prev_phase
}




static inline void shuffle_int(uint32_t list[], size_t len)
{		
	int j;						
	uint32_t tmp;					
	while(len)
	{					
		j = rand() % (len+1);				
		if (j != len - 1)
		{			
			tmp = list[j];			
			list[j] = list[len - 1];	
			list[len - 1] = tmp;		
		}					
		len--;					
	}						
}	

static inline void FrequencyAmplitudeToRegister(double TuneFrequency,uint32_t Amplitude,int NoSample,uint32_t WaitNanoSecond,uint32_t SampleRate,char NoUsePWMF,int debug)
{
	#define ShowInfo s_ShowInfo	// BAREMETAL: reset at each run
				
	static uint32_t CompteurDebug=0;
	#define DEBUG_RATE 20000
	int PwmNumberStep;
	CompteurDebug++;
	static uint32_t TabPwmAmplitude[18]={0x00000000,
									0x80000000,0xA0000000,0xA8000000,0xAA000000,
									0xAA800000,0xAAA00000,0xAAA80000,0xAAAA0000,
									0xAAAA8000,0xAAAAA000,0xAAAAA800,0xAAAAAA00,
									0xAAAAAA80,0xAAAAAAA0,0xAAAAAAA8,0xAAAAAAAA,0xAAAAAAAA};
	
	
	
	static char First=1;
				
	ctl = (struct control_data_s *)virtbase; // Struct ctl is mapped to the memory allocated by RpiDMA (Mailbox)
	dma_cb_t *cbp = ctl->cb+NoSample*CBS_SIZE_BY_SAMPLE;
				
	static dma_cb_t *cbpwrite;
	uint32_t TimeRemaining=0;
				
	int SkipFrequency=0; //When WaitNano is too short, we don't set the frequency

	// WITH DMA_CTL WITHOUT BCM2708_DMA_WAIT_RESP
	// Time = NBStep * 157 ns + 1360 ns
				
	
				
	
	// BAREMETAL: the divisions below only depend on the arguments / on the
	// calibration: the last results are kept (same values, fewer divisions;
	// the ARM1176 has no integer divide instruction)
	static uint32_t s_LastRate=0, s_LastRateWait=0;
	static uint32_t s_LastWait=0xFFFFFFFF; static int s_LastMini=-1, s_LastMargin=-1;
	static int s_LastSteps=0, s_LastDelaySteps=0;
	if(WaitNanoSecond==0)
	{
		if(SampleRate!=0)
		{
			if(SampleRate!=s_LastRate)
			{
				s_LastRate=SampleRate;
				s_LastRateWait=(1e9/SampleRate);
			}
			WaitNanoSecond = s_LastRateWait;
		}
	}	
	if(WaitNanoSecond!=s_LastWait||FREQ_MINI_TIMING!=s_LastMini||PWMF_MARGIN!=s_LastMargin)
	{
		s_LastWait=WaitNanoSecond;
		s_LastMini=FREQ_MINI_TIMING;
		s_LastMargin=PWMF_MARGIN;
		s_LastSteps=WaitNanoSecond/FREQ_MINI_TIMING;
		s_LastDelaySteps=(PWMF_MARGIN+FREQ_DELAY_TIME)/FREQ_MINI_TIMING;
	}
	const int DelaySteps=s_LastDelaySteps;
				
	PwmNumberStep=s_LastSteps;
	if(PwmNumberStep>PWM_STEP_MAXI) PwmNumberStep=PWM_STEP_MAXI;
				

	// ********************************** PWM FREQUENCY PROCESSING *****************************
				
	if(UsePCMClk==0)
		TuneFrequency*=2.0; //Because of pattern 10
				
	// F1 < TuneFrequency < F2
	double PllRatio=(double)PllUsed/TuneFrequency;	// BAREMETAL: computed once
	uint32_t FreqDividerf2=(int) (PllRatio);
	uint32_t FreqFractionnalf2=4096.0 * ((PllRatio)-FreqDividerf2);
				
	uint32_t FreqDividerf1=(FreqFractionnalf2!=4095)?FreqDividerf2:FreqDividerf2+1;				
	uint32_t FreqFractionnalf1=(FreqFractionnalf2!=4095)?FreqFractionnalf2+1:0;
	
	// BAREMETAL: f1 / f2 only depend on the divider: kept from the last sample
	static uint32_t s_LastPll=0, s_LastDiv=0xFFFFFFFF, s_LastFrac=0xFFFFFFFF;
	static double s_f1, s_f2;
	if(PllUsed!=s_LastPll||FreqDividerf2!=s_LastDiv||FreqFractionnalf2!=s_LastFrac)
	{
		s_LastPll=PllUsed;
		s_LastDiv=FreqDividerf2;
		s_LastFrac=FreqFractionnalf2;
		s_f1=PllUsed/(FreqDividerf1+(double)FreqFractionnalf1/4096.0);
		s_f2=PllUsed/(FreqDividerf2+(double)FreqFractionnalf2/4096.0); // f2 is the higher frequency
	}
	double f1=s_f1;
	double f2=s_f2;
	double FreqTuningUp=s_f2;

	double FreqStep=f2-f1;
	static uint32_t RegisterF1;
	static uint32_t RegisterF2;		
							
	if(ShowInfo==1)
	{
		printf("WaitNano=%d F1=%f TuneFrequency %f F2=%f Initial Resolution(Hz)=%f ResolutionPWMF %f NbStep=%d DELAYStep=%d\n",WaitNanoSecond,f1,TuneFrequency,f2,FreqStep,FreqStep/(PwmNumberStep),PwmNumberStep,(PWMF_MARGIN+FREQ_DELAY_TIME)/FREQ_MINI_TIMING);
		ShowInfo=0;
	}
				
	static int DebugStep=71;
	double	fPWMFrequency=((FreqTuningUp-TuneFrequency)*1.0*(double)(PwmNumberStep)/FreqStep); // Give NbStep of F2
	int PWMFrequency=round(fPWMFrequency);
				
	//printf("PWMF =%d PWMSTEP=%d\n",PWMFrequency,PwmNumberStep);
	/*if((CompteurDebug%DEBUG_RATE)==0)
	{
		DebugStep=(DebugStep+1)%PwmNumberStep;
		//printf("PwmNumberStep %d Step %d\n",PwmNumberStep,DebugStep);
	}
	PWMFrequency=(DebugStep);*/
				
	//if((CompteurDebug%200)==0) printf("PwmNumberStep =%d TuneFrequency %f : FreqTuning %f FreqStep %f PwmFreqStep %f fPWMFrequency %f PWMFrequency %d f1 %f f2 %f %x %x\n",PwmNumberStep,TuneFrequency,FreqTuning,FreqStep,FreqStep/PwmNumberStep,fPWMFrequency,PWMFrequency,f1,f2,RegisterF1,RegisterF2);

	int i;
				
	static int NbF1,NbF2,NbF1F2;
	NbF1=0;
	NbF2=0;
	NbF1F2=0;

	
	int AdaptPWMFrequency;			
	if((PwmNumberStep-PWMFrequency-DelaySteps)>PwmNumberStep/2)
	{
		RegisterF1=0x5A000000 | (FreqDividerf1<<12) | (FreqFractionnalf1);
		RegisterF2=0x5A000000 | (FreqDividerf2<<12) | (FreqFractionnalf2);
		AdaptPWMFrequency=PWMFrequency;
		NbF1=0;
		NbF2=DelaySteps;
		
	}
	else // SWAP F1 AND F2
	{
		//if((CompteurDebug%DEBUG_RATE)==0) printf("-");
		RegisterF2=0x5A000000 | (FreqDividerf1<<12) | (FreqFractionnalf1);
		RegisterF1=0x5A000000 | (FreqDividerf2<<12) | (FreqFractionnalf2);
		AdaptPWMFrequency=PwmNumberStep-PWMFrequency;
		NbF1=0;
		NbF2=DelaySteps;
	}
				
	i=0;
	NbF1F2=NbF1+NbF2;
	
	if(NoUsePWMF==1)
	{
		RegisterF1=0x5A000000 | (FreqDividerf1<<12) | (FreqFractionnalf1);
		RegisterF2=0x5A000000 | (FreqDividerf2<<12) | (FreqFractionnalf2);
		i=0;
		ctl->sample[NoSample].FrequencyTab[i++]=RegisterF2;
	}
	else
	{			
		while(NbF1F2<PwmNumberStep-1)
		{
			if(NbF1<AdaptPWMFrequency) 
			{
				ctl->sample[NoSample].FrequencyTab[i++]=RegisterF1;
				NbF1++;
				NbF1F2++;
			}
			if(NbF2<PwmNumberStep-AdaptPWMFrequency-1)
			{
				ctl->sample[NoSample].FrequencyTab[i++]=RegisterF2;
				NbF2++;
				NbF1F2++;
			}
		}
		if (Randomize)
			shuffle_int(ctl->sample[NoSample].FrequencyTab,i);
			
		//SHould finished by F2
		ctl->sample[NoSample].FrequencyTab[i++]=RegisterF2;
		NbF2++;
		NbF1F2++;
	}	
				
	cbpwrite=cbp+2;
	cbpwrite->length=i*4;
	#undef ShowInfo

	
				
	// ****************************** AMPLITUDE PROCESSING **********************************************
				
	
	Amplitude=(Amplitude>32767)?32767:Amplitude;	
	int IntAmplitude=(Amplitude*7.0)/32767.0; // Convert to 8 amplitude step
				
	if(UsePCMClk==0)
	{
		if(IntAmplitude==0)
		{
			ctl->sample[NoSample].Amplitude2=0x0;
		}
		else
		{
			ctl->sample[NoSample].Amplitude2=0xAAAAAAAA;					
		}
	}
	if(UsePCMClk==1)
	{
		if(IntAmplitude==0)
		{
			ctl->sample[NoSample].Amplitude2=(Originfsel & ~(7 << 12)) | (0 << 12);
		}
		else
		{
			ctl->sample[NoSample].Amplitude2=(Originfsel & ~(7 << 12)) | (4 << 12);
		}
	}

	static int OldIntAmplitude=0;
				
	
	if(IntAmplitude>7) IntAmplitude=7;
	
	ctl->sample[NoSample].Amplitude1=0x5a000000 + (IntAmplitude&0x7) + (1<<4) + (0<<3); 
				

}





int GetDMADelay(int Step)
{
	
	//Calibrate DMA Rate
	// =====================================================
	static volatile uint32_t cur_cb,last_cb;
	struct timespec gettime_now;
	int32_t start_time,time_difference;
	int last_sample;
	int this_sample; 
	int free_slots;

	dma_cb_t *cbp = ctl->cb;
	cur_cb = (uint32_t)virtbase; // DMA AT 1st CBS
	dma_reg[DMA_CONBLK_AD+DMA_CHANNEL*0x40]=mem_virt_to_phys((void*)cur_cb);
	usleep(100);
	int samplecnt;
	for (samplecnt = 0; samplecnt <  NUM_SAMPLES ; samplecnt++)
	{
		
		cbp+=2;
		cbp->length = (uint32_t)4L*Step;
		cbp++;
	}
	bm_clean_dcache();	// BAREMETAL
	
	dma_reg[DMA_CS+DMA_CHANNEL*0x40] = DMA_CS_PRIORITY(7) | DMA_CS_PANIC_PRIORITY(7) | DMA_CS_DISDEBUG |DMA_CS_ACTIVE;	// START DMA : go, mid priority, wait for outstanding writes :7 Seems Max Priority
	usleep(5000); //Wait to be sure DMA is running stable
	int i;
	int SumDelay=0;
	for(i=0;i<10;i++)
	{

	

		last_cb = mem_phys_to_virt((uint32_t)(dma_reg[DMA_CONBLK_AD+DMA_CHANNEL*0x40]));
		last_sample = (last_cb - (uint32_t)virtbase) / (sizeof(dma_cb_t) * CBS_SIZE_BY_SAMPLE);

		clock_gettime(CLOCK_REALTIME, &gettime_now);
		start_time = gettime_now.tv_nsec;

		// ONE SAMPLE SHOULD BE MINIMUM AROUND Time = NBStep * 157 ns + 1360 ns +1360*4 ns = 6us and MAX 200*157+1360*5 = 35us
		// Sleep at 80% de DELAY*NUM_SAMPLE
		// BY removing 2 CBP = 300ns gain
		do
		{
			usleep(10);
			cur_cb = mem_phys_to_virt((uint32_t)(dma_reg[DMA_CONBLK_AD+DMA_CHANNEL*0x40]));
			this_sample = (cur_cb - (uint32_t)virtbase) / (sizeof(dma_cb_t) * CBS_SIZE_BY_SAMPLE);
			free_slots = this_sample - last_sample;
			if (free_slots < 0) // WARNING : ORIGINAL CODE WAS < strictly
				free_slots += NUM_SAMPLES;
			clock_gettime(CLOCK_REALTIME, &gettime_now);
		
		}
		while(free_slots<=NUM_SAMPLES*0.6);
	 	
	

		time_difference = gettime_now.tv_nsec - start_time;
		if(time_difference<0) time_difference+=1E9;

		//printf("Delay = %d\n",time_difference/free_slots);

		SumDelay+=time_difference/free_slots;
	}
	
	//STop DMA
	dma_reg[DMA_CS+DMA_CHANNEL*0x40] |= DMA_CS_ABORT;//BCM2708_DMA_INT | BCM2708_DMA_END;
	udelay(100);
	dma_reg[DMA_CS+DMA_CHANNEL*0x40]&= ~DMA_CS_ACTIVE;
	dma_reg[DMA_CS+DMA_CHANNEL*0x40] |= DMA_CS_RESET; //BCM2708_DMA_ABORT|BCM2708_DMA_RESET;
	udelay(100);

	return SumDelay/10;
}

int CalibrateSystem(int *ppm,int *BaseDelayDMA,int *StepDelayDMA)
{
	//Calibrate Clock system (surely depends also on PLL PPM
	// =====================================================
	// BAREMETAL: no NTP daemon to read a clock drift from: ppm stays 0,
	// use the -p option to correct the PLL frequency.
	*ppm=0;
	//printf("Clock PPM = %f\n",ppm);
	int i; 
	int BaseDelay=0;
	BaseDelay=GetDMADelay(0);

	*BaseDelayDMA=BaseDelay;
	*StepDelayDMA=(GetDMADelay(PWM_STEP_MAXI/2)-(*BaseDelayDMA))/(PWM_STEP_MAXI/2);
	//for(i=1;i<200;i+=10)
		//printf("Step %d =%d\n",i,(GetDMADelay(i)-BaseDelay)/i);
	return 1;
}

int pitx_init(int SampleRate, double TuningFrequency, int* skipSignals,int SetDma)
{	
	InitGpio();
	if(!InitDma(terminate, skipSignals))
		fatal("DMA initialisation failed\n");
	if(SetDma)
	{
		// BAREMETAL: an explicit channel must still be free for the ARM
		if(bm_alloc_dma_channel(SetDma)==0xFF)
			fatal("DMA channel %d is not available\n",SetDma);
		DMA_CHANNEL=SetDma;
	}
	bm_add_cleanup(stop_dma);	// BAREMETAL: RF off whatever ends the tool
	SetupGpioClock(SampleRate,TuningFrequency);
//int FREQ_MINI_TIMING=157;
//int PWMF_MARGIN = 1120; //A Margin for now at 1us with PCM ->OK

	if(CalibrateSystem(&globalppmpll,&PWMF_MARGIN,&FREQ_MINI_TIMING))
		printf("Calibrate : ppm=%d DMA %dns:%dns\n",globalppmpll,FREQ_MINI_TIMING,PWMF_MARGIN);
	//printf("Timing : 1 cyle=%dns 1sample=%dns\n",NBSAMPLES_PWM_FREQ_MAX*400*3,(int)(1e9/(float)SampleRate));
	return 1;
}

void print_usage(void)
{

fprintf(stderr,\
"\nrpitx -%s\n\
Usage:\nrpitx [-i File Input][-m ModeInput] [-f frequency output] [-s Samplerate] [-l] [-p ppm] [-h] \n\
-m            {IQ(FileInput is a Stereo Wav contains I on left Channel, Q on right channel)}\n\
              {IQFLOAT(FileInput is a Raw float interlaced I,Q)}\n\
              {RF(FileInput is a (double)Frequency,Time in nanoseconds}\n\
       	      {RFA(FileInput is a (double)Frequency,(int)Time in nanoseconds,(float)Amplitude}\n\
	      {VFO (constant frequency)}\n\
-i            path to File Input (on the SD card) \n\
-f float      frequency to output on GPIO_18 pin 12 in khz : (130 kHz to 750 MHz),\n\
-l            loop mode for file input\n\
-p float      frequency correction in parts per million (ppm), positive or negative, for calibration, default 0.\n\
-d int 	      DMABurstSize (default 1000) but for very short message, could be decrease\n\
-c 1          Transmit on GPIO 4 (Pin 7) instead of GPIO 18\n\
-h            help (this help).\n\
Ctrl-C or ESC stops the transmission.\n\
\n",\
PROGRAM_VERSION);

} /* end function print_usage */



double GlobalTuningFrequency;
int HarmonicNumber =1;

int pitx_SetTuneFrequency(double Frequency)
{
	#define MAX_HARMONIC 41
	int harmonic;
	
	if(Frequency<PLL_FREQ_1GHZ/2048L) //2/4096-> For very Low Frequency we used 19.2 MHZ PLL 
	{
		PllUsed=PllFreq19MHZ;
		PllNumber=PLL_192;
	}
	else 
	{
		PllUsed=PllFreq1GHZ;
		PllNumber=PLL_1GHZ;
	}
	
	printf("Master PLL = %d\n",PllUsed);
		
	for(harmonic=1;harmonic<MAX_HARMONIC;harmonic+=2)
	{
		//printf("->%lf harmonic %d\n",(TuneFrequency/(double)harmonic),harmonic);
		if((Frequency/(double)harmonic)<=(double)PllUsed/4.0) break;
	}
	HarmonicNumber=harmonic;	

	//HarmonicNumber=11; //TEST

	/* BAREMETAL: v1 divided by HarmonicNumber again in pitx_run(), so the
	   wanted signal was the harmonic H*H of F/(H*H) (25th at 434 MHz with
	   PLLD at 500 MHz). pitx_run() now uses GlobalTuningFrequency = F/H as the
	   fundamental: the wanted signal is harmonic H, H times stronger (1/H of
	   the fundamental for a square wave instead of 1/H^2). */
	if(HarmonicNumber>1) //Use Harmonic
	{
		GlobalTuningFrequency=Frequency/HarmonicNumber;			
		printf("\n Warning : Using harmonic %d\n",HarmonicNumber);
	}
	else
	{
		GlobalTuningFrequency=Frequency;
	}
	return 1;
}

/* BAREMETAL: pitx_harmonic_for() and pitx_iq_set_frequency() are in
   pitx_freq.c (they must follow pitx_SetTuneFrequency() above). */

/** Wrapper around read. */
static ssize_t readFile(void *buffer, const size_t count) 
{
	return read(FileInHandle, buffer, count);
}
static void resetFile(void) 
{
	lseek(FileInHandle, 0, SEEK_SET);
}

// BAREMETAL: restore the initial values of the globals (each shell command
// runs in the same address space, there is no fresh process)
void pitx_reset_state(void)
{
	pitx_quiet_stats=0;
	pitx_iq_rate=0;
	pitx_iq_offset_hz=0;
	FREQ_MINI_TIMING=157;
	PWMF_MARGIN = 1120;
	globalppmpll=0;
	TuneFrequency=62500000;
	FreqDivider=2;
	DmaSampleBurstSize=1000;
	NUM_SAMPLES=NUM_SAMPLES_MAX;
	Randomize=0;
	EndOfApp=0;
	loop_mode_flag=0;
	FileName = 0;
	FileInHandle = -1;
	useStdin = 0;
	DelayFromSampleRate=0;
	Instrumentation=0;
	UsePCMClk=0;
	Originfsel=0;
	HarmonicNumber =1;
	GlobalTuningFrequency=0;
	s_prev_phase=0;
	s_ShowInfo=1;
}

int rpitx_main(int argc, char* argv[])
{
	int a;
	int anyargs = 0;
	pitx_reset_state();	// BAREMETAL
#ifdef BM_QEMU_TEST
	/* Test build for QEMU only (make BM_EXTRA=-DBM_QEMU_TEST): QEMU emulates
	   neither the PWM / clock manager nor a cyclic DMA chain. */
	{
		int i;
		printf("QEMU test build, not transmitted: rpitx");
		for(i=1;i<argc;i++) printf(" %s",argv[i]);
		printf("\n");
		return 0;
	}
#endif
	char Mode = MODE_IQ;  // By default
	int SampleRate=48000;
	float SetFrequency=1e6;//1MHZ
	float ppmpll=0.0;
	char NoUsePwmFrequency=0;
	int SetDma=0;
	while(1)
	{
		a = getopt(argc, argv, "i:f:m:s:p:hld:w:c:ra:");
	
		if(a == -1) 
		{
			if(anyargs) break;
			else a='h'; //print usage and exit
		}
		anyargs = 1;	

		switch(a)
		{
		case 'i': // File name
			FileName = optarg;
			break;
		case 'f': // Frequency
			SetFrequency = atof(optarg);
			break;
		case 'm': // Mode (IQ,IQFLOAT,RF,RFA)
			if(strcmp("IQ",optarg)==0) Mode=MODE_IQ;
			if(strcmp("RF",optarg)==0) Mode=MODE_RF;	
			if(strcmp("RFA",optarg)==0) Mode=MODE_RFA;
			if(strcmp("IQFLOAT",optarg)==0) Mode=MODE_IQ_FLOAT;
			if(strcmp("VFO",optarg)==0) Mode=MODE_VFO;
			break;
		case 's': // SampleRate (Only needeed in IQ mode)
			SampleRate = atoi(optarg);
			break;
		case 'p':  //	ppmcorrection
			ppmpll = atof(optarg);
			
			break;
		case 'h': // help
			print_usage();
			exit(1);
			break;
		case 'l': // loop mode
			loop_mode_flag = 1;
			break;
		case 'd': // Dma Sample Burst
			DmaSampleBurstSize = atoi(optarg);
			NUM_SAMPLES=4*DmaSampleBurstSize;
			break;
		case 'c': // Use clock instead of PWM pin
			UsePCMClk = atoi(optarg);
			if(UsePCMClk==1) printf("Use GPCLK Pin instead of PWM\n");
			break;
		case 'w': // No use pwmfrequency 
			NoUsePwmFrequency = atoi(optarg);
			
			break;
		case 'r': // Randomize PWM frequency 
			Randomize=1;
			
			break;
		case 'a': // DMA Channel 1-14
			 if((atoi(optarg)>0)&&(atoi(optarg)<15))
			 {
				SetDma=atoi(optarg);
				//DMA_CHANNEL=SetDma; Should be set after initdma
			 }
			 else
				SetDma=0;
			break;
        	case -1:
        	break;
		case '?':
			if (isprint(optopt) )
 			{
 				fprintf(stderr, "rpitx: unknown option `-%c'.\n", optopt);
 			}
			else
			{
				fprintf(stderr, "rpitx: unknown option character `\\x%x'.\n", optopt);
			}
			print_usage();

			exit(1);
			break;			
		default:
			print_usage();
			exit(1);
			break;
		}/* end switch a */
	}/* end while getopt() */

	//Open File Input for modes which need it
	if((Mode==MODE_IQ)||(Mode==MODE_IQ_FLOAT)||(Mode==MODE_RF)||(Mode==MODE_RFA))
	{
		if(FileName && strcmp(FileName,"-")==0)
		{
			// BAREMETAL: there is no pipe / stdin stream
			fatal("stdin input (-i -) is not available on bare metal, use a file or rtl2tx\n");
		}
		else if(FileName) FileInHandle = open(FileName, O_RDONLY);
		if (FileInHandle < 0)
		{
			fatal("Failed to read Filein %s\n",FileName?FileName:"(no -i option)");	// BAREMETAL: no "(null)" from printf
		}
	}

	resetFile();
	return pitx_run(Mode, SampleRate, SetFrequency, ppmpll, NoUsePwmFrequency, readFile, resetFile, NULL,SetDma);
}

// BAREMETAL: compression of pitx_run MODE_IQ (original expression)
static int pitx_compand(int amp)
{
	double A = 87.7f; // compression parameter
	double ampf=amp/32767.0;
	ampf = (fabs(ampf) < 1.0f/A) ? A*fabs(ampf)/(1.0f+ln(A)) : (1.0f+ln(A*fabs(ampf)))/(1.0f+ln(A)); //compand
	return (int)(round(ampf * 32767.0f)) ;
}

// BAREMETAL: IQ sample -> frequency and companded amplitude (was inline in
// pitx_run MODE_IQ, unchanged; shared with pitx_bench_iq)
static inline void pitx_iq_sample(int I,int Q,double *df,int *amp,double SampleRate)
{
	IQToFreqAmp(I,Q,df,amp,SampleRate);
						
	// Compression have to be done in modulation (SSB not here)
	// BAREMETAL: the companded value only depends on the integer amplitude
	// (0..32767 after IQToFreqAmp): table of the original expression, filled
	// once, instead of 4 log() per sample (not folded with -fno-builtin)
	static int16_t *s_compand=NULL;
	if(s_compand==NULL)
	{
		s_compand=malloc(32768*sizeof(int16_t));
		int a;
		for(a=0;a<32768&&s_compand;a++) s_compand[a]=(int16_t)pitx_compand(a);
	}
	if(s_compand!=NULL && *amp>=0 && *amp<32768)
		*amp=s_compand[*amp];
	else
		*amp=pitx_compand(*amp);
}

// BAREMETAL: follows the DMA engine (see pitx_stats in RpiTx.h). Must be
// called at least once per NUM_SAMPLES played samples (16 ms at 250 kS/s).
static int s_dma_prev_pos=0;
static int s_tx_started=0;
static void pitx_track_dma(void)
{
	if(!s_tx_started) return;
	uint32_t cb=mem_phys_to_virt((uint32_t)(dma_reg[DMA_CONBLK_AD+DMA_CHANNEL*0x40]));
	if(cb<(uint32_t)virtbase) return;
	int pos=(cb-(uint32_t)virtbase)/(sizeof(dma_cb_t)*CBS_SIZE_BY_SAMPLE);
	if(pos>=NUM_SAMPLES) return;
	int d=pos-s_dma_prev_pos;
	if(d<0) d+=NUM_SAMPLES;
	s_dma_prev_pos=pos;
	pitx_stats.dma_samples+=d;
	pitx_stats.last_us=bm_micros();
	if((int64_t)(pitx_stats.written-pitx_stats.dma_samples)<0)
	{
		// the DMA engine passed the last sample written: old ones are replayed
		pitx_stats.underruns++;
		pitx_stats.written=pitx_stats.dma_samples;
	}
}

int pitx_run(
	const char Mode,
	int SampleRate,
	const float SetFrequency,
	float ppmpll,
	const char NoUsePwmFrequency,
	ssize_t (*readWrapper)(void *buffer, size_t count),
	void (*reset)(void),
	int* skipSignals,
	int SetDma) 
{
	int i;
	//char pagemap_fn[64];

	int OffsetModulation=1000;//TBR
	int MicGain=100;
	//unsigned char *data;

	//Specific to ModeIQ
	static signed short *IQArray=NULL;
	static uint32_t RF_TimeRemaining;	// BAREMETAL

	//Specific to ModeIQ_FLOAT
	static float *IQFloatArray=NULL;

	//Specific to Mode RF
	typedef struct {
		double Frequency;
		uint32_t WaitForThisSample;
	} samplerf_t;
	samplerf_t *TabRfSample=NULL;

	fprintf(stdout,"rpitx Version %s compiled %s (F5OEO Evariste) running on ",PROGRAM_VERSION,__DATE__);

	// Init Plls Frequency using ppm (or default)
	// BAREMETAL: v1 replaced a user value by the calibrated one (inverted test)
	if(ppmpll==0) ppmpll=(float)globalppmpll; // Use calibrate only if not setting by user
	PllFreq500MHZ=PLL_FREQ_500MHZ;
	PllFreq500MHZ+=PllFreq500MHZ * (ppmpll / 1000000.0);

	PllFreq1GHZ=PLL_FREQ_1GHZ;
	PllFreq1GHZ+=PllFreq1GHZ * (ppmpll / 1000000.0);

	PllFreq19MHZ=PLLFREQ_192;
	PllFreq19MHZ+=PllFreq19MHZ * (ppmpll / 1000000.0);

	//End of Init Plls

	// BAREMETAL: buffers of a previous run are released (static pointers)
	free(IQArray); IQArray=NULL;
	free(IQFloatArray); IQFloatArray=NULL;
	RF_TimeRemaining=0;
	if(Mode==MODE_IQ)
	{
		IQArray=malloc(DmaSampleBurstSize*2*sizeof(signed short)); // TODO A FREE AT THE END OF SOFTWARE
		reset();
	} 
	if(Mode==MODE_IQ_FLOAT)
	{
		IQFloatArray=malloc(DmaSampleBurstSize*2*sizeof(float)); // TODO A FREE AT THE END OF SOFTWARE
	}
	if((Mode==MODE_RF)||(Mode==MODE_RFA))
	{
		//TabRfSample=malloc(DmaSampleBurstSize*sizeof(samplerf_t));
		SampleRate=50000L; //NOT USED BUT BY CALCULATING TIMETOSLEEP IN RF MODE
	}
	if(Mode==MODE_VFO)
		SampleRate=50000L; //50000 BY EXPERIMENT

	if(Mode==MODE_IQ)
	{
		printf(" Frequency=%f ",GlobalTuningFrequency);
		printf(" SampleRate=%d ",SampleRate);	
	}


	

	pitx_SetTuneFrequency(SetFrequency*1000.0);
	pitx_init(SampleRate, GlobalTuningFrequency, skipSignals,SetDma);
	printf("Tuning %.0f Hz (harmonic %d), PLL %u Hz\n",GlobalTuningFrequency,HarmonicNumber,(unsigned)PllUsed);
	

	static volatile uint32_t cur_cb,last_cb;
	int last_sample;
	int this_sample; 
	int free_slots;
	//int SumDelay=0;
	
	long int start_time;
	static long time_difference=0;
	struct timespec gettime_now;

	cur_cb = (uint32_t)virtbase+ (NUM_SAMPLES-DmaSampleBurstSize)* sizeof(dma_cb_t) *CBS_SIZE_BY_SAMPLE;
	
	last_cb=(uint32_t)virtbase /*+ 965* sizeof(dma_cb_t) *CBS_SIZE_BY_SAMPLE*/ ;


	dma_reg[DMA_CONBLK_AD+DMA_CHANNEL*0x40]=mem_virt_to_phys((void*)cur_cb);

	unsigned char Init=1;
	// BAREMETAL: statistics
	memset((void*)&pitx_stats,0,sizeof pitx_stats);
	s_tx_started=0;
	s_dma_prev_pos=0;
	uint64_t next_stats_us=0;
	uint64_t busy_start_us=0;

// -----------------------------------------------------------------

	for (;;) 
	{
		int TimeToSleep;
		static int StatusCompteur=0;
			
		cur_cb = mem_phys_to_virt((uint32_t)(dma_reg[DMA_CONBLK_AD+DMA_CHANNEL*0x40]));
		this_sample = (cur_cb - (uint32_t)virtbase) / (sizeof(dma_cb_t) * CBS_SIZE_BY_SAMPLE);
		last_sample = (last_cb - (uint32_t)virtbase) / (sizeof(dma_cb_t) * CBS_SIZE_BY_SAMPLE);
		free_slots = this_sample - last_sample;
		if (free_slots < 0) // WARNING : ORIGINAL CODE WAS < strictly
			free_slots += NUM_SAMPLES;
				
		//printf("last_sample %lx cur_cb %lx FreeSlots = %d Time to sleep=%d\n",last_sample,cur_cb,free_slots,TimeToSleep);
		pitx_track_dma();	// BAREMETAL
		if(s_tx_started&&!pitx_quiet_stats&&(Mode==MODE_IQ||Mode==MODE_IQ_FLOAT)&&bm_micros()>=next_stats_us)
		{
			if(next_stats_us!=0) pitx_print_stats(SampleRate);
			next_stats_us=bm_micros()+10000000;
		}
			
		if(Init==0)
		{
			if((Mode==MODE_RF)||(Mode==MODE_RFA))
			{
				TimeToSleep=100; //Max 100KHZ
			}
			else
				TimeToSleep=(1e6*(NUM_SAMPLES-free_slots*2))/SampleRate; // Time to sleep in us
			//printf("TimeToSleep%d\n",TimeToSleep);
		}
		else
			TimeToSleep=1000;
			
		//printf("Buffer Available=%d\n",BufferAvailable());
			
		clock_gettime(CLOCK_REALTIME, &gettime_now);
		start_time = gettime_now.tv_nsec;		
		if(TimeToSleep>=(2200+KERNEL_GRANULARITY)) // 2ms : Time to process File/Canal Coding
		{
			bm_sleep_us(TimeToSleep-(2200+KERNEL_GRANULARITY));	// BAREMETAL: polls
			TimeToSleep=0;
		}
		else
		{
			//udelay(TimeToSleep);
			bm_poll();	// BAREMETAL: instead of sched_yield()
			//TimeToSleep=0;
			//if(free_slots>(NUM_SAMPLES*9/10))
			//printf("Buffer nearly empty...%d/%d\n",free_slots,NUM_SAMPLES);
		}
			
		static int free_slots_now;
		cur_cb = mem_phys_to_virt(dma_reg[DMA_CONBLK_AD+DMA_CHANNEL*0x40]);
		this_sample = (cur_cb - (uint32_t)virtbase) / (sizeof(dma_cb_t) * CBS_SIZE_BY_SAMPLE);
		last_sample = (last_cb - (uint32_t)virtbase) / (sizeof(dma_cb_t) * CBS_SIZE_BY_SAMPLE);
		free_slots_now = this_sample - last_sample;
		if (free_slots_now < 0) // WARNING : ORIGINAL CODE WAS < strictly
			free_slots_now += NUM_SAMPLES;
		pitx_track_dma();	// BAREMETAL
			
		clock_gettime(CLOCK_REALTIME, &gettime_now);
		time_difference = gettime_now.tv_nsec - start_time;
		if(time_difference<0) time_difference+=1E9;
			
		if(StatusCompteur%10==0)
		{ 
			//printf(" DiffTime = %ld FreeSlot %d FreeSlotDiff=%d Bitrate : %f\n",time_difference,free_slots_now,free_slots_now-free_slots,(1e9*(free_slots_now-free_slots))/(float)time_difference);	
		}
		//if((1e9*(free_slots_now-free_slots))/(float)time_difference<40100.0) printf("Drift BAD\n"); else printf("Drift GOOD\n");	
		StatusCompteur++;
		free_slots=free_slots_now;
		// FIX IT : Max(freeslot et Numsample/8)
		if((Init==1)&&(free_slots < DmaSampleBurstSize /*NUM_SAMPLES/8*/))
		{
			bm_clean_dcache();	// BAREMETAL
			printf("****** STARTING TRANSMIT ********\n");
			dma_reg[DMA_CONBLK_AD+DMA_CHANNEL*0x40]=mem_virt_to_phys((void*)virtbase );
			usleep(100);
			//Start DMA PWMFrequency
				
			//dma_reg[DMA_CS+DMA_CHANNEL_PWMFREQUENCY*0x40] = 0x10880001;				

			//Start Main DMA
			dma_reg[DMA_CS+DMA_CHANNEL*0x40] = DMA_CS_PRIORITY(7) | DMA_CS_PANIC_PRIORITY(7) | DMA_CS_DISDEBUG |DMA_CS_ACTIVE;
			pitx_stats.start_us=bm_micros();	// BAREMETAL
			pitx_stats.dma_samples=0;
			pitx_stats.busy_us=0;
			s_dma_prev_pos=0;
			s_tx_started=1;
				
			Init=0;
				
			continue;
		}
		clock_gettime(CLOCK_REALTIME, &gettime_now);
		start_time = gettime_now.tv_nsec;
			
		int debug=0;

		if ((free_slots>=DmaSampleBurstSize)) 
		{
			busy_start_us=bm_micros();	// BAREMETAL
		// *************************************** MODE IQ **************************************************
			if(Mode==MODE_IQ)
			{
				int NbRead=0;
				static int Max=0;
				static int Min=32767;
				static int CompteSample=0;
				CompteSample++;
				NbRead=readWrapper(IQArray,DmaSampleBurstSize*2*2/*SHORT I,SHORT Q*/);
				
				if(NbRead!=DmaSampleBurstSize*2*2) 
				{
					if(loop_mode_flag==1)
					{
						printf("Looping FileIn\n");
						reset();
						NbRead=readWrapper(IQArray,DmaSampleBurstSize*2*2);
					}
					else {
						stop_dma();
						return 0;
					}
				}
				
				for(i=0;i<DmaSampleBurstSize;i++)
				{
					//static float samplerate=48000;
					static int amp;
					static double df;
					
					int CorrectionRpiFrequency=-1000; //TODO PPM / Offset=1KHZ at 144MHZ
					
					CompteSample++;
					//printf("i%d q%d\n",IQArray[2*i],IQArray[2*i+1]);
					
					pitx_iq_sample(IQArray[2*i+1],IQArray[2*i],&df,&amp,pitx_iq_rate>0?pitx_iq_rate:(double)SampleRate);	// BAREMETAL: shared with pitx_bench_iq, real rate (rtl2tx)
						
					if(amp>Max) Max=amp;
					if(amp<Min) Min=amp;	
						
					/*
					if((CompteSample%4800)==0)
					{
						//printf("%d\n",((CompteSample/48000)*1024)%32767);
						//printf("Amp %d Freq %f MinAmp %d MaxAmp %d\n",amp,df,Min,Max);
						printf("%d;%d;%d;%f\n",IQArray[2*i+1],IQArray[2*i],amp,df);
						// printf(".");
						fflush(stdout);
					}
					*/
					// TEST - WARNING, REMOVE FOR RELEASE 
					//amp=((CompteSample/48000)*1024)%32767;
					//df=0;
					//amp=amp*10;
					//amp=32767;
					//if(df<OffsetModulation+100) amp=0;
					//if(amp<32767/8) df= OffsetModulation;
					//

					// FIXME : df/harmonicNumber could alterate maybe modulations
					FrequencyAmplitudeToRegister(GlobalTuningFrequency+(HarmonicNumber==1?(df-OffsetModulation-pitx_iq_offset_hz):(df-OffsetModulation-pitx_iq_offset_hz)/HarmonicNumber),amp,last_sample++,0,SampleRate,NoUsePwmFrequency,CompteSample%2);	// BAREMETAL: harmonic H (see pitx_SetTuneFrequency); no division by 1; offset from rtl2tx (0 otherwise)
					// !!!!!!!!!!!!!!!!!!!! 680 is for 48KHZ , should be adpated !!!!!!!!!!!!!!!!!

					free_slots--;
					if (last_sample == NUM_SAMPLES)	last_sample = 0;
					if((i&255)==255) pitx_track_dma();	// BAREMETAL
				}
			}
		// *************************************** MODE IQ FLOAT**************************************************
			if(Mode==MODE_IQ_FLOAT)
			{
				int NbRead=0;
				static int Max=0;
				static int Min=32767;
				static int CompteSample=0;
				CompteSample++;
				NbRead=readWrapper(IQFloatArray,DmaSampleBurstSize*2*sizeof(float));
				
				if(NbRead!=DmaSampleBurstSize*2*sizeof(float)) 
				{
					if(loop_mode_flag==1)
					{
						printf("Looping FileIn\n");
						reset();
					}
					else if (!useStdin) {
						stop_dma();
						return 0;
					}
				}
				
				for(i=0;i<DmaSampleBurstSize;i++)
				{
					//static float samplerate=48000;
					static int amp;
					static double df;
					
					int CorrectionRpiFrequency=-1000; //TODO PPM / Offset=1KHZ at 144MHZ
					
					CompteSample++;
					//printf("i%d q%d\n",IQArray[2*i],IQArray[2*i+1]);
					
					IQToFreqAmp(IQFloatArray[2*i+1]*32767,IQFloatArray[2*i]*32767,&df,&amp,SampleRate);

					if(amp>Max) Max=amp;
					if(amp<Min) Min=amp;
					/*	
					if((CompteSample%4800)==0)
					{
						//printf("%d\n",((CompteSample/48000)*1024)%32767);
						printf("Amp %d Freq %f MinAmp %d MaxAmp %d\n",amp,df,Min,Max);
						// printf(".");
						fflush(stdout);
					}
					*/
					// TEST - WARNING, REMOVE FOR RELEASE 
					//amp=((CompteSample/48000)*1024)%32767;
					//df=0;
					//amp=amp*10;
					//amp=32767;
					//if(df<OffsetModulation+100) amp=0;
					//
					//amp=32767;
					//if(df>SampleRate/2) df=SampleRate/2-df;
					FrequencyAmplitudeToRegister(GlobalTuningFrequency+(df-OffsetModulation)/HarmonicNumber,amp,last_sample++,0,SampleRate,NoUsePwmFrequency,CompteSample%2);	// BAREMETAL: harmonic H
						
					free_slots--;
					if (last_sample == NUM_SAMPLES)	last_sample = 0;
				}
			}
		// *************************************** MODE RF **************************************************
			if((Mode==MODE_RF)||(Mode==MODE_RFA))
			{
				// SHOULD NOT EXEED 200 STEP*500ns; SAMPLERATE SHOULD BE MAX TO HAVE PRECISION FOR PCM 
				// BUT FIFO OF PCM IS 16 : SAMPLERATE MAYBE NOT EXCESS 16*80000 ! CAREFULL BUGS HERE
				#define MAX_DELAY_WAIT (PWM_STEP_MAXI/2*FREQ_MINI_TIMING-PWMF_MARGIN) 
				static int CompteSample=0;
				#define TimeRemaining RF_TimeRemaining	// BAREMETAL: reset at each run
				static samplerf_t SampleRf;
				static int NbRead;
				CompteSample++;
				int i;
				for(i=0;i<DmaSampleBurstSize;i++)
				{
					if(TimeRemaining==0)
					{
						NbRead=readWrapper(&SampleRf,sizeof(samplerf_t));
						if(NbRead!=sizeof(samplerf_t)) 
						{
							if(loop_mode_flag==1)
							{
								//printf("Looping FileIn\n");
								reset();
								NbRead=readWrapper(&SampleRf,sizeof(samplerf_t));
							}
							else if (!useStdin)
							{
								stop_dma();
								return 0;
							}
						}
							
						TimeRemaining=SampleRf.WaitForThisSample;
						//TimeRemaining=50000;//SampleRf.WaitForThisSample;
						debug=1;
						//printf("A=%f Time =%d \n",SampleRf.Frequency,SampleRf.WaitForThisSample);
					}
					else
						debug=0;	
					
					static int amp=32767;
					static int WaitSample=0;
					
					if(TimeRemaining>MAX_DELAY_WAIT) 
						WaitSample=MAX_DELAY_WAIT;	
					else
						WaitSample=TimeRemaining;
					
					//printf("TimeRemaining %d WaitSample %d\n",TimeRemaining,WaitSample);
					if(Mode==MODE_RF)
					{
						if(SampleRf.Frequency==0.0)
						{
							amp=0;
							SampleRf.Frequency=00.0;// TODO change that ugly frequency
						}
						else
							amp=32767;
						FrequencyAmplitudeToRegister(GlobalTuningFrequency+SampleRf.Frequency/HarmonicNumber,amp,last_sample++,WaitSample,0,NoUsePwmFrequency,debug);	// BAREMETAL: harmonic H
					}
					if(Mode==MODE_RFA)
						FrequencyAmplitudeToRegister(GlobalTuningFrequency,SampleRf.Frequency,last_sample++,WaitSample,0,NoUsePwmFrequency,debug);	// BAREMETAL: harmonic H

					TimeRemaining-=WaitSample;
					free_slots--;
					if (last_sample == NUM_SAMPLES)	last_sample = 0;
				}
				#undef TimeRemaining
			}
				
		// *************************************** MODE VFO **************************************************
			if(Mode==MODE_VFO)
			{
				static uint32_t CompteSample=0;
					
				int i;
				//printf("Begin free %d\n",free_slots);
				for(i=0;i<DmaSampleBurstSize;i++)
				{						
					//To be fine tuned !!!!	
					static int OutputPower=32767;
					CompteSample++;
					debug=1;//(debug+1)%2;	
					//OutputPower=(CompteSample/10)%32768;

					FrequencyAmplitudeToRegister(GlobalTuningFrequency,OutputPower,last_sample++,25000,0,NoUsePwmFrequency,debug);	// BAREMETAL: harmonic H
					free_slots--;
					//printf("%f \n",GlobalTuningFrequency+(((CompteSample/10)*1)%50000));	
					if (last_sample == NUM_SAMPLES)	last_sample = 0;
					if(CompteSample%40000==0)
					{
						//OutputPower=(OutputPower+1)%8;
						//pad_gpios_reg[PADS_GPIO_0] = 0x5a000000 + (OutputPower&0x7) + (1<<4) + (0<<3); // Set output power for I/Q GPIO18/GPIO19 
						//printf("Freq %d Outputpower=%d\n",CompteSample/20000,OutputPower);
					}
					//usleep(1);
				}
					//printf("End free %d\n",free_slots);
			}

		}
			
		bm_clean_dcache();	// BAREMETAL: new samples visible to the DMA engine
		if(busy_start_us!=0)	// BAREMETAL: statistics
		{
			pitx_stats.written+=DmaSampleBurstSize;
			if(s_tx_started) pitx_stats.busy_us+=bm_micros()-busy_start_us;
			busy_start_us=0;
		}

		clock_gettime(CLOCK_REALTIME, &gettime_now);
		time_difference = gettime_now.tv_nsec - start_time;
		if(time_difference<0) time_difference+=1E9;
			
		last_cb = (uint32_t)virtbase + last_sample * sizeof(dma_cb_t) * CBS_SIZE_BY_SAMPLE;
	}
				
	stop_dma();
	return(0);
}


// BAREMETAL: CPU time of the MODE_IQ path for n samples, without DMA nor
// RF output (the control blocks are written, never played). The input is a
// constant amplitude IQ signal turning at 50 kHz (worst case is similar).
long pitx_bench_iq(int SampleRate, double FrequencyHz, int n)
{
	pitx_reset_state();
	PllFreq500MHZ=PLL_FREQ_500MHZ;
	PllFreq1GHZ=PLL_FREQ_1GHZ;
	PllFreq19MHZ=PLLFREQ_192;
	pitx_SetTuneFrequency(FrequencyHz);
	if(!InitDma(terminate, NULL))
		return -1;
	ctl = (struct control_data_s *)virtbase;
	s_ShowInfo=0;

	static int16_t iq[2*1000];
	int k;
	for(k=0;k<1000;k++)
	{
		double ph=2*M_PI*50000.0*k/SampleRate;
		iq[2*k]=(int16_t)(30000*cos(ph));
		iq[2*k+1]=(int16_t)(30000*sin(ph));
	}

	int OffsetModulation=1000;
	int last_sample=0;
	{
		double df; int amp;	// tables filled before the measurement
		pitx_iq_sample(iq[1],iq[0],&df,&amp,SampleRate);
	}
	uint64_t t0=bm_micros();
	for(k=0;k<n;k++)
	{
		double df;
		int amp;
		int j=k%1000;
		pitx_iq_sample(iq[2*j+1],iq[2*j],&df,&amp,SampleRate);
		FrequencyAmplitudeToRegister(GlobalTuningFrequency+(df-OffsetModulation)/HarmonicNumber,amp,last_sample++,0,SampleRate,0,0);
		if(last_sample==NUM_SAMPLES) last_sample=0;
		if(j==999) bm_clean_dcache();
	}
	return (long)(bm_micros()-t0);
}
