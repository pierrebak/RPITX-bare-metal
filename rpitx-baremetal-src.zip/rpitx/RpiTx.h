#ifndef RPITX_H
#define RPITX_H
#include <ctype.h>
#include <stdint.h>
#include <sys/types.h>

int pitx_init(int SampleRate, double TuningFrequency, int* skipSignals,int SetDma);
int pitx_SetTuneFrequencyu(uint32_t Frequency);

#define MODE_IQ 0
#define MODE_RF 1
#define MODE_RFA 2
#define MODE_IQ_FLOAT 3
#define MODE_VFO 4

int pitx_run(
	char Mode,
	int SampleRate,
	float SetFrequency,
	float ppmpll,
	char NoUsePwmFrequency,
	// Wrapper around read to read wav file bytes
	ssize_t (*readWrapper)(void *buffer, size_t count),
	// Wrapper to reset file for looping
	void (*reset)(void),
	int* skipSignals,
	int SetDma
);

/* BAREMETAL: entry point called by the shell (was main) and reset of the
   global state, also used by rtl2tx before calling pitx_run(). */
int rpitx_main(int argc, char* argv[]);
void pitx_reset_state(void);

/* BAREMETAL: harmonic used for a frequency, and rpitx -f value (Hz) that
   puts IQ samples shifted by ShiftHz on WantedHz (see RpiTx.c). */
int pitx_harmonic_for(double Frequency);
double pitx_iq_set_frequency(double WantedHz, double ShiftHz);

/* BAREMETAL: measurements of the running transmission (pitx_run).
   dma_samples: samples actually played by the DMA engine since start_us,
   so dma_samples / time is the real sample rate of the output;
   busy_us: time spent computing / reading samples (CPU load);
   underruns: times the DMA engine caught up with the samples written by the
   CPU (the CPU is too slow: old samples are played again). */
typedef struct {
	uint64_t start_us;
	uint64_t last_us;	/* time of the last dma_samples update */
	uint64_t dma_samples;
	uint64_t written;
	uint64_t busy_us;
	uint32_t underruns;
} pitx_stats_t;
extern volatile pitx_stats_t pitx_stats;
extern int pitx_quiet_stats;	/* 1: pitx_run() does not print them */

/* BAREMETAL, MODE_IQ only, 0 = unused (original behaviour):
   pitx_iq_rate: sample rate used to turn the phase step of an IQ sample into
   Hz, i.e. the real rate at which the DMA engine plays the samples, when the
   caller resamples its signal to that rate (rtl2tx);
   pitx_iq_offset_hz: subtracted from the frequency of every IQ sample. */
extern double pitx_iq_rate;
extern double pitx_iq_offset_hz;

/* BAREMETAL: CPU time of the IQ path (IQToFreqAmp + register computation)
   for n samples, no transmission; returns microseconds, -1 on error. */
long pitx_bench_iq(int SampleRate, double FrequencyHz, int n);

#endif
