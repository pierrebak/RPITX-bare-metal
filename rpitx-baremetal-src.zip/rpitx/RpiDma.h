/*
 * RpiDma.h - rpitx v1 DMA definitions, bare metal version
 *
 * Original: rpitx v1 by Evariste COURJAUD F5OEO (GPL v2 or later).
 * Bare metal changes (rpitx-baremetal, 2026):
 *  - no VideoCore mailbox allocation: the control block area is a 32 byte
 *    aligned block of normal (cached) RAM; the L1 data cache is cleaned
 *    before the DMA engine reads it. Bus addresses use the GPU L2 alias,
 *    exactly like Circle's own DMA users;
 *  - the DMA channel is obtained from Circle, which knows the channels the
 *    VideoCore firmware leaves to the ARM (no guessing from the kernel
 *    version as on Linux);
 *  - globals are declared extern here and defined once in RpiDma.c.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 */
#ifndef RPI_DMA
#define RPI_DMA

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <ctype.h>
#include <bm_compat.h>

char InitDma(void *FunctionTerminate, int* skipSignals);
uint32_t mem_virt_to_phys(volatile void *virt);
uint32_t mem_phys_to_virt(volatile uint32_t phys);

#define NBSAMPLES_PWM_FREQ_MAX 500
#define NUM_CB_PWM_FREQUENCY 8
#define NUM_SAMPLES_MAX		(4000)
#define CBS_SIZE_BY_SAMPLE	(3)
#define NUM_CBS_MAIN 		((NUM_SAMPLES_MAX * CBS_SIZE_BY_SAMPLE))
#define NUM_CBS			(NUM_CBS_MAIN)

#define BCM2708_DMA_SRC_IGNOR           (1<<11)
#define BCM2708_DMA_SRC_INC		(1<<8)
#define BCM2708_DMA_DST_IGNOR           (1<<7)
#define BCM2708_DMA_NO_WIDE_BURSTS	(1<<26)
#define BCM2708_DMA_WAIT_RESP		(1<<3)

#define BCM2708_DMA_D_DREQ		(1<<6)
#define BCM2708_DMA_PER_MAP(x)		((x)<<16)
#define BCM2708_DMA_END			(1<<1)
#define BCM2708_DMA_RESET		(1<<31)
#define BCM2708_DMA_ABORT		(1<<30)
#define BCM2708_DMA_INT			(1<<2)

#define DMA_CS			(0x00/4)
#define DMA_CONBLK_AD		(0x04/4)
#define DMA_DEBUG		(0x20/4)

#define BUS_TO_PHYS(x) ((x)&~0xC0000000)

#define DMA_CS_RESET    (1<<31)
#define DMA_CS_ABORT    (1<<30)
#define DMA_CS_DISDEBUG (1<<28)
#define DMA_CS_END      (1<<1)
#define DMA_CS_ACTIVE   (1<<0)
/* Kept as in rpitx v1. Note: because of operator precedence these macros
   evaluate to 0 for x < 16, i.e. priority bits are never set (v1 behaviour). */
#define DMA_CS_PRIORITY(x) ((x)&0xf << 16)
#define DMA_CS_PANIC_PRIORITY(x) ((x)&0xf << 20)

#define PAGE_SIZE	4096
#define PAGE_SHIFT	12
#define NUM_PAGES	((sizeof(struct control_data_s) + PAGE_SIZE - 1) >> PAGE_SHIFT)

extern char DMA_CHANNEL;

#define DMA_CHANNEL_PWMFREQUENCY (DMA_CHANNEL+1)

typedef struct {
	uint32_t info, src, dst, length,
		 stride, next, pad[2];
} dma_cb_t;

extern uint8_t *virtbase;

#define PWM_STEP_MAXI 200

typedef struct {

	uint32_t FrequencyTab[PWM_STEP_MAXI];
	uint32_t Amplitude1;
	uint32_t Amplitude2;

} sample_t;


struct control_data_s {
	dma_cb_t cb[NUM_CBS];//+1 ??

	sample_t sample[NUM_SAMPLES_MAX];
};

extern struct control_data_s *ctl;

#endif
