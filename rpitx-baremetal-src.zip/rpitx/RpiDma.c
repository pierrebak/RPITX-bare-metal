/*
 * RpiDma.c - rpitx v1 DMA memory setup, bare metal version
 *
 * Original: rpitx v1 by Evariste COURJAUD F5OEO (GPL v2 or later).
 * See RpiDma.h for the list of bare metal changes.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "RpiDma.h"
#include "RpiGpio.h"

char DMA_CHANNEL;
uint8_t *virtbase;
struct control_data_s *ctl;

static int compareInts(const void* first, const void* second)
{
	const int firstInt = *((int*)first);
	const int secondInt = *((int*)second);
	if (firstInt < secondInt) {
		return -1;
	}
	if (firstInt == secondInt) {
		return 0;
	}
	return 1;
}

char InitDma(void *FunctionTerminate, int* skipSignals)
{
	unsigned channel = bm_alloc_dma_channel(0);
	if (channel == 0xFF)
	{
		printf("No free DMA channel\n");
		return 0;
	}
	DMA_CHANNEL = (char) channel;
	printf("DMA channel %d\n", DMA_CHANNEL);

	int sentinel[] = {0};
	if (skipSignals == NULL) {
		skipSignals = sentinel;
	}
	int sentinelIndex;
	for (sentinelIndex = 0; ; ++sentinelIndex) {
		if (skipSignals[sentinelIndex] == 0) {
			break;
		}
	}
	qsort(skipSignals, sentinelIndex, sizeof(int), compareInts);

	// Catch all signals possible - it is vital we kill the DMA engine
	// on process exit! (bare metal: only SIGINT is ever raised, by Ctrl-C/ESC)
	int i;
	for (i = 1; i < 64; i++) {
		// Some signals are fine, so don't catch them
		if (i == *skipSignals) {
			++skipSignals;
		} else {
			struct sigaction sa;

			memset(&sa, 0, sizeof(sa));
			sa.sa_handler = FunctionTerminate;//terminate;
			sigaction(i, &sa, NULL);
		}
	}

	// The control block area (about 3.6 MB) is allocated once and kept:
	// there is no process exit that would release it.
	if (virtbase == NULL)
	{
		virtbase = (uint8_t *) bm_alloc_aligned(NUM_PAGES * PAGE_SIZE, PAGE_SIZE);
		if (virtbase == NULL)
		{
			printf("Cannot allocate %u bytes for DMA control blocks\n",
			       (unsigned) (NUM_PAGES * PAGE_SIZE));
			return 0;
		}
	}
	printf("%u Size NUM PAGES %u PAGE_SIZE %d\n", (unsigned) sizeof(struct control_data_s),
	       (unsigned) NUM_PAGES, PAGE_SIZE);
	return(1);
}

uint32_t mem_virt_to_phys(volatile void *virt)
{
	return bm_bus_address(virt);
}

uint32_t mem_phys_to_virt(volatile uint32_t phys)
{
	return (uint32_t) bm_bus_to_arm(phys);
}
