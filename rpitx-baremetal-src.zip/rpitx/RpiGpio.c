/*
 * RpiGpio.c - rpitx v1 GPIO / peripheral access, bare metal version
 *
 * Original: rpitx v1 by Evariste COURJAUD F5OEO (GPL v2 or later).
 * Bare metal: Circle identity maps the peripheral window, so the register
 * pointers are simply the physical addresses. The board revision decoding
 * (raspberry_pi_revision.c) is not needed: this port targets the BCM2835
 * (Raspberry Pi 1 A/B/A+/B+, Zero).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 */
#include "RpiGpio.h"
#include <bm_compat.h>

int model;
uint32_t mem_flag;

volatile uint32_t *pwm_reg;
volatile uint32_t *clk_reg;
volatile uint32_t *dma_reg;
volatile uint32_t *gpio_reg;
volatile uint32_t *pcm_reg;
volatile uint32_t *pad_gpios_reg;

char InitGpio()
{
	dma_reg = (volatile uint32_t *) DMA_BASE;
	pwm_reg = (volatile uint32_t *) PWM_BASE;
	clk_reg = (volatile uint32_t *) CLK_BASE;
	pcm_reg = (volatile uint32_t *) PCM_BASE;
	gpio_reg = (volatile uint32_t *) GPIO_BASE;
	pad_gpios_reg = (volatile uint32_t *) PADS_GPIO;

	DisplayInfo();

	return 1;
}

int gpioSetMode(unsigned gpio, unsigned mode)
{
   int reg, shift;

   reg   =  gpio/10;
   shift = (gpio%10) * 3;

   gpio_reg[reg] = (gpio_reg[reg] & ~(7<<shift)) | (mode<<shift);

   return 0;
}

void DisplayInfo()
{
	printf("processor: BCM2835 (bare metal)\n");
	printf("peripheral base: 0x%x\n", (unsigned) BCM2708_PERI_BASE);
	printf("PLLD assumed at %d MHz%s\n", bm_plld_mhz,
	       bm_plld_mhz == 1000 ? " (needs the rpitx dt-blob.bin)" : "");
}
