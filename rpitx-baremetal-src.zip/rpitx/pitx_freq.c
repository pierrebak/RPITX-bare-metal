/*
 * pitx_freq.c - frequency helpers for tools driving rpitx v1 in IQ mode
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * Must follow the rules of pitx_SetTuneFrequency() in RpiTx.c.
 */
#include <stdint.h>
#include <bm_compat.h>
#include "RpiTx.h"

#define PLL_FREQ_1GHZ	((uint32_t)bm_plld_mhz*1000000UL)
#define PLLFREQ_192	19200000

/* BAREMETAL: helpers for the tools that drive rpitx in IQ mode.
 *
 * Above PLL/4, pitx_SetTuneFrequency() sets GlobalTuningFrequency = F/H
 * (H odd) and pitx_run() puts the wanted signal on the harmonic H of that
 * fundamental. In IQ mode the output is
 *     f_out = F - OffsetModulation + df   (OffsetModulation = 1000 Hz,
 *                                          df: frequency of the IQ samples)
 * whatever H. (rpitx v1 used the harmonic H*H and its IQ output was then
 * 1000*(H-1) Hz too low: fixed in RpiTx.c.) */
int pitx_harmonic_for(double Frequency)
{
	uint32_t pll = (Frequency < PLL_FREQ_1GHZ/2048L) ? PLLFREQ_192 : PLL_FREQ_1GHZ;
	int harmonic;
	for(harmonic=1;harmonic<41;harmonic+=2)
	{
		if((Frequency/(double)harmonic)<=(double)pll/4.0) break;
	}
	return harmonic;
}

/* Value (Hz) to give to rpitx -f so that IQ samples whose frequency is
   df = f_baseband + ShiftHz are transmitted at WantedHz + f_baseband. */
double pitx_iq_set_frequency(double WantedHz, double ShiftHz)
{
	return WantedHz - ShiftHz + 1000.0;
}
