/*
 * bm_rfwrite.h - writer for rpitx v1 RF / RFA files (rpitx-baremetal)
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Record = {double Frequency (Hz offset in RF mode, amplitude 0..32767 in
 * RFA mode), uint32_t duration in ns}, as read by rpitx v1 -m RF / -m RFA.
 * In RF mode a frequency of exactly 0 means "carrier off" (v1 behaviour),
 * so a carrier wanted at offset 0 is written as RF_ZERO_HZ.
 */
#ifndef BM_RFWRITE_H
#define BM_RFWRITE_H

#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

#define RF_ZERO_HZ	0.001
#define RF_MAX_NS	4000000000.0	/* uint32_t limit, with margin */

typedef struct {
	double Frequency;
	uint32_t WaitForThisSample;
} bm_samplerf_t;

typedef struct {
	int fd;
	int ok;
	double pending_value;		/* records with the same value are merged */
	double pending_ns;
	long records;
	double total_ns;
} bm_rfwriter_t;

static inline int bm_rf_open (bm_rfwriter_t *w, const char *path)
{
	memset (w, 0, sizeof *w);
	w->fd = open (path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
	w->ok = w->fd >= 0;
	w->pending_ns = 0;
	if (!w->ok)
		fprintf (stderr, "Cannot create %s\n", path);
	return w->ok;
}

static inline void bm_rf_flush (bm_rfwriter_t *w)
{
	if (w->pending_ns <= 0 || !w->ok)
		return;
	bm_samplerf_t r;
	memset (&r, 0, sizeof r);
	r.Frequency = w->pending_value;
	r.WaitForThisSample = (uint32_t) (w->pending_ns + 0.5);
	if (write (w->fd, &r, sizeof r) != sizeof r)
		w->ok = 0;
	w->records++;
	w->pending_ns = 0;
}

/* merge: 1 to merge with the previous record of the same value */
static inline void bm_rf_put (bm_rfwriter_t *w, double value, double ns, int merge)
{
	w->total_ns += ns;
	if (merge && w->pending_ns > 0 && value == w->pending_value && w->pending_ns + ns < RF_MAX_NS) {
		w->pending_ns += ns;
		return;
	}
	bm_rf_flush (w);
	w->pending_value = value;
	w->pending_ns = ns;
}

static inline int bm_rf_close (bm_rfwriter_t *w)
{
	bm_rf_flush (w);
	if (w->fd >= 0)
		close (w->fd);
	if (!w->ok)
		fprintf (stderr, "Write error (SD card full?)\n");
	return w->ok;
}

#endif
