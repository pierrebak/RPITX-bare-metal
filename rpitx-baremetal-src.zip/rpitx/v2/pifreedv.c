/*
 * pifreedv.c - plays a FreeDV VCO file (rpitx v2 "FreeDV" demo) with rpitx v1
 *
 * Copyright (C) 2026 rpitx-baremetal contributors. Behaviour of rpitx v2
 * src/freedv/freedv.cpp (F5OEO): the .rf file is a sequence of int16 VCO
 * frequencies (Hz, relative to the carrier), one every 1/SampleRate s
 * (400 for FreeDV 800XA). It is already modulated: no codec is involved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "bm_rfwrite.h"

int pifreedv_main (int argc, char **argv)
{
	if (argc < 3) {
		printf ("usage : pifreedv vco.rf out.ft [samplerate(Hz), default 400]\n"
			"Then : rpitx -m RF -i out.ft -f <kHz>\n");
		return 1;
	}
	int SampleRate = argc > 3 ? (int) atof (argv[3]) : 400;
	if (SampleRate <= 0) {
		fprintf (stderr, "Invalid sample rate\n");
		return 1;
	}

	int in = open (argv[1], O_RDONLY);
	if (in < 0) {
		fprintf (stderr, "Cannot open %s\n", argv[1]);
		return 1;
	}
	bm_rfwriter_t w;
	if (!bm_rf_open (&w, argv[2])) {
		close (in);
		return 1;
	}
	short VCOFreq;
	while (read (in, &VCOFreq, sizeof VCOFreq) == sizeof VCOFreq && w.ok)
		bm_rf_put (&w, VCOFreq == 0 ? RF_ZERO_HZ : (double) VCOFreq, 1e9 / SampleRate, 0);
	close (in);
	if (!bm_rf_close (&w))
		return 1;
	printf ("FreeDV %.1f s written to %s\n", w.total_ns / 1e9, argv[2]);
	return 0;
}
