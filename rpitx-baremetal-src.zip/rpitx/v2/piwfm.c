/*
 * piwfm.c - wide band FM (broadcast, mono, no RDS) for rpitx v1 RF mode
 *
 * Copyright (C) 2026 rpitx-baremetal contributors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Replacement for the "FmRds" item of rpitx v2 easytest: the v2 pifmrds
 * builds a 228 kS/s stereo multiplex with an RDS sub-carrier at 57 kHz,
 * which the rpitx v1 engine cannot carry. This tool makes what v1 can do:
 * mono WFM, 75 kHz deviation, 50 us pre-emphasis (Europe; -t 75 for the
 * Americas), one frequency sample per audio sample (48 kHz WAV, like pifm).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <sndfile.h>
#include "bm_rfwrite.h"

#define BUFFER_LEN	8192

int piwfm_main (int argc, char **argv)
{
	int opt;
	float tau_us = 50;
	float deviation = 75000;
	while ((opt = getopt (argc, argv, "t:d:")) != -1) {
		switch (opt) {
		case 't': tau_us = atof (optarg); break;
		case 'd': deviation = atof (optarg); break;
		default: optind = argc + 1; break;
		}
	}
	if (argc - optind < 1 || argc - optind > 2) {
		printf ("Usage : piwfm [-t 50|75 pre-emphasis us] [-d deviation Hz] in.wav [out.ft]\n"
			"in.wav: 48 kHz, mono or stereo (mixed). Mono FM broadcast, no RDS.\n"
			"Then : rpitx -m RF -i out.ft -f <kHz> -l\n");
		return 1;
	}
	const char *infile = argv[optind];
	const char *outfile = argc - optind == 2 ? argv[optind + 1] : "wfm.ft";

	SF_INFO info;
	memset (&info, 0, sizeof info);
	SNDFILE *in = sf_open (infile, SFM_READ, &info);
	if (in == NULL) {
		printf ("Not able to open input file %s.\n%s\n", infile, sf_strerror (NULL));
		return 1;
	}
	if (info.samplerate != 48000) {
		printf ("Input rate must be 48K.\n");
		sf_close (in);
		return 1;
	}

	bm_rfwriter_t w;
	if (!bm_rf_open (&w, outfile)) {
		sf_close (in);
		return 1;
	}

	/* first order pre-emphasis: y = x + tau/T * (x - x[n-1]), then
	   normalised so that a full scale 1 kHz tone keeps its level */
	double k = tau_us * 1e-6 * 48000.0;
	double norm = 1.0 / sqrt (1.0 + pow (2 * M_PI * 1000 * tau_us * 1e-6, 2));
	static float data[BUFFER_LEN * 2];
	double prev = 0;
	long clipped = 0;
	int n;
	while ((n = sf_readf_float (in, data, BUFFER_LEN / info.channels)) > 0 && w.ok) {
		for (int i = 0; i < n; i++) {
			double x = data[i * info.channels];
			if (info.channels >= 2)
				x = (x + data[i * info.channels + 1]) / 2;
			double y = (x + k * (x - prev)) * norm;
			prev = x;
			if (y > 1.0) { y = 1.0; clipped++; }
			if (y < -1.0) { y = -1.0; clipped++; }
			double f = y * deviation;
			bm_rf_put (&w, f == 0.0 ? RF_ZERO_HZ : f, 1e9 / 48000.0, 0);
		}
	}
	sf_close (in);
	if (!bm_rf_close (&w))
		return 1;
	printf ("WFM %.1f s written to %s (%ld clipped samples)\n", w.total_ns / 1e9, outfile, clipped);
	return 0;
}
