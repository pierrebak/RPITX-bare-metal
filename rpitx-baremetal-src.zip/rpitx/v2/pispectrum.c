/*
 * pispectrum.c - spectrum painting (rpitx v2 "Spectrum") for rpitx v1
 *
 * Copyright (C) 2026 rpitx-baremetal contributors. Principle of rpitx v2
 * src/spectrumpaint/spectrum.cpp and testspectrum.sh (F5OEO).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * v2: the picture is flipped, reduced to 4 grey levels, and each line of
 * 320 pixels is sent as 320 samples at 10 kS/s: pixel x at frequency
 * (x/320 - 0.5) * Excursion with an amplitude equal to its grey level.
 * The image then appears on a waterfall display.
 *
 * rpitx v1 RF mode has no amplitude control (carrier on or off): the grey
 * levels 1 and 2 are rendered by ordered dithering (pixel on 1/3 or 2/3 of
 * the lines), level 3 is always on, level 0 off.
 */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "bm_rfwrite.h"

#define WIDTH	320

int pispectrum_main (int argc, char *argv[])
{
	if (argc < 3) {
		printf ("Usage : pispectrum picture.rgb out.ft [Excursion(Hz), default 100000]\n"
			"picture.rgb: 320 pixels wide RGB, as made by bmp2rgb\n"
			"Then : rpitx -m RF -i out.ft -f <kHz> -l\n");
		return 1;
	}
	float Excursion = argc > 3 ? atof (argv[3]) : 100000;

	int in = open (argv[1], O_RDONLY);
	if (in < 0) {
		fprintf (stderr, "Cannot open %s\n", argv[1]);
		return 1;
	}
	long size = lseek (in, 0, SEEK_END);
	int lines = size / (WIDTH * 3);
	if (lines <= 0) {
		fprintf (stderr, "%s is not a 320 pixels wide RGB picture\n", argv[1]);
		close (in);
		return 1;
	}

	bm_rfwriter_t w;
	if (!bm_rf_open (&w, argv[2])) {
		close (in);
		return 1;
	}

	static unsigned char line[WIDTH * 3];
	for (int l = lines - 1; l >= 0 && w.ok; l--) {	/* flipped, like "convert -flip" */
		lseek (in, (long) l * WIDTH * 3, SEEK_SET);
		if (read (in, line, sizeof line) != (int) sizeof line)
			break;
		for (int x = 0; x < WIDTH; x++) {
			const unsigned char *p = line + 3 * x;
			int y = (299 * p[0] + 587 * p[1] + 114 * p[2]) / 1000;	/* luma */
			int level = y / 64;					/* 0..3 */
			int threshold = (x + 2 * l) % 3;			/* 0, 1, 2 */
			double f = ((float) x / WIDTH - 0.5f) * Excursion;
			if (level > threshold)
				bm_rf_put (&w, f == 0.0 ? RF_ZERO_HZ : f, 1e9 / 10000, 0);
			else
				bm_rf_put (&w, 0.0, 1e9 / 10000, 1);		/* carrier off */
		}
	}
	close (in);
	if (!bm_rf_close (&w))
		return 1;
	printf ("%d lines (%.1f s) painted over %.0f kHz into %s\n", lines,
		w.total_ns / 1e9, Excursion / 1000, argv[2]);
	return 0;
}
