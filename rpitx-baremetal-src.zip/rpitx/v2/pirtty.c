/*
 * pirtty.c - RTTY (Baudot, 45.45 bauds, 170 Hz shift) for rpitx v1
 *
 * Copyright (C) 2026 rpitx-baremetal contributors. Encoder of rpitx v2
 * src/pirtty/pirtty.cpp (F5OEO), unchanged except that characters with no
 * Baudot code are skipped (the v2 indexed out of its table) and that the
 * text length is not limited.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "bm_rfwrite.h"

#define byte uint8_t
#define BAUDOT_SHIFT_LTRS 0x1f
#define BAUDOT_SHIFT_FIGS 0x1b

static int MARK = 2125;
static int SPACE = 1955;
static const int BAUD_RATE = 22;	/* ms per bit: 45.45 baud */
static const char BAUDOT_FIGS[] = " \r\n1234567890-\a@!&#'()\"/:;?,.";
static const char BAUDOT_LTRS[] = " \r\nQWERTYUIOPASDFGHJKLZXCVBNM";
static const uint8_t baudot[] = {0x4,0x8,0x2,0x1d,0x19,0x10,0xa,0x1,0x15,0x1c,0xc,0x3,0xd,0x18,
	0x14,0x12,0x16,0xb,0x5,0x1a,0x1e,0x9,0x11,0x17,0xe,0xf,0x13,0x6,0x7};

static bm_rfwriter_t w;

static void rtty_txbit (int bit)
{
	/* v2: playtone(MARK or SPACE, BAUD_RATE*10000) in 0.1 us units */
	bm_rf_put (&w, bit ? MARK : SPACE, BAUD_RATE * 1e6, 0);
}

static void rtty_txbyte (byte c)
{
	rtty_txbit (0);				/* start bit */
	for (byte i = 5; i > 0; --i)
		rtty_txbit ((c & (1 << (i - 1))) != 0);
	rtty_txbit (1);				/* stop bits */
	rtty_txbit (1);
}

static void tx (const char *string)
{
	char c = *string++;
	byte pos = 0;
	byte shift = 0;
	while (c != '\0') {
		const char *index = strchr (BAUDOT_FIGS, c);
		if (index != NULL) {
			pos = index - BAUDOT_FIGS;
			if (pos > 2 && shift != 1) {
				shift = 1;
				rtty_txbyte (BAUDOT_SHIFT_FIGS);
			}
			rtty_txbyte (baudot[pos]);
		} else {
			c = toupper (c);
			index = strchr (BAUDOT_LTRS, c);
			if (index != NULL) {		/* BAREMETAL: skip unknown characters */
				pos = index - BAUDOT_LTRS;
				if (pos > 2 && shift != 2) {
					shift = 2;
					rtty_txbyte (31);
				}
				rtty_txbyte (baudot[pos]);
			} else {
				fprintf (stderr, "No Baudot code for '%c', skipped\n", c);
			}
		}
		c = *string++;
	}
}

int pirtty_main (int argc, char **argv)
{
	if (argc < 4) {
		printf ("usage : pirtty out.ft [Space Frequency offset(Hz), v2 easytest: 1000] [text]\n"
			"Mark = Space + 170 Hz, 45.45 bauds\n"
			"Then : rpitx -m RF -i out.ft -f <kHz>\n");
		return 1;
	}
	SPACE = atoi (argv[2]);
	MARK = SPACE + 170;
	if (SPACE == 0) SPACE = 1;		/* 0 Hz would mean "carrier off" in v1 RF mode */
	if (!bm_rf_open (&w, argv[1]))
		return 1;
	tx (argv[3]);
	if (!bm_rf_close (&w))
		return 1;
	printf ("RTTY %.1f s written to %s\n", w.total_ns / 1e9, argv[1]);
	return 0;
}
