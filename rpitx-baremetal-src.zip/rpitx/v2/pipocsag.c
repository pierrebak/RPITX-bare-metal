/*MIT License

Copyright (c) 2016 Galen Alderson

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Fork and modification for rpitx (c)(F5OEO 2018)

rpitx-baremetal (2026): taken from rpitx v2 src/pocsag/pocsag.cpp, compiled
as C. The encoder above SendFsk() is unchanged (only "new char[]" and the
includes). SendFsk() writes an rpitx v1 RF file (2-FSK, +/-4500 Hz, one
record per bit) instead of driving librpitx, and the messages come from the
command line instead of stdin (same "address:message" lines).

** 11.09.2019 : Added Numeric Pager support by cuddlycheetah (github.com/cuddlycheetah)
** 14.10.2019 : Added Repeating Transmission + Single Preamble Mode

*/
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>
#include <stdbool.h>
#include <fcntl.h>
#include <bm_compat.h>

#define PROGRAM_VERSION "0.3"
//Check out main() at the bottom of the file
//You can modify MIN_DELAY and MAX_DELAY to fit your needs.

//Check out https://en.wikipedia.org/wiki/POCSAG
//Also see http://www.itu.int/dms_pubrec/itu-r/rec/m/R-REC-M.584-2-199711-I!!PDF-E.pdf
//They'll be handy when trying to understand this stuff.

//The sync word exists at the start of every batch.
//A batch is 16 words, so a sync word occurs every 16 data words.
#define SYNC 0x7CD215D8

//The idle word is used as padding before the address word, and at the end
//of a message to indicate that the message is finished. Interestingly, the
//idle word does not have a valid CRC code, while the sync word does.
#define IDLE 0x7A89C197

//One frame consists of a pair of two words
#define FRAME_SIZE 2

//One batch consists of 8 frames, or 16 words
#define BATCH_SIZE 16

//The preamble comes before a message, and is a series of alternating
//1,0,1,0... bits, for at least 576 bits. It exists to allow the receiver
//to synchronize with the transmitter
#define PREAMBLE_LENGTH 576

//These bits appear as the first bit of a word, 0 for an address word and
//one for a data word
#define FLAG_ADDRESS 0x000000
#define FLAG_MESSAGE 0x100000

//The last two bits of an address word's data represent the data type
//0x3 for text, and 0x0 for numeric.
#define FLAG_TEXT_DATA 0x3
#define FLAG_NUMERIC_DATA = 0x0;

//Each data word can contain 20 bits of text information. Each character is
//7 bits wide, ASCII encoded. The bit order of the characters is reversed from
//the normal bit order; the most significant bit of a word corresponds to the
//least significant bit of a character it is encoding. The characters are split
//across the words of a message to ensure maximal usage of all bits.
#define TEXT_BITS_PER_WORD 20

//As mentioned above, characters are 7 bit ASCII encoded
#define TEXT_BITS_PER_CHAR 7

#define NUMERIC_BITS_PER_WORD 20
#define NUMERIC_BITS_PER_DIGIT 4

//Length of CRC codes in bits
#define CRC_BITS 10

//The CRC generator polynomial
#define CRC_GENERATOR 0b11101101001

/**
 * Calculate the CRC error checking code for the given word.
 * Messages use a 10 bit CRC computed from the 21 data bits.
 * This is calculated through a binary polynomial long division, returning
 * the remainder.
 * See https://en.wikipedia.org/wiki/Cyclic_redundancy_check#Computation
 * for more information.
 */
uint32_t crc(uint32_t inputMsg)
{
    //Align MSB of denominatorerator with MSB of message
    uint32_t denominator = CRC_GENERATOR << 20;

    //Message is right-padded with zeroes to the message length + crc length
    uint32_t msg = inputMsg << CRC_BITS;

    //We iterate until denominator has been right-shifted back to it's original value.
    for (int column = 0; column <= 20; column++)
    {
        //Bit for the column we're aligned to
        int msgBit = (msg >> (30 - column)) & 1;

        //If the current bit is zero, we don't modify the message this iteration
        if (msgBit != 0)
        {
            //While we would normally subtract in long division, we XOR here.
            msg ^= denominator;
        }

        //Shift the denominator over to align with the next column
        denominator >>= 1;
    }

    //At this point 'msg' contains the CRC value we've calculated
    return msg & 0x3FF;
}

/**
 * Calculates the even parity bit for a message.
 * If the number of bits in the message is even, return 0, else return 1.
 */
uint32_t parity(uint32_t x)
{
    //Our parity bit
    uint32_t p = 0;

    //We xor p with each bit of the input value. This works because
    //xoring two one-bits will cancel out and leave a zero bit.  Thus
    //xoring any even number of one bits will result in zero, and xoring
    //any odd number of one bits will result in one.
    for (int i = 0; i < 32; i++)
    {
        p ^= (x & 1);
        x >>= 1;
    }
    return p;
}

/**
 * Encodes a 21-bit message by calculating and adding a CRC code and parity bit.
 */
uint32_t encodeCodeword(uint32_t msg)
{
    uint32_t fullCRC = (msg << CRC_BITS) | crc(msg);
    uint32_t p = parity(fullCRC);
    return (fullCRC << 1) | p;
}

/**
 * ASCII encode a null-terminated string as a series of codewords, written
 * to (*out). Returns the number of codewords written. Caller should ensure
 * that enough memory is allocated in (*out) to contain the message
 *
 * initial_offset indicates which word in the current batch the function is
 * beginning at, so that it can insert SYNC words at appropriate locations.
 */
uint32_t encodeASCII(uint32_t initial_offset, char *str, uint32_t *out)
{
    //Number of words written to *out
    uint32_t numWordsWritten = 0;

    //Data for the current word we're writing
    uint32_t currentWord = 0;

    //Nnumber of bits we've written so far to the current word
    uint32_t currentNumBits = 0;

    //Position of current word in the current batch
    uint32_t wordPosition = initial_offset;

    while (*str != 0)
    {
        unsigned char c = *str;
        str++;
        //Encode the character bits backwards
        for (int i = 0; i < TEXT_BITS_PER_CHAR; i++)
        {
            currentWord <<= 1;
            currentWord |= (c >> i) & 1;
            currentNumBits++;
            if (currentNumBits == TEXT_BITS_PER_WORD)
            {
                //Add the MESSAGE flag to our current word and encode it.
                *out = encodeCodeword(currentWord | FLAG_MESSAGE);
                out++;
                currentWord = 0;
                currentNumBits = 0;
                numWordsWritten++;

                wordPosition++;
                if (wordPosition == BATCH_SIZE)
                {
                    //We've filled a full batch, time to insert a SYNC word
                    //and start a new one.
                    *out = SYNC;
                    out++;
                    numWordsWritten++;
                    wordPosition = 0;
                }
            }
        }
    }

    //Write remainder of message
    if (currentNumBits > 0)
    {
        //Pad out the word to 20 bits with zeroes
        currentWord <<= 20 - currentNumBits;
        *out = encodeCodeword(currentWord | FLAG_MESSAGE);
        out++;
        numWordsWritten++;

        wordPosition++;
        if (wordPosition == BATCH_SIZE)
        {
            //We've filled a full batch, time to insert a SYNC word
            //and start a new one.
            *out = SYNC;
            out++;
            numWordsWritten++;
            wordPosition = 0;
        }
    }

    return numWordsWritten;
}

// Char Translationtable
static char mirrorTab[10] = {0x00, 0x08, 0x04, 0x0c, 0x02, 0x0a, 0x06, 0x0e, 0x01, 0x09};
char encodeDigit(char ch)
{
    if (ch >= '0' && ch <= '9')
        return mirrorTab[ch - '0'];

    switch (ch)
    {
    case ' ':
        return 0x03;

    case 'u':
    case 'U':
        return 0x0d;

    case '-':
    case '_':
        return 0x0b;

    case '(':
    case '[':
        return 0x0f;

    case ')':
    case ']':
        return 0x07;
    }

    return 0x05;
}

uint32_t encodeNumeric(uint32_t initial_offset, char *str, uint32_t *out)
{
    //Number of words written to *out
    uint32_t numWordsWritten = 0;

    //Data for the current word we're writing
    uint32_t currentWord = 0;

    //Nnumber of bits we've written so far to the current word
    uint32_t currentNumBits = 0;

    //Position of current word in the current batch
    uint32_t wordPosition = initial_offset;

    while (*str != 0)
    {
        unsigned char c = *str;
        str++;
        //Encode the digit bits backwards
        for (int i = 0; i < NUMERIC_BITS_PER_DIGIT; i++)
        {
            currentWord <<= 1;
            char digit = encodeDigit(c);
            digit = ((digit & 1) << 3) |
                    ((digit & 2) << 1) |
                    ((digit & 4) >> 1) |
                    ((digit & 8) >> 3);

            currentWord |= (digit >> i) & 1;
            currentNumBits++;
            if (currentNumBits == NUMERIC_BITS_PER_WORD)
            {
                //Add the MESSAGE flag to our current word and encode it.
                *out = encodeCodeword(currentWord | FLAG_MESSAGE);
                out++;
                currentWord = 0;
                currentNumBits = 0;
                numWordsWritten++;

                wordPosition++;
                if (wordPosition == BATCH_SIZE)
                {
                    //We've filled a full batch, time to insert a SYNC word
                    //and start a new one.
                    *out = SYNC;
                    out++;
                    numWordsWritten++;
                    wordPosition = 0;
                }
            }
        }
    }

    //Write remainder of message
    if (currentNumBits > 0)
    {
        //Pad out the word to 20 bits with zeroes
        currentWord <<= 20 - currentNumBits;
        *out = encodeCodeword(currentWord | FLAG_MESSAGE);
        out++;
        numWordsWritten++;

        wordPosition++;
        if (wordPosition == BATCH_SIZE)
        {
            //We've filled a full batch, time to insert a SYNC word
            //and start a new one.
            *out = SYNC;
            out++;
            numWordsWritten++;
            wordPosition = 0;
        }
    }

    return numWordsWritten;
}

/**
 * An address of 21 bits, but only 18 of those bits are encoded in the address
 * word itself. The remaining 3 bits are derived from which frame in the batch
 * is the address word. This calculates the number of words (not frames!)
 * which must precede the address word so that it is in the right spot. These
 * words will be filled with the idle value.
 */
int addressOffset(int address)
{
    return (address & 0x7) * FRAME_SIZE;
}

/**
 * Encode a full text POCSAG transmission addressed to (address).
 * (*message) is a null terminated C string.
 * (*out) is the destination to which the transmission will be written.
 */
bool numeric = false;
uint32_t encodeTransmission(int repeatIndex, int address, int fb, char *message, uint32_t *out)
{
    //BAREMETAL: on memorise le debut pour renvoyer le nombre REEL de mots ecrits
    //(le tampon est alloue plus grand ; on ne transmet que ce qui est encode,
    //jamais la memoire non initialisee -> plus de trames parasites)
    uint32_t *out0 = out;

    //Encode preamble
    //Alternating 1,0,1,0 bits for 576 bits, used for receiver to synchronize
    //with transmitter. BAREMETAL: un preambule AVANT CHAQUE copie (et pas
    //seulement la premiere) pour que chaque repetition soit decodable seule
    //(sinon le recepteur perd la synchro -> trames parasites).
    (void) repeatIndex;
    for (int i = 0; i < PREAMBLE_LENGTH / 32; i++)
    {
        *out = 0xAAAAAAAA;
        out++;
    }

    uint32_t *start = out;

    //Sync
    *out = SYNC;
    out++;

    //Write out padding before adderss word
    int prefixLength = addressOffset(address);
    for (int i = 0; i < prefixLength; i++)
    {
        *out = IDLE;
        out++;
    }

    //Write address word.
    //The last two bits of word's data contain the message type (function bits)
    //The 3 least significant bits are dropped, as those are encoded by the
    //word's location.
    *out = encodeCodeword(((address >> 3) << 2) | fb);
    out++;

    //Encode the message itself
    if (numeric == true)
    {
        out += encodeNumeric(addressOffset(address) + 1, message, out);
    }
    else
    {
        out += encodeASCII(addressOffset(address) + 1, message, out);
    }

    //Finally, write an IDLE word indicating the end of the message
    *out = IDLE;
    out++;

    //Pad out the last batch with IDLE to write a multiple of BATCH_SIZE + 1
    //words (+ 1 is there because of the SYNC words). BAREMETAL: si on est deja
    //aligne, padding = 0 (l'original ajoutait un batch IDLE entier inutile).
    size_t written = out - start;
    size_t rem = written % (BATCH_SIZE + 1);
    size_t padding = rem ? (BATCH_SIZE + 1) - rem : 0;
    for (size_t i = 0; i < padding; i++)
    {
        *out = IDLE;
        out++;
    }

    return (uint32_t) (out - out0);
}

/**
 * Calculates the length in words of a text POCSAG message, given the address
 * and the number of characters to be transmitted.
 */
size_t textMessageLength(int repeatIndex, int address, int numChars)
{
    size_t numWords = 0;

    //Padding before address word.
    numWords += addressOffset(address);

    //Address word itself
    numWords++;

    //numChars * 7 bits per character / 20 bits per word, rounding up
    numWords += (numChars * TEXT_BITS_PER_CHAR + (TEXT_BITS_PER_WORD - 1)) / TEXT_BITS_PER_WORD;

    //Idle word representing end of message
    numWords++;

    //Pad out last batch with idles
    numWords += BATCH_SIZE - (numWords % BATCH_SIZE);

    //Batches consist of 16 words each and are preceded by a sync word.
    //So we add one word for every 16 message words
    numWords += numWords / BATCH_SIZE;

    //Preamble before every copy (see encodeTransmission): included for the
    //buffer size (we only transmit the real encoded count anyway)
    (void) repeatIndex;
    numWords += PREAMBLE_LENGTH / 32;

    return numWords;
}

/**
 * Calculates the length in words of a numeric POCSAG message, given the address
 * and the number of characters to be transmitted.
 */
size_t numericMessageLength(int repeatIndex, int address, int numChars)
{
    size_t numWords = 0;

    //Padding before address word.
    numWords += addressOffset(address);

    //Address word itself
    numWords++;

    //numChars * 7 bits per character / 20 bits per word, rounding up
    numWords += (numChars * NUMERIC_BITS_PER_DIGIT + (NUMERIC_BITS_PER_WORD - 1)) / NUMERIC_BITS_PER_WORD;

    //Idle word representing end of message
    numWords++;

    //Pad out last batch with idles
    numWords += BATCH_SIZE - (numWords % BATCH_SIZE);

    //Batches consist of 16 words each and are preceded by a sync word.
    //So we add one word for every 16 message words
    numWords += numWords / BATCH_SIZE;

    //Preamble before every copy (see encodeTransmission)
    (void) repeatIndex;
    numWords += PREAMBLE_LENGTH / 32;

    return numWords;
}


/* BAREMETAL: output as an rpitx v1 RF / RFA file instead of librpitx.
   Record = {double Frequency (or Amplitude in RFA mode), uint32_t time in ns}.
   The padding is zeroed (v1 generators wrote uninitialised stack bytes). */
typedef struct {
	double Frequency;
	uint32_t WaitForThisSample;
} bm_samplerf_t;

static int bm_out_fd = -1;
static int bm_write_record(double value, double time_ns)
{
	bm_samplerf_t r;
	memset(&r, 0, sizeof r);
	r.Frequency = value;
	r.WaitForThisSample = (uint32_t) (time_ns + 0.5);
	return write(bm_out_fd, &r, sizeof r) == sizeof r;
}

/* Same symbols as the v2 SendFsk() / fskburst(Freq - Deviation, SR,
   Deviation * 2): symbol 0 -> -Deviation, symbol 1 -> +Deviation */
static int SendFsk(bool Inverted, int SR, bool debug, uint32_t *Message, int Size)
{
    float Deviation = 4500;
    int Sym = 0;
    for (int i = 0; i < Size; i++)
    {
        if (!Inverted)
            Message[i] = ~Message[i];
        for (int j = 31; j >= 0; j--)
        {
            int bit = (Message[i] >> j) & 0x1;
            if (!bm_write_record(bit ? Deviation : -Deviation, 1e9 / SR))
                return 0;
            Sym++;
        }
    }
    if (debug)
        fprintf(stderr, "Symbols=%d\n", Sym);
    return 1;
}

static void print_usage(void)
{
    fprintf(stderr,
            "\npipocsag -%s (rpitx v2 pocsag encoder, bare metal)\n\
Usage: pipocsag [-r Rate] [-b bits] [-n] [-t count] [-i] out.ft \"address:message\" ...\n\
-r int        baud rate (512, 1200 or 2400. Default 1200 bps),\n\
-b int        function bits (0-3. Default 3),\n\
-n            use numeric messages,\n\
-t int        repeat messages X times (Default 4)\n\
-i            invert the modulation polarity,\n\
-d            debug,\n\
Several messages: several arguments, or \\n inside one argument.\n\
Then: rpitx -m RF -i out.ft -f <kHz>\n\
\n",
            PROGRAM_VERSION);
}

int pipocsag_main(int argc, char *argv[]) {
    int a;
    int SetRate = 1200;
    int SetFunctionBits = 3;
    int REPEAT_COUNT = 2;	/* BAREMETAL: 2 copies (preambule par copie) */
    bool SetInverted = false;
    bool debug = false;
    numeric = false;            /* BAREMETAL: globals survive between runs */
    while ((a = getopt(argc, argv, "b:dnir:t:")) != -1) {
        switch (a) {
            case 'n': numeric = true; break;
            case 't': REPEAT_COUNT = atoi(optarg); break;
            case 'd': debug = true; break;
            case 'b':
                SetFunctionBits = -1;
                sscanf(optarg, "%d", &SetFunctionBits);
                if (SetFunctionBits < 0 || SetFunctionBits > 3)
                {
                    fprintf(stderr, "Invalid function bits!");
                    print_usage();
                    exit(1);
                }
                break;
            case 'r':
                SetRate = atoi(optarg);
                if (SetRate != 512 && SetRate != 1200 && SetRate != 2400) {
                    fprintf(stderr, "Invalid baud rate!");
                    print_usage();
                    exit(1);
                }
                break;
            case 'i': SetInverted = true; break;
            default: print_usage(); exit(1);
        }
    }
    if (argc - optind < 2) {
        print_usage();
        exit(1);
    }
    bm_out_fd = open(argv[optind], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (bm_out_fd < 0) {
        fprintf(stderr, "Cannot create %s\n", argv[optind]);
        exit(1);
    }

    /* The v2 read "printf '<text>' | pocsag" with fgets(): a "\n" escape
       ends a line and stays at the end of its message (fgets keeps it). */
    static char text[4096];
    text[0] = 0;
    for (int k = optind + 1; k < argc; k++) {
        if (k > optind + 1) strncat(text, "\n", sizeof text - strlen(text) - 1);
        strncat(text, argv[k], sizeof text - strlen(text) - 1);
    }
    static char lines[4096];
    int n = 0;
    for (char *p = text; *p && n < (int) sizeof lines - 1; p++) {
        if (p[0] == '\\' && p[1] == 'n') { lines[n++] = '\n'; p++; }
        else lines[n++] = *p;
    }
    lines[n] = 0;

    int msgIndex = 0;
    size_t completeLength = 0;
    uint32_t *completeTransmission = NULL;
    char *line = lines;
    while (*line) {
        char *eol = strchr(line, '\n');
        char saved = 0;
        char *next;
        if (eol) { saved = eol[1]; eol[1] = 0; next = eol + 1; }
        else next = line + strlen(line);

        char *colon = strchr(line, ':');
        if (colon == NULL) {
            fputs("Malformed Line!", stderr);
            close(bm_out_fd);
            exit(1);
        }
        char *endptr;
        int address = (int)strtol(line, &endptr, 10);
        char *message = colon + 1;
        switch (*endptr) {
            case 'a': case 'A': SetFunctionBits = 0; break;
            case 'b': case 'B': SetFunctionBits = 1; break;
            case 'c': case 'C': SetFunctionBits = 2; break;
            case 'd': case 'D': SetFunctionBits = 3; break;
        }

        for (int x = 0; x < REPEAT_COUNT; x++) {
            size_t messageLength = numeric
                                       ? numericMessageLength(msgIndex, address, strlen(message))
                                       : textMessageLength(msgIndex, address, strlen(message));
            //BAREMETAL: marge d'un batch pour absorber l'ecart de calcul entre
            //messageLength et le remplissage reel (anti-debordement)
            size_t cap = messageLength + 2 * (BATCH_SIZE + 1);
            uint32_t *transmission = (uint32_t *)malloc(sizeof(uint32_t) * cap);
            //on n'ajoute QUE les mots reellement encodes, jamais la queue non initialisee
            uint32_t actual = encodeTransmission(msgIndex, address, SetFunctionBits, message, transmission);
            completeTransmission = (uint32_t *)realloc(completeTransmission,
                                       sizeof(uint32_t) * (completeLength + actual));
            memcpy(completeTransmission + completeLength, transmission, sizeof(uint32_t) * actual);
            completeLength += actual;
            free(transmission);
            msgIndex++;
        }
        if (eol) eol[1] = saved;
        line = next;
    }

    int ok = SendFsk(SetInverted, SetRate, debug, completeTransmission, completeLength);
    free(completeTransmission);
    close(bm_out_fd);
    if (!ok) {
        fprintf(stderr, "Write error\n");
        return 1;
    }
    printf("%u words, %u bits at %d bauds written to %s\n", (unsigned) completeLength,
           (unsigned) completeLength * 32, SetRate, argv[optind]);
    return 0;
}
