/*
 * pichirp.c - moving carrier ("Chirp" of rpitx v2 easytest) for rpitx v1
 *
 * Copyright (C) 2026 rpitx-baremetal contributors. Signal of rpitx v2
 * src/chirp/chirp.cpp (F5OEO): frequency = Bandwidth/2 * sin(2*pi*t/Time).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The v2 updated the frequency 200000 times per second; one period is
 * written here at 10000 updates per second (rpitx v1 RF mode), to be
 * looped: rpitx -m RF -i chirp.ft -f <kHz> -l
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "bm_rfwrite.h"

int pichirp_main (int argc, char *argv[])
{
	if (argc < 2) {
		printf ("Usage : pichirp out.ft [Bandwidth(Hz), default 100000] [Time(Seconds), default 5]"
			" [rate, default 10000]\n"
			"Then : rpitx -m RF -i out.ft -f <kHz> -l\n");
		return 1;
	}
	float Bandwidth = argc > 2 ? atof (argv[2]) : 100000;
	float Time = argc > 3 ? atof (argv[3]) : 5;
	int SR = argc > 4 ? atoi (argv[4]) : 10000;
	if (Time <= 0 || SR < 100 || SR > 50000) {
		fprintf (stderr, "Invalid time or rate\n");
		return 1;
	}

	bm_rfwriter_t w;
	if (!bm_rf_open (&w, argv[1]))
		return 1;

	/* same sequence as the v2: count = 0 .. NbStepWithSR, then restarts */
	int NbStepWithSR = Time * SR;
	for (int count = 0; count <= NbStepWithSR && w.ok; count++) {
		double f = Bandwidth * 0.5 * sin (2 * 3.1415 * (float) count / (float) NbStepWithSR);
		bm_rf_put (&w, f == 0.0 ? RF_ZERO_HZ : f, 1e9 / SR, 0);
	}
	if (!bm_rf_close (&w))
		return 1;
	printf ("Chirp +/-%.0f Hz, period %.2f s, %ld samples written to %s\n",
		Bandwidth / 2, Time, w.records, argv[1]);
	return 0;
}
