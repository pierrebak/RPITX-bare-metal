/*
 * pimorse.c - Morse (CW, on/off keying) for rpitx v1 RFA mode
 *
 * Copyright (C) 2026 rpitx-baremetal contributors. Encoder of rpitx v2
 * src/morse/morse.cpp (code table, dot = "10", dash = "1110", one symbol
 * lasts 1.25/rate seconds, the last symbol of each character's burst is
 * not sent, exactly as Send_CW_OOK() did). Characters without a Morse code
 * are skipped (the v2 crashed on them).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "bm_rfwrite.h"

#define MORSECODES 37

typedef struct morse_code {
	uint8_t ch;
	const char dits[8];
} Morsecode;

static const Morsecode code_table[] = {
	{' ', "    "}, {'0', "-----  "}, {'1', ".----  "}, {'2', "..---  "},
	{'3', "...--  "}, {'4', "....-  "}, {'5', ".....  "}, {'6', "-....  "},
	{'7', "--...  "}, {'8', "---..  "}, {'9', "----.  "}, {'A', ".-  "},
	{'B', "-...  "}, {'C', "-.-.  "}, {'D', "-..  "}, {'E', ".  "},
	{'F', "..-.  "}, {'G', "--.  "}, {'H', "....  "}, {'I', "..  "},
	{'J', ".---  "}, {'K', "-.-  "}, {'L', ".-..  "}, {'M', "--  "},
	{'N', "-.  "}, {'O', "---  "}, {'P', ".--.  "}, {'Q', "--.-  "},
	{'R', ".-.  "}, {'S', "...  "}, {'T', "-  "}, {'U', "..-  "},
	{'V', "...-  "}, {'W', ".--  "}, {'X', "-..-  "}, {'Y', "-.--  "},
	{'Z', "--..  "}
};

static void morse_to_cw (const char *dits, char *cw)
{
	int a = 0;
	for (int i = 0; dits[i] != '\0'; i++) {
		if (dits[i] == '.') { cw[a++] = '1'; cw[a++] = '0'; }
		else if (dits[i] == '-') { cw[a++] = '1'; cw[a++] = '1'; cw[a++] = '1'; cw[a++] = '0'; }
		else if (dits[i] == ' ') { cw[a++] = '0'; }
	}
	cw[a] = '\0';
}

static const char *text_to_morse (char txt)
{
	char tch = toupper (txt);
	for (int j = 0; j < MORSECODES; j++)
		if (code_table[j].ch == tch)
			return code_table[j].dits;
	return NULL;
}

int pimorse_main (int argc, char *argv[])
{
	if (argc < 4) {
		printf ("usage: pimorse rate(dits, v2 default 5) \"MSG\" out.rfa\n"
			"one symbol lasts 1.25/rate s, as in rpitx v2 morse\n"
			"Then: rpitx -m RFA -i out.rfa -f <kHz>\n");
		return 1;
	}
	float wpm = atof (argv[1]);
	const char *msg = argv[2];
	if (wpm <= 0) {
		fprintf (stderr, "Invalid rate\n");
		return 1;
	}
	double symbol_ns = 1e9 / (wpm / 1.25);

	bm_rfwriter_t w;
	if (!bm_rf_open (&w, argv[3]))
		return 1;

	printf ("msg: %s\n", msg);
	char cw[32];
	for (int i = 0; msg[i] != '\0' && w.ok; i++) {
		const char *dits = text_to_morse (msg[i]);
		if (dits == NULL) {
			fprintf (stderr, "No Morse code for '%c', skipped\n", msg[i]);
			continue;
		}
		morse_to_cw (dits, cw);
		printf ("msg[%02d]: %c\tmorse[%s]\tcw[%s]\n", i, toupper (msg[i]), dits, cw);
		int n = strlen (cw) - 1;		/* FifoSize = strlen(cw) - 1 in v2 */
		for (int k = 0; k < n; k++)
			bm_rf_put (&w, cw[k] == '0' ? 0.0 : 32767.0, symbol_ns, 1);
	}
	if (!bm_rf_close (&w))
		return 1;
	printf ("Morse %.1f s written to %s\n", w.total_ns / 1e9, argv[3]);
	return 0;
}
