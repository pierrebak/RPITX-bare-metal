#!/bin/bash
#
# Host (PC) regression test for the bare metal port of the rpitx v1 generators.
#
#   A: original rpitx v1 sources linked with the real libsndfile
#   B: sources of this tree linked with compat/sndfile.c (our WAV layer)
#
# Both are run on the same inputs; the generated .ft/.rfa/.wav files must be
# identical (WAV files: same samples). Also checks bmp2rgb against ImageMagick.
#
# Usage: hosttest/run_generators.sh /path/to/rpitx-v1-checkout
#
set -euo pipefail

V1=${1:?path to an rpitx checkout at tag v1}
HERE=$(cd "$(dirname "$0")/.." && pwd)
WORK=$(mktemp -d)
trap '[ -n "${KEEP:-}" ] || rm -rf "$WORK"' EXIT

mkdir -p "$WORK/A" "$WORK/B" "$WORK/shim"
ln -s "$HERE/compat/include/sndfile.h" "$WORK/shim/sndfile.h"

CF="-O2 -w"
build_a () { gcc $CF -o "$WORK/A/$1" "${@:2}" -lsndfile -lm; }
build_b () { gcc $CF -I "$WORK/shim" -o "$WORK/B/$1" "${@:2}" "$HERE/compat/sndfile.c" -lm; }

build_a pifm    "$V1/fm/pifm.c"
build_a piam    "$V1/am/piam.c"
build_a pissb   "$V1/ssbgen/test_ssb.c" "$V1/ssbgen/ssb_gen.c"
build_a pisstv  "$V1/sstv/pisstv.c"
build_a pifsq   "$V1/fsq/pifsq.c"
build_a pidcf77 "$V1/dcf77/pidcf77.c"

build_b pifm    "$HERE/rpitx/fm/pifm.c"
build_b piam    "$HERE/rpitx/am/piam.c"
build_b pissb   "$HERE/rpitx/ssbgen/test_ssb.c" "$HERE/rpitx/ssbgen/ssb_gen.c"
build_b pisstv  "$HERE/rpitx/sstv/pisstv.c"
build_b pifsq   "$HERE/rpitx/fsq/pifsq.c"
build_b pidcf77 "$HERE/rpitx/dcf77/pidcf77.c"
gcc $CF -include stdint.h -o "$WORK/B/bmp2rgb" -Dbmp2rgb_main=main "$HERE/tools/bmp2rgb.c"

# inputs: the v1 sample, plus a 16 bit stereo file and a 24 bit file
cp "$V1/sampleaudio.wav" "$WORK/in.wav"
sox -n -r 48000 -c 2 -b 16 "$WORK/in_stereo.wav" synth 2 sine 1000 sine 1500 vol 0.7
sox -n -r 48000 -c 1 -b 24 "$WORK/in_24.wav" synth 2 sine 700 vol 0.5
# 320x256 picture: same pixels whatever the converter
convert -size 320x256 gradient:red-blue -fill white -draw "circle 160,128 160,40" "$WORK/pic.bmp"
convert "$WORK/pic.bmp" -depth 8 "rgb:$WORK/pic_im.rgb"

run () {	# run <dir> <prog> <args...>
	(cd "$WORK/$1" && ./"$2" "${@:3}" > /dev/null 2>&1 || true)
}

FAIL=0
check () {	# check <file> [wav|rec]
	if [ "${2:-}" = rec ]; then
		# .ft/.rfa records are {double, uint32_t} written with 4 bytes of
		# uninitialised struct padding (v1 code): compare the fields only
		a=$(python3 -c 'import struct,sys;d=open(sys.argv[1],"rb").read();print([struct.unpack_from("<dI",d,i) for i in range(0,len(d)//16*16,16)])' "$WORK/A/$1" | md5sum | cut -c1-32)
		b=$(python3 -c 'import struct,sys;d=open(sys.argv[1],"rb").read();print([struct.unpack_from("<dI",d,i) for i in range(0,len(d)//16*16,16)])' "$WORK/B/$1" | md5sum | cut -c1-32)
	elif [ "${2:-}" = wav ]; then
		a=$(sox "$WORK/A/$1" -t raw - 2>/dev/null | md5sum | cut -c1-32)
		b=$(sox "$WORK/B/$1" -t raw - 2>/dev/null | md5sum | cut -c1-32)
	else
		a=$(md5sum < "$WORK/A/$1" | cut -c1-32)
		b=$(md5sum < "$WORK/B/$1" | cut -c1-32)
	fi
	size=$(stat -c %s "$WORK/B/$1")
	if [ "$a" = "$b" ]; then
		echo "OK    $1 ($size bytes)"
	else
		echo "DIFF  $1"; FAIL=1
	fi
}

for d in A B; do
	run $d pifm ../in.wav fm.ft
	run $d pifm ../in_stereo.wav fm_stereo.ft
	run $d piam ../in.wav am.rfa
	run $d piam ../in_24.wav am_24.rfa
	run $d pissb ../in.wav ssb.wav
	run $d pifsq "Test bare metal" fsq.ft
	run $d pidcf77 dcf.rfa
	run $d pisstv ../pic_im.rgb sstv.ft
done
run B bmp2rgb ../pic.bmp pic.rgb

check fm.ft rec; check fm_stereo.ft rec; check am.rfa rec; check am_24.rfa rec
check ssb.wav wav; check fsq.ft rec; check dcf.rfa rec; check sstv.ft rec

if cmp -s "$WORK/B/pic.rgb" "$WORK/pic_im.rgb"; then
	echo "OK    bmp2rgb == ImageMagick (320x256)"
else
	echo "DIFF  bmp2rgb"; FAIL=1
fi

exit $FAIL
