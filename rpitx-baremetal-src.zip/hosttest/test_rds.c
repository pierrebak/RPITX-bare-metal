/* Test du decodeur RDS sur un multiplex FM synthetique.
   On genere pilote 19 kHz + sous-porteuse RDS 57 kHz (biphase, decalage de phase,
   audio stereo parasite, bruit) avec un PI et un PS connus, et on verifie que le
   decodeur retrouve PI, PTY et le nom de station PS. */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "../tools/rds.h"

#define FS	256000.0
#define PI_D	3.141592653589793

/* --- encodeur de bloc RDS (identique a la norme) --- */
static unsigned checkword (unsigned info)
{
	unsigned reg = (info & 0xFFFF) << 10;
	for (int i = 25; i >= 10; i--)
		if (reg & (1u << i)) reg ^= 0x5B9u << (i - 10);
	return reg & 0x3FF;
}
static unsigned mkblock (unsigned info, unsigned off)
{
	return ((info & 0xFFFF) << 10) | ((checkword (info) ^ off) & 0x3FF);
}

#define OFF_A 0x0FC
#define OFF_B 0x198
#define OFF_C 0x168
#define OFF_D 0x1B4

int main (void)
{
	const unsigned PI_CODE = 0xF221;
	const int PTY = 10;
	const char *PS = "RADIO-BM";		/* 8 caracteres */
	const char *RT = "ICI RADIO BAREMETAL FM 2026     ";	/* 32 caracteres */

	/* --- construit le flux de bits : alternance groupes 0A (PS) et 2A (RT) --- */
	static unsigned char data[200000];
	int nb = 0;
	int ngroups = 640;
	for (int g = 0; g < ngroups; g++) {
		unsigned A = mkblock (PI_CODE, OFF_A);
		unsigned B, C, D;
		if (g & 1) {				/* groupe 2A : RadioText */
			int addr = (g >> 1) & 7;	/* 8 segments de 4 car. = 32 car. */
			unsigned Binfo = (2 << 12) | (0 << 11) | (0 << 10) | (PTY << 5) | (0 << 4) | addr;
			B = mkblock (Binfo, OFF_B);
			C = mkblock (((unsigned char) RT[addr * 4] << 8) | (unsigned char) RT[addr * 4 + 1], OFF_C);
			D = mkblock (((unsigned char) RT[addr * 4 + 2] << 8) | (unsigned char) RT[addr * 4 + 3], OFF_D);
		} else {				/* groupe 0A : nom de station */
			int seg = (g >> 1) & 3;
			unsigned Binfo = (0 << 12) | (0 << 11) | (0 << 10) | (PTY << 5) | (0 << 4) | seg;
			B = mkblock (Binfo, OFF_B);
			C = mkblock (0xCDCD, OFF_C);
			D = mkblock (((unsigned char) PS[seg * 2] << 8) | (unsigned char) PS[seg * 2 + 1], OFF_D);
		}
		unsigned blocks[4] = { A, B, C, D };
		for (int k = 0; k < 4; k++)
			for (int i = 25; i >= 0; i--)
				data[nb++] = (blocks[k] >> i) & 1;
	}

	/* --- codage differentiel --- */
	static unsigned char diff[200000];
	int e = 0;
	for (int i = 0; i < nb; i++) { e ^= data[i]; diff[i] = e; }

	/* --- generation du multiplex echantillon par echantillon --- */
	rds_t r; rds_init (&r);
	double pilot_cyc = 19000.0 / FS;		/* cycles/echantillon */
	double bit_per_s = 1187.5;
	double theta = 0.7;				/* decalage de phase RDS a corriger */
	double af1 = 1200.0, af2 = 9000.0;		/* audio L+R et L-R (aigu parasite) */
	unsigned seed = 12345;

	long total = (long) (nb / bit_per_s * FS) + FS;	/* assez d'echantillons */
	for (long n = 0; n < total; n++) {
		double t = n / FS;
		uint32_t pilot_ph = (uint32_t) (fmod (n * pilot_cyc, 1.0) * 4294967296.0);

		/* bit biphase courant */
		long bit = (long) (t * bit_per_s);
		if (bit >= nb) break;
		double frac = t * bit_per_s - bit;		/* 0..1 dans le bit */
		int chip = diff[bit] ? (frac < 0.5 ? 1 : -1) : (frac < 0.5 ? -1 : 1);
		double rds = 0.05 * chip * cos (2 * PI_D * 3 * 19000.0 * t + theta);

		double pilot = 0.09 * sin (2 * PI_D * 19000.0 * t);
		double lr = 0.30 * sin (2 * PI_D * af1 * t);
		double diffaudio = 0.25 * sin (2 * PI_D * af2 * t) * sin (2 * PI_D * 2 * 19000.0 * t);
		seed = seed * 1103515245u + 12345u;
		double noise = 0.02 * (((seed >> 8) & 0xFFFF) / 32768.0 - 1.0);

		double mpx = lr + diffaudio + pilot + rds + noise;
		rds_feed (&r, (float) mpx, pilot_ph);
	}

	printf ("bits=%u blocs_ok=%u groupes=%u synchro=%d\n",
		r.bits, r.blocks_ok, r.groups, r.synced);
	printf ("PI=%04X (attendu %04X)  PTY=%d  PS=\"%s\"  ps_ok=%d\n",
		r.pi < 0 ? 0 : r.pi, PI_CODE, r.pty, r.ps, r.ps_ok);
	printf ("RT=\"%s\"  rt_ok=%d\n", r.rt, r.rt_ok);

	int pass = (r.pi == (int) PI_CODE) && r.ps_ok && strcmp (r.ps, PS) == 0 && r.pty == PTY
		   && r.rt_ok && strncmp (r.rt, "ICI RADIO BAREMETAL FM 2026", 27) == 0;
	printf (pass ? "PASS\n" : "FAIL\n");
	return pass ? 0 : 1;
}
