/*
 * test_rtldsp.c - host test of tools/rtldsp.c + rpitx/pitx_freq.c, followed
 * by the rpitx v1 IQ mode frequency computation (copied from RpiTx.c,
 * including the harmonic mode above 250 MHz).
 *
 * Simulates an RTL-SDR tuned Fs/4 above the received frequency, with a DC
 * offset (LO leak), the wanted signal and an out-of-channel interferer.
 *  - RELAY: checks channel position, interferer rejection, and that rpitx
 *    transmits the tone at F_tx + tone offset (below and above 250 MHz);
 *  - FM2SSB: an FM signal modulated by an audio tone must come out as a
 *    single tone at F_tx + audio frequency, the lower side band suppressed.
 *
 * Build: see hosttest/run_all.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
#include "rtldsp.h"

int bm_plld_mhz = 500;			/* default firmware PLLD (no dt-blob.bin) */
int pitx_harmonic_for (double Frequency);
double pitx_iq_set_frequency (double WantedHz, double ShiftHz);

#define FS_IN 240000
#define N_IN (FS_IN * 2)		/* 2 seconds */

/* ---- copied from rpitx v1 src/RpiTx.c ---- */
static int arctan2 (int y, int x)
{
	int abs_y = abs (y);
	int angle;
	if ((x == 0) && (y == 0)) return 0;
	if (x >= 0) angle = 45 - 45 * (x - abs_y) / ((x + abs_y) == 0 ? 1 : (x + abs_y));
	else angle = 135 - 45 * (x + abs_y) / ((abs_y - x) == 0 ? 1 : (abs_y - x));
	return (y < 0) ? -angle : angle;
}
static double prev_phase = 0;
static void IQToFreqAmp (int I, int Q, double *Frequency, int *Amp, int SampleRate)
{
	double phase;
	*Amp = round (sqrt (I * I + Q * Q) / sqrt (2));
	if (*Amp > 32767) *Amp = 32767;
	phase = M_PI + ((float) arctan2 (I, Q)) * M_PI / 180.0f;
	double dp = phase - prev_phase;
	if (dp < 0) dp = dp + 2 * M_PI;
	*Frequency = dp * SampleRate / (2.0f * M_PI);
	prev_phase = phase;
}
/* pitx_SetTuneFrequency + IQ branch of pitx_run (rpitx/RpiTx.c, harmonic
   fix of this port): frequency of the harmonic H of the fundamental written
   to the clock divider */
static double v1_iq_output (double set_hz, double df)
{
	int H = pitx_harmonic_for (set_hz);
	double Global = H > 1 ? set_hz / H : set_hz;
	double OffsetModulation = 1000;
	double reg = Global + (df - OffsetModulation) / H;
	return reg * H;
}
/* ------------------------------------------ */

static double tone_db (const int16_t *iq, int n, double f, double fs)
{
	double re = 0, im = 0;
	for (int k = 0; k < n; k++) {
		double a = -2 * M_PI * f * k / fs;
		double i = iq[2 * k], q = iq[2 * k + 1];
		re += i * cos (a) - q * sin (a);
		im += i * sin (a) + q * cos (a);
	}
	return 20 * log10 (sqrt (re * re + im * im) / n + 1e-9);
}

static int16_t *process (int mode, uint8_t *in, int *n_out)
{
	static rtldsp_t d;
	rtldsp_init (&d, FS_IN / RTLDSP_OUT_RATE, 12000, mode == RTLDSP_MODE_RELAY ? 0 : -200, 0, mode);
	int max_out = N_IN / 5 + 16;
	int16_t *out = malloc (max_out * 2 * sizeof (int16_t));
	int n = 0;
	for (int k = 0; k < N_IN * 2; k += 16384) {
		int len = N_IN * 2 - k < 16384 ? N_IN * 2 - k : 16384;
		n += rtldsp_process (&d, in + k, len, out + 2 * n, max_out - n);
	}
	*n_out = n;
	return out;
}

/* mean transmitted frequency, relative to the wanted one */
static double tx_offset_rate (int16_t *out, int n, int skip, double tx_hz, double shift, int rate)
{
	double set = pitx_iq_set_frequency (tx_hz, shift);
	double sum = 0;
	int cnt = 0;
	prev_phase = 0;
	for (int k = skip; k < n; k++) {
		double df; int amp;
		/* RpiTx.c calls IQToFreqAmp(IQArray[2i+1], IQArray[2i]) */
		IQToFreqAmp (out[2 * k + 1], out[2 * k], &df, &amp, rate);
		if (k > skip) { sum += v1_iq_output (set, df); cnt++; }
	}
	return sum / cnt - tx_hz;
}

static double tx_offset (int16_t *out, int n, int skip, double tx_hz, double shift)
{
	return tx_offset_rate (out, n, skip, tx_hz, shift, RTLDSP_OUT_RATE);
}

static uint8_t to_u8 (double x) { return (uint8_t) lrint (127.5 + 127 * x + (rand () % 3 - 1) * 0.5); }

static int run_relay (double tone_hz, double interferer_hz, double tx_hz)
{
	double tone_bb = tone_hz - FS_IN / 4, intf_bb = interferer_hz - FS_IN / 4;
	uint8_t *in = malloc (N_IN * 2);
	for (int k = 0; k < N_IN; k++) {
		double t = (double) k / FS_IN;
		in[2 * k] = to_u8 (0.30 * cos (2 * M_PI * tone_bb * t) + 0.30 * cos (2 * M_PI * intf_bb * t) + 0.05);
		in[2 * k + 1] = to_u8 (0.30 * sin (2 * M_PI * tone_bb * t) + 0.30 * sin (2 * M_PI * intf_bb * t) + 0.05);
	}
	int n;
	int16_t *out = process (RTLDSP_MODE_RELAY, in, &n);
	int skip = 4800;
	double p_tone = tone_db (out + 2 * skip, n - skip, tone_hz + RTLDSP_SHIFT_OUT_HZ, RTLDSP_OUT_RATE);
	double p_intf = tone_db (out + 2 * skip, n - skip,
				 fmod (interferer_hz + RTLDSP_SHIFT_OUT_HZ + 10 * RTLDSP_OUT_RATE, RTLDSP_OUT_RATE),
				 RTLDSP_OUT_RATE);
	double off = tx_offset (out, n, skip, tx_hz, RTLDSP_SHIFT_OUT_HZ);
	int ok = n == N_IN / 5 && fabs (off - tone_hz) < 50 && p_tone - p_intf > 40;
	printf ("%s relay  tone %+6.0f Hz, TX %.3f MHz (harmonic %d): interferer %+.0f Hz rejected %.1f dB, "
		"transmitted at F_tx %+.1f Hz\n", ok ? "OK  " : "FAIL", tone_hz, tx_hz / 1e6,
		pitx_harmonic_for (tx_hz), interferer_hz, p_tone - p_intf, off);
	free (in); free (out);
	return ok;
}

static int run_fm2ssb (double audio_hz, double carrier_offset_hz, double tx_hz)
{
	/* FM carrier at carrier_offset_hz from the received frequency,
	   3 kHz deviation, modulated by audio_hz */
	uint8_t *in = malloc (N_IN * 2);
	double ph = 0;
	for (int k = 0; k < N_IN; k++) {
		double t = (double) k / FS_IN;
		double f = carrier_offset_hz - FS_IN / 4 + 3000 * sin (2 * M_PI * audio_hz * t);
		ph += 2 * M_PI * f / FS_IN;
		in[2 * k] = to_u8 (0.4 * cos (ph) + 0.03);
		in[2 * k + 1] = to_u8 (0.4 * sin (ph) + 0.03);
	}
	int n;
	int16_t *out = process (RTLDSP_MODE_FM2SSB, in, &n);
	int skip = 9600;
	double usb = tone_db (out + 2 * skip, n - skip, audio_hz, RTLDSP_OUT_RATE);
	double lsb = tone_db (out + 2 * skip, n - skip, -audio_hz, RTLDSP_OUT_RATE);
	double off = tx_offset (out, n, skip, tx_hz, 0);
	int ok = n == N_IN / 5 && fabs (off - audio_hz) < 30 && usb - lsb > 30;
	printf ("%s fm2ssb audio %4.0f Hz, TX %.3f MHz (harmonic %d): side band rejection %.1f dB, "
		"transmitted at F_tx %+.1f Hz\n", ok ? "OK  " : "FAIL", audio_hz, tx_hz / 1e6,
		pitx_harmonic_for (tx_hz), usb - lsb, off);
	free (in); free (out);
	return ok;
}

/* WIDE mode: tone at tone_hz from the tuned frequency (dongle tuned on it),
   then wide FM (1 kHz, 75 kHz deviation): the transmitted instantaneous
   frequency must follow the modulation */
#define WIDE_RATE 250000
static int run_wide (double tone_hz, double tx_hz)
{
	int n_in = WIDE_RATE;			/* 1 s */
	uint8_t *in = malloc (n_in * 2);
	int16_t *out = malloc (n_in * 2 * sizeof (int16_t));
	rtldsp_t d;
	memset (&d, 0, sizeof d);
	for (int k = 0; k < n_in; k++) {
		double t = (double) k / WIDE_RATE;
		in[2 * k] = to_u8 (0.4 * cos (2 * M_PI * tone_hz * t));
		in[2 * k + 1] = to_u8 (0.4 * sin (2 * M_PI * tone_hz * t));
	}
	int n = 0;
	for (int k = 0; k < n_in * 2; k += 8192)
		n += rtldsp_wide (&d, in + k, n_in * 2 - k < 8192 ? n_in * 2 - k : 8192, out + 2 * n, n_in - n);
	double off = tx_offset_rate (out, n, 100, tx_hz, WIDE_RATE / 2.0, WIDE_RATE);
	int ok = n == n_in && fabs (off - tone_hz) < 300;
	printf ("%s wide   tone %+7.0f Hz, TX %.3f MHz (harmonic %d): transmitted at F_tx %+.1f Hz\n",
		ok ? "OK  " : "FAIL", tone_hz, tx_hz / 1e6, pitx_harmonic_for (tx_hz), off);
	free (in); free (out);
	return ok;
}

static int run_wide_fm (double tx_hz)
{
	int n_in = WIDE_RATE;
	uint8_t *in = malloc (n_in * 2);
	int16_t *out = malloc (n_in * 2 * sizeof (int16_t));
	double *f = malloc (n_in * sizeof (double));
	rtldsp_t d;
	memset (&d, 0, sizeof d);
	double ph = 0;
	for (int k = 0; k < n_in; k++) {
		ph += 2 * M_PI * 75000 * sin (2 * M_PI * 1000.0 * k / WIDE_RATE) / WIDE_RATE;
		in[2 * k] = to_u8 (0.4 * cos (ph));
		in[2 * k + 1] = to_u8 (0.4 * sin (ph));
	}
	int n = rtldsp_wide (&d, in, n_in * 2, out, n_in);
	double set = pitx_iq_set_frequency (tx_hz, WIDE_RATE / 2.0);
	prev_phase = 0;
	for (int k = 0; k < n; k++) {
		double df; int amp;
		IQToFreqAmp (out[2 * k + 1], out[2 * k], &df, &amp, WIDE_RATE);
		f[k] = v1_iq_output (set, df) - tx_hz;	/* instantaneous offset */
	}
	/* compare with the modulation (1 kHz tone) after a ~15 kHz low-pass
	   (moving average over 16 samples, first null at 15.6 kHz) */
	double err2 = 0, sig2 = 0;
	for (int k = 1000; k < n - 16; k++) {
		double m = 0;
		for (int j = 0; j < 16; j++) m += f[k + j];
		m /= 16;
		double ref = 0;
		for (int j = 0; j < 16; j++) ref += 75000 * sin (2 * M_PI * 1000.0 * (k + j) / WIDE_RATE);
		ref /= 16;
		err2 += (m - ref) * (m - ref);
		sig2 += ref * ref;
	}
	double snr = 10 * log10 (sig2 / err2);
	int ok = snr > 40;
	printf ("%s wide   FM 1 kHz +/-75 kHz, TX %.3f MHz (harmonic %d): modulation reproduced, S/(N+D) %.1f dB\n",
		ok ? "OK  " : "FAIL", tx_hz / 1e6, pitx_harmonic_for (tx_hz), snr);
	free (in); free (out); free (f);
	return ok;
}

/* no_out_shift + rtldsp_out_shift() gives exactly the samples of the
   direct path (relay, fm2ssb and wide) */
static int run_deferred_shift (void)
{
	uint8_t *in = malloc (N_IN * 2);
	unsigned seed = 7;
	for (int k = 0; k < N_IN * 2; k++) {
		seed = seed * 1103515245u + 12345u;
		in[k] = (uint8_t) (128 + ((int) (seed >> 16) % 61) - 30);
	}
	int ok = 1;
	for (int mode = 0; mode < 3; mode++) {
		static rtldsp_t a, b;
		int max_out = N_IN + 16;
		int16_t *oa = malloc (max_out * 2 * sizeof (int16_t));
		int16_t *ob = malloc (max_out * 2 * sizeof (int16_t));
		int na = 0, nb = 0;
		if (mode == RTLDSP_MODE_WIDE) {
			memset (&a, 0, sizeof a); a.mode = RTLDSP_MODE_WIDE;
			memset (&b, 0, sizeof b); b.mode = RTLDSP_MODE_WIDE;
		} else {
			rtldsp_init (&a, 5, 12000, mode == RTLDSP_MODE_RELAY ? 0 : -200, 0, mode);
			rtldsp_init (&b, 5, 12000, mode == RTLDSP_MODE_RELAY ? 0 : -200, 0, mode);
		}
		b.no_out_shift = 1;
		for (int k = 0; k < N_IN * 2; k += 16384) {
			int len = N_IN * 2 - k < 16384 ? N_IN * 2 - k : 16384;
			if (mode == RTLDSP_MODE_WIDE) {
				na += rtldsp_wide (&a, in + k, len, oa + 2 * na, max_out - na);
				int m = rtldsp_wide (&b, in + k, len, ob + 2 * nb, max_out - nb);
				rtldsp_out_shift (&b, ob + 2 * nb, m);
				nb += m;
			} else {
				na += rtldsp_process (&a, in + k, len, oa + 2 * na, max_out - na);
				int m = rtldsp_process (&b, in + k, len, ob + 2 * nb, max_out - nb);
				rtldsp_out_shift (&b, ob + 2 * nb, m);
				nb += m;
			}
		}
		int same = na == nb && memcmp (oa, ob, na * 2 * sizeof (int16_t)) == 0;
		printf ("%s deferred output shift, mode %d: %d samples %s\n", same ? "OK  " : "FAIL",
			mode, na, same ? "identical" : "DIFFERENT");
		ok &= same;
		free (oa); free (ob);
	}
	free (in);
	return ok;
}

/* rtl2tx rate matching, wide FM (1 kHz, +/-75 kHz) received at 250 kS/s and
   played by the transmitter at tx_rate: the ring + rtldsp_rate_* + output
   shift + rpitx IQ conversion at the real rate (pitx_iq_rate) with the
   shift correction (pitx_iq_offset_hz) must transmit the modulation at the
   right frequencies and the right speed, without overrun nor underflow. */
static int run_rate_match (double tx_rate, double tx_hz, double dongle_ppm)
{
	const double P = WIDE_RATE;
	const double P_real = P * (1 + dongle_ppm * 1e-6);	/* dongle crystal */
	const unsigned ring_pairs = WIDE_RATE;
	const double sim_s = 40.0;
	int16_t *ring = malloc (ring_pairs * 2 * sizeof (int16_t));
	unsigned head = 0, tail = 0;
	rtldsp_t d;
	memset (&d, 0, sizeof d);
	d.mode = RTLDSP_MODE_WIDE;
	d.no_out_shift = 1;
	rtldsp_rate_t r;
	rtldsp_rate_init (&r);
	double ph = 0;
	unsigned long produced = 0;
	uint8_t inb[2 * 4096];
	int16_t tmp[2 * 4096], out[2 * 1000];
	unsigned overruns = 0, underflows = 0;
	double set = pitx_iq_set_frequency (tx_hz, P / 2.0);
	double offset = (tx_rate - P) / 2.0;
	prev_phase = 0;
	/* least squares fit of the transmitted frequency on the last 4 s:
	   f(t) = a sin(2 pi 1k t) + b cos(2 pi 1k t) + c */
	double S[3][3] = {{0}}, Y[3] = {0}, yy = 0;
	unsigned long m = 0;			/* output samples */
	double lp_hist[16] = {0}, lp_sum = 0;
	int lp_pos = 0;

	while (m < (unsigned long) (sim_s * tx_rate)) {
		/* the dongle delivers up to the current time */
		double t_now = m / tx_rate + 0.25;	/* 250 ms prefill */
		while (produced < (unsigned long) (t_now * P_real)) {
			for (int k = 0; k < 4096; k++) {
				double t = (double) (produced + k) / P_real;
				ph += 2 * M_PI * 75000 * sin (2 * M_PI * 1000.0 * t) / P_real;
				inb[2 * k] = to_u8 (0.4 * cos (ph));
				inb[2 * k + 1] = to_u8 (0.4 * sin (ph));
			}
			int n = rtldsp_wide (&d, inb, sizeof inb, tmp, 4096);
			for (int k = 0; k < n; k++) {
				if (head - tail >= ring_pairs) { tail++; overruns++; }
				unsigned w = head % ring_pairs;
				ring[2 * w] = tmp[2 * k];
				ring[2 * w + 1] = tmp[2 * k + 1];
				head++;
			}
			produced += 4096;
		}
		/* as rtl2tx: feed-forward from the DMA rate measured after 200 ms,
		   the excess accumulated until then is dropped once */
		if (m > 0.2 * tx_rate && r.ff == 1.0 && tx_rate != P) {
			r.ff = P / tx_rate;
			unsigned target = (unsigned) (P * 0.25);
			if (head - tail > target + P / 20)
				tail = head - target;
		}
		if (head - tail < rtldsp_rate_need (&r, 1000)) {
			underflows++;
			m++;				/* time passes while waiting */
			continue;
		}
		rtldsp_rate_run (&r, ring, ring_pairs, &tail, out, 1000);
		rtldsp_out_shift (&d, out, 1000);
		rtldsp_rate_control (&r, (double) (head - tail) / P - 0.25, 1000.0 / P);
		for (int k = 0; k < 1000; k++, m++) {
			double df; int amp;
			IQToFreqAmp (out[2 * k + 1], out[2 * k], &df, &amp, tx_rate);
			double f = v1_iq_output (set, df - offset) - tx_hz;
			double t = m / tx_rate;
			/* ~15 kHz low-pass as in run_wide_fm: moving average of 16 */
			lp_sum += f - lp_hist[lp_pos];
			lp_hist[lp_pos] = f;
			lp_pos = (lp_pos + 1) & 15;
			f = lp_sum / 16;
			t -= 7.5 / tx_rate;		/* delay of the average */
			if (t > sim_s - 0.2) {	/* 200 ms: the tone stays coherent */
				double x[3] = { sin (2 * M_PI * 1000.0 * t), cos (2 * M_PI * 1000.0 * t), 1.0 };
				for (int i = 0; i < 3; i++) {
					for (int j = 0; j < 3; j++) S[i][j] += x[i] * x[j];
					Y[i] += x[i] * f;
				}
				yy += f * f;
			}
		}
	}
	/* solve the 3x3 normal equations (Cramer) */
	double det = S[0][0] * (S[1][1] * S[2][2] - S[1][2] * S[2][1])
		   - S[0][1] * (S[1][0] * S[2][2] - S[1][2] * S[2][0])
		   + S[0][2] * (S[1][0] * S[2][1] - S[1][1] * S[2][0]);
	double c[3];
	for (int col = 0; col < 3; col++) {
		double M[3][3];
		memcpy (M, S, sizeof M);
		for (int i = 0; i < 3; i++) M[i][col] = Y[i];
		c[col] = (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1])
			- M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
			+ M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0])) / det;
	}
	double amp = sqrt (c[0] * c[0] + c[1] * c[1]);
	double n_fit = S[2][2];
	double res = yy - (c[0] * Y[0] + c[1] * Y[1] + c[2] * Y[2]);	/* residual energy */
	double snr = 10 * log10 ((amp * amp / 2) * n_fit / res);
	int ok = overruns == 0 && fabs (amp - 75000) < 1500 && fabs (c[2]) < 300 && snr > 30
		 && fabs (r.ratio - P_real / tx_rate) < 0.002;
	printf ("%s rate matching, TX plays %.0f S/s (dongle %.1f): ratio %.4f (expected %.4f), "
		"deviation %.0f Hz, carrier %+.0f Hz, overruns %u, waits %u, S/(N+D) %.1f dB\n",
		ok ? "OK  " : "FAIL", tx_rate, P_real, r.ratio, P_real / tx_rate, amp, c[2], overruns, underflows, snr);
	free (ring);
	return ok;
}

int main (void)
{
	int ok = 1;
	ok &= run_relay (3000, 30000, 50.5e6);
	ok &= run_relay (-5000, -40000, 145.5e6);
	ok &= run_relay (0, 25000, 28.2e6);
	ok &= run_relay (-10000, 60000, 7.05e6);	/* interferer at the dongle DC */
	ok &= run_relay (9000, -21000, 434.0e6);	/* harmonic mode */
	ok &= run_relay (-4000, 30000, 434.0e6);
	ok &= run_fm2ssb (1000, 0, 50.5e6);
	ok &= run_fm2ssb (2200, 1500, 145.5e6);	/* slightly off tuned */
	ok &= run_fm2ssb (800, 0, 434.0e6);
	ok &= run_wide (30000, 87.8e6);
	ok &= run_wide (-90000, 87.8e6);
	ok &= run_wide (110000, 100.3e6);
	ok &= run_wide (-60000, 145.5e6);	/* harmonic mode */
	ok &= run_wide_fm (87.8e6);
	ok &= run_wide_fm (145.5e6);
	ok &= run_deferred_shift ();
	ok &= run_rate_match (250000, 87.8e6, 0);
	ok &= run_rate_match (241000, 87.8e6, 0);
	ok &= run_rate_match (262000, 100.3e6, 0);
	ok &= run_rate_match (190000, 87.8e6, 0);	/* the 5.3 us per sample case */
	ok &= run_rate_match (241000, 145.5e6, 0);	/* harmonic mode */
	ok &= run_rate_match (241000, 87.8e6, 50);	/* dongle 50 ppm fast */
	ok &= run_rate_match (250000, 87.8e6, -80);	/* dongle 80 ppm slow, TX nominal */
	printf (ok ? "rtldsp: all tests passed\n" : "rtldsp: FAILURES\n");
	return ok ? 0 : 1;
}
