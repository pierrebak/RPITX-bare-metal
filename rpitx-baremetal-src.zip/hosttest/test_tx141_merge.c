/* Test TX141 avec fusions d'impulsions injectées (reproduit le matériel :
   le détecteur rate parfois un espace court de 312 µs -> deux marques se
   collent en une impulsion ~892 µs. Le décodeur doit redécouper et décoder
   quand même grâce au vote sur les copies répétées. */
#include <stdio.h>
#include <string.h>
#include "../tools/ook.h"

/* timing réel relevé : période ~724, marque courte 168 / longue 412,
   espaces complémentaires 556 / 312, préambule 4x ~900/1044 */
#define PER   724
#define MK_S  168
#define MK_L  412
#define PRE_P 900
#define PRE_G 1044

/* trame TX141Bv2 37 bits : id=0x4c, batt/ch, temp=135 (13.5 C).
   t10 = ((b1&0x0F)<<8 | b2) - 500 = 635 -> 0x27B ; b1 bas=2, b2=0x7B.
   b0=0x4c, b1=0x02 (ch0,batt0 pour simplifier), b2=0x7b, b3=0, b4=0.
   bit de donnée inversé : court(168)=1, long(412)=0. */
static const unsigned char FRAME[5] = { 0x4c, 0x02, 0x7b, 0x00, 0x00 };

/* ajoute une copie ; si drop>=0, l'espace court du bit 'drop' est raté
   (fusion avec le bit suivant) */
static void add_copy (ook_packet_t *p, int drop)
{
	for (int i = 0; i < 4; i++) { p->pulse_us[p->num] = PRE_P; p->gap_us[p->num] = PRE_G; p->num++; }
	int bit = 0;
	while (bit < 37)
	{
		int by = bit / 8, bi = 7 - (bit % 8);
		int one = (FRAME[by] >> bi) & 1;		/* 1 -> marque courte */
		int mark = one ? MK_S : MK_L;
		int gap  = PER - mark;
		if (bit == drop && bit + 1 < 37)
		{
			/* fusion : marque courante + gap raté + marque suivante */
			int by2 = (bit + 1) / 8, bi2 = 7 - ((bit + 1) % 8);
			int one2 = (FRAME[by2] >> bi2) & 1;
			int mark2 = one2 ? MK_S : MK_L;
			p->pulse_us[p->num] = mark + gap + mark2;
			p->gap_us[p->num] = PER - mark2;
			p->num++;
			bit += 2;
			continue;
		}
		p->pulse_us[p->num] = mark;
		p->gap_us[p->num] = gap;
		p->num++;
		bit++;
	}
	p->gap_us[p->num - 1] = 9500;				/* long silence entre copies */
}

int main (void)
{
	ook_packet_t p; memset (&p, 0, sizeof p);
	/* 12 copies, chacune avec une fusion à une position différente
	   (certaines sans fusion) -> le vote doit retrouver la bonne valeur */
	int drops[12] = { -1, 5, 12, -1, 20, 8, 30, -1, 3, 17, 25, -1 };
	for (int i = 0; i < 12; i++) add_copy (&p, drops[i]);

	sensor_t s;
	int ok = ook_decode_data (&p, &s);
	printf ("num=%d decode=%d\n", p.num, ok);
	if (ok)
		printf ("  modele=%s id=%02lx canal=%d temp=%d.%d C\n",
			s.model, s.id, s.channel, s.temp_dC / 10, (s.temp_dC < 0 ? -s.temp_dC : s.temp_dC) % 10);

	int pass = ok && s.id == 0x4c && s.temp_dC == 135;
	printf (pass ? "PASS\n" : "FAIL (attendu id=4c temp=135)\n");
	return pass ? 0 : 1;
}
