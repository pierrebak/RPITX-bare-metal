#!/bin/bash
#
# Runs the host (PC) tests of rpitx-baremetal.
# Needs: gcc, libsndfile-dev, sox, ImageMagick (convert), python3.
#
# Usage: hosttest/run_all.sh <rpitx checkout at tag v1> <rpitx checkout at master (v2)>
#
set -euo pipefail

V1=${1:?path to an rpitx checkout at tag v1}
V2=${2:?path to an rpitx checkout at master (v2)}
HERE=$(cd "$(dirname "$0")/.." && pwd)
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
cd "$HERE"

echo "== generators (original v1 + libsndfile vs this port)"
hosttest/run_generators.sh "$V1"

echo "== modes taken from rpitx v2 (original v2 + fake librpitx vs this port)"
hosttest/run_v2modes.sh "$V2"

echo "== RTL-SDR DSP, FM->SSB and rpitx IQ frequency plan (incl. harmonics)"
gcc -O2 -Wall -I tools -idirafter compat/include -o "$WORK/test_rtldsp" \
    hosttest/test_rtldsp.c tools/rtldsp.c rpitx/pitx_freq.c -lm
"$WORK/test_rtldsp"

echo "== 433 MHz sensor decoder (rtl433)"
gcc -O2 -Wall -o "$WORK/test_ook" hosttest/test_ook.c tools/ook.c -lm
"$WORK/test_ook"

echo "== 868 MHz FSK sensors (rtl868)"
gcc -O2 -Wall -o "$WORK/test_fsk" hosttest/test_fsk.c tools/fsk.c -lm
"$WORK/test_fsk"

echo "== FM broadcast demodulator (rtlfm)"
gcc -O2 -Wall -o "$WORK/test_fmrx" hosttest/test_fmrx.c tools/fmrx_dsp.c -lm
"$WORK/test_fmrx"

echo "== rpitx IQ path (optimised) vs the version before optimisation"
hosttest/run_iqpath.sh hosttest/ref/RpiTx_before_optim.c 2>/dev/null | tail -1 | tee "$WORK/iq.txt"
grep -q identical "$WORK/iq.txt"

echo "== compat libc vs host libc"
# compat/libc.c is compiled with its symbols renamed bm_* so that both
# implementations can be linked into the same test program
R=""
for s in strtod strtof atof strtol strtoll atol qsort sscanf getopt getopt_long \
	 optarg optind opterr optopt strrchr memchr strdup strspn strcspn strtok \
	 strerror abs labs div rand srand getenv system atexit; do
	R="$R -D$s=bm_$s"
done
gcc -O2 -w -ffreestanding -fno-builtin $R -I compat/include -nostdinc \
    -isystem "$(gcc -print-file-name=include)" -c compat/libc.c -o "$WORK/libc_host.o"
gcc -O2 -w -o "$WORK/test_libc" hosttest/test_libc.c "$WORK/libc_host.o" -lm
"$WORK/test_libc"

echo "== all host tests passed"
