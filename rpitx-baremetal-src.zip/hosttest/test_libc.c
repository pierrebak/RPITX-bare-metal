/*
 * test_libc.c - compares compat/libc.c (getopt, strtod, strtol, qsort,
 * sscanf ...) with the host C library. compat/libc.c is compiled with its
 * symbols renamed bm_* (see hosttest/run_all.sh).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>

double bm_strtod (const char *, char **);
long bm_strtol (const char *, char **, int);
void bm_qsort (void *, size_t, size_t, int (*) (const void *, const void *));
int bm_sscanf (const char *, const char *, ...);
int bm_getopt (int, char * const [], const char *);
extern char *bm_optarg;
extern int bm_optind, bm_opterr, bm_optopt;
char *bm_strrchr (const char *, int);

static int fails;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf ("FAIL: " __VA_ARGS__); printf ("\n"); } } while (0)

static void getopt_case (const char *opts, int argc, char **argv)
{
	char host[512] = "", mine[512] = "";
	char **a1 = malloc (sizeof (char *) * (argc + 1));
	char **a2 = malloc (sizeof (char *) * (argc + 1));
	memcpy (a1, argv, sizeof (char *) * (argc + 1));
	memcpy (a2, argv, sizeof (char *) * (argc + 1));

	int c;
	optind = 0; opterr = 0;
	/* "+" : POSIX mode, glibc would otherwise permute the arguments */
	char posix_opts[64];
	snprintf (posix_opts, sizeof posix_opts, "+%s", opts);
	while ((c = getopt (argc, a1, posix_opts)) != -1)
		snprintf (host + strlen (host), sizeof host - strlen (host), "%c=%s;", c, optarg ? optarg : "-");
	snprintf (host + strlen (host), sizeof host - strlen (host), "ind=%d", optind);

	bm_optind = 0; bm_opterr = 0;	/* the shell resets optind to 0 before each tool */
	while ((c = bm_getopt (argc, a2, opts)) != -1)
		snprintf (mine + strlen (mine), sizeof mine - strlen (mine), "%c=%s;", c, bm_optarg ? bm_optarg : "-");
	snprintf (mine + strlen (mine), sizeof mine - strlen (mine), "ind=%d", bm_optind);

	CHECK (strcmp (host, mine) == 0, "getopt '%s': host %s, mine %s", opts, host, mine);
	free (a1); free (a2);
}

static int cmp_int (const void *a, const void *b) { return *(const int *) a - *(const int *) b; }

int main (void)
{
	/* strtod / strtol */
	const char *nums[] = {"433900", "145.5", "-12.25", "1e6", "2.4E+6", "0.000125", "+7",
			      "50105", "100M", ".5", "3.", "-0", "12abc", "abc", "  42"};
	for (unsigned i = 0; i < sizeof nums / sizeof nums[0]; i++) {
		char *e1, *e2;
		double h = strtod (nums[i], &e1), m = bm_strtod (nums[i], &e2);
		CHECK (fabs (h - m) <= 1e-12 * fabs (h) && e1 - nums[i] == e2 - nums[i],
		       "strtod(%s): host %.17g end %ld, mine %.17g end %ld", nums[i], h,
		       (long) (e1 - nums[i]), m, (long) (e2 - nums[i]));
		long hl = strtol (nums[i], &e1, 10), ml = bm_strtol (nums[i], &e2, 10);
		CHECK (hl == ml && e1 == e2, "strtol(%s)", nums[i]);
	}

	/* getopt: rpitx v1, rtl_sdr and rtl2tx option strings */
	const char *rp = "i:f:m:s:p:hld:w:c:ra:";
	char *t1[] = {"rpitx", "-m", "RF", "-i", "fm.ft", "-f", "433900", "-l", 0};
	char *t2[] = {"rpitx", "-mVFO", "-f433900", "-c", "1", "-p", "-2.5", 0};
	char *t3[] = {"rpitx", "-lr", "-d", "100", "-x", "-a", 0};
	char *t4[] = {"rpitx", "-m", "IQ", "--", "-i", "x", 0};
	char *t5[] = {"rpitx", "file", "-m", "IQ", 0};
	getopt_case (rp, 8, t1);
	getopt_case (rp, 7, t2);
	getopt_case (rp, 6, t3);
	getopt_case (rp, 6, t4);
	getopt_case (rp, 4, t5);
	char *t6[] = {"rtl_sdr", "-f", "100M", "-s", "240000", "-g", "20.7", "-n", "480000", "-S", "out.bin", 0};
	getopt_case ("d:f:g:s:b:n:p:SD", 11, t6);
	char *t7[] = {"rtl2tx", "-r", "145.5M", "-f", "50105", "-q", "-40", "-G", "6", 0};
	getopt_case ("r:f:d:g:P:p:s:w:G:q:c:h", 9, t7);
	getopt_case (rp, 8, t1);	/* second run after a reset */

	/* qsort */
	int v[200], w[200];
	for (int i = 0; i < 200; i++) v[i] = w[i] = (i * 7919) % 211 - 100;
	qsort (v, 200, sizeof (int), cmp_int);
	bm_qsort (w, 200, sizeof (int), cmp_int);
	CHECK (memcmp (v, w, sizeof v) == 0, "qsort");

	/* sscanf */
	int a = 0; float f = 0; char s[16] = "";
	int n = bm_sscanf ("12 3.5 abc", "%d %f %s", &a, &f, s);
	CHECK (n == 3 && a == 12 && f == 3.5f && strcmp (s, "abc") == 0, "sscanf");

	CHECK (bm_strrchr ("a/b/c", '/') == strrchr ("a/b/c", '/') - 0 || 1, "strrchr");
	const char *p = "a/b/c";
	CHECK (bm_strrchr (p, '/') == p + 3 && bm_strrchr (p, 'x') == NULL && bm_strrchr (p, '\0') == p + 5, "strrchr values");

	printf (fails ? "libc: %d FAILURES\n" : "libc: all tests passed\n", fails);
	return fails != 0;
}
