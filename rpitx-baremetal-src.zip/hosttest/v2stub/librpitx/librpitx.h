/*
 * Fake librpitx for host tests: the rpitx v2 programs are compiled against
 * it and every sample they would transmit is appended to $STUB_OUT as
 * (double value, double duration_s). Frequencies are relative to the
 * carrier, amplitudes are 0..1. Stops the program after $STUB_MAX samples.
 */
#ifndef FAKE_LIBRPITX_H
#define FAKE_LIBRPITX_H
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <complex>

static FILE *stub_file () {
	static FILE *f = NULL;
	if (!f) f = fopen (getenv ("STUB_OUT"), "wb");
	return f;
}
static void stub_put (double v, double dt) {
	static long n = 0;
	double r[2] = {v, dt};
	fwrite (r, sizeof r, 1, stub_file ());
	long max = getenv ("STUB_MAX") ? atol (getenv ("STUB_MAX")) : 100000000L;
	if (++n >= max) { fclose (stub_file ()); exit (0); }
}
static inline void dbg_setlevel (int) {}

#define MODE_FREQ_A 1
class padgpio { public: void setlevel (int) {} };

class ngfmdmasync {
	double carrier, sr; int fifo;
public:
	ngfmdmasync (uint64_t f, int SR, int ch, int FifoSize) : carrier (f), sr (SR), fifo (FifoSize) {}
	int GetBufferAvailable () { return fifo; }
	int GetUserMemIndex () { return 0; }
	void SetFrequencySample (int, float f) { stub_put (f, 1.0 / sr); }
	void SetFrequencySamples (float *f, int n) { for (int i = 0; i < n; i++) stub_put (f[i], 1.0 / sr); }
	void stop () {}
};
class amdmasync {
	double sr; int fifo;
public:
	amdmasync (uint64_t f, int SR, int ch, int FifoSize) : sr (SR), fifo (FifoSize) {}
	int GetBufferAvailable () { return fifo; }
	int GetUserMemIndex () { return 0; }
	void SetAmSample (int, float a) { stub_put (a, 1.0 / sr); }
	void stop () {}
};
class fskburst {
	double low, sr, dev;
public:
	fskburst (uint64_t f, float SR, float Deviation, int ch, int fifo, int up = 1, float ramp = 0)
		: low (0), sr (SR), dev (Deviation) { (void) f; }
	void SetSymbols (unsigned char *s, int n) {
		/* first argument is Freq - Deviation/2*2: symbol 0 -> -dev/2, 1 -> +dev/2 */
		for (int i = 0; i < n; i++) stub_put (s[i] ? dev / 2 : -dev / 2, 1.0 / sr);
	}
	void stop () {}
};
class ookburst {
	double sr;
public:
	ookburst (uint64_t f, float SR, int ch, int fifo, float up) : sr (SR) {}
	void SetSymbols (unsigned char *s, int n) { for (int i = 0; i < n; i++) stub_put (s[i] ? 1 : 0, 1.0 / sr); }
};
class iqdmasync {
	double sr;
public:
	iqdmasync (uint64_t f, int SR, int ch, int fifo, int mode) : sr (SR) {}
	void SetIQSamples (std::complex<float> *s, int n, int h) {
		/* MODE_FREQ_A: real = frequency, imag = amplitude */
		for (int i = 0; i < n; i++) { stub_put (s[i].real (), 1.0 / sr); stub_put (s[i].imag (), 0); }
	}
};
#endif
