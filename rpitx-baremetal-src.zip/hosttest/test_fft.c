/* Test de la FFT : tons complexes a des bins connus, verif de la position du pic
   et de l'echelle dB (0 dB = pleine echelle). */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "../tools/fft.h"

#define N 1024
#define PI 3.14159265358979

static int argmax (const float *p, int n)
{
	int im = 0;
	for (int i = 1; i < n; i++) if (p[i] > p[im]) im = i;
	return im;
}

int main (void)
{
	fft_t f;
	if (fft_init (&f, N)) { printf ("fft_init FAIL\n"); return 1; }
	uint8_t *iq = malloc (2 * N);
	float *pdb = malloc (sizeof (float) * N);
	int pass = 1;

	/* --- ton a +100/N, amplitude 1 (pleine echelle) -> pic au bin recentre 512+100 */
	int kbin = 100;
	for (int i = 0; i < N; i++) {
		double ph = 2 * PI * kbin * i / N;
		iq[2 * i]     = (uint8_t) (127 + 126.0 * cos (ph));
		iq[2 * i + 1] = (uint8_t) (127 + 126.0 * sin (ph));
	}
	fft_power_u8 (&f, iq, pdb);
	int pk = argmax (pdb, N);
	printf ("ton +100 : pic au bin %d (attendu %d), niveau %.1f dB\n", pk, N / 2 + kbin, pdb[pk]);
	if (pk != N / 2 + kbin) pass = 0;
	if (pdb[pk] < -2.0f || pdb[pk] > 1.0f) pass = 0;	/* ~0 dB */

	/* --- ton a -200/N, amplitude 0,5 -> pic au bin 512-200, niveau ~-6 dB */
	kbin = -200;
	for (int i = 0; i < N; i++) {
		double ph = 2 * PI * kbin * i / N;
		iq[2 * i]     = (uint8_t) (127 + 0.5 * 126.0 * cos (ph));
		iq[2 * i + 1] = (uint8_t) (127 + 0.5 * 126.0 * sin (ph));
	}
	fft_power_u8 (&f, iq, pdb);
	pk = argmax (pdb, N);
	printf ("ton -200 (0,5) : pic au bin %d (attendu %d), niveau %.1f dB\n", pk, N / 2 + kbin, pdb[pk]);
	if (pk != N / 2 + kbin) pass = 0;
	if (pdb[pk] < -8.0f || pdb[pk] > -4.0f) pass = 0;	/* ~-6 dB */

	/* --- plancher loin du pic : doit etre bien plus bas */
	float floor_db = pdb[100];		/* bin loin de 512-200=312 */
	printf ("plancher (bin 100) : %.1f dB\n", floor_db);
	if (floor_db > -40.0f) pass = 0;

	printf (pass ? "PASS\n" : "FAIL\n");
	fft_free (&f);
	return pass ? 0 : 1;
}
