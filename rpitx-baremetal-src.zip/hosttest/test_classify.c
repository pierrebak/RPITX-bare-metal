/* Test du classifieur de modulation sur signaux synthetiques en bande de base. */
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "../tools/classify.h"
#include "../tools/fft.h"

#define N 1024
#define PI 3.14159265358979

static float re[N], im[N];

static void gen_am (void)			/* enveloppe variable, freq nulle */
{
	double fa = 0.02, m = 0.6;
	for (int i = 0; i < N; i++) {
		double env = 1.0 + m * cos (2 * PI * fa * i);
		re[i] = 0.4 * env; im[i] = 0.0;
	}
}
static void gen_fm (void)			/* enveloppe constante, freq tres etalee */
{
	double fa = 0.02, beta = 5.0;
	for (int i = 0; i < N; i++) {
		double ph = beta * sin (2 * PI * fa * i);
		re[i] = 0.5 * cos (ph); im[i] = 0.5 * sin (ph);
	}
}
static void gen_cw (void)			/* porteuse tout-ou-rien (Morse) */
{
	double fc = 0.03;
	for (int i = 0; i < N; i++) {
		int on = ((i / 90) % 2) == 0;		/* ~50 % de rapport cyclique */
		double ph = 2 * PI * fc * i;
		re[i] = on ? 0.5 * cos (ph) : 0.0;
		im[i] = on ? 0.5 * sin (ph) : 0.0;
	}
}
static void gen_ssb (void)			/* deux tons, cote positif seulement */
{
	double f1 = 0.02, f2 = 0.04;
	for (int i = 0; i < N; i++) {
		re[i] = 0.3 * (cos (2 * PI * f1 * i) + cos (2 * PI * f2 * i));
		im[i] = 0.3 * (sin (2 * PI * f1 * i) + sin (2 * PI * f2 * i));
	}
}
static void gen_fsk (void)			/* 2 frequences alternees */
{
	double fa = -0.15, fb = 0.15, ph = 0;
	for (int i = 0; i < N; i++) {
		int sym = (i / 50) & 1;
		ph += 2 * PI * (sym ? fb : fa);
		re[i] = 0.5 * cos (ph); im[i] = 0.5 * sin (ph);
	}
}
static void gen_digital (void)			/* OFDM : beaucoup de porteuses, spectre plat */
{
	int K = (int) (0.4 * N);		/* occupe +/-40 % de la bande */
	static double phase[2 * N];
	unsigned s = 999;
	for (int k = 0; k < 2 * K + 1; k++) {
		s = s * 1103515245u + 12345u;
		phase[k] = 2 * PI * (((s >> 8) & 0xFFFF) / 65536.0);
	}
	double norm = 0.5 / sqrt (2.0 * K + 1);
	for (int i = 0; i < N; i++) {
		double ar = 0, ai = 0;
		for (int k = -K; k <= K; k++) {
			double a = 2 * PI * k * i / N + phase[k + K];
			ar += cos (a); ai += sin (a);
		}
		re[i] = norm * ar; im[i] = norm * ai;
	}
}

int main (void)
{
	fft_t f;
	if (fft_init (&f, N)) { printf ("fft FAIL\n"); return 1; }
	struct { const char *name; void (*gen) (void); mod_t exp; } cases[] = {
		{ "AM",  gen_am,  MOD_AM },
		{ "FM",  gen_fm,  MOD_FM },
		{ "CW",  gen_cw,  MOD_CW },
		{ "SSB", gen_ssb, MOD_SSB },
		{ "FSK", gen_fsk, MOD_FSK },
		{ "NUM", gen_digital, MOD_DIGITAL },
	};
	int pass = 1;
	for (int c = 0; c < 6; c++) {
		cases[c].gen ();
		float conf;
		mod_t m = classify (&f, re, im, N, &conf);
		int ok = (m == cases[c].exp);
		printf ("%-4s -> %-8s (conf %.1f)  %s\n", cases[c].name, mod_name (m),
			conf, ok ? "ok" : "ATTENDU !");
		if (!ok) pass = 0;
	}
	printf (pass ? "PASS\n" : "FAIL\n");
	fft_free (&f);
	return pass ? 0 : 1;
}
