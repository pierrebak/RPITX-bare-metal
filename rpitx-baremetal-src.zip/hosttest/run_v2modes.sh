#!/bin/bash
#
# Host test: modes taken from rpitx v2. Each original v2 program is built
# against a fake librpitx (hosttest/v2stub) that records every sample it
# would transmit; the generator of this port writes an rpitx v1 .ft/.rfa
# file. Both are compared on the same time grid.
#
# Usage: hosttest/run_v2modes.sh /path/to/rpitx-checkout (master = v2)
#
set -euo pipefail

V2=${1:?path to an rpitx v2 checkout}/src
HERE=$(cd "$(dirname "$0")/.." && pwd)
WORK=$(mktemp -d)
trap '[ -n "${KEEP:-}" ] || rm -rf "$WORK"' EXIT
cd "$WORK"

# originals (v2) against the fake librpitx
GXX="g++ -O2 -w -fpermissive -I $HERE/hosttest/v2stub"
$GXX -o v2_pocsag $V2/pocsag/pocsag.cpp
$GXX -o v2_opera $V2/opera/opera.cpp
$GXX -o v2_rtty $V2/pirtty/pirtty.cpp
$GXX -o v2_morse $V2/morse/morse.cpp
$GXX -o v2_freedv $V2/freedv/freedv.cpp
$GXX -o v2_chirp $V2/chirp/chirp.cpp
$GXX -o v2_spectrum $V2/spectrumpaint/spectrum.cpp

# this port, built for the host
CC="gcc -O2 -w -idirafter $HERE/compat/include"
$CC -Dpipocsag_main=main -o bm_pocsag $HERE/rpitx/v2/pipocsag.c
$CC -Dmain=main -o bm_opera $HERE/rpitx/v2/piopera.c -lm
$CC -Dpirtty_main=main -o bm_rtty $HERE/rpitx/v2/pirtty.c
$CC -Dpimorse_main=main -o bm_morse $HERE/rpitx/v2/pimorse.c
$CC -Dpifreedv_main=main -o bm_freedv $HERE/rpitx/v2/pifreedv.c
$CC -Dpichirp_main=main -o bm_chirp $HERE/rpitx/v2/pichirp.c -lm
$CC -Dpispectrum_main=main -o bm_spectrum $HERE/rpitx/v2/pispectrum.c
gcc -O2 -w -include stdint.h -Dbmp2rgb_main=main -o bmp2rgb $HERE/tools/bmp2rgb.c

q () { "$@" > /dev/null 2>&1 || true; }

printf '1:YOURCALL\n2: Hello world' | STUB_OUT=v2_pocsag.bin q ./v2_pocsag -f 434e6
q ./bm_pocsag bm_pocsag.ft '1:YOURCALL\n2: Hello world'
STUB_OUT=v2_opera.bin q ./v2_opera F5OEO 0.5 434e6
q ./bm_opera F5OEO 0.5 bm_opera.rfa
STUB_OUT=v2_rtty.bin q ./v2_rtty 434e6 1000 "HELLO WORLD FROM RPITX 73"
q ./bm_rtty bm_rtty.ft 1000 "HELLO WORLD FROM RPITX 73"
STUB_OUT=v2_morse.bin q ./v2_morse 434e6 5 "CQ CQ DE F5OEO 73"
q ./bm_morse 5 "CQ CQ DE F5OEO 73" bm_morse.rfa
STUB_OUT=v2_freedv.bin q ./v2_freedv $V2/resources/SAMPLE_FREEDV.rf 434e6 400
q ./bm_freedv $V2/resources/SAMPLE_FREEDV.rf bm_freedv.ft 400
STUB_OUT=v2_chirp.bin STUB_MAX=1000000 q ./v2_chirp 434e6 100000 5
q ./bm_chirp bm_chirp.ft 100000 5
convert "$HERE/boot/picture.bmp" -flip -quantize YUV -dither FloydSteinberg -colors 4 \
	-interlace partition picture.yuv
STUB_OUT=v2_spectrum.bin q ./v2_spectrum picture.Y 434e6 100000
q ./bmp2rgb "$HERE/boot/picture.bmp" picture.rgb
q ./bm_spectrum picture.rgb bm_spectrum.ft 100000

python3 - <<'EOF'
import struct, sys

def stub(path):
    d = open(path, 'rb').read()
    return [struct.unpack_from('<dd', d, i) for i in range(0, len(d), 16)]

def records(path):
    d = open(path, 'rb').read()
    return [(v, ns * 1e-9) for v, ns in (struct.unpack_from('<dI', d, i) for i in range(0, len(d) // 16 * 16, 16))]

def sample(recs, times):
    """value of a piecewise constant record list at each time"""
    out, i, t0 = [], 0, 0.0
    for t in times:
        while i < len(recs) and t >= t0 + recs[i][1] - 1e-12:
            t0 += recs[i][1]; i += 1
        out.append(recs[i][0] if i < len(recs) else None)
    return out

def midtimes(st):
    t, out = 0.0, []
    for v, dt in st:
        out.append(t + dt / 2); t += dt
    return out, t

fails = 0
def check(name, ok, detail):
    global fails
    print(("OK    " if ok else "FAIL  ") + name + ": " + detail)
    fails += 0 if ok else 1

def compare(name, v2, mine, scale=1.0, tol=1e-6, zero_is=None, v2_extra=0):
    """v2_extra: samples the v2 sends after the end of the message (its
    output loop fills whole FIFO blocks), not compared"""
    if v2_extra:
        v2 = v2[:len(v2) - v2_extra]
    times, total = midtimes(v2)
    got = sample(mine, times)
    bad = 0
    for (v, _), g in zip(v2, got):
        if g is None: bad += 1; continue
        if zero_is is not None and abs(g - zero_is) < 1e-9: g = 0.0
        if abs(v * scale - g) > tol: bad += 1
    dur_m = sum(r[1] for r in mine)
    check(name, bad == 0 and abs(dur_m - total) < 0.5 / len(v2) * total + 1e-3,
          "%d v2 samples, %.3f s (v2) / %.3f s (port), %d different" % (len(v2), total, dur_m, bad))

compare("POCSAG", stub('v2_pocsag.bin'), records('bm_pocsag.ft'))
v2 = stub('v2_opera.bin')
compare("Opera", v2, records('bm_opera.rfa'), scale=32767, v2_extra=len(v2) - 238 * 10001)
compare("RTTY", stub('v2_rtty.bin'), records('bm_rtty.ft'))
compare("Morse", stub('v2_morse.bin'), records('bm_morse.rfa'), scale=32767)
compare("FreeDV", stub('v2_freedv.bin'), records('bm_freedv.ft'), zero_is=0.001)

# chirp: v2 at 200 kS/s, port at 10 kS/s: same curve within the slope over 100 us
v2 = stub('v2_chirp.bin')[:1000000]
times, total = midtimes(v2)
mine = records('bm_chirp.ft')
period = sum(r[1] for r in mine)
got = sample(mine, [t % period for t in times])
err = max(abs(v - g) for (v, _), g in zip(v2, got))
check("Chirp", err < 10.0, "%.1f s compared, max difference %.2f Hz (slope over 100 us: 6.3 Hz)" % (total, err))

# spectrum painting: same frequency for every pixel, same timing. The v2
# reads one line more than the picture (last read loop), ignored. The
# brightness is rendered differently on purpose (4 amplitude levels in v2,
# dithering in the port): compare the average level of 32x32 pixel blocks.
v2 = stub('v2_spectrum.bin')[:2 * 256 * 320]
freq = [v2[i] for i in range(0, len(v2), 2)]
amp = [v2[i + 1][0] for i in range(0, len(v2), 2)]
mine = records('bm_spectrum.ft')
times, total = midtimes(freq)
got = sample(mine, times)
on = [g not in (None, 0.0) for g in got]
bad = sum(1 for (f, _), g in zip(freq, got) if g not in (None, 0.0) and abs(f - (0 if abs(g) < 0.01 else g)) > 0.01)
def blocks(vals):
    out = []
    for by in range(0, 256, 32):
        for bx in range(0, 320, 32):
            out.append(sum(vals[(by + y) * 320 + bx + x] for y in range(32) for x in range(32)) / 1024.0)
    return out
def corr(a, b):
    ma, mb = sum(a) / len(a), sum(b) / len(b)
    cov = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    return cov / ((sum((x - ma) ** 2 for x in a) * sum((y - mb) ** 2 for y in b)) ** 0.5)
# true luminance of the picture, in transmission order (flipped)
rgb = open('picture.rgb', 'rb').read()
luma = []
for l in range(255, -1, -1):
    for x in range(320):
        r, g, b_ = rgb[(l * 320 + x) * 3:(l * 320 + x) * 3 + 3]
        luma.append((0.299 * r + 0.587 * g + 0.114 * b_) / 255.0)
ref = blocks(luma)
c_v2 = corr(ref, blocks([x / 3.0 for x in amp]))
c_bm = corr(ref, blocks([1.0 if x else 0.0 for x in on]))
check("Spectrum", bad == 0 and len(freq) == 256 * 320 and c_bm > 0.95,
      "%d pixels, %.2f s, frequency mapping identical; brightness of 32x32 blocks vs picture "
      "luminance: port %.2f, v2 %.2f" % (len(freq), total, c_bm, c_v2))

sys.exit(1 if fails else 0)
EOF
