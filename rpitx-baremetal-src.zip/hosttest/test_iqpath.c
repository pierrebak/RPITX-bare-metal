/*
 * test_iqpath.c - the IQ path of rpitx (IQ -> DMA sample registers) gives
 * the same output as the original code.
 *
 * Built twice by hosttest/run_iqpath.sh: once around the original
 * rpitx/RpiTx.c (-DRPITX_C=<old file>), once around the current one
 * (-DRPITX_C=<new file> -DHAVE_PITX_IQ_SAMPLE). Each build prints a hash of
 * every value the DMA engine would read (frequency table, its length,
 * amplitude registers) for a few million samples; the hashes must match.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

/* ---- stubs of the bare metal services used by RpiTx.c */
int bm_plld_mhz = 500;
uint64_t bm_micros (void) { return 0; }
void bm_udelay (unsigned us) { (void) us; }
void bm_sleep_us (unsigned us) { (void) us; }
void bm_poll (void) { }
int bm_stop_requested (void) { return 0; }
void bm_clear_stop (void) { }
int bm_add_poll_hook (void (*h) (void *), void *c) { (void) h; (void) c; return 0; }
void bm_remove_poll_hook (int id) { (void) id; }
void bm_clean_dcache (void) { }
void bm_clean_dcache_range (const volatile void *p, uint32_t l) { (void) p; (void) l; }
void *bm_alloc_aligned (size_t s, size_t a) { (void) a; return calloc (1, s); }
unsigned bm_alloc_dma_channel (int f) { (void) f; return 4; }
uint32_t bm_peripheral_base (void) { return 0x20000000; }
uint32_t bm_bus_address (const volatile void *p) { return (uint32_t) (uintptr_t) p; }
void *bm_bus_to_arm (uint32_t b) { return (void *) (uintptr_t) b; }
void bm_add_cleanup (void (*f) (void)) { (void) f; }

#include RPITX_C

/* RpiDma.c / RpiGpio.c parts that are referenced */
char DMA_CHANNEL;
uint8_t *virtbase;
volatile uint32_t *dma_reg, *pwm_reg, *clk_reg, *pcm_reg, *gpio_reg, *pad_gpios_reg;
struct control_data_s *ctl;
char InitDma (void *f, int *s) { (void) f; (void) s; return 1; }
char InitGpio (void) { return 1; }
int gpioSetMode (unsigned g, unsigned m) { (void) g; (void) m; return 0; }
int model;
uint32_t mem_flag;
uint32_t mem_virt_to_phys (volatile void *p) { return (uint32_t) (uintptr_t) p; }
uint32_t mem_phys_to_virt (volatile uint32_t p) { return p; }

static uint64_t s_hash = 1469598103934665603ULL;
static void hash_word (uint32_t w)
{
	for (int b = 0; b < 4; b++) {
		s_hash ^= (w >> (8 * b)) & 0xFF;
		s_hash *= 1099511628211ULL;
	}
}

static uint32_t s_rng = 12345;
static uint32_t rnd (void)
{
	s_rng = s_rng * 1664525u + 1013904223u;
	return s_rng;
}

/* one sample through the IQ path, as pitx_run() MODE_IQ does it */
static void one_sample (int I, int Q, int SampleRate, int no, char NoUsePWMF)
{
	static int amp;
	static double df;
	int OffsetModulation = 1000;
#ifdef HAVE_PITX_IQ_SAMPLE
	/* exactly as in pitx_run() (overrides at their default value, 0) */
	pitx_iq_sample (I, Q, &df, &amp, pitx_iq_rate > 0 ? pitx_iq_rate : (double) SampleRate);
	FrequencyAmplitudeToRegister (GlobalTuningFrequency + (HarmonicNumber == 1 ? (df - OffsetModulation - pitx_iq_offset_hz) : (df - OffsetModulation - pitx_iq_offset_hz) / HarmonicNumber),
				      amp, no, 0, SampleRate, NoUsePWMF, 0);
#else
	IQToFreqAmp (I, Q, &df, &amp, SampleRate);
	double A = 87.7f;
	double ampf = amp / 32767.0;
	ampf = (fabs (ampf) < 1.0f / A) ? A * fabs (ampf) / (1.0f + ln (A)) : (1.0f + ln (A * fabs (ampf))) / (1.0f + ln (A));
	amp = (int) (round (ampf * 32767.0f));
	FrequencyAmplitudeToRegister (GlobalTuningFrequency + (df - OffsetModulation) / HarmonicNumber,
				      amp, no, 0, SampleRate, NoUsePWMF, 0);
#endif
	sample_t *s = &ctl->sample[no];
	dma_cb_t *cb = ctl->cb + no * CBS_SIZE_BY_SAMPLE + 2;
	hash_word (cb->length);
	for (unsigned k = 0; k < cb->length / 4; k++)
		hash_word (s->FrequencyTab[k]);
	hash_word (s->Amplitude1);
	hash_word (s->Amplitude2);
	hash_word ((uint32_t) amp);
	uint64_t d;
	memcpy (&d, &df, sizeof d);
	hash_word ((uint32_t) d);
	hash_word ((uint32_t) (d >> 32));
}

int main (void)
{
	virtbase = calloc (1, NUM_PAGES * PAGE_SIZE);
	ctl = (struct control_data_s *) virtbase;
	static const double freqs[] = { 100e3, 7040e3, 14070e3, 28e6, 87.8e6, 100e6, 124.9e6,
					145.5e6, 434e6 };
	static const int rates[] = { 48000, 96000, 240000, 250000, 300000 };
	static const int minis[][2] = { {157, 1120}, {150, 1300}, {163, 980} };
	unsigned total = 0;

	for (unsigned f = 0; f < sizeof freqs / sizeof freqs[0]; f++)
	for (unsigned r = 0; r < sizeof rates / sizeof rates[0]; r++)
	for (unsigned m = 0; m < 3; m++)
	for (int pwmf = 0; pwmf < 2; pwmf++)
	for (int pattern = 0; pattern < 4; pattern++) {
		pitx_reset_state ();
		PllFreq500MHZ = PLL_FREQ_500MHZ;
		PllFreq1GHZ = PLL_FREQ_1GHZ;
		PllFreq19MHZ = PLLFREQ_192;
		pitx_SetTuneFrequency (freqs[f]);
		FREQ_MINI_TIMING = minis[m][0];
		PWMF_MARGIN = minis[m][1];
		UsePCMClk = (pattern & 1);
		s_ShowInfo = 0;
		for (int n = 0; n < 2500; n++) {
			int I, Q;
			switch (pattern) {
			case 0:		/* full range noise */
				I = (int16_t) rnd ();
				Q = (int16_t) rnd ();
				break;
			case 1: {	/* constant envelope, wide FM like */
				double ph = 0.5 * n + 2.0 * sin (n * 0.01);
				I = (int) (30000 * cos (ph));
				Q = (int) (30000 * sin (ph));
				break;
			}
			case 2:		/* small amplitudes */
				I = (int) (rnd () % 401) - 200;
				Q = (int) (rnd () % 401) - 200;
				break;
			default:	/* zeros and extremes */
				I = (n % 3 == 0) ? 0 : (n % 3 == 1 ? 32767 : -32767);
				Q = (n % 5 == 0) ? 0 : -I;
				break;
			}
			one_sample (I, Q, rates[r], n % NUM_SAMPLES, (char) pwmf);
			total++;
		}
	}
	printf ("%u samples, hash %016llx\n", total, (unsigned long long) s_hash);
	return 0;
}
