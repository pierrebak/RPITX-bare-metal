/* Test du detecteur de porteuses sur un spectre synthetique :
   plancher bruite + 3 porteuses de niveaux connus a des bins connus. */
#include <stdio.h>
#include <math.h>
#include "../tools/scan.h"

#define N 2048

int main (void)
{
	static float pdb[N];
	unsigned seed = 777;
	for (int i = 0; i < N; i++) {
		seed = seed * 1103515245u + 12345u;
		float r = ((seed >> 10) & 0x3FF) / 1024.0f;	/* 0..1 */
		pdb[i] = -80.0f + 3.0f * r;			/* plancher ~ -80 dB */
	}
	/* porteuses : (bin, niveau crete, demi-largeur) */
	int   bins[3]  = { 300, 1000, 1700 };
	float lvl[3]   = { -20.0f, -35.0f, -50.0f };
	int   half[3]  = { 3, 1, 2 };
	for (int c = 0; c < 3; c++)
		for (int d = -half[c]; d <= half[c]; d++) {
			float v = lvl[c] - 2.0f * (d < 0 ? -d : d);	/* forme en toit */
			int b = bins[c] + d;
			if (b >= 0 && b < N && v > pdb[b]) pdb[b] = v;
		}

	double f0 = 400e6, df = 1000.0;		/* bin 0 = 400 MHz, 1 kHz/bin */
	signal_t sig[16];
	float floor;
	int ns = scan_detect (pdb, N, f0, df, 8.0f, sig, 16, &floor);

	printf ("plancher = %.1f dB, %d signaux\n", floor, ns);
	for (int i = 0; i < ns; i++)
		printf ("  %.3f MHz  %.1f dB  SNR %.1f dB  largeur %.1f kHz\n",
			sig[i].freq_hz / 1e6, sig[i].level_db, sig[i].snr_db, sig[i].bw_hz / 1e3);

	int pass = (ns == 3)
		&& fabs (sig[0].freq_hz - (f0 + df * 300)) < df
		&& fabs (sig[1].freq_hz - (f0 + df * 1000)) < df
		&& fabs (sig[2].freq_hz - (f0 + df * 1700)) < df
		&& sig[0].level_db > sig[1].level_db && sig[1].level_db > sig[2].level_db
		&& floor < -70.0f && floor > -90.0f;
	printf (pass ? "PASS\n" : "FAIL\n");
	return pass ? 0 : 1;
}
