/* test_fsk.c - teste la démodulation FSK + le décodeur LaCrosse IT+ sur PC */
#include "../tools/fsk.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define FS	250000
#define BAUD	17241
#define DEV	50000.0		/* ±50 kHz */
#define OFFSET	30000.0		/* décalage d'accord */
#define AMP	40.0

static uint8_t iq[4000000];
static int niq;
static double phase;

static void mod_bit (int bit)
{
	int ns = FS / BAUD;
	double f = OFFSET + (bit ? DEV : -DEV);
	for (int i = 0; i < ns && niq + 2 <= (int) sizeof iq; i++)
	{
		phase += 2.0 * M_PI * f / FS;
		iq[niq++] = (uint8_t) (127.0 + AMP * cos (phase));
		iq[niq++] = (uint8_t) (127.0 + AMP * sin (phase));
	}
}

static void mod_byte (uint8_t b)
{
	for (int i = 7; i >= 0; i--)
	{
		mod_bit ((b >> i) & 1);
	}
}

static void mod_silence (int us)
{
	int ns = (int) ((long long) us * FS / 1000000);
	for (int i = 0; i < ns && niq + 2 <= (int) sizeof iq; i++)
	{
		unsigned s = (niq * 2654435761u) >> 24;
		iq[niq++] = (uint8_t) (127 + (int) (s & 3));	/* bruit faible, pas de porteuse */
		iq[niq++] = (uint8_t) (127 - (int) (s & 3));
	}
}

static char g_out[160];
static void on_packet (const fsk_packet_t *pkt, void *ctx)
{
	(void) ctx;
	char line[160];
	if (fsk_decode_lacrosse (pkt, line, sizeof line))
	{
		if (!g_out[0]) strcpy (g_out, line);
	}
	else
	{
		fsk_raw (pkt, line, sizeof line);
		printf ("    (non décodé) %s\n", line);
	}
}

int main (void)
{
	/* trame IT+ : id=42, température 21,5 C, humidité 55% */
	uint8_t b[5];
	b[0] = 0x9A;			/* 9 fixe, id haut = 0xA */
	b[1] = 0x86;			/* id bas (10) + centaines BCD 6 */
	b[2] = 0x15;			/* dizaines 1, unités 5 -> 615 -> 61,5 -> 21,5 C */
	b[3] = 0x37;			/* humidité 55, pile ok */
	b[4] = fsk_crc8 (b, 4, 0x31, 0x00);

	niq = 0;
	phase = 0;
	mod_silence (3000);
	for (int i = 0; i < 6; i++) mod_byte (0xAA);	/* préambule */
	mod_byte (0x2D);				/* synchro 0x2DD4 */
	mod_byte (0xD4);
	for (int i = 0; i < 5; i++) mod_byte (b[i]);	/* données + CRC */
	mod_silence (3000);

	fsk_t f;
	fsk_init (&f, FS, BAUD, 0x2DD4, 16, 5, on_packet, NULL);
	g_out[0] = '\0';
	fsk_feed (&f, iq, niq);

	const char *attendu = "LaCrosse-IT+  id=42  21.5 C  55%  pile=ok";
	int ok = strcmp (g_out, attendu) == 0;
	printf ("%-4s %s\n", ok ? "OK" : "FAIL", g_out[0] ? g_out : "(rien décodé)");
	if (!ok)
	{
		printf ("     attendu : %s\n", attendu);
		printf ("\nLa démodulation FSK a-t-elle récupéré les octets ? (le décodage dépend\n"
			"du format exact du capteur, à confirmer sur matériel.)\n");
		return 1;
	}
	printf ("\nChaîne FSK + décodeur LaCrosse IT+ : OK sur signal synthétique\n");
	return 0;
}
