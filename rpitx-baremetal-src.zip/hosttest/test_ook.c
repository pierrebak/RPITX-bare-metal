/* test_ook.c - teste le détecteur d'impulsions + le décodeur Nexus sur PC */
#include "../tools/ook.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FS	250000

static uint16_t buf[8000000];
static int nbuf;

static void push_level (int level_us, int high)
{
	int ns = (int) ((int64_t) level_us * FS / 1000000);
	unsigned seed = high * 7 + nbuf;
	for (int i = 0; i < ns && nbuf < (int) (sizeof buf / sizeof buf[0]); i++)
	{
		seed = seed * 1103515245u + 12345u;
		int noise = (int) ((seed >> 20) & 7);		/* 0..7 */
		buf[nbuf++] = (uint16_t) ((high ? 100 : 0) + noise);
	}
}

/* une trame Nexus : 36 bits, marque 500 µs, espace 1000 (0) / 2000 (1) µs */
static void gen_nexus (unsigned id, int battery, int channel, int temp_dC, int hum)
{
	uint8_t b[36];
	memset (b, 0, sizeof b);
	for (int i = 0; i < 8; i++)  b[i]      = (id >> (7 - i)) & 1;
	b[8] = battery ? 1 : 0;
	b[9] = 0;
	b[10] = ((channel - 1) >> 1) & 1;
	b[11] = (channel - 1) & 1;
	unsigned t = (unsigned) (temp_dC & 0xFFF);
	for (int i = 0; i < 12; i++) b[12 + i] = (t >> (11 - i)) & 1;
	for (int i = 0; i < 4; i++)  b[24 + i] = 1;			/* 1111 */
	for (int i = 0; i < 8; i++)  b[28 + i] = (hum >> (7 - i)) & 1;

	push_level (10000, 0);				/* silence de reset avant */
	for (int i = 0; i < 36; i++)
	{
		push_level (500, 1);
		push_level (b[i] ? 2000 : 1000, 0);
	}
	push_level (500, 1);				/* impulsion de terminaison */
	push_level (10000, 0);				/* silence de reset après */
}

/* TFA-Pool : PPM, marque 420 µs, espace 2000 (0) / 4600 (1) µs, 28 bits */
static void gen_tfa_pool (int id, int temp_dC, int channel, int battery)
{
	uint8_t b[4];
	int traw = temp_dC < 0 ? temp_dC + 4096 : temp_dC;
	b[0] = (uint8_t) (((id >> 4) & 0x0F));			/* quartet id haut, checksum après */
	b[1] = (uint8_t) (((id & 0x0F) << 4) | ((traw >> 8) & 0x0F));
	b[2] = (uint8_t) (traw & 0xFF);
	b[3] = (uint8_t) (((channel & 3) << 6) | ((battery & 1) << 5));
	int cs = ((b[0] & 0x0F) + (b[1] >> 4) + (b[1] & 0x0F)
		  + (b[2] >> 4) + (b[2] & 0x0F) + (b[3] >> 4) - 1) & 0x0F;
	b[0] = (uint8_t) ((cs << 4) | (b[0] & 0x0F));
	uint8_t bits[28];
	for (int i = 0; i < 8; i++)  bits[i]      = (b[0] >> (7 - i)) & 1;
	for (int i = 0; i < 8; i++)  bits[8 + i]  = (b[1] >> (7 - i)) & 1;
	for (int i = 0; i < 8; i++)  bits[16 + i] = (b[2] >> (7 - i)) & 1;
	for (int i = 0; i < 4; i++)  bits[24 + i] = (b[3] >> (7 - i)) & 1;

	push_level (10000, 0);
	for (int i = 0; i < 28; i++)
	{
		push_level (420, 1);
		push_level (bits[i] ? 4600 : 2000, 0);
	}
	push_level (420, 1);					/* terminaison */
	push_level (10000, 0);
}

/* LaCrosse TX141-Bv2 : préambule 4x833 µs, puis 37 bits PWM (bit 1 -> marque
   208 µs, bit 0 -> marque 417 µs), répété 3 fois */
static void gen_tx141 (int id, int temp_dC, int channel, int batt_ok)
{
	int traw = (temp_dC) + 500;
	uint8_t b[5];
	b[0] = (uint8_t) id;
	b[1] = (uint8_t) (((batt_ok & 1) << 7) | ((channel & 3) << 4) | ((traw >> 8) & 0x0F));
	b[2] = (uint8_t) (traw & 0xFF);
	b[3] = 0;
	b[4] = 0;
	uint8_t bits[37];
	for (int i = 0; i < 37; i++)
	{
		bits[i] = (b[i / 8] >> (7 - (i % 8))) & 1;
	}
	push_level (12000, 0);
	for (int rep = 0; rep < 3; rep++)
	{
		for (int p = 0; p < 4; p++)			/* préambule */
		{
			push_level (833, 1);
			push_level (833, 0);
		}
		for (int i = 0; i < 37; i++)			/* données */
		{
			push_level (bits[i] ? 208 : 417, 1);
			push_level (bits[i] ? 417 : 208, 0);
		}
	}
	push_level (12000, 0);
}

static char g_out[128];
static int g_ok, g_total;

static void on_packet (const ook_packet_t *pkt, void *ctx)
{
	(void) ctx;
	g_total++;
	char line[128];
	if (ook_decode (pkt, line, sizeof line))
	{
		strcpy (g_out, line);
		g_ok++;
	}
	else
	{
		ook_raw (pkt, line, sizeof line);
		printf ("    (non décodé) %s\n", line);
	}
}

int main (void)
{
	int fails = 0;
	struct { unsigned id; int bat, ch, temp, hum; } cas[] = {
		{0x5A, 1, 1,  213, 48},		/* 21,3 C  48% */
		{0xC3, 0, 2, -55, 72},		/* -5,5 C  72% */
		{0x11, 1, 3,  305, 95},		/* 30,5 C  95% */
	};
	for (unsigned c = 0; c < sizeof cas / sizeof cas[0]; c++)
	{
		nbuf = 0;
		gen_nexus (cas[c].id, cas[c].bat, cas[c].ch, cas[c].temp, cas[c].hum);
		ook_detector_t d;
		ook_init (&d, FS, on_packet, NULL);
		g_out[0] = '\0';
		ook_feed (&d, buf, nbuf);

		char attendu[128];
		snprintf (attendu, sizeof attendu,
			  "Nexus/clone  id=%u  canal=%d  %d.%d C  %d%%  pile=%s",
			  cas[c].id, cas[c].ch, cas[c].temp / 10,
			  (cas[c].temp < 0 ? -cas[c].temp : cas[c].temp) % 10, cas[c].hum,
			  cas[c].bat ? "ok" : "faible");
		int ok = strcmp (g_out, attendu) == 0;
		printf ("%-4s %s\n", ok ? "OK" : "FAIL", g_out[0] ? g_out : "(rien décodé)");
		if (!ok)
		{
			printf ("     attendu : %s\n", attendu);
			fails++;
		}
	}
	/* TFA-Pool */
	{
		nbuf = 0;
		gen_tfa_pool (131, 182, 1, 1);			/* id 131, 18.2 C, canal 1, pile ok */
		ook_detector_t d; ook_init (&d, FS, on_packet, NULL);
		g_out[0] = '\0'; ook_feed (&d, buf, nbuf);
		const char *att = "TFA-Pool  id=131  canal=1  18.2 C  pile=ok";
		int ok = strcmp (g_out, att) == 0;
		printf ("%-4s %s\n", ok ? "OK" : "FAIL", g_out[0] ? g_out : "(rien)");
		if (!ok) { printf ("     attendu : %s\n", att); fails++; }
	}
	/* LaCrosse TX141-Bv2 */
	{
		nbuf = 0;
		gen_tx141 (0x4c, 135, 1, 0);			/* id 4c, 13.5 C, canal 1, pile 0 */
		ook_detector_t d; ook_init (&d, FS, on_packet, NULL);
		g_out[0] = '\0'; ook_feed (&d, buf, nbuf);
		const char *att = "LaCrosse-TX141  id=4c  canal=1  13.5 C  pile=faible";
		int ok = strcmp (g_out, att) == 0;
		printf ("%-4s %s\n", ok ? "OK" : "FAIL", g_out[0] ? g_out : "(rien)");
		if (!ok) { printf ("     attendu : %s\n", att); fails++; }
	}

	printf (fails ? "\n%d test(s) en échec\n" : "\nTous les tests OOK passent\n", fails);
	return fails ? 1 : 0;
}
