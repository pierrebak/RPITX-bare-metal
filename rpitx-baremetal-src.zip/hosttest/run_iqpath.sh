#!/bin/bash
# Compares the IQ path of rpitx/RpiTx.c with the original one (see
# hosttest/test_iqpath.c). Usage: hosttest/run_iqpath.sh <original RpiTx.c> [file to test]
set -euo pipefail
OLD=$(realpath "${1:?path to the original rpitx/RpiTx.c}")
HERE=$(cd "$(dirname "$0")/.." && pwd)
NEW=$(realpath "${2:-$HERE/rpitx/RpiTx.c}")
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
# the original file is compiled next to the current headers
mkdir -p "$WORK/old"
cp "$OLD" "$WORK/old/RpiTx.c"
cp "$HERE"/rpitx/*.h "$WORK/old/"
mkdir -p "$WORK/inc"; cp "$HERE/compat/include/bm_compat.h" "$WORK/inc/"
F="-O2 -w -I $WORK/inc"
gcc $F -DRPITX_C="\"$WORK/old/RpiTx.c\"" -o "$WORK/t_old" "$HERE/hosttest/test_iqpath.c" -lm
gcc $F -DRPITX_C="\"$NEW\"" -DHAVE_PITX_IQ_SAMPLE -o "$WORK/t_new" "$HERE/hosttest/test_iqpath.c" -lm
A=$("$WORK/t_old" | tail -1); B=$("$WORK/t_new" | tail -1)
echo "original: $A"; echo "current : $B"
[ "$A" = "$B" ] && echo "IQ path: identical output" || { echo "IQ path: DIFFERENT"; exit 1; }
