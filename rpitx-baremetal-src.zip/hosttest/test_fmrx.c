/*
 * test_fmrx.c - essais du demodulateur FM (tools/fmrx_dsp.c) sur signaux synthetiques
 *
 * Le signal est fabrique comme le recevrait la cle RTL-SDR a 1 024 kS/s accordee
 * FMRX_TUNE_OFFSET au-dessus de la station : multiplex stereo norme (0,9 x audio,
 * pilote 19 kHz a 10 %), excursion 75 kHz, bruit, station voisine eventuelle, puis
 * quantification sur 8 bits. On mesure a la sortie (32 kHz) : niveau, rapport
 * signal / (bruit + distorsion), separation stereo, verrouillage du pilote.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../tools/fmrx_dsp.h"

#define FS	FMRX_IN_RATE
#define SECS	2.0
#define SKIP	0.5			/* reglage des filtres et du pilote */

static double s_proc_s, s_signal_s;

static double gauss (void)
{
	double u = (rand () + 1.0) / (RAND_MAX + 2.0), v = (rand () + 1.0) / (RAND_MAX + 2.0);
	return sqrt (-2 * log (u)) * cos (2 * M_PI * v);
}

/* sinusoide de frequence f ajustee (moindres carres) sur x[0..n) a fs : amplitude et residu */
static void fit (const double *x, int n, double fs, double f, double *amp, double *res_rms)
{
	double s11 = 0, s12 = 0, s22 = 0, y1 = 0, y2 = 0, m = 0;
	for (int k = 0; k < n; k++) m += x[k];
	m /= n;
	for (int k = 0; k < n; k++) {
		double a = sin (2 * M_PI * f * k / fs), b = cos (2 * M_PI * f * k / fs), y = x[k] - m;
		s11 += a * a; s12 += a * b; s22 += b * b; y1 += a * y; y2 += b * y;
	}
	double det = s11 * s22 - s12 * s12;
	double ca = (y1 * s22 - y2 * s12) / det, cb = (s11 * y2 - s12 * y1) / det;
	double r = 0;
	for (int k = 0; k < n; k++) {
		double e = x[k] - m - ca * sin (2 * M_PI * f * k / fs) - cb * cos (2 * M_PI * f * k / fs);
		r += e * e;
	}
	*amp = sqrt (ca * ca + cb * cb);
	*res_rms = sqrt (r / n);
}

typedef struct {
	double fl, fr, al, ar;		/* tonalites gauche / droite (Hz, amplitude 0..1) */
	int pilot;
	double snr_db;			/* bruit d'entree (rapport porteuse / bruit dans 1 MHz) */
	double adj_db;			/* station voisine a +200 kHz (dB par rapport a la station) */
	double deemph_us;
	double amp;			/* amplitude de la station (pleine echelle 1) */
} sig_t;

/* fabrique le signal, le demodule, renvoie les sorties L et R (apres SKIP) */
static int run (const sig_t *sg, fmrx_t *f, double **pl, double **pr)
{
	int n = (int) (SECS * FS);
	uint8_t *buf = malloc (2 * 8192);
	int16_t *out = malloc (sizeof (int16_t) * 2 * 1024);
	int nout = (int) (SECS * FMRX_OUT_RATE) + 64, k = 0;
	double *L = calloc (nout, sizeof (double)), *R = calloc (nout, sizeof (double));
	double ph = 0, ph_adj = 0, amp = sg->amp > 0 ? sg->amp : 0.35, namp = amp / pow (10, sg->snr_db / 20) / sqrt (2);
	fmrx_init (f);
	fmrx_set_deemphasis (f, (float) sg->deemph_us);
	f->volume = 1.0f;
	srand (1);
	for (int base = 0; base < n; base += 8192) {
		for (int j = 0; j < 8192; j++) {
			double t = (double) (base + j) / FS;
			double l = sg->al * sin (2 * M_PI * sg->fl * t), r = sg->ar * sin (2 * M_PI * sg->fr * t);
			double mpx = 0.9 * ((l + r) / 2 + (sg->pilot ? (l - r) / 2 * sin (2 * 2 * M_PI * 19000 * t) : 0))
				   + (sg->pilot ? 0.1 * sin (2 * M_PI * 19000 * t) : 0);
			ph += 2 * M_PI * 75000 * mpx / FS;
			double zi = amp * cos (ph), zq = amp * sin (ph);
			if (sg->adj_db > -200) {		/* voisine a +200 kHz, modulee par 2 kHz */
				double aa = amp * pow (10, sg->adj_db / 20);
				ph_adj += 2 * M_PI * (200000 + 60000 * sin (2 * M_PI * 2000 * t)) / FS;
				zi += aa * cos (ph_adj);
				zq += aa * sin (ph_adj);
			}
			zi += namp * gauss ();
			zq += namp * gauss ();
			/* la cle est accordee FMRX_TUNE_OFFSET plus haut : station a -Fs/4 */
			double a = -2 * M_PI * FMRX_TUNE_OFFSET * t, c = cos (a), s = sin (a);
			double yi = zi * c - zq * s, yq = zi * s + zq * c;
			int vi = (int) lrint (127.5 + 127.5 * yi), vq = (int) lrint (127.5 + 127.5 * yq);
			buf[2 * j] = (uint8_t) (vi < 0 ? 0 : vi > 255 ? 255 : vi);
			buf[2 * j + 1] = (uint8_t) (vq < 0 ? 0 : vq > 255 ? 255 : vq);
		}
		struct timespec t0, t1;
		clock_gettime (CLOCK_MONOTONIC, &t0);
		int m = fmrx_process (f, buf, 2 * 8192, out, 1024);
		clock_gettime (CLOCK_MONOTONIC, &t1);
		s_proc_s += (t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9;
		s_signal_s += 8192.0 / FS;
		for (int j = 0; j < m && k < nout; j++, k++) {
			L[k] = out[2 * j] / 32767.0;
			R[k] = out[2 * j + 1] / 32767.0;
		}
	}
	free (buf);
	free (out);
	int skip = (int) (SKIP * FMRX_OUT_RATE);
	*pl = L + skip;
	*pr = R + skip;
	return k - skip;
}

static int check (const char *what, int ok)
{
	printf ("%s %s\n", ok ? "OK  " : "FAIL", what);
	return ok;
}

int main (void)
{
	int ok = 1;
	fmrx_t f;
	double *L, *R, a, r, a2, r2;
	char msg[256];

	/* 1. mono, 1 kHz : niveau, S/(B+D), pas de stereo */
	sig_t mono = { 1000, 1000, 0.8, 0.8, 0, 40, -300, 0, 0 };
	int n = run (&mono, &f, &L, &R);
	fit (L, n, FMRX_OUT_RATE, 1000, &a, &r);
	fit (R, n, FMRX_OUT_RATE, 1000, &a2, &r2);
	snprintf (msg, sizeof msg, "mono 1 kHz : niveau L %.3f R %.3f (attendu 0,72), S/(B+D) %.1f dB, stereo=%d",
		  a, a2, 20 * log10 (a / sqrt (2) / r), f.stereo);
	ok &= check (msg, fabs (a - 0.72) < 0.03 && fabs (a2 - a) < 0.005 && 20 * log10 (a / sqrt (2) / r) > 40 && !f.stereo);

	/* 2. stereo, 1 kHz a gauche seulement : separation */
	sig_t left = { 1000, 3000, 0.8, 0.0, 1, 40, -300, 0, 0 };
	n = run (&left, &f, &L, &R);
	fit (L, n, FMRX_OUT_RATE, 1000, &a, &r);
	fit (R, n, FMRX_OUT_RATE, 1000, &a2, &r2);
	snprintf (msg, sizeof msg, "stereo, 1 kHz a gauche : L %.3f, fuite a droite %.4f -> separation %.1f dB, "
		  "pilote %.3f, stereo=%d, S/(B+D) L %.1f dB", a, a2, 20 * log10 (a / a2), f.pilot_level, f.stereo,
		  20 * log10 (a / sqrt (2) / r));
	ok &= check (msg, f.stereo && 20 * log10 (a / a2) > 30 && fabs (a - 0.72) < 0.03);

	/* 3. stereo, 5 kHz a droite seulement */
	sig_t right = { 1000, 5000, 0.0, 0.8, 1, 40, -300, 0, 0 };
	n = run (&right, &f, &L, &R);
	fit (R, n, FMRX_OUT_RATE, 5000, &a, &r);
	fit (L, n, FMRX_OUT_RATE, 5000, &a2, &r2);
	snprintf (msg, sizeof msg, "stereo, 5 kHz a droite : R %.3f, fuite a gauche %.4f -> separation %.1f dB",
		  a, a2, 20 * log10 (a / a2));
	ok &= check (msg, f.stereo && 20 * log10 (a / a2) > 30);

	/* 4. station voisine a +200 kHz, 16 dB plus forte (la voisine occupe presque toute la
	   dynamique des 8 bits, comme apres reglage du gain) */
	sig_t adj = { 1000, 1000, 0.8, 0.8, 0, 40, 16, 0, 0.05 };
	n = run (&adj, &f, &L, &R);
	fit (L, n, FMRX_OUT_RATE, 1000, &a, &r);
	snprintf (msg, sizeof msg, "voisine +16 dB a +200 kHz : S/(B+D) %.1f dB", 20 * log10 (a / sqrt (2) / r));
	ok &= check (msg, 20 * log10 (a / sqrt (2) / r) > 30);
	sig_t adjref = { 1000, 1000, 0.8, 0.8, 0, 40, -300, 0, 0.05 };
	n = run (&adjref, &f, &L, &R);
	fit (L, n, FMRX_OUT_RATE, 1000, &a, &r);
	printf ("     (meme station seule, meme niveau : S/(B+D) %.1f dB)\n", 20 * log10 (a / sqrt (2) / r));

	/* 5. desaccentuation 50 us : 10 kHz / 1 kHz (theorie -9,9 dB) */
	sig_t d1 = { 1000, 1000, 0.5, 0.5, 0, 40, -300, 50, 0 }, d10 = { 10000, 10000, 0.5, 0.5, 0, 40, -300, 50, 0 };
	n = run (&d1, &f, &L, &R);
	fit (L, n, FMRX_OUT_RATE, 1000, &a, &r);
	n = run (&d10, &f, &L, &R);
	fit (L, n, FMRX_OUT_RATE, 10000, &a2, &r2);
	double th = 20 * log10 (sqrt (1 + pow (2 * M_PI * 1000 * 50e-6, 2)) / sqrt (1 + pow (2 * M_PI * 10000 * 50e-6, 2)));
	snprintf (msg, sizeof msg, "desaccentuation 50 us : 10 kHz / 1 kHz = %.1f dB (theorie %.1f dB)",
		  20 * log10 (a2 / a), th);
	ok &= check (msg, fabs (20 * log10 (a2 / a) - th) < 1.0);

	/* 6. signal faible : 15 dB de rapport porteuse / bruit dans 1 MHz */
	sig_t weak = { 1000, 1000, 0.8, 0.8, 1, 15, -300, 50, 0 };
	n = run (&weak, &f, &L, &R);
	fit (L, n, FMRX_OUT_RATE, 1000, &a, &r);
	snprintf (msg, sizeof msg, "signal faible (15 dB dans 1 MHz) : S/(B+D) %.1f dB, stereo=%d",
		  20 * log10 (a / sqrt (2) / r), f.stereo);
	ok &= check (msg, 20 * log10 (a / sqrt (2) / r) > 15);

	printf ("temps de calcul PC : %.1f ms par seconde de signal (%.2f %% d'un coeur)\n",
		1000 * s_proc_s / s_signal_s, 100 * s_proc_s / s_signal_s);
	printf (ok ? "fmrx: all tests passed\n" : "fmrx: FAILURES\n");
	return ok ? 0 : 1;
}
