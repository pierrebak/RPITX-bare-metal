/*
 * fft.h - FFT radix-2 en float, et spectre de puissance depuis des IQ 8 bits
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#ifndef FFT_H
#define FFT_H

#include <stdint.h>

typedef struct {
	int   n;		/* taille (puissance de 2) */
	int   logn;
	float *wr, *wi;		/* table de rotation (N/2) */
	int   *brev;		/* permutation par inversion de bits */
	float *win;		/* fenetre de Hann (N) */
	float wsum;		/* somme de la fenetre (normalisation) */
} fft_t;

/* alloue pour une taille n (puissance de 2) ; renvoie 0 si OK, -1 sinon */
int  fft_init (fft_t *f, int n);
void fft_free (fft_t *f);

/* FFT directe en place */
void fft_run (fft_t *f, float *re, float *im);

/* spectre de puissance (dB) depuis n echantillons IQ 8 bits non signes
   (I,Q entrelaces). Sortie recentree : pdb[0] = -Fs/2 ... pdb[n-1] = +Fs/2.
   0 dB = pleine echelle (sinusoide a +/-1). */
void fft_power_u8 (fft_t *f, const uint8_t *iq, float *pdb);

#endif
