/*
 * rtlscan.c - scanner de bande + detecteur de porteuses avec une cle RTL-SDR
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Balaie le tuner par pas sur la bande demandee ; a chaque pas, une FFT du bloc
 * capture donne la puissance par canal. On assemble le plancher de bruit, on
 * detecte les bins qui depassent (plancher + seuil), regroupes en porteuses, et
 * on affiche la liste des frequences actives (triees par niveau).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <bm_compat.h>
#include "rtl-sdr.h"
#include "rtl-sdr-bm.h"
#include "convenience/convenience.h"
#include "fft.h"
#include "scan.h"
#include "classify.h"
#include "bandplan.h"
#include "fmrx_dsp.h"

#define RATE		1024000		/* debit prouve stable sur Pi 1 (= FMRX_IN_RATE) */
#define FM_LO_MHZ	87.3		/* bande FM pour l'identification RDS */
#define FM_HI_MHZ	108.1
#define FFTN		1024		/* 2 kHz par bin */
#define FRAMES		6		/* moyennage pour baisser le bruit */
#define USB_BUF_NUM	6
#define USB_BUF_LEN	16384
#define SKIP_BUFS	3		/* buffers jetes apres un changement de frequence */
#define USE_LO		(FFTN / 10)		/* bins utiles : 10 % .. 90 % */
#define USE_HI		(FFTN - FFTN / 10)	/* (bords du filtre ecartes) */
#define DC_HALF		2		/* bins masques autour de la continue */
#define MAX_SIG		256
#define MERGE_HZ	6000.0		/* fusion des doublons (recouvrement) */

static rtlsdr_dev_t *s_dev;
static volatile int s_quit;

static uint8_t  s_cap[FRAMES * FFTN * 2];
static volatile int s_cap_len;
static volatile int s_skip;
static volatile int s_done;

static fft_t s_fft;
static float s_pdb[FFTN];
static float s_pacc[FFTN];
static float s_cre[FFTN], s_cim[FFTN];		/* bande de base pour la classification */

static signal_t s_sig[MAX_SIG];
static int s_nsig;

/* identification RDS : demodulateur FM reutilise pour lire le nom de station */
static fmrx_t s_fm;
static int16_t s_fm_out[1024];
static volatile int s_rds_mode;

/* gain du tuner (manuel, comme rtlfm : indispensable au verrouillage RDS) */
static int s_gains[64];
static int s_ngains;
static int s_gidx;
static int s_agc_on = 1;			/* AGC logiciel actif (sauf gain fixe -g) */
static int s_dbg = 0;				/* -D : diagnostic de classification */

static int nearest_gain_idx (int tenths)
{
	int best = 0;
	for (int i = 1; i < s_ngains; i++)
		if (abs (s_gains[i] - tenths) < abs (s_gains[best] - tenths))
			best = i;
	return best;
}

static void set_gain_idx (int idx)
{
	if (idx < 0) idx = 0;
	if (idx >= s_ngains) idx = s_ngains - 1;
	s_gidx = idx;
	rtlsdr_set_tuner_gain (s_dev, s_gains[idx]);
}

static void rtl_callback (unsigned char *buf, uint32_t len, void *ctx)
{
	(void) ctx;
	if (s_rds_mode) {			/* passe RDS : on alimente le demod FM */
		fmrx_process (&s_fm, buf, (int) len, s_fm_out,
			      (int) (sizeof s_fm_out / sizeof s_fm_out[0] / 2));
		return;
	}
	if (s_done)
		return;
	if (s_skip > 0) { s_skip--; return; }	/* jette les buffers d'apres-retune */
	int cap = (int) sizeof s_cap;
	int n = (int) len;
	if (s_cap_len + n > cap)
		n = cap - s_cap_len;
	memcpy (s_cap + s_cap_len, buf, n);
	s_cap_len += n;
	if (s_cap_len >= cap)
		s_done = 1;
}

static void on_sigint (int sig) { (void) sig; s_quit = 1; }

static void cleanup (void)
{
	if (s_dev) { rtlsdr_stop_async (s_dev); rtlsdr_close (s_dev); s_dev = NULL; }
}

/* ajoute une porteuse a la liste globale, en fusionnant les doublons proches */
static void add_signal (const signal_t *s)
{
	for (int i = 0; i < s_nsig; i++) {
		double d = s_sig[i].freq_hz - s->freq_hz;
		if (d < 0) d = -d;
		if (d < MERGE_HZ) {
			if (s->level_db > s_sig[i].level_db)
				s_sig[i] = *s;		/* garde le plus fort */
			return;
		}
	}
	if (s_nsig < MAX_SIG)
		s_sig[s_nsig++] = *s;
}

/* capture un dwell a la frequence centrale donnee, renvoie 0 si OK */
static int capture (uint32_t center)
{
	rtlsdr_set_center_freq (s_dev, center);
	s_cap_len = 0;
	s_done = 0;
	s_skip = SKIP_BUFS;
	uint64_t t0 = bm_micros ();
	while (!s_done && !s_quit) {
		if (rtlsdr_poll_async (s_dev) < 0)
			return -1;
		bm_poll ();				/* pompe le clavier */
		if (bm_micros () - t0 > 2000000)	/* 2 s : abandon */
			return -1;
		int k = bm_getkey ();
		if (k == 0x1B || k == 'q' || k == 'Q') s_quit = 1;
	}
	return s_quit ? -1 : 0;
}

/* detecte les porteuses du dwell capture, centre sur 'center' */
static void process (uint32_t center, float thr_db)
{
	for (int i = 0; i < FFTN; i++) s_pacc[i] = 0.0f;
	for (int f = 0; f < FRAMES; f++) {
		fft_power_u8 (&s_fft, s_cap + f * FFTN * 2, s_pdb);
		for (int i = 0; i < FFTN; i++) s_pacc[i] += s_pdb[i];
	}
	for (int i = 0; i < FFTN; i++) s_pacc[i] /= FRAMES;

	/* masque la raie continue (au centre du spectre recentre) */
	for (int d = -DC_HALF; d <= DC_HALF; d++)
		s_pacc[FFTN / 2 + d] = s_pacc[FFTN / 2 - DC_HALF - 1];

	double df = (double) RATE / FFTN;
	double f0 = center + (USE_LO - FFTN / 2) * df;	/* freq du 1er bin utile */
	signal_t seg[64];
	float floor;
	int ns = scan_detect (s_pacc + USE_LO, USE_HI - USE_LO, f0, df,
			      thr_db, seg, 64, &floor);
	for (int i = 0; i < ns; i++)
		add_signal (&seg[i]);
}

/* se cale sur chaque porteuse de la bande FM et lit le nom de station (RDS).
   Le scanner tourne deja a 1,024 Msps (= FMRX_IN_RATE), donc on NE touche PAS a
   l'USB (ni arret/redemarrage async, ni changement de debit) : on change juste
   la frequence, comme le transpondeur. On bascule la callback vers le demod FM. */
static void identify_fm (void)
{
	printf ("Identification RDS des stations FM (Echap pour passer)...\n");
	int tried = 0;
	for (int i = 0; i < s_nsig && !s_quit; i++) {
		double f = s_sig[i].freq_hz / 1e6;
		if (f < FM_LO_MHZ || f > FM_HI_MHZ)
			continue;
		if (tried >= 12)			/* plafond : bornes le temps total */
			break;
		tried++;
		printf ("  %8.4f MHz : ", f);
		fflush (stdout);

		fmrx_init (&s_fm);		/* remet le decodeur RDS a zero */
		s_rds_mode = 1;
		rtlsdr_set_center_freq (s_dev, (uint32_t) (s_sig[i].freq_hz + FMRX_TUNE_OFFSET));
		uint64_t t0 = bm_micros (), t_agc = t0;
		float clipmax = 0.0f;
		while (!s_quit && bm_micros () - t0 < 5000000) {		/* <= 5 s */
			if (rtlsdr_poll_async (s_dev) < 0)
				break;
			int k = bm_getkey ();
			if (k == 0x1B || k == 'q' || k == 'Q') { s_quit = 1; break; }
			if (s_fm.rds.ps_ok)
				break;
			if (s_fm.clip_ratio > clipmax) clipmax = s_fm.clip_ratio;
			/* AGC logiciel calque sur rtlfm : vise -12 dBFS, recule sur saturation */
			uint64_t now = bm_micros ();
			if (s_agc_on && now - t_agc > 300000) {
				t_agc = now;
				float db = s_fm.level_dbfs;
				if (clipmax > 0.002f) set_gain_idx (s_gidx - 3);
				else if (clipmax > 0.0002f || db > -8.0f) set_gain_idx (s_gidx - 1);
				else if (db < -16.0f && clipmax == 0.0f) set_gain_idx (s_gidx + 1);
				clipmax = 0.0f;
			}
		}
		s_rds_mode = 0;
		if (s_fm.rds.ps_ok) {
			strncpy (s_sig[i].name, s_fm.rds.ps, 8);
			s_sig[i].name[8] = 0;
			printf ("%s\n", s_sig[i].name);
		} else {
			/* diagnostic : niveau d'entree, pilote (stereo), synchro RDS */
			printf ("(rien)  [niv %.0f dB  pilote %.0f%%  rds-sync %d]\n",
				s_fm.level_dbfs, s_fm.pilot_level * 100.0, s_fm.rds.synced);
		}
	}
}

/* 'mode' figure-t-il dans la liste 'allowed' (modes separes par des virgules) ? */
static int mode_in (const char *allowed, const char *mode)
{
	const char *p = allowed;
	size_t n = strlen (mode);
	while (p && *p) {
		if (strncmp (p, mode, n) == 0 && (p[n] == ',' || p[n] == 0))
			return 1;
		const char *c = strchr (p, ',');
		if (!c) break;
		p = c + 1;
	}
	return 0;
}

/* classe la modulation d'une porteuse : on se cale Fs/4 au-dessus (le signal
   tombe a -Fs/4, loin de la raie continue), on le ramene a 0 Hz par la rotation
   {1,j,-1,-j} tout en decimant par 4 (filtre boxcar), puis on classe le bloc.
   'allowed' = modes plausibles de la bande (0 = bande inconnue). On n'affiche le
   mode que s'il est sur ET coherent avec la bande : pas de faux positif. */
static void classify_carrier (signal_t *s, const char *allowed)
{
	if (capture ((uint32_t) (s->freq_hz + RATE / 4)) != 0)
		return;
	for (int k = 0; k < FFTN; k++) {
		float ar = 0.0f, ai = 0.0f;
		for (int m = 0; m < 4; m++) {
			int idx = k * 4 + m;
			float I = ((int) s_cap[2 * idx]     - 127) / 128.0f;
			float Q = ((int) s_cap[2 * idx + 1] - 127) / 128.0f;
			switch (m & 3) {		/* multiplie par e^{+j pi/2 m} */
			case 0: ar += I;  ai += Q;  break;
			case 1: ar += -Q; ai += I;  break;
			case 2: ar += -I; ai += -Q; break;
			default: ar += Q; ai += -I; break;
			}
		}
		s_cre[k] = ar; s_cim[k] = ai;
	}
	float conf;
	char dbg[96];
	mod_t m = classify_dbg (&s_fft, s_cre, s_cim, FFTN, &conf, dbg, sizeof dbg);
	if (m != MOD_NOISE && m != MOD_UNKNOWN && conf >= 0.6f) {
		const char *mn = mod_name (m);
		/* bande connue multi-mode : le mode doit figurer dans la liste ;
		   bande inconnue (allowed=0) : on exige une confiance elevee */
		int ok = allowed ? mode_in (allowed, mn) : (conf >= 0.65f);
		if (ok) {
			strncpy (s->mod, mn, sizeof s->mod - 1);
			s->mod[sizeof s->mod - 1] = 0;
		}
	}
	if (s_dbg)					/* -D : detail des indicateurs */
		printf ("  %.4f : %-8s  %s\n", s->freq_hz / 1e6, mod_name (m), dbg);
}

static int cmp_level (const void *a, const void *b)
{
	const signal_t *x = a, *y = b;
	return x->level_db < y->level_db ? 1 : x->level_db > y->level_db ? -1 : 0;
}

static void usage (void)
{
	fprintf (stderr,
		"rtlscan, scanner de bande + detecteur de porteuses (RTL-SDR)\n\n"
		"Usage: rtlscan [-a debut_MHz] [-b fin_MHz] [-t seuil_dB] [-g dB] [-c] [-P ppm] [-d index]\n"
		"\t[-a MHz]   debut de bande (defaut 88)\n"
		"\t[-b MHz]   fin de bande (defaut 108)\n"
		"\t[-t dB]    seuil au-dessus du plancher de bruit (defaut 8)\n"
		"\t[-g dB]    gain fixe du tuner (defaut : automatique)\n"
		"\t[-c]       balayage continu (Echap pour quitter)\n"
		"\t[-P ppm]   correction de frequence\n"
		"\t[-d index] numero de la cle\n"
		"\t[-D]       diagnostic de classification (indicateurs par porteuse)\n"
		"Exemples : rtlscan -a 433 -b 435   rtlscan -a 144 -b 146 -t 6\n");
	exit (1);
}

int rtlscan_main (int argc, char **argv)
{
	int opt, dev_index = 0, ppm = 0, fixed_gain = -1, cont = 0;
	double a_mhz = 88.0, b_mhz = 108.0;
	float thr_db = 8.0f;

	s_dev = NULL; s_quit = 0;
	optind = 1;
	while ((opt = getopt (argc, argv, "a:b:t:g:cP:d:Dh")) != -1) {
		switch (opt) {
		case 'a': a_mhz = atof (optarg); break;
		case 'b': b_mhz = atof (optarg); break;
		case 't': thr_db = (float) atof (optarg); break;
		case 'g': fixed_gain = (int) (atof (optarg) * 10); break;
		case 'c': cont = 1; break;
		case 'P': ppm = atoi (optarg); break;
		case 'd': dev_index = atoi (optarg); break;
		case 'D': s_dbg = 1; break;
		default: usage ();
		}
	}
	if (a_mhz < 0.1 || b_mhz > 1700 || b_mhz <= a_mhz) usage ();

	if (fft_init (&s_fft, FFTN)) { fprintf (stderr, "FFT: memoire\n"); exit (1); }
	bm_add_cleanup (cleanup);
	signal (SIGINT, on_sigint);

	if (rtlsdr_get_device_count () == 0) { fprintf (stderr, "Pas de cle RTL-SDR\n"); exit (1); }
	if (rtlsdr_open (&s_dev, dev_index) < 0) { fprintf (stderr, "Ouverture cle #%d impossible\n", dev_index); s_dev = NULL; exit (1); }
	rtlsdr_set_bias_tee (s_dev, 0);
	rtlsdr_set_direct_sampling (s_dev, 0);
	verbose_set_sample_rate (s_dev, RATE);
	rtlsdr_set_agc_mode (s_dev, 0);
	rtlsdr_set_tuner_gain_mode (s_dev, 1);			/* gain manuel (comme rtlfm) */
	s_ngains = rtlsdr_get_tuner_gains (s_dev, NULL);
	if (s_ngains > 64) s_ngains = 64;
	if (s_ngains < 1) s_ngains = 1;
	rtlsdr_get_tuner_gains (s_dev, s_gains);
	set_gain_idx (fixed_gain >= 0 ? nearest_gain_idx (fixed_gain) : nearest_gain_idx (200));
	s_agc_on = (fixed_gain < 0);		/* AGC sauf si gain impose par -g */
	if (ppm != 0) verbose_ppm_set (s_dev, ppm);
	verbose_reset_buffer (s_dev);

	if (rtlsdr_start_async (s_dev, rtl_callback, NULL, USB_BUF_NUM, USB_BUF_LEN) < 0) {
		fprintf (stderr, "Echec du demarrage de la reception\n"); exit (1);
	}
	bm_key_capture (1);

	double df = (double) RATE / FFTN;
	double span = (USE_HI - USE_LO) * df;		/* largeur utile par pas */
	uint64_t a_hz = (uint64_t) (a_mhz * 1e6);
	uint64_t b_hz = (uint64_t) (b_mhz * 1e6);

	do {
		s_nsig = 0;
		printf ("Balayage %.3f - %.3f MHz (pas %.2f MHz)...\n",
			a_mhz, b_mhz, span / 1e6);
		for (uint64_t c = a_hz + (uint64_t) (span / 2); c < b_hz + (uint64_t) (span / 2) && !s_quit;
		     c += (uint64_t) span) {
			if (capture ((uint32_t) c) == 0)
				process ((uint32_t) c, thr_db);
		}
		if (s_quit) break;

		qsort (s_sig, s_nsig, sizeof s_sig[0], cmp_level);

		/* plan de bandes + modulation (balayage unique) :
		   le service vient du plan (fiable) ; le mode est impose si la bande
		   n'en admet qu'un, sinon issu du classifieur seulement s'il est sur. */
		if (!cont && !s_quit) {
			printf ("Identification (plan de bandes + modulation)...\n");
			for (int i = 0; i < s_nsig && !s_quit; i++) {
				band_info_t b = bandplan_lookup (s_sig[i].freq_hz);
				s_sig[i].service = b.service;
				if (b.fixed_mode) {		/* bande a mode unique : autoritatif */
					strncpy (s_sig[i].mod, b.fixed_mode, sizeof s_sig[i].mod - 1);
					s_sig[i].mod[sizeof s_sig[i].mod - 1] = 0;
				} else if (i < 24) {		/* sinon classifieur (borne au temps) */
					classify_carrier (&s_sig[i], b.allowed);
				}
			}
		}

		/* puis identification RDS si la bande recouvre la FM (balayage unique) */
		if (!cont && !s_quit && a_mhz <= FM_HI_MHZ && b_mhz >= FM_LO_MHZ)
			identify_fm ();

		printf ("\n%d porteuse(s) detectee(s) :\n", s_nsig);
		for (int i = 0; i < s_nsig; i++)
			printf ("  %9.4f MHz   %6.1f dB   SNR %4.1f dB   ~%.0f kHz   %-18s %-7s%s%s\n",
				s_sig[i].freq_hz / 1e6, s_sig[i].level_db,
				s_sig[i].snr_db, s_sig[i].bw_hz / 1e3,
				s_sig[i].service ? s_sig[i].service : "",
				s_sig[i].mod[0] ? s_sig[i].mod : "",
				s_sig[i].name[0] ? "  " : "", s_sig[i].name);
		printf ("\n");
	} while (cont && !s_quit);

	/* balayage unique : on garde la liste a l'ecran jusqu'a une touche
	   (sinon la TUI redessine son menu et efface le resultat) */
	if (!cont && !s_quit) {
		printf ("Balayage termine. Une touche (ou Echap) pour revenir...\n");
		while (!s_quit) {
			int k = bm_getkey ();
			if (k >= 0)
				break;
			bm_poll ();
		}
	}
	return 0;
}
