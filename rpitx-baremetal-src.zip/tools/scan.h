/*
 * scan.h - detection de porteuses dans un spectre de puissance
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#ifndef SCAN_H
#define SCAN_H

typedef struct {
	double freq_hz;		/* frequence centrale (du pic) */
	float  level_db;	/* niveau crete */
	float  snr_db;		/* au-dessus du plancher de bruit */
	double bw_hz;		/* largeur estimee (bins au-dessus du seuil) */
	char   name[9];		/* nom RDS si station FM identifiee (sinon vide) */
	char   mod[10];		/* modulation estimee / imposee (sinon vide) */
	const char *service;	/* service du plan de bandes (sinon 0) */
} signal_t;

/* estime le plancher de bruit (dB) d'un spectre par un percentile bas */
float scan_noise_floor (const float *pdb, int n);

/* detecte les porteuses : bins au-dessus de (plancher + thr_db), regroupes.
   f0_hz = frequence du bin 0, df_hz = pas entre bins. Remplit out (trie par
   niveau decroissant), renvoie le nombre de signaux (<= maxout). *pfloor
   recoit le plancher si non NULL. */
int scan_detect (const float *pdb, int n, double f0_hz, double df_hz,
		 float thr_db, signal_t *out, int maxout, float *pfloor);

#endif
