/*
 * bandplan.h - plan de bandes (France/Europe) : frequence -> service + mode
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Donne, pour une frequence, le service alloue (fiable, reglementaire) et, selon
 * la bande, soit un mode unique impose (fixed_mode), soit la liste des modes
 * plausibles (allowed) pour filtrer le classifieur, soit rien (bande inconnue).
 */
#ifndef BANDPLAN_H
#define BANDPLAN_H

typedef struct {
	const char *service;	/* nom du service, 0 si inconnu */
	const char *fixed_mode;	/* mode unique impose (sinon 0 : utiliser le classifieur) */
	const char *allowed;	/* modes plausibles (liste), 0 = tous (bande inconnue) */
} band_info_t;

/* cherche la bande contenant freq_hz ; renvoie service=0 si hors plan */
band_info_t bandplan_lookup (double freq_hz);

#endif
