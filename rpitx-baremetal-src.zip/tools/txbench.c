/*
 * txbench.c - CPU time of the transmit chain, without transmitting
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Measures, on the board itself and with no RF output:
 *  - the rpitx v1 IQ path (IQ -> frequency / amplitude -> DMA control
 *    blocks), which runs for every transmitted sample;
 *  - the rtl2tx signal processing (wide and narrow modes).
 * The result says whether the CPU can keep up with a given sample rate.
 * During a real transmission the DMA engine also loads the memory bus, so
 * the real margin is smaller than the one printed here.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bm_compat.h>
#include "../rpitx/RpiTx.h"
#include "rtldsp.h"

#define N_BENCH		50000

static uint8_t s_in[2 * 8192];
static int16_t s_out[2 * 8192];
static rtldsp_t s_dsp;

static double per_sample_us (uint64_t us, unsigned n)
{
	return (double) us / (double) n;
}

static double bench_dsp (int mode, int decim, unsigned n_in)
{
	if (mode == RTLDSP_MODE_WIDE) {
		rtldsp_init (&s_dsp, 5, 12000, -200, 0, RTLDSP_MODE_RELAY);
		s_dsp.mode = RTLDSP_MODE_WIDE;
	} else {
		rtldsp_init (&s_dsp, decim, 12000, -200, 0, mode);
	}
	unsigned done = 0;
	uint64_t t0 = bm_micros ();
	while (done < n_in) {
		unsigned pairs = sizeof s_in / 2;
		if (pairs > n_in - done) pairs = n_in - done;
		if (mode == RTLDSP_MODE_WIDE)
			rtldsp_wide (&s_dsp, s_in, pairs * 2, s_out, sizeof s_out / 4);
		else
			rtldsp_process (&s_dsp, s_in, pairs * 2, s_out, sizeof s_out / 4);
		done += pairs;
		bm_poll ();
	}
	return per_sample_us (bm_micros () - t0, n_in);	/* per input pair */
}

int txbench_main (int argc, char **argv)
{
	int rate = argc > 1 ? atoi (argv[1]) : 250000;
	double freq_khz = argc > 2 ? atof (argv[2]) : 100000.0;
	if (rate < 1000 || rate > 1000000 || freq_khz <= 0) {
		fprintf (stderr, "usage: txbench [sample_rate (250000)] [freq_kHz (100000)]\n"
			 "CPU time of the transmit chain, nothing is transmitted.\n");
		return 1;
	}

	/* synthetic dongle input: noise-like bytes */
	unsigned seed = 1;
	for (unsigned k = 0; k < sizeof s_in; k++) {
		seed = seed * 1103515245u + 12345u;
		s_in[k] = (uint8_t) (seed >> 16);
	}

	printf ("txbench: %d S/s, %.3f kHz, %u samples (no RF output)\n", rate, freq_khz, N_BENCH);

	long us = pitx_bench_iq (rate, freq_khz * 1000.0, N_BENCH);
	if (us < 0) {
		fprintf (stderr, "txbench: DMA memory not available\n");
		return 1;
	}
	double iq = per_sample_us (us, N_BENCH);
	printf ("  rpitx IQ path      : %6.2f us/sample -> at most %6.1f kS/s\n", iq, 1000.0 / iq);

	double wide = bench_dsp (RTLDSP_MODE_WIDE, 5, N_BENCH);
	printf ("  rtl2tx wide DSP    : %6.2f us/sample\n", wide);
	double relay = bench_dsp (RTLDSP_MODE_RELAY, 5, N_BENCH * 5);
	printf ("  rtl2tx relay DSP   : %6.2f us per 48 kS/s output sample (240 kS/s input)\n", relay * 5);
	double fm2ssb = bench_dsp (RTLDSP_MODE_FM2SSB, 5, N_BENCH * 5);
	printf ("  rtl2tx fm2ssb DSP  : %6.2f us per 48 kS/s output sample (240 kS/s input)\n", fm2ssb * 5);

	double load_wide = (iq + wide) * rate / 1e6 * 100.0;
	double load_narrow = (iq + relay * 5) * 48000 / 1e6 * 100.0;
	printf ("CPU needed (USB transfers not counted):\n");
	printf ("  rtl2tx -m wide at %d S/s : %5.1f %%%s\n", rate, load_wide,
		load_wide >= 100.0 ? "  -> too slow, overruns expected" : "");
	printf ("  rtl2tx relay at 48 kS/s     : %5.1f %%\n", load_narrow);
	printf ("  rpitx -m IQ at %d S/s    : %5.1f %%%s\n", rate, iq * rate / 1e4,
		iq * rate / 1e4 >= 100.0 ? "  -> too slow" : "");
	return 0;
}
