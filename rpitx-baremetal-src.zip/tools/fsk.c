/*
 * fsk.c - démodulation FSK 2 états + décodeur LaCrosse IT+ (868 MHz)
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Principe : la clé est accordée près de la porteuse. Pour chaque échantillon
 * I/Q on mesure la fréquence instantanée (discriminateur : angle de
 * z[n]·conj(z[n-1])). En FSK 2 états, ce signal est haut pour un « 1 », bas
 * pour un « 0 ». On enlève la composante continue (décalage d'accord), on
 * tranche au milieu, on récupère l'horloge bit par une PLL numérique, puis on
 * cherche le mot de synchro et on assemble les octets.
 *
 * La porteuse est détectée par l'amplitude : hors transmission le
 * discriminateur ne donne que du bruit, on ne tranche donc que porteuse
 * présente.
 */
#include "fsk.h"
#include "ook.h"			/* sensor_t, sensor_format */
#include <stdio.h>
#include <string.h>
#include <math.h>

#ifndef PI_F
#define PI_F	3.14159265f
#endif

/* atan2 approché (erreur < 0,01 rad), renvoie l'angle en radians */
static float fast_atan2 (float y, float x)
{
	if (x == 0.0f && y == 0.0f)
	{
		return 0.0f;
	}
	float ax = x < 0 ? -x : x;
	float ay = y < 0 ? -y : y;
	float a = (ax < ay ? ax : ay) / (ax > ay ? ax : ay);
	float s = a * a;
	float r = ((-0.0464964749f * s + 0.15931422f) * s - 0.327622764f) * s * a + a;
	if (ay > ax) r = 1.57079637f - r;
	if (x < 0)   r = PI_F - r;
	if (y < 0)   r = -r;
	return r;
}

void fsk_init (fsk_t *f, int fs, int baud, uint32_t sync, int sync_bits,
	       int payload_len, fsk_cb cb, void *ctx)
{
	memset (f, 0, sizeof *f);
	f->fs = fs;
	f->clk_inc = (float) baud / fs;
	f->sync = sync;
	f->sync_mask = sync_bits >= 32 ? 0xFFFFFFFFu : ((1u << sync_bits) - 1);
	f->payload_len = payload_len < FSK_MAX_BYTES ? payload_len : FSK_MAX_BYTES;
	f->amp_noise = 2.0f;
	f->amp_level = 30.0f;
	f->cb = cb;
	f->ctx = ctx;
}

static void emit_bit (fsk_t *f, int bit)
{
	f->shift = (f->shift << 1) | (bit & 1);

	if (!f->in_packet)
	{
		if ((f->shift & f->sync_mask) == f->sync)
		{
			f->in_packet = 1;
			f->cur = 0;
			f->curbits = 0;
			f->pkt.num = 0;
		}
		return;
	}

	f->cur = (uint8_t) ((f->cur << 1) | (bit & 1));
	if (++f->curbits == 8)
	{
		if (f->pkt.num < FSK_MAX_BYTES)
		{
			f->pkt.data[f->pkt.num++] = f->cur;
		}
		f->cur = 0;
		f->curbits = 0;
		if (f->pkt.num >= f->payload_len)
		{
			if (f->cb)
			{
				f->cb (&f->pkt, f->ctx);
			}
			f->in_packet = 0;
		}
	}
}

void fsk_feed (fsk_t *f, const uint8_t *iq, int n_bytes)
{
	int ns = n_bytes / 2;
	for (int k = 0; k < ns; k++)
	{
		float i = (float) (iq[2 * k] - 127);
		float q = (float) (iq[2 * k + 1] - 127);

		/* amplitude (porteuse) */
		float ai = i < 0 ? -i : i;
		float aq = q < 0 ? -q : q;
		float amp = ai > aq ? ai + 0.375f * aq : aq + 0.375f * ai;

		/* discriminateur : fréquence instantanée */
		float re = i * f->prev_i + q * f->prev_q;
		float im = q * f->prev_i - i * f->prev_q;
		f->prev_i = i;
		f->prev_q = q;
		float freq = fast_atan2 (im, re);

		/* suivi du plancher/niveau d'amplitude */
		if (amp > f->amp_level) f->amp_level = amp;
		else f->amp_level += (amp - f->amp_level) * 0.0005f;
		f->amp_noise += (amp - f->amp_noise) * 0.0005f;
		float thr = f->amp_noise + (f->amp_level - f->amp_noise) * 0.4f;
		if (thr < f->amp_noise + 3.0f) thr = f->amp_noise + 3.0f;

		int carrier = amp > thr;

		/* continu du discriminateur : ne le suivre que porteuse présente,
		   sinon le bruit fausserait le centre entre les deux tons */
		if (carrier)
		{
			f->freq_mean += (freq - f->freq_mean) * 0.01f;
		}

		if (!carrier)
		{
			/* perte de porteuse : abandonne une trame en cours */
			f->carrier = 0;
			f->in_packet = 0;
			f->shift = 0;
			continue;
		}
		f->carrier = 1;

		int slice = (freq - f->freq_mean) > 0.0f ? 1 : 0;

		/* PLL bit : resynchronise la phase sur chaque transition */
		if (slice != f->last_slice)
		{
			f->clk = 0.5f;
			f->last_slice = slice;
		}
		f->clk += f->clk_inc;
		if (f->clk >= 1.0f)
		{
			f->clk -= 1.0f;
			emit_bit (f, slice);
		}
	}
}

uint8_t fsk_crc8 (const uint8_t *data, int len, uint8_t poly, uint8_t init)
{
	uint8_t crc = init;
	for (int i = 0; i < len; i++)
	{
		crc ^= data[i];
		for (int b = 0; b < 8; b++)
		{
			crc = (crc & 0x80) ? (uint8_t) ((crc << 1) ^ poly) : (uint8_t) (crc << 1);
		}
	}
	return crc;
}

/*
 * LaCrosse IT+ (TX29, TX35). Après la synchro 0x2DD4 : 4 octets de données + 1
 * octet de CRC-8 (poly 0x31, init 0x00). Décodage des champs (à confirmer sur
 * matériel réel) :
 *   octet0 : [7:4] = 9 (fixe), [3:0] = id haut
 *   octet1 : [7:6] = id bas, [3:0]+octet2 = température BCD sur 3 chiffres,
 *            valeur = BCD/10 - 40 °C
 *   octet3 : [6:0] = humidité %, bit7 = pile faible
 */
int fsk_decode_data (const fsk_packet_t *pkt, sensor_t *s)
{
	if (pkt->num < 5)
	{
		return 0;
	}
	const uint8_t *b = pkt->data;
	if (fsk_crc8 (b, 4, 0x31, 0x00) != b[4])
	{
		return 0;				/* CRC faux : pas une trame IT+ valable */
	}
	int id = ((b[0] & 0x0F) << 2) | (b[1] >> 6);
	int bcd = ((b[1] & 0x0F) * 100) + ((b[2] >> 4) * 10) + (b[2] & 0x0F);
	int hum = b[3] & 0x7F;
	int batt_low = (b[3] & 0x80) != 0;
	float temp = bcd * 0.1f - 40.0f;
	int t10 = (int) (temp * 10.0f + (temp < 0 ? -0.5f : 0.5f));

	sensor_init (s);
	strcpy (s->model, "LaCrosse-IT+");
	s->id = id;
	s->has_temp = 1;
	s->temp_dC = t10;
	s->humidity = hum <= 100 ? hum : -1;
	s->battery_ok = batt_low ? 0 : 1;
	return 1;
}

int fsk_decode_lacrosse (const fsk_packet_t *pkt, char *out, int outlen)
{
	sensor_t s;
	if (!fsk_decode_data (pkt, &s))
	{
		return 0;
	}
	sensor_format (&s, out, outlen);
	return 1;
}

void fsk_raw (const fsk_packet_t *pkt, char *out, int outlen)
{
	int hp = 0;
	hp += snprintf (out + hp, outlen - hp, "FSK 868  %d oct :", pkt->num);
	for (int i = 0; i < pkt->num && hp < outlen - 4; i++)
	{
		hp += snprintf (out + hp, outlen - hp, " %02x", pkt->data[i]);
	}
	if (pkt->num >= 5)
	{
		uint8_t crc = fsk_crc8 (pkt->data, 4, 0x31, 0x00);
		snprintf (out + hp, outlen - hp, "  (CRC/0x31 %s)",
			  crc == pkt->data[4] ? "ok" : "non");
	}
}
