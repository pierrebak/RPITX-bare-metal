/*
 * ook.h - détection d'impulsions OOK (tout-ou-rien) et décodeurs de capteurs
 *         433 MHz (température / humidité), inspiré de rtl_433
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#ifndef OOK_H
#define OOK_H

#include <stdint.h>

#define OOK_MAX_PULSES	1200

/* une rafale : suite de marques (niveau haut) et d'espaces (niveau bas) en µs */
typedef struct {
	int num;				/* nombre de couples marque/espace */
	int pulse_us[OOK_MAX_PULSES];		/* durée du niveau haut */
	int gap_us[OOK_MAX_PULSES];		/* durée du niveau bas qui suit */
} ook_packet_t;

typedef void (*ook_cb) (const ook_packet_t *pkt, void *ctx);

/* résultat décodé, partagé par les capteurs 433 (ook) et 868 (fsk) */
typedef struct sensor_t {
	char model[24];
	long id;
	int id_hex;				/* afficher l'id en hexa */
	int channel;				/* -1 : absent */
	int has_temp;
	int temp_dC;				/* dixièmes de °C */
	int humidity;				/* -1 : absent */
	int battery_ok;				/* -1 : absent, sinon 0/1 */
} sensor_t;

void sensor_init (sensor_t *s);
void sensor_format (const sensor_t *s, char *out, int outlen);	/* ligne simple */
void sensor_print (const sensor_t *s, unsigned sec);		/* ligne en couleur */

/* détecteur : on lui donne un flux d'amplitude (enveloppe), il appelle cb à
   chaque rafale séparée par un long silence */
typedef struct {
	int fs;					/* fréquence d'échantillonnage */
	int state;				/* 0 bas, 1 haut */
	int run;				/* échantillons dans la phase courante */
	int pending;				/* une marque attend son espace */
	int last_pulse_us;			/* durée (µs) de cette marque */
	float noise;				/* estimation du plancher de bruit */
	float level;				/* estimation du niveau du signal */
	ook_packet_t pkt;
	ook_cb cb;
	void *ctx;
} ook_detector_t;

void ook_init (ook_detector_t *d, int fs, ook_cb cb, void *ctx);
void ook_feed (ook_detector_t *d, const uint16_t *mag, int n);

/* Essaie les décodeurs connus ; écrit une ligne lisible dans out.
   Renvoie 1 si un capteur a été reconnu, 0 sinon. */
int ook_decode (const ook_packet_t *pkt, char *out, int outlen);

/* Variante remplissant la structure (pour l'affichage en couleur). */
int ook_decode_data (const ook_packet_t *pkt, sensor_t *s);

/* Résumé « brut » d'une rafale (nb de bits, timings dominants, hex) pour les
   capteurs pas encore reconnus. */
void ook_raw (const ook_packet_t *pkt, char *out, int outlen);

/* suite brute marque/espace (débogage) : écrit "p/g p/g ..." dans out */
void ook_dump (const ook_packet_t *pkt, char *out, int outlen);

/* diagnostic du décodage TX141 : préambules trouvés, longueurs, valeurs */
void ook_dbg_tx141 (const ook_packet_t *pkt, char *out, int outlen);

#endif
