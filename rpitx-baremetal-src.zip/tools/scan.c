/*
 * scan.c - detection de porteuses (voir scan.h)
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Plancher de bruit par histogramme (percentile bas, robuste aux porteuses).
 * Les bins au-dessus de plancher+seuil sont regroupes (on tolere un petit trou)
 * en signaux : frequence du pic, niveau, SNR, largeur.
 */
#include "scan.h"

#define FLOOR_PCT	30		/* percentile du plancher de bruit */
#define GAP_BINS	2		/* trou tolere dans un groupe */

float scan_noise_floor (const float *pdb, int n)
{
	/* histogramme de -160 a +20 dB, pas 1 dB */
	int hist[181];
	for (int i = 0; i < 181; i++) hist[i] = 0;
	for (int i = 0; i < n; i++) {
		int b = (int) (pdb[i] + 160.0f);
		if (b < 0) b = 0;
		if (b > 180) b = 180;
		hist[b]++;
	}
	int target = n * FLOOR_PCT / 100;
	int acc = 0;
	for (int b = 0; b < 181; b++) {
		acc += hist[b];
		if (acc >= target)
			return (float) b - 160.0f;
	}
	return 0.0f;
}

int scan_detect (const float *pdb, int n, double f0_hz, double df_hz,
		 float thr_db, signal_t *out, int maxout, float *pfloor)
{
	float floor = scan_noise_floor (pdb, n);
	float thr = floor + thr_db;
	if (pfloor) *pfloor = floor;

	int nsig = 0;
	int i = 0;
	while (i < n && nsig < maxout) {
		if (pdb[i] <= thr) { i++; continue; }

		/* debut d'un groupe : on avance tant qu'on reste au-dessus du seuil,
		   en tolerant un trou de GAP_BINS bins */
		int start = i, last = i, gap = 0;
		int peak = i;
		int j = i;
		while (j < n) {
			if (pdb[j] > thr) {
				last = j;
				gap = 0;
				if (pdb[j] > pdb[peak]) peak = j;
			} else if (++gap > GAP_BINS) {
				break;
			}
			j++;
		}

		signal_t *s = &out[nsig++];
		s->freq_hz = f0_hz + df_hz * peak;
		s->level_db = pdb[peak];
		s->snr_db = pdb[peak] - floor;
		s->bw_hz = df_hz * (last - start + 1);
		s->name[0] = 0;
		s->mod[0] = 0;
		s->service = 0;
		i = j;
	}

	/* tri par niveau decroissant (petit n : tri a bulles) */
	for (int a = 0; a < nsig; a++)
		for (int b = a + 1; b < nsig; b++)
			if (out[b].level_db > out[a].level_db) {
				signal_t t = out[a]; out[a] = out[b]; out[b] = t;
			}
	return nsig;
}
