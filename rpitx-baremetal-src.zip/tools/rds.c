/*
 * rds.c - decodeur RDS sur le multiplex FM (voir rds.h)
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Calcul en float (VFP du Pi 1). Chaine : melange a 57 kHz par la 3e harmonique
 * de la phase pilote -> passe-bas 4 poles + decimation -> correction de phase
 * BPSK (estimateur a l'ordre 2) -> integration par bit avec recalage d'horloge
 * (early-late) -> symboles biphase -> decodage differentiel -> synchro blocs par
 * mots d'offset et CRC (polynome 0x5B9) -> groupes 0 (PS) et 2 (RadioText).
 */
#include <math.h>
#include <string.h>
#include "rds.h"

#define PI_F		3.14159265f
#define SIN_BITS	11
#define SIN_SIZE	(1 << SIN_BITS)

static float s_sin[SIN_SIZE];
static int   s_ready;

static inline float tsin (uint32_t ph) { return s_sin[ph >> (32 - SIN_BITS)]; }
static inline float tcos (uint32_t ph) { return s_sin[(ph + 0x40000000u) >> (32 - SIN_BITS)]; }

/* atan2 rapide (erreur < 1e-5 rad), rend un angle en Q32 (2^32 = un tour) */
static inline uint32_t atan2_q32 (float y, float x)
{
	float ax = fabsf (x), ay = fabsf (y);
	float mx = ax > ay ? ax : ay, mn = ax > ay ? ay : ax;
	if (mx == 0.0f) return 0;
	float a = mn / mx, s = a * a;
	float r = ((-0.0464964749f * s + 0.15931422f) * s - 0.327622764f) * s * a + a;
	if (ay > ax) r = 1.57079637f - r;
	if (x < 0.0f) r = 3.14159265f - r;
	if (y < 0.0f) r = -r;
	return (uint32_t) (int32_t) (r * 683565275.6f);	/* rad -> Q32 */
}

/* --- deux biquattres passe-bas identiques (Butterworth 4 poles, fc ~2,4 kHz) --- */
static float B0, B1, B2, A1, A2;		/* coefficients communs aux 2 etages */

static void design_lpf (void)
{
	float fc = 2400.0f, fs = RDS_MPX_RATE;
	float w0 = 2.0f * PI_F * fc / fs;
	float c = cosf (w0), sn = sinf (w0);
	float q = 0.707f;			/* 2 etages a Q=0,707 : reponse douce */
	float alpha = sn / (2.0f * q);
	float a0 = 1.0f + alpha;
	B0 = (1.0f - c) * 0.5f / a0;
	B1 = (1.0f - c) / a0;
	B2 = (1.0f - c) * 0.5f / a0;
	A1 = (-2.0f * c) / a0;
	A2 = (1.0f - alpha) / a0;
}

/* biquad en forme directe II transposee ; st[0], st[1] = etat */
static inline float biquad (float x, float *st)
{
	float y = B0 * x + st[0];
	st[0] = B1 * x - A1 * y + st[1];
	st[1] = B2 * x - A2 * y;
	return y;
}

/* --- code de bloc RDS (26,16) : mot de controle --- */
static const uint16_t OFF_A = 0x0FC, OFF_B = 0x198, OFF_C = 0x168,
		      OFF_CP = 0x350, OFF_D = 0x1B4;

static uint16_t checkword (uint16_t info)
{
	uint32_t reg = (uint32_t) info << 10;	/* info * x^10 */
	for (int i = 25; i >= 10; i--)
		if (reg & (1u << i))
			reg ^= 0x5B9u << (i - 10);
	return (uint16_t) (reg & 0x3FF);
}

/* un bloc de 26 bits est-il valide pour ce mot d'offset ? */
static int blk_valid (uint32_t blk, uint16_t off)
{
	uint16_t info = (blk >> 10) & 0xFFFF;
	uint16_t chk = blk & 0x3FF;
	return ((checkword (info) ^ off) & 0x3FF) == chk;
}

void rds_init (rds_t *r)
{
	memset (r, 0, sizeof *r);
	if (!s_ready) {
		for (int i = 0; i < SIN_SIZE; i++)
			s_sin[i] = sinf (2.0f * PI_F * i / SIN_SIZE);
		s_ready = 1;
	}
	design_lpf ();
	r->pi = r->pty = r->tp = r->ta = -1;
	r->rt_ab = -1;
	strcpy (r->ps, "        ");
	memset (r->rt, ' ', 64); r->rt[64] = 0;
	memset (r->ps_tmp, ' ', 8);
	memset (r->rt_tmp, ' ', 64);
	r->have_prev_sym = 0;
	r->synced = 0;
	r->blk_idx = 0;
	r->theta_ct = 1.0f;
	r->theta_st = 0.0f;
}

/* --- assemblage des groupes --- */
static void decode_group (rds_t *r)
{
	if (!r->grp_ok[0] || !r->grp_ok[1])
		return;				/* il faut au moins A (PI) et B (type) */
	int pi = r->grp[0];
	int tp = (r->grp[1] >> 10) & 1;
	int pty = (r->grp[1] >> 5) & 0x1F;
	int gtype = (r->grp[1] >> 12) & 0xF;
	int ver = (r->grp[1] >> 11) & 1;
	r->pi = pi; r->tp = tp; r->pty = pty;
	r->groups++;

	if (gtype == 0) {			/* groupe 0 : nom de station (PS) */
		r->ta = (r->grp[1] >> 4) & 1;
		int seg = r->grp[1] & 0x3;
		if (r->grp_ok[3]) {
			r->ps_tmp[seg * 2]     = (char) ((r->grp[3] >> 8) & 0xFF);
			r->ps_tmp[seg * 2 + 1] = (char) (r->grp[3] & 0xFF);
			r->ps_seen[seg] = 1;
			if (r->ps_seen[0] && r->ps_seen[1] && r->ps_seen[2] && r->ps_seen[3]) {
				for (int i = 0; i < 8; i++) {
					char c = r->ps_tmp[i];
					r->ps[i] = (c >= 32 && c < 127) ? c : ' ';
				}
				r->ps[8] = 0;
				r->ps_ok = 1;
			}
		}
	} else if (gtype == 2) {		/* groupe 2 : RadioText */
		int ab = (r->grp[1] >> 4) & 1;
		int addr = r->grp[1] & 0xF;
		if (ab != r->rt_ab) {		/* changement de message -> on repart */
			r->rt_ab = ab;
			memset (r->rt_tmp, ' ', 64);
			memset (r->rt_seen, 0, sizeof r->rt_seen);
			r->rt_ok = 0;
		}
		if (ver == 0) {			/* 2A : 4 caracteres (blocs C et D) */
			if (r->grp_ok[2] && r->grp_ok[3]) {
				r->rt_tmp[addr * 4]     = (char) ((r->grp[2] >> 8) & 0xFF);
				r->rt_tmp[addr * 4 + 1] = (char) (r->grp[2] & 0xFF);
				r->rt_tmp[addr * 4 + 2] = (char) ((r->grp[3] >> 8) & 0xFF);
				r->rt_tmp[addr * 4 + 3] = (char) (r->grp[3] & 0xFF);
				r->rt_seen[addr] = 1;
			}
		} else {			/* 2B : 2 caracteres (bloc D) */
			if (r->grp_ok[3] && addr < 8) {
				r->rt_tmp[addr * 2]     = (char) ((r->grp[3] >> 8) & 0xFF);
				r->rt_tmp[addr * 2 + 1] = (char) (r->grp[3] & 0xFF);
				r->rt_seen[addr] = 1;
			}
		}
		/* message pret : tous les segments vus jusqu'a un retour chariot (0x0D) */
		int done = 1, n = 0;
		for (int i = 0; i < 16 && done; i++) {
			if (!r->rt_seen[i]) {
				/* accepte un message plus court termine par 0x0D deja place */
				break;
			}
			n = (i + 1) * 4;
		}
		(void) done;
		if (n > 0) {
			int end = n;
			for (int i = 0; i < n; i++)
				if (r->rt_tmp[i] == 0x0D) { end = i; break; }
			for (int i = 0; i < end; i++) {
				char c = r->rt_tmp[i];
				r->rt[i] = (c >= 32 && c < 127) ? c : ' ';
			}
			r->rt[end] = 0;
			if (end >= 1) r->rt_ok = 1;
		}
	}
}

/* un bit de donnees entre dans l'assembleur de blocs.
   Non synchronise : on cherche un bloc A valide (debut de groupe).
   Synchronise : on lit un bloc tous les 26 bits et on verifie le mot d'offset
   attendu selon la position (A,B,C,D) ; trop d'erreurs -> resynchro. */
static void push_bit (rds_t *r, int bit)
{
	r->bits++;
	r->reg = ((r->reg << 1) | (bit & 1)) & 0x3FFFFFF;	/* 26 bits */

	if (!r->synced) {
		if (blk_valid (r->reg, OFF_A)) {
			r->grp[0] = (r->reg >> 10) & 0xFFFF;
			r->grp_ok[0] = 1;
			r->grp_ok[1] = r->grp_ok[2] = r->grp_ok[3] = 0;
			r->synced = 1;
			r->blk_idx = 1;			/* prochain attendu : B */
			r->in_bits = 0;
			r->bad = 0;
			r->blocks_ok++;
		}
		return;
	}

	if (++r->in_bits < 26)
		return;
	r->in_bits = 0;

	int idx = r->blk_idx;
	uint16_t off = idx == 0 ? OFF_A : idx == 1 ? OFF_B : idx == 2 ? OFF_C : OFF_D;
	int ok = blk_valid (r->reg, off);
	if (!ok && idx == 2)
		ok = blk_valid (r->reg, OFF_CP);	/* bloc C' (groupe version B) */
	r->grp[idx] = (r->reg >> 10) & 0xFFFF;
	r->grp_ok[idx] = ok;
	if (ok) { r->blocks_ok++; r->bad = 0; }
	else if (++r->bad >= 8) { r->synced = 0; r->blk_idx = 0; return; }

	if (idx == 3) {
		decode_group (r);
		r->grp_ok[0] = r->grp_ok[1] = r->grp_ok[2] = r->grp_ok[3] = 0;
		r->blk_idx = 0;				/* prochain attendu : A */
	} else {
		r->blk_idx = idx + 1;
	}
}

void rds_feed (rds_t *r, float mpx, uint32_t pilot_phase)
{
	/* 0) cumul de l'avance du pilote / 16 (horloge symbole RDS = pilote / 16) ;
	   on divise chaque delta avant de cumuler pour ne pas deborder l'entier */
	if (r->have_prev_pilot)
		r->pilot_acc += (int32_t) (pilot_phase - r->prev_pilot) >> 4;
	r->prev_pilot = pilot_phase;
	r->have_prev_pilot = 1;

	/* 1) melange a 57 kHz = 3e harmonique de la phase pilote */
	uint32_t ref = pilot_phase * 3u;		/* Q32 : 3x la frequence */
	float ci = tcos (ref), si = tsin (ref);
	float mi = mpx * ci;
	float mq = -mpx * si;

	/* 2) passe-bas 4 poles sur I et Q */
	mi = biquad (biquad (mi, r->lp_i), r->lp_i + 2);
	mq = biquad (biquad (mq, r->lp_q), r->lp_q + 2);

	/* 3) decimation */
	if (++r->dec_cnt < RDS_DECIM)
		return;
	r->dec_cnt = 0;

	/* 4) estimation de phase BPSK (ordre 2) : angle de la moyenne de (I+jQ)^2.
	   La phase varie lentement : on ne recalcule l'angle que de temps en temps. */
	float e_re = mi * mi - mq * mq;
	float e_im = 2.0f * mi * mq;
	r->ph_re += (e_re - r->ph_re) * 0.001f;
	r->ph_im += (e_im - r->ph_im) * 0.001f;
	if (++r->theta_cnt >= 16) {
		r->theta_cnt = 0;
		uint32_t th = atan2_q32 (r->ph_im, r->ph_re) >> 1;	/* 0,5 x angle */
		r->theta_ct = tcos (th);
		r->theta_st = tsin (th);
	}
	float dI = mi * r->theta_ct + mq * r->theta_st;	/* bande de base reelle (BPSK) */

	/* 5) integration par bit (filtre adapte biphase : 1re moitie - 2e moitie).
	   On ajoute l'echantillon a la fenetre courante, puis on avance l'horloge
	   d'un pas = (avance pilote cumulee)/16 ; le debordement termine un bit. */
	uint32_t p = r->bit_phase;
	if (p >> 31) r->a2 += dI; else r->a1 += dI;	/* 1 : seconde moitie */

	uint32_t step = (uint32_t) r->pilot_acc;	/* deja divise par 16 */
	r->pilot_acc = 0;
	uint32_t np = p + step;
	r->bit_phase = np;
	if (np < p) {					/* debordement : fin d'un bit */
		float cp = r->a1 - r->a2;
		int sym = cp > 0.0f ? 1 : 0;
		r->a1 = r->a2 = 0.0f;
		/* 6) decodage differentiel : bit = sym XOR sym precedent */
		if (r->have_prev_sym)
			push_bit (r, sym ^ r->prev_sym);
		r->prev_sym = sym;
		r->have_prev_sym = 1;
	}
}
