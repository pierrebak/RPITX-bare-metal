/*
 * bandplan.c - plan de bandes (voir bandplan.h)
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Table ordonnee de plages [lo, hi] en MHz. Premiere plage contenant la
 * frequence gagne. Les noms de mode correspondent a mod_name() (AM, FM, BLU,
 * CW/OOK, FSK, NUM) pour la coherence avec le classifieur.
 */
#include "bandplan.h"

typedef struct {
	double lo, hi;		/* MHz */
	const char *service;
	const char *fixed;	/* mode impose, ou 0 */
	const char *allowed;	/* modes plausibles, ou 0 */
} band_t;

static const band_t BANDS[] = {
	/* grandes / petites ondes : porteuse AM permanente */
	{ 0.148, 0.283, "Grandes ondes",       "AM", 0 },
	{ 0.526, 1.606, "Petites ondes (AM)",  "AM", 0 },
	/* radioamateur HF (BLU/CW) */
	{ 1.810, 2.000, "Radioamateur 160m",   0, "BLU,CW/OOK" },
	{ 3.500, 3.800, "Radioamateur 80m",    0, "BLU,CW/OOK" },
	{ 5.351, 5.367, "Radioamateur 60m",    0, "BLU,CW/OOK" },
	{ 7.000, 7.200, "Radioamateur 40m",    0, "BLU,CW/OOK" },
	{ 10.100, 10.150, "Radioamateur 30m",  0, "CW/OOK" },
	{ 14.000, 14.350, "Radioamateur 20m",  0, "BLU,CW/OOK" },
	{ 18.068, 18.168, "Radioamateur 17m",  0, "BLU,CW/OOK" },
	{ 21.000, 21.450, "Radioamateur 15m",  0, "BLU,CW/OOK" },
	{ 24.890, 24.990, "Radioamateur 12m",  0, "BLU,CW/OOK" },
	{ 28.000, 29.700, "Radioamateur 10m",  0, "BLU,CW/OOK,FM" },
	/* diffusion FM */
	{ 87.5, 108.0, "FM broadcast",         "FM", 0 },
	/* aviation */
	{ 108.0, 137.0, "Aviation (airband)",  "AM", 0 },
	{ 137.0, 138.0, "Satellites meteo",    0, 0 },
	/* VHF */
	{ 144.0, 146.0, "Radioamateur 2m",     0, "BLU,CW/OOK,FM" },
	{ 156.0, 162.025, "Marine VHF / AIS",  "FM", 0 },
	{ 162.025, 174.0, "Mobile pro / PMR",  "FM", 0 },
	/* DAB+ / TV bande III */
	{ 174.0, 230.0, "DAB+ / TV III",       "NUM", 0 },
	/* UHF */
	{ 380.0, 400.0, "TETRA",               "NUM", 0 },
	{ 430.0, 433.05, "Radioamateur 70cm",  0, "BLU,CW/OOK,FM" },
	{ 433.05, 434.79, "ISM 433 (capteurs)", 0, "CW/OOK,FSK" },
	{ 434.79, 440.0, "Radioamateur 70cm",  0, "BLU,CW/OOK,FM" },
	{ 446.0, 446.2, "PMR446",              "FM", 0 },
	{ 470.0, 790.0, "TV TNT (DVB-T)",      "NUM", 0 },
	{ 791.0, 862.0, "LTE (telephonie)",    "NUM", 0 },
	{ 863.0, 870.0, "ISM 868 (capteurs)",  0, "FSK" },
	{ 880.0, 960.0, "GSM (telephonie)",    "NUM", 0 },
	{ 1090.0, 1090.1, "ADS-B (avions)",    0, 0 },
};

band_info_t bandplan_lookup (double freq_hz)
{
	double mhz = freq_hz / 1e6;
	band_info_t r = { 0, 0, 0 };
	for (unsigned i = 0; i < sizeof BANDS / sizeof BANDS[0]; i++)
		if (mhz >= BANDS[i].lo && mhz < BANDS[i].hi) {
			r.service = BANDS[i].service;
			r.fixed_mode = BANDS[i].fixed;
			r.allowed = BANDS[i].allowed;
			return r;
		}
	return r;				/* hors plan : service=0 */
}
