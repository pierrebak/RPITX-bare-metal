/*
 * fmrx_dsp.c - demodulateur FM large bande (radiodiffusion), mono ou stereo
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Voir fmrx_dsp.h. Calcul en float simple precision (VFP du Pi 1) ; filtres concus par
 * tools/gen_fmrx_taps.py (Remez) : demi-bandes 74 et 81 dB, audio 87 et 91 dB, pilote
 * attenue de 93 dB avant le passage a 32 kHz.
 */
#include <math.h>
#include <string.h>
#include "fmrx_dsp.h"
#include "fmrx_taps.h"

#define PI_F		3.14159265f
#define FMRX_MID_RATE	64000
#define PILOT_HZ	19000.0f
#define SIN_BITS	10
#define SIN_SIZE	(1 << SIN_BITS)

static float s_sin[SIN_SIZE];
static int   s_sin_ready;

/* filtre de Hilbert (BLU) : antisymetrique, prises paires nulles, fenetre de Hamming */
static float s_hilb[FMRX_HILB_N];
static int   s_hilb_ready;

/* filtres de canal audio (symetriques, fenetre de Hamming), concus a 32 kHz :
   BLU = passe-bande 300-2800 Hz (une bande laterale), AM = passe-bas 4500 Hz */
static float s_aud_ssb[FMRX_AUD_N];
static float s_aud_am[FMRX_AUD_N];
static int   s_aud_ready;

/* reponse d'un passe-bas a coupure fc (Hz) : 2 fcn sinc (2 fcn m), a 32 kHz */
static float sinc_lp (int m, float fc)
{
	float fcn = fc / FMRX_OUT_RATE;
	if (m == 0)
		return 2.0f * fcn;
	float x = 2.0f * fcn * m;
	return 2.0f * fcn * sinf (PI_F * x) / (PI_F * x);
}

static inline float tsin (uint32_t ph) { return s_sin[ph >> (32 - SIN_BITS)]; }
static inline float tcos (uint32_t ph) { return s_sin[(ph + 0x40000000u) >> (32 - SIN_BITS)]; }

/* atan2 rapide : erreur < 1e-5 rad (polynome de degre 7 sur [0, 1]) */
static inline float fast_atan2 (float y, float x)
{
	float ax = fabsf (x), ay = fabsf (y);
	float mx = ax > ay ? ax : ay, mn = ax > ay ? ay : ax;
	if (mx == 0.0f)
		return 0.0f;
	float a = mn / mx, s = a * a;
	float r = ((-0.0464964749f * s + 0.15931422f) * s - 0.327622764f) * s * a + a;
	if (ay > ax) r = 1.57079637f - r;
	if (x < 0.0f) r = PI_F - r;
	if (y < 0.0f) r = -r;
	return r;
}

/* ligne a retard doublee de paires (I/Q ou M/S) : la fenetre des n dernieres paires est
   toujours contigue, d[2 pos] la plus ancienne ... d[2 (pos + n - 1)] la plus recente */
static inline const float *push_pair (float *d, int *pos, int n, float a, float b)
{
	int p = *pos;
	d[2 * p] = d[2 * (p + n)] = a;
	d[2 * p + 1] = d[2 * (p + n) + 1] = b;
	p = p + 1 == n ? 0 : p + 1;
	*pos = p;
	return &d[2 * p];
}

/* petit anneau de paires : renvoie la plus ancienne apres ajout (retard r - 1) */
static inline void ring_pair (float *d, int *pos, int r, float *a, float *b)
{
	int p = *pos;
	d[2 * p] = *a;
	d[2 * p + 1] = *b;
	p = p + 1 == r ? 0 : p + 1;
	*pos = p;
	*a = d[2 * p];
	*b = d[2 * p + 1];
}

/* demi-bande, partie impaire, sur des paires : sum h[2k] (w[k] + w[L-1-k]) pour les L
   echantillons d'indice impair (les prises d'indice impair du filtre sont nulles) ;
   deux accumulateurs par voie (latence des multiplications de la VFP) */
#define HB_SUM(w, h, L, ya, yb) do {						\
	float a0 = 0.0f, a1 = 0.0f, b0 = 0.0f, b1 = 0.0f;			\
	_Pragma ("GCC unroll 12")						\
	for (int k = 0; k < (L) / 2; k += 2) {					\
		float c0 = (h)[2 * k];						\
		a0 += c0 * ((w)[2 * k] + (w)[2 * ((L) - 1 - k)]);		\
		b0 += c0 * ((w)[2 * k + 1] + (w)[2 * ((L) - 1 - k) + 1]);	\
		if (k + 1 < (L) / 2) {						\
			float c1 = (h)[2 * k + 2];				\
			a1 += c1 * ((w)[2 * k + 2] + (w)[2 * ((L) - 2 - k)]);	\
			b1 += c1 * ((w)[2 * k + 3] + (w)[2 * ((L) - 2 - k) + 1]);\
		}							\
	}								\
	ya = a0 + a1;								\
	yb = b0 + b1;								\
} while (0)

/* filtre symetrique de longueur impaire n sur des paires (M/S) */
#define SYM_SUM2(w, h, n, ya, yb) do {						\
	float a0 = (h)[(n) / 2] * (w)[2 * ((n) / 2)], a1 = 0.0f;		\
	float b0 = (h)[(n) / 2] * (w)[2 * ((n) / 2) + 1], b1 = 0.0f;		\
	_Pragma ("GCC unroll 4")						\
	for (int k = 0; k + 1 < (n) / 2; k += 2) {				\
		a0 += (h)[k] * ((w)[2 * k] + (w)[2 * ((n) - 1 - k)]);		\
		b0 += (h)[k] * ((w)[2 * k + 1] + (w)[2 * ((n) - 1 - k) + 1]);	\
		a1 += (h)[k + 1] * ((w)[2 * k + 2] + (w)[2 * ((n) - 2 - k)]);	\
		b1 += (h)[k + 1] * ((w)[2 * k + 3] + (w)[2 * ((n) - 2 - k) + 1]);\
	}								\
	if (((n) / 2) & 1) {							\
		int k = (n) / 2 - 1;						\
		a0 += (h)[k] * ((w)[2 * k] + (w)[2 * ((n) - 1 - k)]);		\
		b0 += (h)[k] * ((w)[2 * k + 1] + (w)[2 * ((n) - 1 - k) + 1]);	\
	}								\
	ya = a0 + a1;								\
	yb = b0 + b1;								\
} while (0)

/* meme chose, voie M seulement (mono) */
#define SYM_SUM1(w, h, n, ya) do {						\
	float a0 = (h)[(n) / 2] * (w)[2 * ((n) / 2)], a1 = 0.0f;		\
	_Pragma ("GCC unroll 4")						\
	for (int k = 0; k + 1 < (n) / 2; k += 2) {				\
		a0 += (h)[k] * ((w)[2 * k] + (w)[2 * ((n) - 1 - k)]);		\
		a1 += (h)[k + 1] * ((w)[2 * k + 2] + (w)[2 * ((n) - 2 - k)]);	\
	}								\
	if (((n) / 2) & 1) {							\
		int k = (n) / 2 - 1;						\
		a0 += (h)[k] * ((w)[2 * k] + (w)[2 * ((n) - 1 - k)]);		\
	}								\
	ya = a0 + a1;								\
} while (0)

void fmrx_set_deemphasis (fmrx_t *f, float us)
{
	/* filtre du premier ordre a 64 kHz (a 32 kHz, trop pres de la frequence de Nyquist,
	   il s'ecarterait de 1,4 dB a 10 kHz) : y += a (x - y), a = 1 - exp (-T / tau) */
	f->deemph_alpha = us > 0.0f ? 1.0f - expf (-1.0f / (FMRX_MID_RATE * us * 1e-6f)) : 1.0f;
}

void fmrx_init (fmrx_t *f)
{
	memset (f, 0, sizeof *f);
	if (!s_sin_ready) {
		for (int i = 0; i < SIN_SIZE; i++)
			s_sin[i] = sinf (2.0f * PI_F * i / SIN_SIZE);
		s_sin_ready = 1;
	}
	if (!s_hilb_ready) {
		int M = FMRX_HILB_N / 2;		/* retard de groupe */
		for (int n = 0; n < FMRX_HILB_N; n++) {
			int m = n - M;
			float win = 0.54f - 0.46f * cosf (2.0f * PI_F * n / (FMRX_HILB_N - 1));
			s_hilb[n] = (m == 0 || (m & 1) == 0) ? 0.0f : (2.0f / (PI_F * m)) * win;
		}
		s_hilb_ready = 1;
	}
	if (!s_aud_ready) {
		int M = FMRX_AUD_N / 2;
		for (int n = 0; n < FMRX_AUD_N; n++) {
			int m = n - M;
			float win = 0.54f - 0.46f * cosf (2.0f * PI_F * n / (FMRX_AUD_N - 1));
			s_aud_ssb[n] = (sinc_lp (m, 2800.0f) - sinc_lp (m, 300.0f)) * win;
			s_aud_am[n]  = sinc_lp (m, 4500.0f) * win;
		}
		s_aud_ready = 1;
	}
	for (int i = 0; i < 256; i++)
		f->lut[i] = (i - 127.4f) / 128.0f;
	f->stereo_enable = 1;
	f->volume = 0.7f;
	f->level_dbfs = -100.0f;
	f->rds_enable = 1;
	rds_init (&f->rds);
	fmrx_set_deemphasis (f, 50.0f);
}

/* boucle a verrouillage de phase sur le pilote (phase en Q32 : 2^32 = un tour) ;
   frequence propre 8 Hz, amortissement 0,7, pour un pilote a 9 % de l'excursion : assez
   etroite pour que le son ne fasse pas trembler la phase (separation), verrouillage en
   ~0,1 s (le pilote est a 19 kHz exactement, a 1 ppm pres) */
#define PLL_STEP0	((uint32_t) (PILOT_HZ / FMRX_MPX_RATE * 4294967296.0))
#define RAD_TO_Q32	683565275.6f			/* 2^32 / (2 pi) */
#define PLL_KD		0.045f				/* gain du comparateur (pilote / 2) */
#define PLL_WNT		(2.0f * PI_F * 8.0f / FMRX_MPX_RATE)
#define PLL_KP		(2.0f * 0.707f * PLL_WNT / PLL_KD * RAD_TO_Q32)
#define PLL_KI		(PLL_WNT * PLL_WNT / PLL_KD * RAD_TO_Q32)
#define PILOT_LP	(1.0f / (0.05f * FMRX_MPX_RATE))	/* detecteur : 50 ms */
#define STEREO_ON	0.025f				/* amplitude / 2 : nominal 0,045 */
#define STEREO_OFF	0.015f
#define AM_DC_ALPHA	0.004f				/* AM : retrait porteuse ~20 Hz a 32 kHz */
#define AM_GAIN		4.0f				/* AM : niveau (reglable par le volume) */
#define SSB_GAIN	6.0f				/* BLU : niveau (reglable par le volume) */

/* demi-bande 1 : nouvel echantillon pair e puis impair o -> une sortie a 512 kS/s */
static inline void hb1_step (fmrx_t *f, float ei, float eq, float oi, float oq, float *yi, float *yq)
{
	ring_pair (f->hb1_e, &f->hb1_epos, FMRX_HB1_L / 2, &ei, &eq);
	const float *w = push_pair (f->hb1_o, &f->hb1_pos, FMRX_HB1_L, oi, oq);
	float si, sq;
	HB_SUM (w, HB1_TAPS, FMRX_HB1_L, si, sq);
	*yi = si + 0.5f * ei;
	*yq = sq + 0.5f * eq;
}

static int fmrx_block (fmrx_t *f, const uint8_t *in, int n_bytes, int16_t *out_lr,
		       int max_frames, unsigned *pclip, unsigned *ppow)
{
	const float mpx_gain = FMRX_MPX_RATE / (2.0f * PI_F * FMRX_DEVIATION);
	const float *lut = f->lut;
	int frames = 0;
	unsigned clip = 0, pw = 0;

	/* 4 echantillons (8 octets) par tour : la permutation j^n (station ramenee de -Fs/4
	   a 0) est fixe, et chaque tour donne un echantillon a 256 kS/s */
	for (int b = 0; b + 7 < n_bytes; b += 8) {
		const uint8_t *p = in + b;
		/* mesures sur un echantillon sur deux (assez pour l'AGC), en entiers */
		for (int k = 0; k < 8; k += 4) {
			int di = p[k] - 127, dq = p[k + 1] - 127;
			pw += (unsigned) (di * di + dq * dq);
			clip += ((unsigned) (p[k] - 1) >= 254u) + ((unsigned) (p[k + 1] - 1) >= 254u);
		}
		/* x0 = z0, x1 = j z1, x2 = -z2, x3 = -j z3 */
		float y0i, y0q, y1i, y1q;
		hb1_step (f, lut[p[0]], lut[p[1]], -lut[p[3]], lut[p[2]], &y0i, &y0q);
		hb1_step (f, -lut[p[4]], -lut[p[5]], lut[p[7]], -lut[p[6]], &y1i, &y1q);

		/* demi-bande 2 : y0 indice pair, y1 indice impair -> 256 kS/s */
		ring_pair (f->hb2_e, &f->hb2_epos, FMRX_HB2_D, &y0i, &y0q);
		const float *w = push_pair (f->hb2_o, &f->hb2_pos, FMRX_HB2_L, y1i, y1q);
		float i, q;
		HB_SUM (w, HB2_TAPS, FMRX_HB2_L, i, q);
		i += 0.5f * y0i;
		q += 0.5f * y0q;

		/* --- AM / BLU : la station est centree sur 0 Hz ; on demodule en bande de
		   base, sans discriminateur. Les memes filtres de decimation que la FM
		   traitent la paire I,Q comme une paire M,S : passe-bas complexe 256 k -> 32 k. */
		if (f->mode != FMRX_MODE_FM) {
			const float *wc = push_pair (f->a1, &f->a1_pos, FMRX_A1_N, i, q);
			if (++f->a1_ph < 4)
				continue;
			f->a1_ph = 0;
			float ci, cq;
			SYM_SUM2 (wc, A1_TAPS, FMRX_A1_N, ci, cq);
			wc = push_pair (f->a2, &f->a2_pos, FMRX_A2_N, ci, cq);
			if ((f->a2_ph ^= 1) != 0)
				continue;
			SYM_SUM2 (wc, A2_TAPS, FMRX_A2_N, ci, cq);
			float audio;
			float gain;
			if (f->mode == FMRX_MODE_AM) {
				float env = sqrtf (ci * ci + cq * cq);
				f->am_dc += (env - f->am_dc) * AM_DC_ALPHA;
				audio = env - f->am_dc;
				gain = AM_GAIN;
			} else {
				/* BLU par dephasage : garde une seule bande laterale.
				   USB = I - H(Q), LSB = I + H(Q) ; I retarde du groupe du Hilbert. */
				const float *wh = push_pair (f->hil, &f->hil_pos, FMRX_HILB_N, ci, cq);
				float hq = 0.0f;
				for (int t = 0; t < FMRX_HILB_N; t++)	/* 1 prise sur 2 est nulle */
					hq += s_hilb[t] * wh[2 * t + 1];
				float di = wh[2 * (FMRX_HILB_N / 2)];
				audio = f->mode == FMRX_MODE_USB ? di - hq : di + hq;
				gain = SSB_GAIN;
			}
			/* filtre de canal : resserre la bande (BLU ~2,5 kHz, AM ~4,5 kHz) */
			const float *wa = push_pair (f->aud, &f->aud_pos, FMRX_AUD_N, audio, 0.0f);
			float af;
			SYM_SUM1 (wa, f->mode == FMRX_MODE_AM ? s_aud_am : s_aud_ssb, FMRX_AUD_N, af);
			float v = af * f->volume * gain;
			if (fabsf (v) > f->peak_acc) f->peak_acc = fabsf (v);
			if (frames < max_frames) {
				int iv = (int) (v * 32767.0f);
				if (iv > 32767) iv = 32767; else if (iv < -32767) iv = -32767;
				out_lr[2 * frames] = out_lr[2 * frames + 1] = (int16_t) iv;
				frames++;
			}
			continue;
		}

		/* discriminateur : angle de z[n] * conj (z[n-1]) */
		float re = i * f->prev_i + q * f->prev_q;
		float im = q * f->prev_i - i * f->prev_q;
		f->prev_i = i;
		f->prev_q = q;
		float mpx = fast_atan2 (im, re) * mpx_gain;

		/* pilote : pilote = A sin (phase) ; erreur = mpx cos (phase) ~ A/2 sin (ecart) */
		uint32_t ph = f->pll_phase;
		float err = mpx * tcos (ph);
		f->pll_integ += PLL_KI * err;
		float adj = f->pll_integ + PLL_KP * err;
		f->pll_phase = ph + PLL_STEP0 + (uint32_t) (int32_t) adj;
		f->pilot_lp += (mpx * tsin (ph) - f->pilot_lp) * PILOT_LP;

		/* RDS : sous-porteuse a 57 kHz (3e harmonique du pilote), sur le MPX brut ;
		   seulement si un pilote est present (sinon pas de RDS, on epargne le CPU) */
		if (f->rds_enable && f->pilot_lp > 0.01f)
			rds_feed (&f->rds, mpx, ph);

		/* L-R : sous-porteuse sin (2 phase), demodulee par 2 sin (2 phase) */
		float s = f->stereo ? mpx * 2.0f * tsin (ph << 1) : 0.0f;

		/* 256 k -> 64 k */
		w = push_pair (f->a1, &f->a1_pos, FMRX_A1_N, mpx, s);
		if (++f->a1_ph < 4)
			continue;
		f->a1_ph = 0;
		float m;
		if (f->stereo)
			SYM_SUM2 (w, A1_TAPS, FMRX_A1_N, m, s);
		else {
			SYM_SUM1 (w, A1_TAPS, FMRX_A1_N, m);
			s = 0.0f;
		}
		/* desaccentuation de M et S (lineaire : identique a celle de L et R) */
		f->de_l += (m - f->de_l) * f->deemph_alpha;
		f->de_r += (s - f->de_r) * f->deemph_alpha;

		/* 64 k -> 32 k */
		w = push_pair (f->a2, &f->a2_pos, FMRX_A2_N, f->de_l, f->de_r);
		if ((f->a2_ph ^= 1) != 0)
			continue;
		if (f->stereo)
			SYM_SUM2 (w, A2_TAPS, FMRX_A2_N, m, s);
		else {
			SYM_SUM1 (w, A2_TAPS, FMRX_A2_N, m);
			s = 0.0f;
		}

		/* matrice : le multiplex porte 0,9 (L+R)/2 et 0,9 (L-R)/2 */
		float vl = (m + s) * f->volume, vr = (m - s) * f->volume;
		float pk = fabsf (vl) > fabsf (vr) ? fabsf (vl) : fabsf (vr);
		if (pk > f->peak_acc) f->peak_acc = pk;
		if (frames < max_frames) {
			int il = (int) (vl * 32767.0f), ir = (int) (vr * 32767.0f);
			out_lr[2 * frames]     = (int16_t) (il > 32767 ? 32767 : il < -32767 ? -32767 : il);
			out_lr[2 * frames + 1] = (int16_t) (ir > 32767 ? 32767 : ir < -32767 ? -32767 : ir);
			frames++;
		}
	}
	*pclip += clip;
	*ppow += pw;
	return frames;
}

int fmrx_process (fmrx_t *f, const uint8_t *in, int n_bytes, int16_t *out_lr, int max_frames)
{
	const int stereo_ok = f->stereo_enable;
	unsigned clip = 0, pw = 0;
	int frames = 0, n_meas = n_bytes;

	/* fin d'un appel precedent non multiple de 8 octets */
	if (f->npend > 0) {
		while (f->npend < 8 && n_bytes > 0) {
			f->pend[f->npend++] = *in++;
			n_bytes--;
		}
		if (f->npend < 8)
			return 0;
		frames += fmrx_block (f, f->pend, 8, out_lr, max_frames, &clip, &pw);
		f->npend = 0;
	}
	int whole = n_bytes & ~7;
	frames += fmrx_block (f, in, whole, out_lr + 2 * frames, max_frames - frames, &clip, &pw);
	for (int k = whole; k < n_bytes; k++)
		f->pend[f->npend++] = in[k];

	/* mesures (sur un echantillon sur deux) */
	int n = n_meas / 4;
	if (n > 0) {
		float p = (float) pw / (128.0f * 128.0f) / n;
		f->level_dbfs = 10.0f * log10f (p > 1e-10f ? p : 1e-10f);
		f->clip_ratio = (float) clip / (2 * n);
	}
	f->pilot_level = 2.0f * f->pilot_lp;
	if (!stereo_ok)
		f->stereo = 0;
	else if (!f->stereo && f->pilot_lp > STEREO_ON)
		f->stereo = 1;
	else if (f->stereo && f->pilot_lp < STEREO_OFF)
		f->stereo = 0;
	if (++f->peak_n >= 8) {
		f->audio_peak = f->peak_acc;
		f->peak_acc *= 0.5f;
		f->peak_n = 0;
	}
	return frames;
}
