#!/usr/bin/env python3
"""Filtres du recepteur FM (tools/fmrx_dsp.c) -> tools/fmrx_taps.h
   1 024 kS/s --HB1/2--> 512 kS/s --HB2/2--> 256 kS/s (discriminateur, stereo)
   --A1/4--> 64 kS/s --A2/2--> 32 kS/s (audio)"""
import sys
import numpy as np
from scipy import signal

def report(name, h, fs, passband, stopband):
    w, H = signal.freqz(h, worN=8192, fs=fs)
    a = 20 * np.log10(np.abs(H) + 1e-12)
    pb = a[(w <= passband)]
    sb = a[(w >= stopband)]
    sys.stderr.write(f"{name}: {len(h)} taps ({np.count_nonzero(np.abs(h) > 1e-9)} non nuls), "
                     f"ondulation {pb.max() - pb.min():.3f} dB jusqu'a {passband/1e3:.0f} kHz, "
                     f"rejection {-sb.max():.1f} dB des {stopband/1e3:.1f} kHz\n")

def halfband(n, fpass, fs):
    """demi-bande equiripple : bandes symetriques autour de fs/4, une prise sur deux nulle"""
    h = signal.remez(n, [0, fpass, fs / 2 - fpass, fs / 2], [1, 0], fs=fs, maxiter=200)
    c = n // 2
    for k in range(n):
        if (k - c) % 2 == 0 and k != c:
            h[k] = 0.0
    h[c] = 0.5
    return h / h.sum()

hb1 = halfband(15, 125e3, 1024e3)   # 1024 -> 512 k : rien a replier sous 125 kHz
hb2 = halfband(43, 100e3, 512e3)    # 512 -> 256 k : voisines (>= 156 kHz) eliminees
a1 = signal.remez(39, [0, 16e3, 47e3, 128e3], [1, 0], weight=[1, 10], fs=256e3)    # 256 -> 64 k
a2 = signal.remez(127, [0, 15e3, 17.2e3, 32e3], [1, 0], weight=[1, 30], fs=64e3)   # 64 -> 32 k

report("HB1", hb1, 1024e3, 120e3, 392e3)
report("HB2", hb2, 512e3, 100e3, 156e3)
report("A1", a1, 256e3, 15e3, 49e3)
report("A2", a2, 64e3, 15e3, 17.2e3)
w, H = signal.freqz(a2, worN=[19e3, 23e3], fs=64e3)
sys.stderr.write("A2 a 19 kHz (pilote) %.1f dB, 23 kHz %.1f dB\n" % tuple(20*np.log10(np.abs(H))))

def emit(name, h):
    out = [f"static const float {name}[{len(h)}] = {{"]
    for i in range(0, len(h), 6):
        out.append("    " + ", ".join(f"{v: .9e}f" for v in h[i:i+6]) + ",")
    out.append("};")
    return "\n".join(out)

print("/* genere par tools/gen_fmrx_taps.py - ne pas modifier */")
for n, h in (("HB1_TAPS", hb1), ("HB2_TAPS", hb2), ("A1_TAPS", a1), ("A2_TAPS", a2)):
    print(emit(n, h))
