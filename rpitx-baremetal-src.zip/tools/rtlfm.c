/*
 * rtlfm.c - recepteur FM (radiodiffusion, stereo) avec une cle RTL-SDR, son
 *           sur la prise jack 3,5 mm (PWM) ou en HDMI
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Reglages de la cle (choisis pour la RTL-SDR Blog V4, valables pour les autres) :
 *  - 1 024 kS/s : bien plus que les ~200 kHz d'une station, assez pour filtrer
 *    proprement les voisines, et la moitie de 2 048 kS/s (debit verifie sur le
 *    materiel avec la file USB a une requete) : de la marge pour l'USB et le CPU ;
 *  - accord 256 kHz (Fs/4) au-dessus de la station : la raie continue et le bruit
 *    en 1/f du recepteur tombent hors du canal, le retour a 0 Hz est une
 *    permutation de I/Q ;
 *  - AGC numerique du RTL2832 coupe, gain du tuner manuel pilote par un AGC
 *    logiciel (niveau d'entree vise -12 dBFS, sans saturation des 8 bits) : RTL-SDR
 *    Blog conseille de ne pas utiliser l'AGC de FI sur la V4 ;
 *  - correction 0 ppm (la V4 a un TCXO a 1 ppm : 100 Hz d'erreur a 100 MHz, sans
 *    effet en FM large bande) ; -P pour les autres cles ;
 *  - bias-tee coupe, pas d'echantillonnage direct (la V4 couvre la HF par
 *    conversion, inutile ici) ; les filtres coupe-bande FM de la V4 sont coupes
 *    par le pilote entre 85 et 112 MHz, dans la bande FM.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>
#include <bm_compat.h>
#include "rtl-sdr.h"
#include "rtl-sdr-bm.h"
#include "convenience/convenience.h"
#include "rtldsp.h"
#include "fmrx_dsp.h"

#define USB_BUF_NUM		8
#define USB_BUF_LEN		16384		/* 8 ms a 1 024 kS/s */
#define RING_PAIRS		FMRX_OUT_RATE	/* 1 s de son */
#define AUDIO_QUEUE_MS		120
#define TARGET_FILL_S		0.08		/* son en attente dans l'anneau */
#define AGC_PERIOD_US		300000
#define AGC_TARGET_DB		-12.0f
#define STATUS_PERIOD_US	1000000

static rtlsdr_dev_t *s_dev;
static fmrx_t *s_fm;
static int16_t *s_ring;
static unsigned s_head, s_tail;
static unsigned s_overruns;
static int16_t s_tmp[2 * (USB_BUF_LEN / 64 + 8)];

/* mesures accumulees entre deux passages de l'AGC */
static double s_pow_acc;
static unsigned s_pow_n;
static float s_clip_max;
static uint64_t s_dsp_us;			/* temps passe dans le demodulateur */
static uint64_t s_bytes;

static void rtl_callback (unsigned char *buf, uint32_t len, void *ctx)
{
	(void) ctx;
	uint64_t t0 = bm_micros ();
	int n = fmrx_process (s_fm, buf, (int) len, s_tmp, sizeof s_tmp / sizeof s_tmp[0] / 2);
	s_dsp_us += bm_micros () - t0;
	s_bytes += len;
	s_pow_acc += pow (10.0, s_fm->level_dbfs / 10.0);
	s_pow_n++;
	if (s_fm->clip_ratio > s_clip_max)
		s_clip_max = s_fm->clip_ratio;
	for (int k = 0; k < n; k++) {
		if (s_head - s_tail >= RING_PAIRS) {	/* plein : on jette le plus ancien */
			s_tail++;
			s_overruns++;
		}
		unsigned w = s_head % RING_PAIRS;
		s_ring[2 * w] = s_tmp[2 * k];
		s_ring[2 * w + 1] = s_tmp[2 * k + 1];
		s_head++;
	}
}

/* rtlfm -B : mesure du temps de calcul du demodulateur seul (1 s de signal
   synthetique : station stereo, bruit), sans cle ni son */
static int bench (void)
{
	uint8_t *buf = malloc (USB_BUF_LEN);
	if (buf == NULL)
		return 1;
	uint32_t seed = 1;
	double ph = 0, pp = 0;
	for (int k = 0; k < USB_BUF_LEN / 2; k++) {
		/* MPX : 1 kHz + pilote, station a -Fs/4 (comme accordee par rtlfm) */
		double t = k / (double) FMRX_IN_RATE;
		double mpx = 0.8 * sin (2 * M_PI * 1000 * t) + 0.1 * sin (2 * M_PI * 19000 * t);
		ph += 2 * M_PI * 75000 * mpx / FMRX_IN_RATE;
		pp += -M_PI / 2;
		seed = seed * 1103515245u + 12345u;
		float n = ((seed >> 16) & 0xFF) / 255.0f - 0.5f;
		buf[2 * k] = (uint8_t) (127.5 + 40 * cos (ph + pp) + 8 * n);
		buf[2 * k + 1] = (uint8_t) (127.5 + 40 * sin (ph + pp) - 8 * n);
	}
	fmrx_init (s_fm);
	int frames = 0;
	unsigned blocks = 2 * FMRX_IN_RATE / USB_BUF_LEN;	/* 1 s */
	uint64_t t0 = bm_micros ();
	for (unsigned b = 0; b < blocks; b++)
		frames += fmrx_process (s_fm, buf, USB_BUF_LEN, s_tmp, sizeof s_tmp / sizeof s_tmp[0] / 2);
	uint64_t dt = bm_micros () - t0;
	printf ("Demodulateur : %u ms de calcul pour 1 s de signal (%u %% du CPU), %d trames, "
		"pilote %.1f %%, stereo %d\n", (unsigned) (dt / 1000), (unsigned) (dt / 10000),
		frames, s_fm->pilot_level * 100, s_fm->stereo);
	free (buf);
	return 0;
}

/* Ctrl-C / Echap : sans gestionnaire, l'arret par defaut (exit) partirait de
   bm_poll (), appele au milieu du traitement des transferts USB par
   rtlsdr_poll_async () : l'arret de la cle bloquait ensuite. On leve un drapeau
   et la boucle principale sort normalement. */
static volatile int s_quit;
static void on_sigint (int sig)
{
	(void) sig;
	s_quit = 1;
}

/* rtlfm -T [-o hdmi] : essai de la sortie son seule, sans cle : 1 kHz a gauche, puis a
   droite, puis des deux cotes, 2 s chacun ; affiche le debit reellement joue */
static int tone_test (int hdmi)
{
	if (bm_audio_open (FMRX_OUT_RATE, hdmi, AUDIO_QUEUE_MS) < 0) {
		fprintf (stderr, "Sortie son %s indisponible\n", hdmi ? "HDMI" : "jack");
		return 1;
	}
	printf ("Essai du son (%s) : 1 kHz a gauche, a droite, puis des deux cotes\n",
		hdmi ? "HDMI" : "jack 3,5 mm");
	static const char *side[] = {"gauche", "droite", "les deux"};
	int16_t buf[2 * 256];
	uint32_t ph = 0, n_total = 0;
	uint64_t t0 = bm_micros ();
	for (int part = 0; part < 3 && !s_quit; part++) {
		printf ("  %s...\n", side[part]);
		uint32_t n_part = 0;
		while (n_part < 2 * FMRX_OUT_RATE && !s_quit) {
			unsigned space = bm_audio_space ();
			if (space > 256) space = 256;
			for (unsigned k = 0; k < space; k++) {
				int16_t v = (int16_t) (12000.0f * sinf (2.0f * (float) M_PI * ph / 32.0f));
				ph = (ph + 1) & 31;			/* 1 kHz a 32 kHz */
				buf[2 * k] = part != 1 ? v : 0;
				buf[2 * k + 1] = part != 0 ? v : 0;
			}
			if (space > 0)
				space = bm_audio_write (buf, space);
			n_part += space;
			bm_poll ();
		}
		n_total += n_part;
	}
	char info[200];
	bm_audio_info (info, sizeof info);
	printf ("%s\n", info);
	uint64_t dt = bm_micros () - t0;
	unsigned played = n_total - bm_audio_queued ();
	printf ("Joue : %u trames en %u ms, soit %.0f Hz (attendu %u)%s\n", played,
		(unsigned) (dt / 1000), dt > 0 ? played * 1e6 / dt : 0.0, FMRX_OUT_RATE,
		played < FMRX_OUT_RATE / 2 ? " : LA SORTIE SON NE TOURNE PAS" : "");
	return 0;
}

static void cleanup (void)
{
	if (s_dev) {
		rtlsdr_stop_async (s_dev);
		rtlsdr_close (s_dev);
		s_dev = NULL;
	}
	bm_audio_close ();
	printf ("\n");
}

static void usage (void)
{
	fprintf (stderr,
		"rtlfm, recepteur FM (radiodiffusion) RTL-SDR, son jack ou HDMI\n\n"
		"Usage: rtlfm -f MHz [options]\n"
		"\t-f MHz        frequence de la station (ex. 105.1)\n"
		"\t[-g dB]       gain fixe du tuner (defaut : AGC logiciel)\n"
		"\t[-o sortie]   jack (defaut) ou hdmi\n"
		"\t[-m]          mono\n"
		"\t[-M mode]     fm (defaut), am, usb, lsb\n"
		"\t[-e us]       desaccentuation 50 (Europe, defaut) ou 75 (Ameriques)\n"
		"\t[-v vol]      volume 0..4 (defaut 1)\n"
		"\t[-P ppm]      correction de frequence (defaut 0 : V4 a TCXO)\n"
		"\t[-d index]    numero de la cle (defaut 0)\n"
		"\t[-B]          mesure le temps de calcul du demodulateur et quitte\n"
		"\t[-T]          essai de la sortie son seule (1 kHz), sans cle\n"
		"Touches : fleches gauche/droite +-0,1 MHz, haut/bas +-1 MHz,\n"
		"          + - volume, m muet, s stereo/mono, g G gain, a AGC auto,\n"
		"          Echap ou Ctrl-C quitte.\n");
	exit (1);
}

static int s_gains[64];
static int s_ngains;
static int s_gain_idx;
static int s_agc = 1;

static void set_gain_idx (int idx)
{
	if (idx < 0) idx = 0;
	if (idx >= s_ngains) idx = s_ngains - 1;
	s_gain_idx = idx;
	rtlsdr_set_tuner_gain (s_dev, s_gains[idx]);
}

static int nearest_gain_idx (int tenths)
{
	int best = 0;
	for (int i = 1; i < s_ngains; i++)
		if (abs (s_gains[i] - tenths) < abs (s_gains[best] - tenths))
			best = i;
	return best;
}

static uint32_t s_freq;

static void tune (uint32_t freq)
{
	if (freq < 100000) freq = 100000;	/* HF comprise (la V4 convertit sous ~28,8 MHz) */
	if (freq > 1700000000) freq = 1700000000;
	s_freq = freq;
	rtlsdr_set_center_freq (s_dev, freq + FMRX_TUNE_OFFSET);
	if (s_fm)
		rds_init (&s_fm->rds);		/* oublie le RDS de la station precedente */
}

int rtlfm_main (int argc, char **argv)
{
	int opt;
	double mhz = 0;
	int dev_index = 0;
	int ppm = 0;
	int hdmi = 0;
	int mono = 0;
	int mode = FMRX_MODE_FM;
	float deemph = 50.0f;
	float vol = 1.0f;
	int fixed_gain = -1;		/* dixiemes de dB */
	int do_bench = 0, do_tone = 0;

	s_dev = NULL;
	s_head = s_tail = 0;
	s_overruns = 0;
	s_pow_acc = 0;
	s_pow_n = 0;
	s_clip_max = 0;
	s_dsp_us = 0;
	s_bytes = 0;
	s_agc = 1;
	s_quit = 0;

	while ((opt = getopt (argc, argv, "f:g:o:me:v:P:d:M:BTh")) != -1) {
		switch (opt) {
		case 'f': mhz = atof (optarg); break;
		case 'M':
			if (strcmp (optarg, "fm") == 0) mode = FMRX_MODE_FM;
			else if (strcmp (optarg, "am") == 0) mode = FMRX_MODE_AM;
			else if (strcmp (optarg, "usb") == 0) mode = FMRX_MODE_USB;
			else if (strcmp (optarg, "lsb") == 0) mode = FMRX_MODE_LSB;
			else usage ();
			break;
		case 'g': fixed_gain = (int) (atof (optarg) * 10); break;
		case 'o':
			if (strcmp (optarg, "hdmi") == 0) hdmi = 1;
			else if (strcmp (optarg, "jack") == 0 || strcmp (optarg, "pwm") == 0) hdmi = 0;
			else usage ();
			break;
		case 'm': mono = 1; break;
		case 'e': deemph = atof (optarg); break;
		case 'v': vol = atof (optarg); break;
		case 'P': ppm = atoi (optarg); break;
		case 'd': dev_index = atoi (optarg); break;
		case 'B': do_bench = 1; break;
		case 'T': do_tone = 1; break;
		default: usage ();
		}
	}
	if (s_fm == NULL)
		s_fm = malloc (sizeof *s_fm);
	if (do_bench)
		return s_fm != NULL ? bench () : 1;
	if (do_tone) {
		bm_add_cleanup (cleanup);
		signal (SIGINT, on_sigint);
		return tone_test (hdmi);
	}
	if (mhz > 1700) mhz /= 1e6;		/* donne en Hz (seuil au-dessus de la plage) */
	if (mhz < 0.1 || mhz > 1700)
		usage ();
	if (vol < 0) vol = 0;
	if (vol > 4) vol = 4;

	if (s_fm == NULL)
		s_fm = malloc (sizeof *s_fm);
	if (s_ring == NULL)
		s_ring = malloc (RING_PAIRS * 2 * sizeof (int16_t));
	if (s_fm == NULL || s_ring == NULL) {
		fprintf (stderr, "Memoire insuffisante\n");
		exit (1);
	}
	fmrx_init (s_fm);
	fmrx_set_deemphasis (s_fm, deemph);
	s_fm->stereo_enable = !mono;
	s_fm->mode = mode;
	if (mode != FMRX_MODE_FM) {		/* AM/BLU : ni stereo ni RDS (on epargne le CPU) */
		s_fm->stereo_enable = 0;
		s_fm->rds_enable = 0;
	}
	float vol_base = s_fm->volume;		/* 1.0 = reglage par defaut du demodulateur */
	s_fm->volume = vol_base * vol;
	int muted = 0;

	bm_add_cleanup (cleanup);
	signal (SIGINT, on_sigint);

	if (rtlsdr_get_device_count () == 0) {
		fprintf (stderr, "Pas de cle RTL-SDR (la brancher avant de lancer rtlfm)\n");
		exit (1);
	}

	/* ---- son, avant d'ouvrir la cle (une erreur ici ne la laisse pas ouverte) */
	if (bm_audio_open (FMRX_OUT_RATE, hdmi, AUDIO_QUEUE_MS) < 0) {
		fprintf (stderr, "Sortie son %s indisponible\n", hdmi ? "HDMI" : "jack");
		exit (1);
	}

	/* ---- cle */
	if (rtlsdr_open (&s_dev, dev_index) < 0) {
		fprintf (stderr, "Impossible d'ouvrir la cle #%d\n", dev_index);
		s_dev = NULL;
		exit (1);
	}
	rtlsdr_set_bias_tee (s_dev, 0);
	rtlsdr_set_direct_sampling (s_dev, 0);
	verbose_set_sample_rate (s_dev, FMRX_IN_RATE);
	rtlsdr_set_agc_mode (s_dev, 0);			/* AGC numerique du RTL2832 */
	rtlsdr_set_tuner_gain_mode (s_dev, 1);		/* gain du tuner manuel */
	s_ngains = rtlsdr_get_tuner_gains (s_dev, NULL);
	if (s_ngains <= 0 || s_ngains > 64) {
		fprintf (stderr, "Tuner sans table de gains\n");
		exit (1);
	}
	rtlsdr_get_tuner_gains (s_dev, s_gains);
	if (fixed_gain >= 0) {
		s_agc = 0;
		set_gain_idx (nearest_gain_idx (fixed_gain));
	} else {
		set_gain_idx (nearest_gain_idx (200));	/* depart a ~20 dB, l'AGC ajuste */
	}
	if (ppm != 0)
		verbose_ppm_set (s_dev, ppm);
	tune ((uint32_t) (mhz * 1e6 + 0.5));
	verbose_reset_buffer (s_dev);

	if (rtlsdr_start_async (s_dev, rtl_callback, NULL, USB_BUF_NUM, USB_BUF_LEN) < 0) {
		fprintf (stderr, "Echec du demarrage de la reception\n");
		exit (1);
	}

	const char *modename = mode == FMRX_MODE_AM ? "AM" : mode == FMRX_MODE_USB ? "BLU USB"
			     : mode == FMRX_MODE_LSB ? "BLU LSB" : "FM";
	if (mode == FMRX_MODE_FM)
		printf ("Reception FM %.1f MHz, son %s (%s), desaccentuation %.0f us\n",
			s_freq / 1e6, hdmi ? "HDMI" : "jack 3,5 mm", mono ? "mono" : "stereo", deemph);
	else
		printf ("Reception %s %.4f MHz, son %s (mono)\n",
			modename, s_freq / 1e6, hdmi ? "HDMI" : "jack 3,5 mm");
	printf ("Touches : <- -> 0,1 MHz, haut/bas 1 MHz, + - volume, m muet, s stereo, "
		"g G gain, a AGC, Echap quitte\n");
	bm_key_capture (1);

	/* ---- attente des premiers echantillons */
	uint64_t start = bm_micros ();
	while (s_head - s_tail < (unsigned) (FMRX_OUT_RATE * TARGET_FILL_S)) {
		if (rtlsdr_poll_async (s_dev) < 0 || bm_micros () - start > 3000000) {
			fprintf (stderr, "Aucun echantillon de la cle\n");
			exit (1);
		}
		bm_poll ();
		if (s_quit)
			return 0;
	}

	/* ---- boucle principale */
	rtldsp_rate_t rate;
	rtldsp_rate_init (&rate);
	int16_t out[2 * 256];
	uint64_t written = 0, t_play0 = bm_micros (), t_agc = t_play0, t_status = t_play0;
	uint64_t dsp_us0 = s_dsp_us, bytes0 = s_bytes;
	unsigned underruns = 0;
	int ff_set = 0;
	char last_rt[65] = "";

	while (!s_quit) {
		if (rtlsdr_poll_async (s_dev) < 0) {
			fprintf (stderr, "\nCle RTL-SDR perdue\n");
			break;
		}

		/* son : remplit la file de la carte son depuis l'anneau, au rythme reel
		   de la sortie (reechantillonnage lineaire, rapport asservi au remplissage) */
		unsigned space = bm_audio_space ();
		while (space > 0) {
			unsigned n = space > 256 ? 256 : space;
			unsigned need = rtldsp_rate_need (&rate, n);
			if (s_head - s_tail < need) {
				if (bm_audio_queued () < FMRX_OUT_RATE / 100)
					underruns++;
				break;
			}
			rtldsp_rate_run (&rate, s_ring, RING_PAIRS, &s_tail, out, n);
			if (muted)
				memset (out, 0, n * 2 * sizeof out[0]);
			written += bm_audio_write (out, n);
			space -= n;
			rtldsp_rate_control (&rate,
				(double) (s_head - s_tail) / FMRX_OUT_RATE - TARGET_FILL_S,
				(double) n / FMRX_OUT_RATE);
		}

		uint64_t now = bm_micros ();

		/* debit reel de la sortie son, mesure sur 2 s puis suivi */
		if (now - t_play0 > 2000000) {
			uint64_t played = written - bm_audio_queued ();
			double real = (double) played * 1e6 / (double) (now - t_play0);
			if (!ff_set && (real < FMRX_OUT_RATE * 0.95 || real > FMRX_OUT_RATE * 1.05))
				printf ("\nNote : la sortie joue a %.0f Hz au lieu de %u (reglage PLLD : "
					"\"set plld\" ?), compense\n", real, FMRX_OUT_RATE);
			ff_set = 1;
			rate.ff = FMRX_OUT_RATE / real;
		}

		/* AGC logiciel du tuner */
		if (now - t_agc >= AGC_PERIOD_US) {
			t_agc = now;
			if (s_agc && s_pow_n > 0) {
				float db = 10.0f * log10f ((float) (s_pow_acc / s_pow_n) + 1e-12f);
				if (s_clip_max > 0.002f)
					set_gain_idx (s_gain_idx - 3);
				else if (s_clip_max > 0.0002f || db > AGC_TARGET_DB + 4)
					set_gain_idx (s_gain_idx - 1);
				else if (db < AGC_TARGET_DB - 4 && s_clip_max == 0.0f)
					set_gain_idx (s_gain_idx + 1);
			}
			s_pow_acc = 0;
			s_pow_n = 0;
			s_clip_max = 0;
		}

		/* touches */
		int k;
		while ((k = bm_getkey ()) >= 0) {
			switch (k) {
			case BM_KEY_LEFT:	tune (s_freq - 100000); break;
			case BM_KEY_RIGHT:	tune (s_freq + 100000); break;
			case BM_KEY_DOWN:
			case BM_KEY_PGDN:	tune (s_freq - 1000000); break;
			case BM_KEY_UP:
			case BM_KEY_PGUP:	tune (s_freq + 1000000); break;
			case '+': case '=':	vol *= 1.189f; if (vol > 4) vol = 4; break;
			case '-':		vol /= 1.189f; break;
			case 'm': case 'M':	muted = !muted; break;
			case 's': case 'S':	s_fm->stereo_enable = !s_fm->stereo_enable; break;
			case 'g':		s_agc = 0; set_gain_idx (s_gain_idx - 1); break;
			case 'G':		s_agc = 0; set_gain_idx (s_gain_idx + 1); break;
			case 'a': case 'A':	s_agc = 1; break;
			case 'q': case 'Q': case 0x1B:	s_quit = 1; break;
			}
			s_fm->volume = vol_base * vol;
			t_status = 0;		/* affichage immediat */
		}

		/* RadioText RDS : affiche sur sa propre ligne quand il change */
		if (s_fm->rds.rt_ok && strcmp (s_fm->rds.rt, last_rt) != 0) {
			strncpy (last_rt, s_fm->rds.rt, sizeof last_rt - 1);
			printf ("\nRDS texte : %s\n", s_fm->rds.rt);
			t_status = 0;			/* reaffiche l'etat tout de suite */
		}

		/* etat */
		if (now - t_status >= STATUS_PERIOD_US) {
			t_status = now;
			uint64_t db = s_bytes - bytes0;
			unsigned cpu = db > 0 ? (unsigned) ((s_dsp_us - dsp_us0) * 100 * 2 * FMRX_IN_RATE
							    / ((uint64_t) 1000000 * db)) : 0;
			dsp_us0 = s_dsp_us;
			bytes0 = s_bytes;
			/* barre S-metre : -60 dBFS (faible) .. 0 dBFS (fort) sur 12 crans */
			char sig[13];
			int lv = (int) ((s_fm->level_dbfs + 60.0f) * 12.0f / 60.0f);
			if (lv < 0) lv = 0;
			if (lv > 12) lv = 12;
			for (int i = 0; i < 12; i++) sig[i] = i < lv ? '#' : '-';
			sig[12] = 0;

			char rds[48] = "";
			if (s_fm->rds.synced && s_fm->rds.pi >= 0) {
				if (s_fm->rds.ps_ok)
					snprintf (rds, sizeof rds, "  RDS %s (%04X)",
						  s_fm->rds.ps, s_fm->rds.pi);
				else
					snprintf (rds, sizeof rds, "  RDS %04X", s_fm->rds.pi);
			}
			printf ("\r%7.1f MHz  %5.1f dBFS [%s]  gain %4.1f dB%s  %s pilote %4.1f %%  vol %3.0f %%%s"
				"  CPU %2u %%  pertes %u/%u%s   ",
				s_freq / 1e6, s_fm->level_dbfs, sig, s_gains[s_gain_idx] / 10.0,
				s_agc ? " (auto)" : "", s_fm->stereo ? "STEREO" : "mono  ",
				s_fm->pilot_level * 100, vol * 100, muted ? " MUET" : "",
				cpu, s_overruns, underruns, rds);
		}

		bm_poll ();
	}
	return 0;
}
