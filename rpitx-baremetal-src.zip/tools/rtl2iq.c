/*
 * rtl2iq.c - convert an rtl_sdr capture into an IQ WAV file for "rpitx -m IQ"
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The capture must have been recorded a quarter of the sample rate above
 * the wanted frequency, i.e. with
 *     rtl_sdr -f <wanted + rate/4> -s <rate> capture.bin
 * (rate 240000 or 288000). The output is 48 kS/s stereo PCM16 (I left,
 * Q right) with the channel shifted up by 12 kHz: see tools/rtldsp.h.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sndfile.h>
#include <bm_compat.h>
#include "rtldsp.h"
#include "../rpitx/RpiTx.h"

#define IN_CHUNK	16384

static void usage (void)
{
	fprintf (stderr,
		"rtl2iq, rtl_sdr capture -> rpitx v1 IQ WAV file\n\n"
		"Usage: rtl2iq [options] capture.bin out.wav\n"
		"\t[-s rate]     capture sample rate: 240000 (default) or 288000\n"
		"\t[-w hz]       channel half width (default 12000)\n"
		"\t[-G db]       fixed gain in dB (default: AGC)\n"
		"\t[-q dbfs]     squelch level in dBFS (default: off)\n"
		"\t[-f tx_khz]   print the rpitx command for this transmit frequency\n"
		"Record the capture with: rtl_sdr -f <wanted_hz + rate/4> -s <rate> capture.bin\n");
	exit (1);
}

int rtl2iq_main (int argc, char **argv)
{
	int opt;
	unsigned rate = 240000;
	float width = 12000, gain_db = -200, squelch_db = 0;
	double tx_khz = 0;

	while ((opt = getopt (argc, argv, "s:w:G:q:f:h")) != -1) {
		switch (opt) {
		case 's': rate = (unsigned) atof (optarg); break;
		case 'w': width = atof (optarg); break;
		case 'G': gain_db = atof (optarg); break;
		case 'q': squelch_db = atof (optarg); break;
		case 'f': tx_khz = atof (optarg); break;
		default: usage ();
		}
	}
	if (argc - optind != 2)
		usage ();
	if (rate != 240000 && rate != 288000) {
		fprintf (stderr, "Sample rate must be 240000 or 288000\n");
		exit (1);
	}

	static rtldsp_t dsp;
	rtldsp_init (&dsp, rate / RTLDSP_OUT_RATE, width, gain_db, squelch_db, RTLDSP_MODE_RELAY);

	int in = open (argv[optind], O_RDONLY);
	if (in < 0) {
		fprintf (stderr, "Cannot open %s\n", argv[optind]);
		exit (1);
	}

	SF_INFO info;
	memset (&info, 0, sizeof info);
	info.samplerate = RTLDSP_OUT_RATE;
	info.channels = 2;
	info.format = SF_FORMAT_WAV | SF_FORMAT_PCM_16;
	SNDFILE *out = sf_open (argv[optind + 1], SFM_WRITE, &info);
	if (out == NULL) {
		fprintf (stderr, "Cannot create %s: %s\n", argv[optind + 1], sf_strerror (NULL));
		close (in);
		exit (1);
	}

	static uint8_t buf[IN_CHUNK];
	static int16_t pairs[2 * (IN_CHUNK / 2 / 5 + 8)];
	long total = 0;
	int n;
	while ((n = read (in, buf, sizeof buf)) > 0) {
		int k = rtldsp_process (&dsp, buf, n & ~1, pairs, sizeof pairs / sizeof pairs[0] / 2);
		if (sf_writef_short (out, pairs, k) != k) {
			fprintf (stderr, "Write error (SD card full?)\n");
			break;
		}
		total += k;
		bm_poll ();
		if (bm_stop_requested ())
			break;
	}
	sf_close (out);
	close (in);

	printf ("%ld IQ samples (%.1f s) written to %s\n", total,
		total / (double) RTLDSP_OUT_RATE, argv[optind + 1]);
	if (tx_khz > 0)
		printf ("Transmit with: rpitx -m IQ -i %s -f %.3f\n", argv[optind + 1],
			pitx_iq_set_frequency (tx_khz * 1000.0, rtldsp_shift_hz (&dsp)) / 1000.0);
	else
		printf ("Transmit with: rpitx -m IQ -i %s -f <wanted_khz - 11> (without harmonic)\n",
			argv[optind + 1]);
	return 0;
}
