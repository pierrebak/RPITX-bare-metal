/*
 * fft.c - FFT radix-2 (voir fft.h)
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cooley-Tukey a entrelacement temporel : reordonnancement par inversion de bits
 * puis log2(N) etages de papillons. Table de rotation unique de N/2 points,
 * indexee par k << (logN - etage). Calcul en float (VFP du Pi 1).
 */
#include <math.h>
#include <stdlib.h>
#include "fft.h"

#define PI_F	3.14159265358979f

int fft_init (fft_t *f, int n)
{
	int logn = 0;
	while ((1 << logn) < n) logn++;
	if ((1 << logn) != n || n < 2)
		return -1;
	f->n = n;
	f->logn = logn;
	f->wr = malloc (sizeof (float) * (n / 2));
	f->wi = malloc (sizeof (float) * (n / 2));
	f->brev = malloc (sizeof (int) * n);
	f->win = malloc (sizeof (float) * n);
	if (!f->wr || !f->wi || !f->brev || !f->win) {
		fft_free (f);
		return -1;
	}
	for (int k = 0; k < n / 2; k++) {
		f->wr[k] = cosf (-2.0f * PI_F * k / n);
		f->wi[k] = sinf (-2.0f * PI_F * k / n);
	}
	for (int i = 0; i < n; i++) {
		int r = 0, x = i;
		for (int b = 0; b < logn; b++) { r = (r << 1) | (x & 1); x >>= 1; }
		f->brev[i] = r;
	}
	f->wsum = 0.0f;
	for (int i = 0; i < n; i++) {
		f->win[i] = 0.5f - 0.5f * cosf (2.0f * PI_F * i / (n - 1));	/* Hann */
		f->wsum += f->win[i];
	}
	return 0;
}

void fft_free (fft_t *f)
{
	free (f->wr); free (f->wi); free (f->brev); free (f->win);
	f->wr = f->wi = f->win = NULL; f->brev = NULL;
}

void fft_run (fft_t *f, float *re, float *im)
{
	int n = f->n, logn = f->logn;
	/* reordonnancement par inversion de bits */
	for (int i = 0; i < n; i++) {
		int j = f->brev[i];
		if (j > i) {
			float tr = re[i]; re[i] = re[j]; re[j] = tr;
			float ti = im[i]; im[i] = im[j]; im[j] = ti;
		}
	}
	/* etages de papillons */
	for (int s = 1; s <= logn; s++) {
		int m = 1 << s, m2 = m >> 1;
		int step = 1 << (logn - s);		/* pas dans la table de rotation */
		for (int k = 0; k < m2; k++) {
			float wr = f->wr[k * step], wi = f->wi[k * step];
			for (int i = k; i < n; i += m) {
				int j = i + m2;
				float tr = wr * re[j] - wi * im[j];
				float ti = wr * im[j] + wi * re[j];
				re[j] = re[i] - tr; im[j] = im[i] - ti;
				re[i] += tr;        im[i] += ti;
			}
		}
	}
}

void fft_power_u8 (fft_t *f, const uint8_t *iq, float *pdb)
{
	int n = f->n;
	/* tampons de travail (reutilises entre appels non necessaire : pile) */
	float *re = malloc (sizeof (float) * n);
	float *im = malloc (sizeof (float) * n);
	if (!re || !im) { free (re); free (im); return; }

	for (int i = 0; i < n; i++) {
		float w = f->win[i];
		re[i] = ((int) iq[2 * i]     - 127) / 128.0f * w;
		im[i] = ((int) iq[2 * i + 1] - 127) / 128.0f * w;
	}
	fft_run (f, re, im);

	/* normalisation : une exponentielle complexe pleine echelle (amplitude 1)
	   donne 0 dB. A la raie exacte, |X| = A * somme(fenetre) -> puissance A^2 wsum^2. */
	float norm = f->wsum * f->wsum;
	for (int i = 0; i < n; i++) {
		int src = (i + n / 2) % n;		/* recentrage : -Fs/2 .. +Fs/2 */
		float p = (re[src] * re[src] + im[src] * im[src]) / norm;
		pdb[i] = 10.0f * log10f (p > 1e-12f ? p : 1e-12f);
	}
	free (re); free (im);
}
