/*
 * rtl868.c - réception de capteurs 868 MHz en FSK (LaCrosse IT+ : TX29, TX35…)
 *            avec une clé RTL-SDR
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>
#include <bm_compat.h>
#include "rtl-sdr.h"
#include "rtl-sdr-bm.h"
#include "convenience/convenience.h"
#include "fsk.h"
#include "ook.h"

#define RATE		250000
#define TUNE_OFFSET	(RATE / 4)		/* les deux tons FSK hors de la raie continue */
#define USB_BUF_NUM	6
#define USB_BUF_LEN	16384
#define LACROSSE_BAUD	17241
#define LACROSSE_SYNC	0x2DD4
#define LACROSSE_LEN	5			/* 4 octets données + 1 CRC */

static rtlsdr_dev_t *s_dev;
static fsk_t s_fsk;
static volatile int s_quit;
static unsigned s_frames, s_decoded;
static int s_raw;
static uint64_t s_t0;

static void on_packet (const fsk_packet_t *pkt, void *ctx)
{
	(void) ctx;
	s_frames++;
	unsigned sec = (unsigned) ((bm_micros () - s_t0) / 1000000);
	sensor_t sd;
	if (fsk_decode_data (pkt, &sd))
	{
		s_decoded++;
		sensor_print (&sd, sec);
	}
	else if (s_raw)
	{
		char line[160];
		fsk_raw (pkt, line, sizeof line);
		printf ("[%4u s] %s\n", sec, line);
	}
}

static void rtl_callback (unsigned char *buf, uint32_t len, void *ctx)
{
	(void) ctx;
	fsk_feed (&s_fsk, buf, (int) len);
}

static void on_sigint (int sig) { (void) sig; s_quit = 1; }

static void cleanup (void)
{
	if (s_dev)
	{
		rtlsdr_stop_async (s_dev);
		rtlsdr_close (s_dev);
		s_dev = NULL;
	}
}

static void usage (void)
{
	fprintf (stderr,
		"rtl868, capteurs 868 MHz en FSK (LaCrosse IT+ : TX29, TX35…) avec RTL-SDR\n\n"
		"Usage: rtl868 [options]\n"
		"\t[-f MHz]   fréquence (défaut 868.300)\n"
		"\t[-g dB]    gain fixe du tuner (défaut : automatique)\n"
		"\t[-R]       afficher aussi les trames brutes (octets + CRC)\n"
		"\t[-P ppm]   correction de fréquence\n"
		"\t[-d index] numéro de la clé\n"
		"Le format exact LaCrosse est à confirmer : si rien ne se décode mais que\n"
		"-R montre des trames « CRC ok », transmettez-les.\n"
		"Échap ou Ctrl-C pour quitter.\n");
	exit (1);
}

int rtl868_main (int argc, char **argv)
{
	int opt;
	double mhz = 868.300;
	int dev_index = 0, ppm = 0, fixed_gain = -1;

	s_dev = NULL;
	s_quit = 0;
	s_frames = s_decoded = 0;
	s_raw = 0;

	while ((opt = getopt (argc, argv, "f:g:RP:d:h")) != -1)
	{
		switch (opt)
		{
		case 'f': mhz = atof (optarg); break;
		case 'g': fixed_gain = (int) (atof (optarg) * 10); break;
		case 'R': s_raw = 1; break;
		case 'P': ppm = atoi (optarg); break;
		case 'd': dev_index = atoi (optarg); break;
		default: usage ();
		}
	}
	if (mhz > 10000) mhz /= 1e6;
	if (mhz < 24 || mhz > 1700) usage ();

	bm_add_cleanup (cleanup);
	signal (SIGINT, on_sigint);

	if (rtlsdr_get_device_count () == 0)
	{
		fprintf (stderr, "Pas de clé RTL-SDR\n");
		exit (1);
	}
	if (rtlsdr_open (&s_dev, dev_index) < 0)
	{
		fprintf (stderr, "Impossible d'ouvrir la clé #%d\n", dev_index);
		s_dev = NULL;
		exit (1);
	}
	rtlsdr_set_bias_tee (s_dev, 0);
	rtlsdr_set_direct_sampling (s_dev, 0);
	verbose_set_sample_rate (s_dev, RATE);
	rtlsdr_set_agc_mode (s_dev, 0);
	if (fixed_gain >= 0)
	{
		rtlsdr_set_tuner_gain_mode (s_dev, 1);
		rtlsdr_set_tuner_gain (s_dev, fixed_gain);
	}
	else
	{
		rtlsdr_set_tuner_gain_mode (s_dev, 0);
	}
	if (ppm != 0)
	{
		verbose_ppm_set (s_dev, ppm);
	}
	rtlsdr_set_center_freq (s_dev, (uint32_t) (mhz * 1e6 + 0.5) + TUNE_OFFSET);
	verbose_reset_buffer (s_dev);

	fsk_init (&s_fsk, RATE, LACROSSE_BAUD, LACROSSE_SYNC, 16, LACROSSE_LEN, on_packet, NULL);
	s_t0 = bm_micros ();

	if (rtlsdr_start_async (s_dev, rtl_callback, NULL, USB_BUF_NUM, USB_BUF_LEN) < 0)
	{
		fprintf (stderr, "Échec du démarrage de la réception\n");
		exit (1);
	}

	printf ("Écoute FSK 868 MHz sur %.3f MHz (Échap pour quitter)%s\n",
		mhz, s_raw ? ", trames brutes affichées" : "");
	bm_key_capture (1);

	uint64_t t_status = bm_micros ();
	while (!s_quit)
	{
		if (rtlsdr_poll_async (s_dev) < 0)
		{
			fprintf (stderr, "\nClé RTL-SDR perdue\n");
			break;
		}
		int k = bm_getkey ();
		if (k == 0x1B || k == 'q' || k == 'Q')
		{
			break;
		}
		uint64_t now = bm_micros ();
		if (now - t_status >= 10000000)
		{
			t_status = now;
			printf ("  ... %u trame(s), %u décodée(s)\n", s_frames, s_decoded);
		}
		bm_poll ();
	}
	printf ("\nArrêt. %u trame(s), %u décodée(s).\n", s_frames, s_decoded);
	return 0;
}
