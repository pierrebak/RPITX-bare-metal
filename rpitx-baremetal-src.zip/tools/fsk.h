/*
 * fsk.h - démodulation FSK 2 états et décodage de capteurs 868 MHz
 *         (LaCrosse IT+ : TX29, TX35…), inspiré de rtl_433
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#ifndef FSK_H
#define FSK_H

#include <stdint.h>

#define FSK_MAX_BYTES	16

typedef struct {
	int num;				/* octets récupérés après la synchro */
	uint8_t data[FSK_MAX_BYTES];
} fsk_packet_t;

typedef void (*fsk_cb) (const fsk_packet_t *pkt, void *ctx);

typedef struct {
	int fs;
	float clk_inc;				/* bauds / fs : avance d'horloge par échantillon */

	/* discriminateur de fréquence */
	float prev_i, prev_q;
	float freq_mean;			/* continu : enlève le décalage d'accord */

	/* porteuse (amplitude) */
	float amp_noise, amp_level;
	int carrier;

	/* horloge bit (boucle à verrouillage de phase numérique) */
	float clk;
	int last_slice;

	/* recherche de synchro et assemblage des octets */
	uint32_t shift;
	uint32_t sync;
	uint32_t sync_mask;
	int in_packet;
	uint8_t cur;
	int curbits;
	int payload_len;
	fsk_packet_t pkt;

	fsk_cb cb;
	void *ctx;
} fsk_t;

void fsk_init (fsk_t *f, int fs, int baud, uint32_t sync, int sync_bits,
	       int payload_len, fsk_cb cb, void *ctx);
void fsk_feed (fsk_t *f, const uint8_t *iq, int n_bytes);

/* CRC-8 (poly et init paramétrables) */
uint8_t fsk_crc8 (const uint8_t *data, int len, uint8_t poly, uint8_t init);

struct sensor_t;
/* LaCrosse IT+ : renvoie 1 et remplit out si décodé, 0 sinon */
int fsk_decode_lacrosse (const fsk_packet_t *pkt, char *out, int outlen);
int fsk_decode_data (const fsk_packet_t *pkt, struct sensor_t *s);

/* affichage brut (octets + état du CRC) */
void fsk_raw (const fsk_packet_t *pkt, char *out, int outlen);

#endif
