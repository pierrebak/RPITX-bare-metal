/*
 * rtl433.c - réception de capteurs 433 MHz (température / humidité) avec une
 *            clé RTL-SDR, décodage façon rtl_433
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Chaîne : la clé échantillonne à 250 kS/s, accordée légèrement au-dessus de
 * la fréquence (la raie continue de la clé reste hors du signal) ; on calcule
 * l'amplitude (enveloppe) de chaque échantillon I/Q, que le détecteur d'ook.c
 * découpe en rafales, puis les décodeurs reconnaissent les capteurs connus.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>
#include <bm_compat.h>
#include "rtl-sdr.h"
#include "rtl-sdr-bm.h"
#include "convenience/convenience.h"
#include "ook.h"

#define RATE		250000		/* base stable Pi 1 */
#define TUNE_OFFSET	(RATE / 4)		/* signal hors de la raie continue */
#define USB_BUF_NUM	6
#define USB_BUF_LEN	16384

static rtlsdr_dev_t *s_dev;
static ook_detector_t s_det;
static uint16_t s_mag[USB_BUF_LEN / 2 + 8];
static volatile int s_quit;
static unsigned s_frames, s_decoded;
static int s_raw;				/* -R : afficher aussi les trames brutes */
static int s_dump;				/* -D : suite brute des impulsions */
static uint64_t s_t0;

static void on_packet (const ook_packet_t *pkt, void *ctx)
{
	(void) ctx;
	s_frames++;
	unsigned sec = (unsigned) ((bm_micros () - s_t0) / 1000000);
	sensor_t sd;
	if (ook_decode_data (pkt, &sd))
	{
		s_decoded++;
		sensor_print (&sd, sec);
	}
	else if (s_dump)
	{
		char line[512];
		ook_dump (pkt, line, sizeof line);
		printf ("[%4u s] %s\n", sec, line);
		if (pkt->num > 100)
		{
			ook_dbg_tx141 (pkt, line, sizeof line);
			printf ("          %s\n", line);
		}
	}
	else if (s_raw)
	{
		char line[160];
		ook_raw (pkt, line, sizeof line);
		printf ("[%4u s] %s\n", sec, line);
	}
}

static void rtl_callback (unsigned char *buf, uint32_t len, void *ctx)
{
	(void) ctx;
	int ns = (int) (len / 2);
	for (int k = 0; k < ns; k++)
	{
		int i = buf[2 * k] - 127;
		int q = buf[2 * k + 1] - 127;
		int a = i < 0 ? -i : i;
		int b = q < 0 ? -q : q;
		/* approximation alpha-max + beta-min de sqrt(i^2+q^2) */
		s_mag[k] = (uint16_t) (a > b ? a + ((b * 3) >> 3) : b + ((a * 3) >> 3));
	}
	ook_feed (&s_det, s_mag, ns);
}

static void on_sigint (int sig)
{
	(void) sig;
	s_quit = 1;
}

static void cleanup (void)
{
	if (s_dev)
	{
		rtlsdr_stop_async (s_dev);
		rtlsdr_close (s_dev);
		s_dev = NULL;
	}
}

static void usage (void)
{
	fprintf (stderr,
		"rtl433, décodage de capteurs 433 MHz (température/humidité) avec RTL-SDR\n\n"
		"Usage: rtl433 [options]\n"
		"\t[-f MHz]   fréquence (défaut 433.92)\n"
		"\t[-g dB]    gain fixe du tuner (défaut : automatique)\n"
		"\t[-R]       afficher aussi les trames non reconnues (brut)\n"
		"\t[-D]       suite brute des impulsions (débogage)\n"
		"\t[-P ppm]   correction de fréquence\n"
		"\t[-d index] numéro de la clé\n"
		"Capteurs reconnus : Nexus et clones (Digoo, Sencor, Froggit, nombreux\n"
		"sans marque). Pour en ajouter : lancer avec -R, noter la ligne « inconnu »\n"
		"de votre capteur et la transmettre.\n"
		"Échap ou Ctrl-C pour quitter.\n");
	exit (1);
}

int rtl433_main (int argc, char **argv)
{
	int opt;
	double mhz = 433.92;
	int dev_index = 0, ppm = 0, fixed_gain = -1;

	s_dev = NULL;
	s_quit = 0;
	s_frames = s_decoded = 0;
	s_raw = 0;
	s_dump = 0;

	while ((opt = getopt (argc, argv, "f:g:RDP:d:h")) != -1)
	{
		switch (opt)
		{
		case 'f': mhz = atof (optarg); break;
		case 'g': fixed_gain = (int) (atof (optarg) * 10); break;
		case 'R': s_raw = 1; break;
		case 'D': s_dump = 1; break;
		case 'P': ppm = atoi (optarg); break;
		case 'd': dev_index = atoi (optarg); break;
		default: usage ();
		}
	}
	if (mhz > 1000) mhz /= 1e6;
	if (mhz < 24 || mhz > 1700) usage ();

	bm_add_cleanup (cleanup);
	signal (SIGINT, on_sigint);

	if (rtlsdr_get_device_count () == 0)
	{
		fprintf (stderr, "Pas de clé RTL-SDR\n");
		exit (1);
	}
	if (rtlsdr_open (&s_dev, dev_index) < 0)
	{
		fprintf (stderr, "Impossible d'ouvrir la clé #%d\n", dev_index);
		s_dev = NULL;
		exit (1);
	}
	rtlsdr_set_bias_tee (s_dev, 0);
	rtlsdr_set_direct_sampling (s_dev, 0);
	verbose_set_sample_rate (s_dev, RATE);
	rtlsdr_set_agc_mode (s_dev, 0);
	if (fixed_gain >= 0)
	{
		rtlsdr_set_tuner_gain_mode (s_dev, 1);
		rtlsdr_set_tuner_gain (s_dev, fixed_gain);
	}
	else
	{
		rtlsdr_set_tuner_gain_mode (s_dev, 0);		/* gain automatique du tuner */
	}
	if (ppm != 0)
	{
		verbose_ppm_set (s_dev, ppm);
	}
	rtlsdr_set_center_freq (s_dev, (uint32_t) (mhz * 1e6 + 0.5) + TUNE_OFFSET);
	verbose_reset_buffer (s_dev);

	ook_init (&s_det, RATE, on_packet, NULL);
	s_t0 = bm_micros ();

	if (rtlsdr_start_async (s_dev, rtl_callback, NULL, USB_BUF_NUM, USB_BUF_LEN) < 0)
	{
		fprintf (stderr, "Échec du démarrage de la réception\n");
		exit (1);
	}

	printf ("Écoute des capteurs sur %.3f MHz (Échap pour quitter)%s\n",
		mhz, s_raw ? ", trames brutes affichées" : "");
	bm_key_capture (1);

	uint64_t t_status = bm_micros ();
	while (!s_quit)
	{
		if (rtlsdr_poll_async (s_dev) < 0)
		{
			fprintf (stderr, "\nClé RTL-SDR perdue\n");
			break;
		}
		int k = bm_getkey ();
		if (k == 0x1B || k == 'q' || k == 'Q')
		{
			break;
		}
		uint64_t now = bm_micros ();
		if (now - t_status >= 10000000)			/* toutes les 10 s */
		{
			t_status = now;
			printf ("  ... %u trame(s) reçue(s), %u décodée(s)\n", s_frames, s_decoded);
		}
		bm_poll ();
	}
	printf ("\nArrêt. %u trame(s) reçue(s), %u décodée(s).\n", s_frames, s_decoded);
	return 0;
}
