/*
 * bmp2rgb.c - BMP picture -> raw 320x256 RGB file for pisstv
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Replaces "convert -depth 8 picture.jpg picture.rgb" (ImageMagick) used
 * on Linux. Accepts uncompressed 24 or 32 bit BMP files of any size; the
 * picture is resized (nearest neighbour) to 320x256, the Martin 1 format.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define OUT_W 320
#define OUT_H 256

static uint32_t rd32 (const unsigned char *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((uint32_t) p[3] << 24); }
static uint16_t rd16 (const unsigned char *p) { return (uint16_t) (p[0] | (p[1] << 8)); }

int bmp2rgb_main (int argc, char **argv)
{
	if (argc != 3) {
		fprintf (stderr, "Usage: bmp2rgb picture.bmp picture.rgb\n"
				 "(uncompressed 24/32 bit BMP, resized to 320x256 for pisstv)\n");
		return 1;
	}

	int in = open (argv[1], O_RDONLY);
	if (in < 0) {
		fprintf (stderr, "Cannot open %s\n", argv[1]);
		return 1;
	}
	unsigned char h[54];
	if (read (in, h, sizeof h) != sizeof h || h[0] != 'B' || h[1] != 'M') {
		fprintf (stderr, "%s is not a BMP file\n", argv[1]);
		close (in);
		return 1;
	}
	uint32_t data_offset = rd32 (h + 10);
	int32_t width = (int32_t) rd32 (h + 18);
	int32_t height = (int32_t) rd32 (h + 22);
	int bpp = rd16 (h + 28);
	uint32_t compression = rd32 (h + 30);
	int top_down = height < 0;
	if (top_down) height = -height;

	if ((bpp != 24 && bpp != 32) || !(compression == 0 || (compression == 3 && bpp == 32))
	    || width <= 0 || height <= 0 || width > 16384 || height > 16384) {
		fprintf (stderr, "Unsupported BMP (need uncompressed 24 or 32 bit)\n");
		close (in);
		return 1;
	}

	uint32_t stride = ((uint32_t) width * (bpp / 8) + 3) & ~3u;
	unsigned char *row = malloc (stride);
	unsigned char *out = malloc (OUT_W * OUT_H * 3);
	if (row == NULL || out == NULL) {
		fprintf (stderr, "Out of memory\n");
		free (row); free (out);
		close (in);
		return 1;
	}

	for (int y = 0; y < OUT_H; y++) {
		int sy = (int) ((long) y * height / OUT_H);
		int file_row = top_down ? sy : height - 1 - sy;
		lseek (in, data_offset + (long) file_row * stride, SEEK_SET);
		if (read (in, row, stride) != (int) stride) {
			fprintf (stderr, "Truncated BMP file\n");
			free (row); free (out);
			close (in);
			return 1;
		}
		for (int x = 0; x < OUT_W; x++) {
			int sx = (int) ((long) x * width / OUT_W);
			const unsigned char *p = row + sx * (bpp / 8);	/* B, G, R */
			unsigned char *o = out + (y * OUT_W + x) * 3;
			o[0] = p[2];
			o[1] = p[1];
			o[2] = p[0];
		}
	}
	close (in);

	int fd = open (argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);
	int ok = fd >= 0 && write (fd, out, OUT_W * OUT_H * 3) == OUT_W * OUT_H * 3;
	if (fd >= 0) close (fd);
	free (row);
	free (out);
	if (!ok) {
		fprintf (stderr, "Cannot write %s\n", argv[2]);
		return 1;
	}
	printf ("%s: %dx%d -> %s: 320x256 RGB\n", argv[1], (int) width, (int) height, argv[2]);
	return 0;
}
