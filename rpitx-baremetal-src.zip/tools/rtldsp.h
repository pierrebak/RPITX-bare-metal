/*
 * rtldsp.h - RTL-SDR samples -> rpitx v1 IQ samples
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Chain (input rate Fs_in = 48000 * decim, output 48000 S/s):
 *   uint8 I/Q -> float -> shift by +Fs_in/4 -> low-pass FIR -> decimate
 *   RELAY:  -> AGC / squelch -> shift by +12 kHz -> int16 I/Q (I first)
 *   FM2SSB: -> squelch -> FM discriminator -> complex band-pass keeping
 *           +300..+3000 Hz only (upper side band) -> AGC -> int16 I/Q
 *
 * Why the two shifts:
 *  - the dongle is tuned Fs_in/4 above the wanted frequency, so its DC
 *    offset / LO leak ends up far outside the channel and is filtered out;
 *  - rpitx v1 IQ mode turns the phase increment into a frequency in
 *    [0, 48 kHz): negative baseband frequencies would be transmitted 48 kHz
 *    too high. Moving the channel (+/-12 kHz wide) up by 12 kHz keeps the
 *    whole channel in the positive range; the transmit frequency given to
 *    rpitx is lowered accordingly (pitx_iq_set_frequency()).
 * Both shifts are quarter of the sample rate: multiplications by j^n.
 */
#ifndef RTLDSP_H
#define RTLDSP_H

#include <stdint.h>

#define RTLDSP_OUT_RATE		48000
#define RTLDSP_MAX_TAPS		161
#define RTLDSP_AUDIO_TAPS	127
#define RTLDSP_SHIFT_OUT_HZ	(RTLDSP_OUT_RATE / 4)		/* 12 kHz */

/* Processing modes */
#define RTLDSP_MODE_RELAY	0	/* channel IQ retransmitted as is */
#define RTLDSP_MODE_FM2SSB	1	/* narrow FM demodulated, sent as USB voice
					   (equivalent of fm2ssb.sh in rpitx v2) */
#define RTLDSP_MODE_WIDE	2	/* whole band at the dongle rate, like
					   transponder.sh of rpitx v2 (rtl_sdr -s
					   250000 | sendiq): wide FM broadcast */

/* The frequency to give to rpitx -f is computed with
   pitx_iq_set_frequency(wanted_hz, rtldsp_shift_hz(d)) (rpitx/RpiTx.c),
   which also handles the v1 harmonic mode above 250 MHz. */

typedef struct {
	int mode;
	int decim;
	int ntaps;
	float taps[RTLDSP_MAX_TAPS];
	float hist_i[2 * RTLDSP_MAX_TAPS];	/* doubled circular buffer */
	float hist_q[2 * RTLDSP_MAX_TAPS];
	int hpos;
	int phase;			/* input samples since last output */
	unsigned rot_in;		/* j^n counters */
	unsigned rot_out;

	/* FM -> SSB */
	float prev_i, prev_q;		/* previous channel sample */
	float ssb_re[RTLDSP_AUDIO_TAPS];	/* complex band-pass 300..3000 Hz */
	float ssb_im[RTLDSP_AUDIO_TAPS];
	float hist_a[2 * RTLDSP_AUDIO_TAPS];
	int apos;

	/* level control */
	float fixed_gain;		/* > 0: no AGC */
	float agc_peak;
	float agc_target;
	float squelch_lin;		/* power threshold, 0 = off */
	float power_avg;
	int squelch_open;

	/* statistics */
	float level_db;			/* average input power in dBFS */

	/* 1: the output shift (+12 kHz, +Fs/2 in WIDE mode) is not applied by
	   rtldsp_process / rtldsp_wide but later by rtldsp_out_shift(), so that
	   the samples can be resampled in between (rtl2tx rate matching:
	   interpolating after the shift would distort a signal near Fs/2) */
	int no_out_shift;
} rtldsp_t;

/* decim: 5 (240 kS/s) or 6 (288 kS/s). cutoff_hz: channel half width.
   gain_db: fixed gain (AGC if <= -100). squelch_db: dBFS, 0 = off.
   mode: RTLDSP_MODE_RELAY or RTLDSP_MODE_FM2SSB. */
void rtldsp_init (rtldsp_t *d, int decim, float cutoff_hz, float gain_db, float squelch_db,
		  int mode);

/* frequency of the output IQ samples relative to the received signal
   (RELAY: +12 kHz, FM2SSB: the audio frequency itself, 0) */
float rtldsp_shift_hz (const rtldsp_t *d);

/* Processes n_bytes of interleaved uint8 I/Q, writes int16 I,Q pairs.
   Returns the number of pairs written (at most max_pairs). */
int rtldsp_process (rtldsp_t *d, const uint8_t *in, int n_bytes, int16_t *out, int max_pairs);

/* WIDE mode (rtldsp_init not needed, d->level_db updated):
   no filter nor decimation, the dongle is tuned on the wanted frequency and
   the whole -Fs/2..+Fs/2 band is retransmitted (wide FM broadcast fits in
   250 kS/s, as in rpitx v2). Limiter: the amplitude is made constant, so
   only FM / phase modulations come out right (AM and SSB do not).
   Samples are shifted by +Fs/2 (multiplied by (-1)^n) so that the band lies
   in [0, Fs), the range of rpitx v1 IQ mode: the frequency given to rpitx
   is pitx_iq_set_frequency(wanted_hz, Fs / 2).
   Returns the number of pairs written (n_bytes / 2, at most max_pairs). */
int rtldsp_wide (rtldsp_t *d, const uint8_t *in, int n_bytes, int16_t *out, int max_pairs);

/* ---- rate matching (rtl2tx): the transmitter does not play exactly the
   nominal rate. Samples are linearly interpolated at `ratio` input samples
   per output sample: ratio = ff * (1 + slow PI correction on the low-passed
   fill level of the caller's ring). ff is set by the caller to nominal rate
   / measured output rate; the correction absorbs the rest (clock offsets).
   The fill level is low-passed because the dongle delivers by blocks: a
   direct correction would modulate the timing (phase noise on wide FM). */
typedef struct {
	double ratio;
	double ff;			/* feed-forward ratio, 1.0 by default */
	double fill_lp;			/* low-passed fill error, s */
	double integ;
	float frac;			/* position between two input samples */
} rtldsp_rate_t;

#define RTLDSP_RATE_MIN		0.7
#define RTLDSP_RATE_MAX		1.4

void rtldsp_rate_init (rtldsp_rate_t *r);
/* input pairs needed (including the interpolation neighbour) to produce n */
unsigned rtldsp_rate_need (const rtldsp_rate_t *r, unsigned n);
/* produces n pairs from the ring (ring_pairs long, read from *tail, which is
   advanced; free running counter) */
void rtldsp_rate_run (rtldsp_rate_t *r, const int16_t *ring, unsigned ring_pairs,
		      unsigned *tail, int16_t *out, unsigned n);
/* fill_err_s: ring fill minus target, in seconds; dt_s: duration of the
   block just produced */
void rtldsp_rate_control (rtldsp_rate_t *r, double fill_err_s, double dt_s);

/* Applies the output shift (see no_out_shift) to n int16 I,Q pairs:
   multiplication by j^n (+Fs/4) or, in WIDE mode, by (-1)^n (+Fs/2);
   nothing in FM2SSB mode (no shift). */
void rtldsp_out_shift (rtldsp_t *d, int16_t *iq, int n);

#endif
