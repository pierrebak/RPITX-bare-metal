/*
 * rds.h - decodeur RDS (Radio Data System) sur le multiplex FM
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Le RDS est une sous-porteuse a 57 kHz (3x le pilote 19 kHz) modulee en BPSK
 * a 1187,5 bit/s (= pilote / 48... en fait pilote / 16 pour l'horloge symbole),
 * codage differentiel puis biphase. On se branche sur le signal multiplex (MPX)
 * demodule a 256 kHz et sur la phase du pilote fournie par la PLL du recepteur FM :
 *   MPX -> melange a 57 kHz (3 x phase pilote) -> bande de base I/Q
 *       -> filtre passe-bas + decimation a 8 kHz
 *       -> correction de phase (constellation BPSK sur l'axe reel)
 *       -> integration par bit (horloge verrouillee sur le pilote) -> symboles biphase
 *       -> decodage differentiel -> flux de bits
 *       -> synchro blocs (mots d'offset + CRC) -> groupes -> PI, PTY, PS, RadioText
 */
#ifndef RDS_H
#define RDS_H

#include <stdint.h>

#define RDS_MPX_RATE	256000
#define RDS_DECIM	16			/* 256 k -> 16 k en bande de base */
#define RDS_BB_RATE	(RDS_MPX_RATE / RDS_DECIM)

typedef struct {
	/* --- sorties (lisibles a tout moment) --- */
	int   pi;			/* code PI (identifiant emetteur), -1 si inconnu */
	int   pty;			/* type de programme 0..31, -1 si inconnu */
	int   tp;			/* Traffic Program, -1 si inconnu */
	int   ta;			/* Traffic Announcement, -1 si inconnu */
	char  ps[9];			/* nom de station (8 car. + \0) */
	char  rt[65];			/* RadioText (64 car. + \0) */
	int   ps_ok;			/* les 8 caracteres du PS ont ete recus */
	int   rt_ok;			/* RadioText complet recu */

	/* --- statistiques (diagnostic) --- */
	unsigned groups;		/* groupes complets decodes */
	unsigned blocks_ok;		/* blocs valides (CRC) */
	unsigned bits;			/* bits de donnees produits */
	int   synced;			/* synchro blocs acquise */

	/* --- etat interne --- */
	/* melange / bande de base */
	uint32_t prev_pilot;
	int   have_prev_pilot;
	float lp_i[4], lp_q[4];		/* 2 biquattres passe-bas (I et Q), etat */
	int   dec_cnt;
	/* estimation de phase (ordre 2 : angle de la somme de (I+jQ)^2) */
	float ph_re, ph_im;		/* accumulateurs lissants */
	int   theta_cnt;		/* recalcul periodique de l'angle */
	float theta_ct, theta_st;	/* cos/sin de la correction de phase */
	/* horloge bit verrouillee sur le pilote (horloge symbole = pilote / 16) :
	   porteuse (3x pilote) et horloge derivent du meme pilote -> aucune derive.
	   On cumule l'avance du pilote a la cadence MPX, et on avance l'horloge bit
	   d'un pas (cumul / 16) a chaque echantillon bande de base. */
	uint32_t bit_phase;		/* Q32, un tour = un bit */
	int32_t pilot_acc;		/* avance pilote cumulee depuis le dernier pas */
	float a1, a2;			/* integrateurs : 1re / 2e moitie du bit */
	/* decodage differentiel */
	int   prev_sym;
	int   have_prev_sym;
	/* assemblage des blocs */
	uint32_t reg;			/* 26 derniers bits */
	int   in_bits;			/* bits accumules depuis le dernier bloc */
	int   blk_idx;			/* 0..3 : prochain bloc attendu (A,B,C,D) */
	int   bad;			/* blocs ratés d'affilée */
	uint16_t grp[4];		/* 4 x 16 bits d'info du groupe courant */
	int   grp_ok[4];
	/* assemblage PS / RT */
	char  ps_tmp[8];
	int   ps_seen[4];		/* 4 segments de 2 caracteres */
	char  rt_tmp[64];
	int   rt_seen[16];
	int   rt_ab;			/* drapeau A/B du RadioText (reset au changement) */
} rds_t;

void rds_init (rds_t *r);
/* alimente le decodeur avec un echantillon MPX (normalise, 75 kHz = 1) et la
   phase courante du pilote 19 kHz (Q32, celle de la PLL du recepteur FM) */
void rds_feed (rds_t *r, float mpx, uint32_t pilot_phase);

#endif
