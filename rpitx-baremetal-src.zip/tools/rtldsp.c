/*
 * rtldsp.c - RTL-SDR samples -> rpitx v1 IQ samples (see rtldsp.h)
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#include "rtldsp.h"
#include <math.h>
#include <string.h>

#define FULL_SCALE	32767.0f
#define AGC_TARGET	0.5f		/* peak envelope after AGC, of full scale */
#define AGC_DECAY	0.99995f	/* per output sample: about 0.4 s */
#define AGC_MAX_GAIN	2000.0f
#define POWER_ALPHA	0.001f		/* level / squelch averaging */
#define SQUELCH_HYST	2.0f		/* 3 dB hysteresis (power ratio) */
#define FM_DEVIATION	5000.0f		/* narrow FM: 5 kHz -> audio 1.0 */
#define SSB_LOW_HZ	300.0f
#define SSB_HIGH_HZ	3000.0f

static float hamming (int i, int n)
{
	return 0.54f - 0.46f * cosf (2.0f * (float) M_PI * i / (n - 1));
}

void rtldsp_init (rtldsp_t *d, int decim, float cutoff_hz, float gain_db, float squelch_db,
		  int mode)
{
	memset (d, 0, sizeof *d);
	d->mode = mode;
	d->decim = decim;

	/* channel filter: windowed sinc low-pass (Hamming), length chosen for a
	   transition band of about 6 kHz whatever the input rate */
	float fs_in = (float) RTLDSP_OUT_RATE * decim;
	int n = (int) (3.3f * fs_in / 6000.0f) | 1;
	if (n > RTLDSP_MAX_TAPS) n = RTLDSP_MAX_TAPS;
	d->ntaps = n;

	float fc = cutoff_hz / fs_in;		/* normalised cutoff */
	float sum = 0.0f;
	for (int i = 0; i < n; i++) {
		float m = i - (n - 1) / 2.0f;
		float s = (m == 0.0f) ? 2.0f * fc : sinf (2.0f * (float) M_PI * fc * m) / ((float) M_PI * m);
		d->taps[i] = s * hamming (i, n);
		sum += d->taps[i];
	}
	for (int i = 0; i < n; i++)
		d->taps[i] /= sum;		/* unity gain at DC */

	/* FM -> SSB: low-pass prototype of half width (3000-300)/2, moved to the
	   centre of 300..3000 Hz: a complex filter passing positive audio
	   frequencies only, i.e. the upper side band of the voice */
	if (mode == RTLDSP_MODE_FM2SSB) {
		const int na = RTLDSP_AUDIO_TAPS;
		float half = (SSB_HIGH_HZ - SSB_LOW_HZ) / 2.0f / RTLDSP_OUT_RATE;
		float centre = (SSB_HIGH_HZ + SSB_LOW_HZ) / 2.0f / RTLDSP_OUT_RATE;
		float g = 0.0f;
		for (int i = 0; i < na; i++) {
			float m = i - (na - 1) / 2.0f;
			float s = (m == 0.0f) ? 2.0f * half : sinf (2.0f * (float) M_PI * half * m) / ((float) M_PI * m);
			s *= hamming (i, na);
			g += s;
			d->ssb_re[i] = s * cosf (2.0f * (float) M_PI * centre * m);
			d->ssb_im[i] = s * sinf (2.0f * (float) M_PI * centre * m);
		}
		for (int i = 0; i < na; i++) {	/* unity gain in the pass band */
			d->ssb_re[i] /= g;
			d->ssb_im[i] /= g;
		}
	}

	d->fixed_gain = gain_db > -100.0f ? powf (10.0f, gain_db / 20.0f) : 0.0f;
	d->agc_peak = 1e-3f;
	d->agc_target = AGC_TARGET;
	d->squelch_lin = squelch_db < 0.0f ? powf (10.0f, squelch_db / 10.0f) : 0.0f;
	d->squelch_open = d->squelch_lin == 0.0f;
	d->level_db = -100.0f;
}

float rtldsp_shift_hz (const rtldsp_t *d)
{
	return d->mode == RTLDSP_MODE_FM2SSB ? 0.0f : (float) RTLDSP_SHIFT_OUT_HZ;
}

/* (i, q) * j^k */
static inline void rotate (unsigned k, float *i, float *q)
{
	float a = *i, b = *q;
	switch (k & 3) {
	case 0: break;
	case 1: *i = -b; *q = a; break;
	case 2: *i = -a; *q = -b; break;
	case 3: *i = b; *q = -a; break;
	}
}

static inline int16_t clip16 (float x)
{
	if (x > FULL_SCALE) return 32767;
	if (x < -FULL_SCALE) return -32767;
	return (int16_t) lrintf (x);
}

static float agc_gain (rtldsp_t *d, float envelope)
{
	if (d->fixed_gain > 0.0f)
		return d->fixed_gain;
	if (envelope > d->agc_peak) d->agc_peak = envelope;
	else d->agc_peak *= AGC_DECAY;
	float g = d->agc_target / (d->agc_peak > 1e-6f ? d->agc_peak : 1e-6f);
	return g > AGC_MAX_GAIN ? AGC_MAX_GAIN : g;
}

int rtldsp_process (rtldsp_t *d, const uint8_t *in, int n_bytes, int16_t *out, int max_pairs)
{
	int produced = 0;
	const int n = d->ntaps;

	for (int k = 0; k + 1 < n_bytes; k += 2) {
		float i = (in[k] - 127.5f) * (1.0f / 128.0f);
		float q = (in[k + 1] - 127.5f) * (1.0f / 128.0f);
		rotate (d->rot_in++, &i, &q);

		/* store in the doubled circular history */
		d->hist_i[d->hpos] = d->hist_i[d->hpos + n] = i;
		d->hist_q[d->hpos] = d->hist_q[d->hpos + n] = q;
		if (++d->hpos == n) d->hpos = 0;

		if (++d->phase < d->decim)
			continue;
		d->phase = 0;

		/* FIR at the output rate only: hist[hpos .. hpos+n-1] is oldest..newest */
		const float *hi = &d->hist_i[d->hpos];
		const float *hq = &d->hist_q[d->hpos];
		float acc_i = 0.0f, acc_q = 0.0f;
		for (int t = 0; t < n; t++) {
			float c = d->taps[n - 1 - t];
			acc_i += c * hi[t];
			acc_q += c * hq[t];
		}

		/* level and squelch on the filtered channel */
		float p = acc_i * acc_i + acc_q * acc_q;
		d->power_avg += POWER_ALPHA * (p - d->power_avg);
		if (d->squelch_lin > 0.0f) {
			if (d->squelch_open && d->power_avg < d->squelch_lin / SQUELCH_HYST)
				d->squelch_open = 0;
			else if (!d->squelch_open && d->power_avg > d->squelch_lin)
				d->squelch_open = 1;
		}

		float out_i, out_q;
		if (d->mode == RTLDSP_MODE_FM2SSB) {
			/* FM discriminator: phase step between two channel samples */
			float re = acc_i * d->prev_i + acc_q * d->prev_q;
			float im = acc_q * d->prev_i - acc_i * d->prev_q;
			d->prev_i = acc_i;
			d->prev_q = acc_q;
			float audio = atan2f (im, re) * (RTLDSP_OUT_RATE / (2.0f * (float) M_PI * FM_DEVIATION));

			/* complex band-pass on the audio: analytic upper side band */
			const int na = RTLDSP_AUDIO_TAPS;
			d->hist_a[d->apos] = d->hist_a[d->apos + na] = audio;
			if (++d->apos == na) d->apos = 0;
			const float *ha = &d->hist_a[d->apos];
			float s_re = 0.0f, s_im = 0.0f;
			for (int t = 0; t < na; t++) {
				s_re += d->ssb_re[na - 1 - t] * ha[t];
				s_im += d->ssb_im[na - 1 - t] * ha[t];
			}

			float g = agc_gain (d, sqrtf (s_re * s_re + s_im * s_im));
			if (!d->squelch_open) g = 0.0f;
			out_i = s_re * g * FULL_SCALE;
			out_q = s_im * g * FULL_SCALE;
		} else {
			float g = agc_gain (d, sqrtf (p));
			if (!d->squelch_open) g = 0.0f;
			out_i = acc_i * g * FULL_SCALE;
			out_q = acc_q * g * FULL_SCALE;
			if (!d->no_out_shift)
				rotate (d->rot_out++, &out_i, &out_q);
		}

		if (produced < max_pairs) {
			out[2 * produced] = clip16 (out_i);
			out[2 * produced + 1] = clip16 (out_q);
			produced++;
		}
	}

	d->level_db = d->power_avg > 1e-12f ? 10.0f * log10f (d->power_avg) : -120.0f;
	return produced;
}

int rtldsp_wide (rtldsp_t *d, const uint8_t *in, int n_bytes, int16_t *out, int max_pairs)
{
	int n = n_bytes / 2;
	float power = 0;

	if (n > max_pairs)
		n = max_pairs;
	for (int k = 0; k < n; k++) {
		float i = in[2 * k] - 127.5f;
		float q = in[2 * k + 1] - 127.5f;
		float m2 = i * i + q * q;
		power += m2;
		/* limiter: constant amplitude, phase kept */
		float g = m2 > 1e-6f ? 32000.0f / sqrtf (m2) : 0.0f;
		if (g == 0.0f) {
			i = 1.0f;
			q = 0.0f;
			g = 32000.0f;
		}
		if (!d->no_out_shift && (d->rot_out++ & 1))	/* +Fs/2 */
			g = -g;
		out[2 * k] = (int16_t) lrintf (i * g);
		out[2 * k + 1] = (int16_t) lrintf (q * g);
	}
	if (n > 0) {
		/* same scale as rtldsp_process: full scale = 128 */
		float db = 10.0f * log10f (power / n / (128.0f * 128.0f) + 1e-12f);
		d->level_db = d->level_db == 0.0f ? db : 0.9f * d->level_db + 0.1f * db;
	}
	return n;
}

void rtldsp_out_shift (rtldsp_t *d, int16_t *iq, int n)
{
	if (d->mode == RTLDSP_MODE_FM2SSB)
		return;				/* no output shift in this mode */
	for (int k = 0; k < n; k++) {
		int16_t a = iq[2 * k], b = iq[2 * k + 1];
		unsigned r = d->rot_out++;
		if (d->mode == RTLDSP_MODE_WIDE) {
			if (r & 1) {		/* (-1)^n; -32768 never occurs (clip16, limiter) */
				iq[2 * k] = (int16_t) -a;
				iq[2 * k + 1] = (int16_t) -b;
			}
			continue;
		}
		switch (r & 3) {		/* same as rotate() */
		case 0: break;
		case 1: iq[2 * k] = (int16_t) -b; iq[2 * k + 1] = a; break;
		case 2: iq[2 * k] = (int16_t) -a; iq[2 * k + 1] = (int16_t) -b; break;
		case 3: iq[2 * k] = b; iq[2 * k + 1] = (int16_t) -a; break;
		}
	}
}

/* ---- rate matching */

#define RATE_KP		0.3		/* per second of fill error */
#define RATE_KI		0.03		/* per second^2 */
#define RATE_LP_S	0.5		/* fill level low-pass time constant */

void rtldsp_rate_init (rtldsp_rate_t *r)
{
	r->ratio = 1.0;
	r->ff = 1.0;
	r->fill_lp = 0.0;
	r->integ = 0.0;
	r->frac = 0.0f;
}

unsigned rtldsp_rate_need (const rtldsp_rate_t *r, unsigned n)
{
	return (unsigned) (n * r->ratio + r->frac) + 2;
}

void rtldsp_rate_run (rtldsp_rate_t *r, const int16_t *ring, unsigned ring_pairs,
		      unsigned *tail, int16_t *out, unsigned n)
{
	float frac = r->frac;
	float step = (float) r->ratio;
	unsigned t = *tail;
	for (unsigned k = 0; k < n; k++) {
		unsigned r0 = t % ring_pairs;
		unsigned r1 = r0 + 1 == ring_pairs ? 0 : r0 + 1;
		float i0 = ring[2 * r0], q0 = ring[2 * r0 + 1];
		out[2 * k] = (int16_t) (i0 + (ring[2 * r1] - i0) * frac);
		out[2 * k + 1] = (int16_t) (q0 + (ring[2 * r1 + 1] - q0) * frac);
		frac += step;
		while (frac >= 1.0f) {
			frac -= 1.0f;
			t++;
		}
	}
	*tail = t;
	r->frac = frac;
}

void rtldsp_rate_control (rtldsp_rate_t *r, double fill_err_s, double dt_s)
{
	double a = dt_s / RATE_LP_S;
	if (a > 1.0) a = 1.0;
	r->fill_lp += (fill_err_s - r->fill_lp) * a;
	r->integ += RATE_KI * r->fill_lp * dt_s;
	if (r->integ > 0.2) r->integ = 0.2;
	if (r->integ < -0.2) r->integ = -0.2;
	r->ratio = r->ff * (1.0 + RATE_KP * r->fill_lp + r->integ);
	if (r->ratio > RTLDSP_RATE_MAX) r->ratio = RTLDSP_RATE_MAX;
	if (r->ratio < RTLDSP_RATE_MIN) r->ratio = RTLDSP_RATE_MIN;
}
