/*
 * fmrx_dsp.h - demodulateur FM large bande (radiodiffusion), mono ou stereo
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Entree : octets I,Q non signes d'une cle RTL-SDR a 1 024 kS/s, accordee FMRX_TUNE_OFFSET
 * au-dessus de la station (la station est a -Fs/4 : ramenee a 0 par une simple permutation
 * de I/Q, et la composante continue du recepteur tombe hors du canal).
 * Chaine : -> 512 k (demi-bande) -> 256 k (demi-bande, stations voisines eliminees)
 *          -> discriminateur (atan2) -> signal multiplex (MPX) normalise (75 kHz = 1)
 *          -> pilote 19 kHz (boucle a verrouillage de phase), L-R a 38 kHz
 *          -> 64 k (desaccentuation) -> 32 k (filtres audio) -> matrice L/R -> int16
 */
#ifndef FMRX_DSP_H
#define FMRX_DSP_H

#include <stdint.h>
#include "rds.h"

#define FMRX_IN_RATE		1024000
#define FMRX_MPX_RATE		256000
#define FMRX_OUT_RATE		32000
#define FMRX_TUNE_OFFSET	(FMRX_IN_RATE / 4)	/* Hz au-dessus de la station */
#define FMRX_DEVIATION		75000.0f

/* mode de demodulation (champ .mode) */
#define FMRX_MODE_FM	0
#define FMRX_MODE_AM	1
#define FMRX_MODE_USB	2
#define FMRX_MODE_LSB	3

#define FMRX_HILB_N	31		/* BLU : longueur du filtre de Hilbert (impair) */
#define FMRX_AUD_N	95		/* AM/BLU : filtre de canal audio a 32 kHz (impair) */

#define FMRX_HB1_N	15
#define FMRX_HB2_N	43
#define FMRX_A1_N	39
#define FMRX_A2_N	127
/* demi-bandes (longueur N = 4 L - 1) : L echantillons d'indice impair dans les prises
   non nulles, l'echantillon central (d'indice pair) retarde de D = L - 1 */
#define FMRX_HB1_L	((FMRX_HB1_N + 1) / 2)
#define FMRX_HB2_L	((FMRX_HB2_N + 1) / 2)
#define FMRX_HB2_D	(FMRX_HB2_L / 2)

typedef struct {
	/* reglages (modifiables entre deux appels) */
	int   stereo_enable;		/* 0 : toujours mono */
	int   mode;			/* FMRX_MODE_* : demodulation (FM par defaut) */
	float deemph_alpha;		/* fmrx_set_deemphasis () */
	float volume;			/* 1.0 : excursion de 75 kHz -> pleine echelle */

	/* mesures, mises a jour par fmrx_process () */
	float level_dbfs;		/* puissance d'entree I/Q (0 dB : pleine echelle) */
	float clip_ratio;		/* part des octets a 0 ou 255 (saturation) */
	float pilot_level;		/* amplitude du pilote / excursion (9 % nominal) */
	int   stereo;			/* stereo active (pilote verrouille) */
	float audio_peak;		/* crete de sortie, 1.0 = pleine echelle */

	/* etat interne (les lignes a retard sont doublees : la fenetre est toujours contigue ;
	   I/Q et M/S entrelaces) */
	float lut[256];
	float hb1_o[2 * 2 * FMRX_HB1_L];	/* demi-bande 1 : echantillons d'indice impair */
	float hb1_e[2 * 4];			/* ... et les 4 derniers d'indice pair */
	int   hb1_pos, hb1_epos;
	float hb2_o[2 * 2 * FMRX_HB2_L];
	float hb2_e[2 * FMRX_HB2_D];
	int   hb2_pos, hb2_epos;
	uint8_t pend[8];			/* octets en attente (appels non multiples de 8) */
	int   npend;
	float prev_i, prev_q;
	uint32_t pll_phase;
	float pll_integ;
	float pilot_lp;
	float a1[2 * 2 * FMRX_A1_N];		/* M, S entrelaces */
	int   a1_pos, a1_ph;
	float a2[2 * 2 * FMRX_A2_N];
	int   a2_pos, a2_ph;
	float de_l, de_r;		/* desaccentuation de M et S, a 64 kHz */
	float am_dc;			/* AM : continu de l'enveloppe (retire la porteuse) */
	float hil[2 * 2 * FMRX_HILB_N];	/* BLU : fenetre I/Q (retard de I + Hilbert de Q) */
	int   hil_pos;
	float aud[2 * 2 * FMRX_AUD_N];	/* AM/BLU : fenetre du filtre de canal audio */
	int   aud_pos;
	float peak_acc;
	uint32_t peak_n;

	int   rds_enable;		/* decodage RDS (lecture dans .rds) */
	rds_t rds;
} fmrx_t;

void fmrx_init (fmrx_t *f);
/* constante de temps de desaccentuation : 50 us (Europe) ou 75 us (Ameriques) */
void fmrx_set_deemphasis (fmrx_t *f, float us);
/* n_bytes octets I,Q -> trames L,R (int16) a 32 kHz ; renvoie le nombre de trames
   (n_bytes / 64 au plus) */
int fmrx_process (fmrx_t *f, const uint8_t *in, int n_bytes, int16_t *out_lr, int max_frames);

#endif
