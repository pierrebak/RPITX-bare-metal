/*
 * classify.c - reconnaissance de modulation (voir classify.h)
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "classify.h"

const char *mod_name (mod_t m)
{
	switch (m) {
	case MOD_NOISE:   return "bruit";
	case MOD_CARRIER: return "porteuse";
	case MOD_AM:      return "AM";
	case MOD_FM:      return "FM";
	case MOD_SSB:     return "BLU";
	case MOD_CW:      return "CW/OOK";
	case MOD_FSK:     return "FSK";
	case MOD_DIGITAL: return "NUM";
	default:          return "?";
	}
}

mod_t classify (fft_t *fft, const float *re, const float *im, int n, float *conf)
{
	return classify_dbg (fft, re, im, n, conf, 0, 0);
}

mod_t classify_dbg (fft_t *fft, const float *re, const float *im, int n,
		    float *conf, char *dbg, int dbglen)
{
	if (conf) *conf = 0.3f;
	if (dbg && dbglen) dbg[0] = 0;

	/* --- enveloppe et puissance --- */
	float *a = malloc (sizeof (float) * n);
	if (!a) return MOD_UNKNOWN;
	double sp = 0.0, sa = 0.0;
	for (int i = 0; i < n; i++) {
		float p = re[i] * re[i] + im[i] * im[i];
		a[i] = sqrtf (p);
		sp += p;
		sa += a[i];
	}
	float pmean = (float) (sp / n);
	float amean = (float) (sa / n);
	if (pmean < 1e-5f) {					/* trop faible */
		if (dbg && dbglen) snprintf (dbg, dbglen, "p=%.1e (faible)", pmean);
		free (a); return MOD_NOISE;
	}

	/* variation d'enveloppe (coefficient de variation) et taux de "silence" */
	double va = 0.0; int off = 0;
	for (int i = 0; i < n; i++) {
		float d = a[i] - amean;
		va += d * d;
		if (a[i] < 0.25f * amean) off++;
	}
	float gamma = amean > 0 ? sqrtf ((float) (va / n)) / amean : 0.0f;
	float off_frac = (float) off / n;

	/* --- frequence instantanee (sur les echantillons "actifs") ---
	   On mesure aussi |f[i]-f[i-1]| (variation d'un echantillon a l'autre) :
	   FSK = frequence constante par paliers -> variation quasi nulle sauf aux
	   transitions ; FM = frequence qui varie en continu -> variation soutenue. */
	double sf = 0.0, sff = 0.0; int nf = 0;
	int hist[32]; for (int i = 0; i < 32; i++) hist[i] = 0;
	for (int i = 1; i < n; i++) {
		if (a[i] < 0.3f * amean || a[i - 1] < 0.3f * amean)
			continue;			/* ignore les creux (bruit de phase) */
		float d = atan2f (im[i] * re[i - 1] - re[i] * im[i - 1],
				  re[i] * re[i - 1] + im[i] * im[i - 1]);	/* rad/ech */
		sf += d; sff += d * d; nf++;
		int b = (int) ((d / 3.14159265f + 1.0f) * 16.0f);
		if (b < 0) b = 0;
		if (b > 31) b = 31;
		hist[b]++;
	}
	float fmean = nf > 0 ? (float) (sf / nf) : 0.0f;
	float fstd = nf > 0 ? sqrtf ((float) (sff / nf) - fmean * fmean) : 0.0f;

	/* concentration : part des 2 classes de frequence les plus peuplees.
	   FSK = 2 frequences discretes -> forte ; FM = etalee -> faible. */
	int h1 = 0, h2 = 0;
	for (int b = 0; b < 32; b++) {
		if (hist[b] > h1) { h2 = h1; h1 = hist[b]; }
		else if (hist[b] > h2) h2 = hist[b];
	}
	float top2 = nf > 0 ? (float) (h1 + h2) / nf : 0.0f;

	/* --- analyse spectrale : symetrie (BLU), occupation et platitude (numerique) --- */
	float *fr = malloc (sizeof (float) * n);
	float *fi = malloc (sizeof (float) * n);
	float asym = 0.0f, occ = 0.0f, flat = 0.0f;
	if (fr && fi && n == fft->n) {
		for (int i = 0; i < n; i++) { fr[i] = re[i]; fi[i] = im[i]; }
		fft_run (fft, fr, fi);
		double pu = 0.0, pl = 0.0;		/* bins positifs vs negatifs */
		for (int k = 1; k < n / 2; k++) {
			pu += fr[k] * fr[k] + fi[k] * fi[k];		/* freq > 0 */
			pl += fr[n - k] * fr[n - k] + fi[n - k] * fi[n - k];	/* freq < 0 */
		}
		if (pu + pl > 0) asym = (float) (fabs (pu - pl) / (pu + pl));

		/* puissance par bin, crete, puis occupation et platitude spectrale.
		   La platitude (moyenne geometrique / moyenne arithmetique) vaut ~1 pour
		   un spectre plat (OFDM/numerique, bruit) et <<1 pour un spectre pointu. */
		double pmax = 0.0, psum = 0.0, plog = 0.0;
		int occn = 0, tot = 0;
		for (int k = 1; k < n; k++) {
			if (k == n / 2) continue;
			float pk = fr[k] * fr[k] + fi[k] * fi[k];
			if (pk > pmax) pmax = pk;
		}
		for (int k = 1; k < n; k++) {
			if (k == n / 2) continue;
			float pk = fr[k] * fr[k] + fi[k] * fi[k];
			tot++;
			if (pk > pmax * 0.01) {			/* bin occupe (> -20 dB) */
				occn++;
				psum += pk;			/* platitude sur les bins occupes */
				plog += log ((double) pk);
			}
		}
		if (tot > 0) occ = (float) occn / tot;
		if (occn > 0) {
			double am = psum / occn;
			double gm = exp (plog / occn);
			flat = am > 0 ? (float) (gm / am) : 0.0f;
		}
	}
	free (fr); free (fi);
	free (a);

	/* --- arbre de decision --- */
	mod_t m = MOD_UNKNOWN;
	float c = 0.5f;
	if (off_frac > 0.15f && fstd < 0.15f) {
		m = MOD_CW; c = 0.7f;			/* enveloppe tout-ou-rien, freq stable */
	} else if (asym > 0.55f && gamma > 0.15f) {
		m = MOD_SSB; c = 0.65f;			/* spectre asymetrique = une seule bande */
	} else if (occ > 0.6f && flat > 0.5f) {
		m = MOD_DIGITAL; c = 0.6f;		/* large + plat = numerique (OFDM, DAB, TV) */
	} else if (fstd > 0.25f) {			/* frequence tres etalee */
		if (top2 > 0.6f) { m = MOD_FSK; c = 0.7f; }	/* 2 freq discretes = FSK */
		else { m = MOD_FM; c = 0.7f; }			/* etale = FM */
	} else if (gamma > 0.25f) {
		m = MOD_AM; c = 0.6f;			/* enveloppe variable, freq stable */
	} else {
		m = MOD_CARRIER; c = 0.5f;		/* enveloppe et freq stables */
	}
	if (conf) *conf = c;
	if (dbg && dbglen)
		snprintf (dbg, dbglen, "gam=%.2f off=%.2f fstd=%.2f top2=%.2f asym=%.2f occ=%.2f flat=%.2f p=%.1e",
			  gamma, off_frac, fstd, top2, asym, occ, flat, pmean);
	return m;
}
