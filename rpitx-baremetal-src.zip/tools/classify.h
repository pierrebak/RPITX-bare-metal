/*
 * classify.h - reconnaissance sommaire de la modulation d'un signal
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * A partir d'un bloc de bande de base complexe (le signal ramene autour de 0),
 * on extrait quelques indicateurs simples (variation d'enveloppe, etalement de
 * la frequence instantanee, symetrie du spectre, taux de silence) et on en
 * deduit une famille de modulation. Methode statistique, volontairement simple :
 * fiable sur un signal fort et propre, "indetermine" sinon.
 */
#ifndef CLASSIFY_H
#define CLASSIFY_H

#include "fft.h"

typedef enum {
	MOD_UNKNOWN = 0,
	MOD_NOISE,		/* pas de signal */
	MOD_CARRIER,		/* porteuse pure (non modulee) */
	MOD_AM,
	MOD_FM,
	MOD_SSB,
	MOD_CW,			/* manipulation tout-ou-rien d'une porteuse (Morse) */
	MOD_FSK,
	MOD_DIGITAL		/* large bande plat : OFDM/numerique (DAB, TV, ...) */
} mod_t;

const char *mod_name (mod_t m);

/* classe un bloc complexe (re/im, n echantillons, n == fft->n).
   fft sert a la mesure de symetrie spectrale. conf (0..1) : confiance. */
mod_t classify (fft_t *fft, const float *re, const float *im, int n, float *conf);

/* idem, mais remplit dbg avec les indicateurs calcules (diagnostic). */
mod_t classify_dbg (fft_t *fft, const float *re, const float *im, int n,
		    float *conf, char *dbg, int dbglen);

#endif
