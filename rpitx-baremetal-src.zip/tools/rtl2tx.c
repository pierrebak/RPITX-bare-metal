/*
 * rtl2tx.c - receive with an RTL-SDR dongle and retransmit with rpitx v1
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Bare metal equivalent of the Linux pipeline
 *     rtl_sdr ... - | (filter, decimate) | rpitx -m IQ -i - ...
 * which rpitx v1 cannot do itself on bare metal (no pipes, no threads).
 * The dongle is read asynchronously from the rpitx transmit loop through a
 * polling hook; the channel is filtered, decimated to 48 kS/s and given to
 * pitx_run() in IQ mode (see tools/rtldsp.h for the frequency plan).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <bm_compat.h>
#include "rtl-sdr.h"
#include "rtl-sdr-bm.h"
#include "convenience/convenience.h"
#include "../rpitx/RpiTx.h"
#include "rtldsp.h"

#define RING_MAX_PAIRS		300000		/* 1 s at the highest rate */
#define USB_BUF_NUM		6
#define USB_BUF_LEN		8192				/* 17 ms at 240 kS/s */
#define STATS_INTERVAL_US	5000000

static rtlsdr_dev_t *s_dev;
static rtldsp_t s_dsp;
static int16_t *s_ring;
static unsigned s_head, s_tail;		/* free running pair counters */
static unsigned s_ring_pairs;		/* ring size: 1 s at s_out_rate */
static unsigned s_out_rate;		/* rate of the samples given to rpitx */
static unsigned s_overruns;
static unsigned s_waits;
static int s_hook = -1;
static uint64_t s_last_stats;

/* Rate matching. The transmitter does not consume exactly s_out_rate samples
   per second (DMA timing calibrated at start, rounded to whole DMA steps;
   slower if the CPU cannot keep up), while the dongle delivers exactly its
   rate: the ring would fill up (overruns) or run dry (waits). The samples
   given to rpitx are interpolated at s_rate.ratio input samples per output
   sample, the ratio being adjusted so that the ring stays TARGET_FILL_S full
   (it settles at dongle rate / real transmit rate). */
#define TARGET_FILL_S		0.25
static rtldsp_rate_t s_rate;
static int s_resample = 1;
static uint64_t s_pulled;			/* samples given to rpitx */
static int s_warned;				/* CPU warning printed */
static uint64_t s_pull_start_us;
static int16_t s_tmp[2 * (USB_BUF_LEN / 2 / 5 + 8)];

static void rtl_callback (unsigned char *buf, uint32_t len, void *ctx)
{
	(void) ctx;
	uint32_t done = 0;
	while (done < len) {
		uint32_t chunk = len - done;
		/* bound the number of output pairs per call to the temp buffer */
		int wide = s_dsp.mode == RTLDSP_MODE_WIDE;
		uint32_t max_in = (sizeof s_tmp / sizeof s_tmp[0] / 2) * (wide ? 1 : s_dsp.decim) * 2;
		if (chunk > max_in) chunk = max_in;
		int n = wide ? rtldsp_wide (&s_dsp, buf + done, chunk, s_tmp,
					    sizeof s_tmp / sizeof s_tmp[0] / 2)
			     : rtldsp_process (&s_dsp, buf + done, chunk, s_tmp,
					       sizeof s_tmp / sizeof s_tmp[0] / 2);
		done += chunk;
		for (int k = 0; k < n; k++) {
			if (s_head - s_tail >= s_ring_pairs) {	/* full: drop oldest */
				s_tail++;
				s_overruns++;
			}
			unsigned w = s_head % s_ring_pairs;
			s_ring[2 * w] = s_tmp[2 * k];
			s_ring[2 * w + 1] = s_tmp[2 * k + 1];
			s_head++;
		}
	}
}

static void pump (void *ctx)
{
	(void) ctx;
	if (s_dev)
		rtlsdr_poll_async (s_dev);
}

static void print_stats (void)
{
	uint64_t now = bm_micros ();
	if (now - s_last_stats < STATS_INTERVAL_US)
		return;
	s_last_stats = now;
	printf ("RX %.1f dBFS%s, buffer %u ms, overruns %u, waits %u\n",
		s_dsp.level_db,
		s_dsp.squelch_lin > 0.0f ? (s_dsp.squelch_open ? " (squelch open)" : " (squelch closed)") : "",
		(unsigned) ((uint64_t) (s_head - s_tail) * 1000 / s_out_rate), s_overruns, s_waits);
	/* transmitter side, see pitx_stats in rpitx/RpiTx.h */
	uint64_t dt = now - pitx_stats.start_us;
	if (pitx_stats.start_us != 0 && dt > 0) {
		double pull = now > s_pull_start_us
			      ? (double) s_pulled * 1000.0 / (double) (now - s_pull_start_us) : 0.0;
		printf ("TX DMA %.2f kS/s, taken %.2f kS/s (nominal %.2f), ratio %.4f, CPU %u%%, DMA underruns %u\n",
			(double) pitx_stats.dma_samples * 1000.0 / (double) dt, pull,
			s_out_rate / 1000.0, s_resample ? s_rate.ratio : 1.0,
			(unsigned) (pitx_stats.busy_us * 100 / dt), (unsigned) pitx_stats.underruns);
		if (pitx_stats.underruns > 0 && !s_warned) {
			s_warned = 1;
			printf ("Warning: the CPU does not keep up with %u S/s (DMA underruns): "
				"distorted output, try a lower rate (see txbench)\n", s_out_rate);
		}
	}
}

/* pitx_run() input: blocks until enough IQ pairs are available */
static ssize_t read_wrapper (void *buffer, size_t count)
{
	unsigned pairs = count / 4;
	int16_t *out = buffer;
	/* input pairs used by this call (+1 for the interpolation) */
	unsigned need = s_resample ? rtldsp_rate_need (&s_rate, pairs) : pairs;

	if (s_pull_start_us == 0)
		s_pull_start_us = bm_micros ();
	if (s_head - s_tail < need)
		s_waits++;
	while (s_head - s_tail < need) {
		if (rtlsdr_poll_async (s_dev) < 0) {
			fprintf (stderr, "RTL-SDR: device lost\n");
			return 0;			/* ends pitx_run() */
		}
		bm_poll ();
	}

	if (!s_resample) {
		for (unsigned k = 0; k < pairs; k++) {
			unsigned r = (s_tail + k) % s_ring_pairs;
			out[2 * k] = s_ring[2 * r];
			out[2 * k + 1] = s_ring[2 * r + 1];
		}
		s_tail += pairs;
	} else {
		rtldsp_rate_run (&s_rate, s_ring, s_ring_pairs, &s_tail, out, pairs);
		rtldsp_out_shift (&s_dsp, out, pairs);

		/* real rate of the transmitter, once known (200 ms of transmission,
		   1 sample resolution: 20 ppm, better and better afterwards):
		   rpitx converts phase steps to Hz with it, the output shift (a
		   fraction of that rate) is corrected (see pitx_iq_rate), and the
		   resampling ratio follows it */
		uint64_t span = pitx_stats.last_us - pitx_stats.start_us;
		if (pitx_stats.start_us != 0 && pitx_stats.last_us > pitx_stats.start_us &&
		    span > 200000 && pitx_stats.underruns == 0) {
			double c = (double) pitx_stats.dma_samples * 1e6 / (double) span;
			if (pitx_iq_rate == 0) {
				/* first estimate: what accumulated since the start at the
				   wrong ratio is dropped once (no slow recovery) */
				unsigned target = (unsigned) (s_out_rate * TARGET_FILL_S);
				if (s_head - s_tail > target + s_out_rate / 20)
					s_tail = s_head - target;
			}
			pitx_iq_rate = c;
			s_rate.ff = s_out_rate / c;
			pitx_iq_offset_hz = s_dsp.mode == RTLDSP_MODE_WIDE ? (c - s_out_rate) / 2.0
					  : s_dsp.mode == RTLDSP_MODE_FM2SSB ? 0.0
					  : (c - s_out_rate) / 4.0;
		}

		/* fill level control, once per block */
		rtldsp_rate_control (&s_rate, (double) (s_head - s_tail) / s_out_rate - TARGET_FILL_S,
				     (double) pairs / s_out_rate);
	}
	s_pulled += pairs;

	print_stats ();
	return count;
}

static void reset_wrapper (void)
{
}

static void cleanup (void)
{
	if (s_hook >= 0) {
		bm_remove_poll_hook (s_hook);
		s_hook = -1;
	}
	if (s_dev) {
		rtlsdr_stop_async (s_dev);
		rtlsdr_close (s_dev);
		s_dev = NULL;
	}
}

static void usage (void)
{
	fprintf (stderr,
		"rtl2tx, RTL-SDR receiver -> rpitx v1 transmitter (bare metal)\n\n"
		"Usage: rtl2tx -r rx_freq -f tx_freq_khz [options]\n"
		"\t-r rx_freq    receive frequency in Hz (suffix k, M allowed: 145.5M)\n"
		"\t-f tx_khz     transmit frequency in kHz (as rpitx -f)\n"
		"\t[-m mode]     relay (default): retransmit the channel as is\n"
		"\t              fm2ssb: demodulate narrow FM, transmit the voice in USB\n"
		"\t              wide: whole band at the dongle rate (default 250000),\n"
		"\t                    for wide FM broadcast, like rpitx v2 transponder\n"
		"\t[-d index]    dongle index (default 0)\n"
		"\t[-g gain]     RTL tuner gain in dB (default: automatic)\n"
		"\t[-P ppm]      RTL frequency correction (default 0)\n"
		"\t[-p ppm]      rpitx PLL correction (default 0)\n"
		"\t[-s rate]     RTL sample rate: 240000 (default) or 288000;\n"
		"\t              wide mode: 240000 to 300000 (default 250000)\n"
		"\t[-w hz]       channel half width (default 12000, max 18000)\n"
		"\t[-G db]       fixed output gain in dB (default: AGC)\n"
		"\t[-q dbfs]     squelch level in dBFS, e.g. -40 (default: off)\n"
		"\t[-c 1]        transmit on GPIO 4 (pin 7) instead of GPIO 18\n"
		"\t[-R 0]        no rate matching (samples given as received)\n"
		"Ctrl-C or ESC stops.\n");
	exit (1);
}

int rtl2tx_main (int argc, char **argv)
{
	int opt;
	uint32_t rx_freq = 0;
	double tx_khz = 0;
	int dev_index = 0;
	int gain = 0;			/* tenths of dB, 0 = auto */
	int have_gain = 0;
	int rx_ppm = 0;
	float tx_ppm = 0;
	uint32_t rate = 0;
	float width = 12000;
	float out_gain_db = -200;
	float squelch_db = 0;
	char *rpitx_extra = NULL;
	int mode = RTLDSP_MODE_RELAY;

	s_dev = NULL;
	s_head = s_tail = 0;
	s_overruns = s_waits = 0;
	s_hook = -1;
	s_last_stats = bm_micros ();
	rtldsp_rate_init (&s_rate);
	s_resample = 1;
	s_warned = 0;
	s_pulled = 0;
	s_pull_start_us = 0;

	while ((opt = getopt (argc, argv, "r:f:m:d:g:P:p:s:w:G:q:c:R:h")) != -1) {
		switch (opt) {
		case 'r': rx_freq = (uint32_t) atofs (optarg); break;
		case 'f': tx_khz = atof (optarg); break;
		case 'm':
			if (strcmp (optarg, "relay") == 0) mode = RTLDSP_MODE_RELAY;
			else if (strcmp (optarg, "fm2ssb") == 0) mode = RTLDSP_MODE_FM2SSB;
			else if (strcmp (optarg, "wide") == 0) mode = RTLDSP_MODE_WIDE;
			else usage ();
			break;
		case 'd': dev_index = atoi (optarg); break;
		case 'g': gain = (int) (atof (optarg) * 10); have_gain = 1; break;
		case 'P': rx_ppm = atoi (optarg); break;
		case 'p': tx_ppm = atof (optarg); break;
		case 's': rate = (uint32_t) atofs (optarg); break;
		case 'w': width = atof (optarg); break;
		case 'G': out_gain_db = atof (optarg); break;
		case 'q': squelch_db = atof (optarg); break;
		case 'c': rpitx_extra = optarg; break;
		case 'R': s_resample = atoi (optarg) != 0; break;
		default: usage ();
		}
	}
	if (rx_freq == 0 || tx_khz <= 0)
		usage ();
	if (rate == 0)
		rate = mode == RTLDSP_MODE_WIDE ? 250000 : 240000;
	if (mode == RTLDSP_MODE_WIDE) {
		if (rate < 240000 || rate > 300000) {
			fprintf (stderr, "Sample rate must be 240000..300000 in wide mode\n");
			exit (1);
		}
	} else if (rate != 240000 && rate != 288000) {
		fprintf (stderr, "Sample rate must be 240000 or 288000\n");
		exit (1);
	}
	if (width < 1000 || width > 18000) {
		fprintf (stderr, "Channel half width must be 1000..18000 Hz\n");
		exit (1);
	}

	if (s_ring == NULL)
		s_ring = malloc (RING_MAX_PAIRS * 2 * sizeof (int16_t));
	if (s_ring == NULL) {
		fprintf (stderr, "Out of memory\n");
		exit (1);
	}

	if (mode == RTLDSP_MODE_WIDE) {
		rtldsp_init (&s_dsp, 5, width, out_gain_db, 0, RTLDSP_MODE_RELAY);
		s_dsp.mode = RTLDSP_MODE_WIDE;
		s_out_rate = rate;
		if (squelch_db != 0)
			fprintf (stderr, "Note: no squelch in wide mode\n");
	} else {
		rtldsp_init (&s_dsp, rate / RTLDSP_OUT_RATE, width, out_gain_db, squelch_db, mode);
		s_out_rate = RTLDSP_OUT_RATE;
	}
	s_ring_pairs = s_out_rate;		/* 1 s */
	s_dsp.no_out_shift = s_resample;	/* shift after the interpolation */

	/* ---- receiver */
	bm_add_cleanup (cleanup);
	if (rtlsdr_get_device_count () == 0) {
		fprintf (stderr, "No RTL-SDR dongle found (plug it in before running rtl2tx)\n");
		exit (1);
	}
	if (rtlsdr_open (&s_dev, dev_index) < 0) {
		fprintf (stderr, "Failed to open rtlsdr device #%d\n", dev_index);
		s_dev = NULL;
		exit (1);
	}
	verbose_set_sample_rate (s_dev, rate);
	/* tune a quarter of the sample rate above: DC offset out of the channel
	   (wide mode: on the frequency, the whole band is used, as in rpitx v2) */
	verbose_set_frequency (s_dev, mode == RTLDSP_MODE_WIDE ? rx_freq : rx_freq + rate / 4);
	if (have_gain) {
		gain = nearest_gain (s_dev, gain);
		verbose_gain_set (s_dev, gain);
	} else {
		verbose_auto_gain (s_dev);
	}
	verbose_ppm_set (s_dev, rx_ppm);
	verbose_reset_buffer (s_dev);

	if (rtlsdr_start_async (s_dev, rtl_callback, NULL, USB_BUF_NUM, USB_BUF_LEN) < 0) {
		fprintf (stderr, "Failed to start streaming\n");
		exit (1);
	}
	s_hook = bm_add_poll_hook (pump, NULL);

	if (mode == RTLDSP_MODE_WIDE)
		printf ("Receiving %u Hz, whole %u kHz band, waiting for samples...\n",
			(unsigned) rx_freq, (unsigned) (rate / 1000));
	else
		printf ("Receiving %u Hz, %d taps filter, waiting for samples...\n",
			(unsigned) rx_freq, s_dsp.ntaps);
	uint64_t start = bm_micros ();
	while (s_head - s_tail < (unsigned) (s_out_rate * TARGET_FILL_S)) {	/* 250 ms */
		if (rtlsdr_poll_async (s_dev) < 0 || bm_micros () - start > 3000000) {
			fprintf (stderr, "No samples from the dongle\n");
			exit (1);
		}
		bm_poll ();
	}

	/* ---- transmitter: rpitx v1 IQ mode, -f corrected for the IQ shift
	   (see pitx_iq_set_frequency in rpitx/pitx_freq.c) */
	double shift = mode == RTLDSP_MODE_WIDE ? rate / 2.0 : rtldsp_shift_hz (&s_dsp);
	double set_khz = pitx_iq_set_frequency (tx_khz * 1000.0, shift) / 1000.0;
	int h = pitx_harmonic_for (set_khz * 1000.0);
	printf ("Transmitting %s on %.3f kHz (rpitx tuned to %.3f kHz)\n",
		mode == RTLDSP_MODE_FM2SSB ? "USB voice"
		: mode == RTLDSP_MODE_WIDE ? "the whole band (FM only)" : "the channel", tx_khz, set_khz);
	if (h > 1)
		printf ("Note: above %d MHz the output is harmonic %d of %.3f kHz (weaker)\n",
			bm_plld_mhz / 4, h, tx_khz / h);

	pitx_reset_state ();
	pitx_quiet_stats = 1;
	if (rpitx_extra != NULL) {
		/* same meaning as "rpitx -c 1": the clock output pin */
		extern int UsePCMClk;
		UsePCMClk = atoi (rpitx_extra);
	}
	pitx_run (MODE_IQ, s_out_rate, (float) set_khz, tx_ppm, 0,
		  read_wrapper, reset_wrapper, NULL, 0);

	return 0;
}
