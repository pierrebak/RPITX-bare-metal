/*
 * rtlwf.c - waterfall + spectre en temps reel avec une cle RTL-SDR
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Affiche ~0,9 MHz autour de la frequence reglee : en haut le spectre
 * instantane (trace), en dessous un waterfall colore qui defile (circulaire :
 * une seule ligne redessinee par image, donc tres leger sur le Pi 1).
 * Fleches : frequence ; +/- : echelle ; Echap : quitter.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <math.h>
#include <bm_compat.h>
#include "rtl-sdr.h"
#include "rtl-sdr-bm.h"
#include "convenience/convenience.h"
#include "fft.h"
#include "scan.h"

#define RATE		1024000		/* 1 MHz de span, debit stable */
#define FFTN		1024		/* 1 kHz par bin */
#define USB_BUF_NUM	6
#define USB_BUF_LEN	16384
#define BIN_LO		(FFTN / 20)		/* bins affiches : 5 % .. 95 % */
#define BIN_HI		(FFTN - FFTN / 20)
#define DC_HALF		2

#define SPEC_TOP	36		/* ligne 1 : statut, ligne 2 : echelle de freq */
#define SPEC_H		60		/* hauteur du spectre */
#define RULER_Y		(SPEC_TOP + SPEC_H + 1)	/* graduations (traits verticaux) */
#define RULER_H		6
#define WF_TOP		(RULER_Y + RULER_H + 2)

static rtlsdr_dev_t *s_dev;
static volatile int s_quit;
static uint8_t  s_cap[FFTN * 2];
static volatile int s_cap_len, s_done, s_skip;

static fft_t s_fft;
static float s_pdb[FFTN];

static int s_gains[64], s_ngains, s_gidx;

static int W, H, WFH;			/* dimensions ecran et waterfall */
static int s_prev_y[2048];		/* trace du spectre (effacement rapide) */
static int s_wf_pos;			/* ligne courante du waterfall (circulaire) */
static int s_secs_left = 0;		/* compte a rebours avant sortie auto */

#define WF_TIMEOUT_US	60000000ULL	/* sortie auto apres 60 s (evite le reboot) */

static void rtl_callback (unsigned char *buf, uint32_t len, void *ctx)
{
	(void) ctx;
	if (s_done) return;
	if (s_skip > 0) { s_skip--; return; }
	int n = (int) len, cap = (int) sizeof s_cap;
	if (s_cap_len + n > cap) n = cap - s_cap_len;
	memcpy (s_cap + s_cap_len, buf, n);
	s_cap_len += n;
	if (s_cap_len >= cap) s_done = 1;
}

static void on_sigint (int sig) { (void) sig; s_quit = 1; }
static void cleanup (void)
{
	if (s_dev) { rtlsdr_stop_async (s_dev); rtlsdr_close (s_dev); s_dev = NULL; }
}

static int wf_nearest_gain (int tenths)
{
	int best = 0;
	for (int i = 1; i < s_ngains; i++)
		if (abs (s_gains[i] - tenths) < abs (s_gains[best] - tenths)) best = i;
	return best;
}
static void wf_set_gain (int idx)
{
	if (idx < 0) idx = 0;
	if (idx >= s_ngains) idx = s_ngains - 1;
	s_gidx = idx;
	rtlsdr_set_tuner_gain (s_dev, s_gains[idx]);
}

/* dB -> couleur : noir -> bleu -> cyan -> vert -> jaune -> rouge -> blanc */
static unsigned heat (float v)			/* v dans [0,1] */
{
	if (v < 0) v = 0; if (v > 1) v = 1;
	int r, g, b;
	if (v < 0.2f)      { float t = v / 0.2f;        r = 0;              g = 0;              b = (int) (40 + 215 * t); }
	else if (v < 0.4f) { float t = (v - 0.2f) / 0.2f; r = 0;            g = (int) (255 * t); b = 255; }
	else if (v < 0.6f) { float t = (v - 0.4f) / 0.2f; r = 0;            g = 255;             b = (int) (255 * (1 - t)); }
	else if (v < 0.8f) { float t = (v - 0.6f) / 0.2f; r = (int) (255 * t); g = 255;          b = 0; }
	else               { float t = (v - 0.8f) / 0.2f; r = 255;         g = (int) (255 - 100 * t); b = (int) (200 * t); }
	return bm_fb_color (r, g, b);
}

static void draw_frame (double center_mhz, float dmin, float drange)
{
	fft_power_u8 (&s_fft, s_cap, s_pdb);
	for (int d = -DC_HALF; d <= DC_HALF; d++)	/* masque la raie continue */
		s_pdb[FFTN / 2 + d] = s_pdb[FFTN / 2 - DC_HALF - 1];

	int wf_row = WF_TOP + s_wf_pos;
	unsigned black = bm_fb_color (0, 0, 0);
	unsigned white = bm_fb_color (255, 255, 255);

	for (int x = 0; x < W; x++) {
		int bin = BIN_LO + x * (BIN_HI - BIN_LO) / W;
		float db = s_pdb[bin];
		float v = (db - dmin) / drange;

		/* spectre (trace) : efface l'ancien point, dessine le nouveau */
		int y = SPEC_TOP + SPEC_H - 1 - (int) (v * (SPEC_H - 1));
		if (y < SPEC_TOP) y = SPEC_TOP;
		if (y > SPEC_TOP + SPEC_H - 1) y = SPEC_TOP + SPEC_H - 1;
		if (x < 2048) {
			bm_fb_pixel (x, s_prev_y[x], black);
			bm_fb_pixel (x, y, bm_fb_color (0, 255, 120));
			s_prev_y[x] = y;
		}
		/* waterfall : une ligne coloree */
		bm_fb_pixel (x, wf_row, heat (v));
	}
	/* curseur du waterfall (ligne vive juste en dessous) + marqueur centre */
	int nrow = WF_TOP + (s_wf_pos + 1) % WFH;
	for (int x = 0; x < W; x++) bm_fb_pixel (x, nrow, bm_fb_color (30, 30, 30));
	bm_fb_pixel (W / 2, wf_row, white);		/* repere de la frequence centrale */

	s_wf_pos = (s_wf_pos + 1) % WFH;

	/* --- echelle de frequence : graduations tous les 100 kHz + 3 reperes --- */
	double fl = center_mhz + (BIN_LO - FFTN / 2) * 0.001;	/* bord gauche (MHz) */
	double fr = center_mhz + (BIN_HI - FFTN / 2) * 0.001;	/* bord droit */
	double span = fr - fl;
	for (int yy = RULER_Y; yy < RULER_Y + RULER_H; yy++)	/* efface l'ancienne regle */
		for (int x = 0; x < W; x++) bm_fb_pixel (x, yy, black);
	double f0 = (floor (fl * 10.0) + 1.0) / 10.0;		/* 1er multiple de 0,1 */
	for (double f = f0; f <= fr; f += 0.1) {
		int x = (int) ((f - fl) / span * W);
		if (x < 0 || x >= W) continue;
		unsigned col = fabs (f - center_mhz) < 0.05 ? white : bm_fb_color (110, 110, 110);
		for (int yy = RULER_Y; yy < RULER_Y + RULER_H; yy++) bm_fb_pixel (x, yy, col);
	}

	/* reperes chiffres (ligne 2) : bord gauche / centre / bord droit */
	int cols = W / 8;
	if (cols > 250) cols = 250;
	if (cols < 24) cols = 24;
	char line[256];
	memset (line, ' ', cols);
	line[cols] = 0;
	char tmp[16];
	snprintf (tmp, sizeof tmp, "%.3f", fl);
	memcpy (line + 1, tmp, strlen (tmp));
	snprintf (tmp, sizeof tmp, "%.3f", center_mhz);
	memcpy (line + cols / 2 - 3, tmp, strlen (tmp));
	snprintf (tmp, sizeof tmp, "%.3f", fr);
	memcpy (line + cols - 8, tmp, strlen (tmp));
	printf ("\x1b[2;1H\x1b[K%s", line);

	/* texte d'etat (ligne du haut) */
	printf ("\x1b[H\x1b[K  %.4f MHz   span 0,9 MHz   gain %.0f dB   "
		"fin auto dans %ds   Echap quitter",
		center_mhz, s_gains[s_gidx] / 10.0, s_secs_left);
	fflush (stdout);
}

static void usage (void)
{
	fprintf (stderr,
		"rtlwf, waterfall + spectre temps reel (RTL-SDR)\n\n"
		"Usage: rtlwf [-f MHz] [-g dB] [-d index]\n"
		"\t[-f MHz]   frequence centrale (defaut 100)\n"
		"\t[-g dB]    gain fixe du tuner (defaut 30)\n"
		"\t[-d index] numero de la cle\n"
		"Fleches G/D: +/-100 kHz   Haut/Bas: +/-1 MHz   +/-: echelle   Echap: quitter\n");
	exit (1);
}

int rtlwf_main (int argc, char **argv)
{
	int opt, dev_index = 0, fixed_gain = -1;
	double mhz = 100.0;
	float dmin = -70.0f, drange = 60.0f;

	s_dev = NULL; s_quit = 0; s_wf_pos = 0;
	optind = 1;
	while ((opt = getopt (argc, argv, "f:g:d:h")) != -1) {
		switch (opt) {
		case 'f': mhz = atof (optarg); break;
		case 'g': fixed_gain = (int) (atof (optarg) * 10); break;
		case 'd': dev_index = atoi (optarg); break;
		default: usage ();
		}
	}
	if (mhz < 0.1 || mhz > 1700) usage ();

	if (bm_fb_width () == 0) {
		fprintf (stderr, "Pas d'ecran HDMI : le waterfall a besoin d'un affichage.\n");
		exit (1);
	}
	if (fft_init (&s_fft, FFTN)) { fprintf (stderr, "FFT: memoire\n"); exit (1); }

	bm_add_cleanup (cleanup);
	signal (SIGINT, on_sigint);

	if (rtlsdr_get_device_count () == 0) { fprintf (stderr, "Pas de cle RTL-SDR\n"); exit (1); }
	if (rtlsdr_open (&s_dev, dev_index) < 0) { fprintf (stderr, "Ouverture cle impossible\n"); s_dev = NULL; exit (1); }
	rtlsdr_set_bias_tee (s_dev, 0);
	rtlsdr_set_direct_sampling (s_dev, 0);
	verbose_set_sample_rate (s_dev, RATE);
	rtlsdr_set_agc_mode (s_dev, 0);
	rtlsdr_set_tuner_gain_mode (s_dev, 1);
	s_ngains = rtlsdr_get_tuner_gains (s_dev, NULL);
	if (s_ngains > 64) s_ngains = 64; if (s_ngains < 1) s_ngains = 1;
	rtlsdr_get_tuner_gains (s_dev, s_gains);
	wf_set_gain (wf_nearest_gain (fixed_gain >= 0 ? fixed_gain : 300));

	rtlsdr_set_center_freq (s_dev, (uint32_t) (mhz * 1e6));
	verbose_reset_buffer (s_dev);
	if (rtlsdr_start_async (s_dev, rtl_callback, NULL, USB_BUF_NUM, USB_BUF_LEN) < 0) {
		fprintf (stderr, "Echec du demarrage\n"); exit (1);
	}
	bm_key_capture (1);

	W = bm_fb_width ();
	H = bm_fb_height ();
	if (W > 2048) W = 2048;
	WFH = H - WF_TOP - 1;
	if (WFH < 1) WFH = 1;
	for (int x = 0; x < W; x++) s_prev_y[x] = SPEC_TOP + SPEC_H - 1;
	printf ("\x1b[2J\x1b[H");			/* ecran noir */
	fflush (stdout);

	/* boucle unique facon rtlfm : a chaque tour on pompe l'USB, on lit TOUTES
	   les touches, et on dessine une image au plus toutes les 50 ms */
	uint64_t t_draw = 0, t_start = bm_micros ();
	while (!s_quit) {
		rtlsdr_poll_async (s_dev);
		bm_poll ();

		uint64_t elapsed = bm_micros () - t_start;	/* sortie auto apres 60 s */
		if (elapsed > WF_TIMEOUT_US)
			break;
		s_secs_left = (int) ((WF_TIMEOUT_US - elapsed) / 1000000);

		int k, retune = 0;
		while ((k = bm_getkey ()) >= 0) {
			switch (k) {
			case BM_KEY_LEFT:  mhz -= 0.1; retune = 1; break;
			case BM_KEY_RIGHT: mhz += 0.1; retune = 1; break;
			case BM_KEY_DOWN:  mhz -= 1.0; retune = 1; break;
			case BM_KEY_UP:    mhz += 1.0; retune = 1; break;
			case '+': case '=': drange -= 5.0f; if (drange < 20.0f) drange = 20.0f; break;
			case '-':          drange += 5.0f; if (drange > 120.0f) drange = 120.0f; break;
			case 'g':          wf_set_gain (s_gidx - 1); break;
			case 'G':          wf_set_gain (s_gidx + 1); break;
			case 0x1B: case 'q': case 'Q': s_quit = 1; break;
			}
		}
		if (retune) {
			if (mhz < 0.1) mhz = 0.1;
			if (mhz > 1700) mhz = 1700;
			rtlsdr_set_center_freq (s_dev, (uint32_t) (mhz * 1e6));
			s_skip = 3;
			s_cap_len = 0; s_done = 0;
		}

		if (s_done) {				/* une image est prete */
			if (bm_micros () - t_draw > 50000) {
				draw_frame (mhz, dmin, drange);
				t_draw = bm_micros ();
			}
			s_cap_len = 0; s_done = 0;	/* relance la capture suivante */
		}
	}
	printf ("\x1b[0m\x1b[2J\x1b[H");
	fflush (stdout);
	return 0;
}
