/*
 * ook.c - détection d'impulsions OOK et décodeurs de capteurs 433 MHz
 *
 * Copyright (C) 2026 rpitx-baremetal contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Le détecteur transforme un flux d'amplitude (enveloppe du signal) en une
 * suite de marques (niveau haut) et d'espaces (niveau bas), séparée en rafales
 * par les longs silences. Chaque rafale est passée aux décodeurs.
 *
 * Seuil adaptatif : on suit en continu le plancher de bruit (pendant les bas)
 * et le niveau du signal (pendant les hauts) ; le basculement se fait entre les
 * deux, avec hystérésis.
 */
#include "ook.h"
#include <stdio.h>
#include <string.h>

#define RESET_US	9000		/* un silence plus long termine la rafale */
#define MIN_PULSES	16		/* rafale plus courte = parasite, ignorée */

void ook_init (ook_detector_t *d, int fs, ook_cb cb, void *ctx)
{
	memset (d, 0, sizeof *d);
	d->fs = fs;
	d->cb = cb;
	d->ctx = ctx;
	d->noise = 1.0f;
	d->level = 40.0f;
}

static int samples_to_us (ook_detector_t *d, int n)
{
	return (int) ((int64_t) n * 1000000 / d->fs);
}

static void finalize (ook_detector_t *d, int last_gap_us)
{
	if (d->pending && d->pkt.num < OOK_MAX_PULSES)
	{
		d->pkt.pulse_us[d->pkt.num] = d->last_pulse_us;
		d->pkt.gap_us[d->pkt.num] = last_gap_us;
		d->pkt.num++;
		d->pending = 0;
	}
	if (d->pkt.num >= MIN_PULSES && d->cb)
	{
		d->cb (&d->pkt, d->ctx);
	}
	d->pkt.num = 0;
}

void ook_feed (ook_detector_t *d, const uint16_t *mag, int n)
{
	for (int k = 0; k < n; k++)
	{
		float m = mag[k];
		float span = d->level - d->noise;
		if (span < 6.0f)
		{
			span = 6.0f;			/* marge minimale anti-bruit */
		}
		float thr_hi = d->noise + span * 0.55f;
		float thr_lo = d->noise + span * 0.35f;	/* base stable */

		if (d->state == 0)			/* niveau bas */
		{
			d->noise += (m - d->noise) * 0.002f;	/* suit le plancher */
			if (m > thr_hi)			/* front montant */
			{
				int gap = samples_to_us (d, d->run);
				if (d->pending && d->pkt.num < OOK_MAX_PULSES)
				{
					d->pkt.pulse_us[d->pkt.num] = d->last_pulse_us;
					d->pkt.gap_us[d->pkt.num] = gap;
					d->pkt.num++;
					d->pending = 0;
				}
				d->state = 1;
				d->run = 0;
			}
			else
			{
				d->run++;
				if (samples_to_us (d, d->run) > RESET_US && d->pkt.num > 0)
				{
					finalize (d, samples_to_us (d, d->run));
				}
			}
		}
		else					/* niveau haut */
		{
			if (m > d->level)
			{
				d->level = m;
			}
			else
			{
				d->level += (m - d->level) * 0.01f;
			}
			if (m < thr_lo)			/* front descendant */
			{
				d->last_pulse_us = samples_to_us (d, d->run);
				d->pending = 1;
				d->state = 0;
				d->run = 0;
			}
			else
			{
				d->run++;
			}
		}
	}
}

/* ------------------------------------------------------------------ */
/* Décodeurs                                                          */
/* ------------------------------------------------------------------ */

static int near (int v, int target, int tol)
{
	return v >= target - tol && v <= target + tol;
}

/* extension de signe d'un entier de nbits bits */
static int sign_extend (unsigned v, int nbits)
{
	int m = 1 << (nbits - 1);
	return (int) ((v ^ m) - m);
}

/* bits par la durée de l'espace (codage PPM : espace long = 1) */
static int bits_from_gap (const ook_packet_t *pkt, int seuil, uint8_t *bits, int max)
{
	int n = pkt->num < max ? pkt->num : max;
	for (int i = 0; i < n; i++)
	{
		bits[i] = pkt->gap_us[i] > seuil ? 1 : 0;
	}
	return n;
}

static unsigned pack (const uint8_t *bits, int start, int len)
{
	unsigned v = 0;
	for (int i = 0; i < len; i++)
	{
		v = (v << 1) | (bits[start + i] & 1);
	}
	return v;
}

/*
 * Nexus et clones (Digoo, Sencor, Froggit, nombreux capteurs « sans marque »).
 * 36 bits, marque ~500 µs fixe, espace ~1000 µs = 0, ~2000 µs = 1.
 *   id(8) pile(1) ?(1) canal(2) temp(12 signé /10) 1111(4) humidité(8)
 * Le quartet fixe 1111 et l'humidité <= 100 servent de garde-fou.
 */
static int decode_nexus (const ook_packet_t *pkt, sensor_t *s)
{
	if (pkt->num < 36)
	{
		return 0;
	}
	/* marque à peu près constante autour de 500 µs ? */
	if (!near (pkt->pulse_us[0], 500, 250) || !near (pkt->pulse_us[10], 500, 250))
	{
		return 0;
	}
	uint8_t b[37];
	bits_from_gap (pkt, 1500, b, 37);

	if (pack (b, 24, 4) != 0x0F)		/* quartet fixe */
	{
		return 0;
	}
	unsigned id = pack (b, 0, 8);
	int battery = b[8];
	int channel = (int) pack (b, 10, 2) + 1;
	int temp = sign_extend (pack (b, 12, 12), 12);
	int hum = (int) pack (b, 28, 8);
	if (hum > 100)
	{
		return 0;
	}
	sensor_init (s);
	strcpy (s->model, "Nexus/clone");
	s->id = id;
	s->channel = channel;
	s->has_temp = 1;
	s->temp_dC = temp;
	s->humidity = hum;
	s->battery_ok = battery;
	return 1;
}

/*
 * TFA-Pool (TFA 30.3160). PPM, marque constante ~420 µs, espace ~2000 µs = 0,
 * ~4600 µs = 1, 28 bits répétés. Format :  CCCCIIII IIIITTTT TTTTTTTT DDBF
 *   C somme des quartets - 1, I identifiant, T température, D canal, B pile,
 *   F première émission. (source : décodeur rtl_433)
 */
static int decode_tfa_pool (const ook_packet_t *pkt, sensor_t *s)
{
	int usable = pkt->num;
	if (usable > 0 && pkt->gap_us[usable - 1] >= RESET_US)
	{
		usable--;			/* dernier espace = silence de fin */
	}
	if (usable != 28)
	{
		return 0;
	}
	uint8_t bits[28];
	for (int i = 0; i < 28; i++)
	{
		if (pkt->gap_us[i] < 1200 || pkt->gap_us[i] > 6000)
		{
			return 0;		/* espaces hors des familles 2000/4600 */
		}
		bits[i] = pkt->gap_us[i] > 3300 ? 1 : 0;
	}
	uint8_t b[4];
	b[0] = (uint8_t) pack (bits, 0, 8);
	b[1] = (uint8_t) pack (bits, 8, 8);
	b[2] = (uint8_t) pack (bits, 16, 8);
	b[3] = (uint8_t) (pack (bits, 24, 4) << 4);	/* quartet DDBF en haut */

	int crx = b[0] >> 4;
	int cs = ((b[0] & 0x0F) + (b[1] >> 4) + (b[1] & 0x0F)
		  + (b[2] >> 4) + (b[2] & 0x0F) + (b[3] >> 4) - 1) & 0x0F;
	if (crx != cs)
	{
		return 0;
	}
	int id = ((b[0] & 0x0F) << 4) | (b[1] >> 4);
	int traw = ((b[1] & 0x0F) << 8) | b[2];
	int t10 = traw > 2048 ? traw - 4096 : traw;	/* dixièmes de °C */
	int ch = (b[3] & 0xC0) >> 6;
	int batt = (b[3] & 0x20) >> 5;
	sensor_init (s);
	strcpy (s->model, "TFA-Pool");
	s->id = id;
	s->channel = ch;
	s->has_temp = 1;
	s->temp_dC = t10;
	s->battery_ok = batt;
	return 1;
}

/*
 * LaCrosse TX141-Bv2 / TX141TH-Bv2. PWM : marque 417 µs = 1, 208 µs = 0 (puis
 * bits inversés), précédée de 4 impulsions de préambule ~833 µs, le tout répété
 * ~12 fois dans une rafale. 37 bits (Bv2, température seule) ou 40 (TH, +humidité).
 *   id(8) pileT(1) test(1) canal(2) temp(12 : (raw-500)/10 °C) [humidité(8)]
 * (source : décodeur rtl_433)
 */
static int decode_tx141 (const ook_packet_t *pkt, sensor_t *s)
{
	/* décode chaque copie de la rafale, garde la valeur qui revient >=2 fois
	   (les copies abîmées par un glitch donnent des valeurs qui ne se répètent pas) */
	struct { int id, t10, ch, batt, th, hum; } cand[40];
	int nc = 0;
	int n = pkt->num;
	int st = 0;

	/* estime la période d'un bit sur cette rafale (variantes de timing selon
	   le capteur) : moyenne de marque+espace des impulsions de données */
	long psum = 0; int pn = 0;
	for (int i = 0; i < n; i++)
	{
		int pw = pkt->pulse_us[i], gw = pkt->gap_us[i];
		if (pw > 80 && pw <= 600 && gw > 80 && gw < 900)
		{
			psum += pw + gw; pn++;
		}
	}
	int period = pn >= 4 ? (int) (psum / pn) : 724;	/* ~724 µs par défaut */
	if (period < 400) period = 400;
	if (period > 1000) period = 1000;
	while (st + 4 < n && nc < 40)
	{
		int pre = 0;
		while (st + pre < n && pkt->pulse_us[st + pre] > 600)
		{
			pre++;				/* préambule : marques ~900 µs */
		}
		if (pre < 2)
		{
			st++;
			continue;
		}
		int d = st + pre;
		uint8_t bits[48];
		int nb = 0;
		int mthr = period * 2 / 5;		/* seuil marque courte/longue */
		/* données : marques courtes(=1)/longues(=0), espaces complémentaires.
		   Une impulsion >600 isolée (suivie de données, pas d'une autre marque
		   longue) est une FUSION de 2+ bits : l'espace court a été raté et deux
		   marques se sont collées. On la redécoupe au lieu de couper la trame :
		   marque_fusion ~= période + marque2, donc on récupère le dernier bit et
		   on comble les bits perdus (supposés longs). Ça garde l'alignement 37 bits. */
		while (d < n && nb < 44)
		{
			int pw = pkt->pulse_us[d];
			int gw = pkt->gap_us[d];
			if (pw > 600)
			{
				if (d + 1 < n && pkt->pulse_us[d + 1] > 600)
				{
					break;			/* série de marques longues = préambule suivant */
				}
				int span = (pw + gw + period / 2) / period;
				if (span < 2) span = 2;
				if (span > 4) span = 4;
				for (int k = 0; k < span - 1 && nb < 44; k++)
				{
					bits[nb++] = 0;		/* bits perdus dans la fusion -> longs */
				}
				if (nb < 44)
				{
					int m2 = pw - period;	/* marque du dernier bit récupérable */
					bits[nb++] = m2 < mthr ? 1 : 0;
				}
				d++;
				if (gw >= 900) break;		/* fin de copie */
				continue;
			}
			bits[nb++] = pw < mthr ? 1 : 0;	/* court=1, long=0 (inversé) */
			d++;
			if (gw >= 900) break;			/* dernier bit de la copie (silence) */
		}
		st = d > st ? d : st + 1;
		if (nb < 37)
		{
			continue;			/* copie trop courte */
		}
		uint8_t b[5];
		for (int i = 0; i < 5; i++)
		{
			b[i] = (uint8_t) pack (bits, i * 8, 8);
		}
		int id = b[0];
		int t10 = (((b[1] & 0x0F) << 8) | b[2]) - 500;
		if (id == 0 || t10 < -400 || t10 > 600)
		{
			continue;			/* copie aberrante */
		}
		cand[nc].id = id;
		cand[nc].t10 = t10;
		cand[nc].ch = (b[1] & 0x30) >> 4;
		cand[nc].batt = (b[1] >> 7) & 1;
		cand[nc].th = nb >= 40 && b[3] > 0 && b[3] <= 100;
		cand[nc].hum = cand[nc].th ? b[3] : -1;
		nc++;
	}

	for (int i = 0; i < nc; i++)			/* cherche une valeur répétée */
	{
		int cnt = 1;
		for (int j = i + 1; j < nc; j++)
		{
			if (cand[j].id == cand[i].id && cand[j].t10 == cand[i].t10)
			{
				cnt++;
			}
		}
		if (cnt >= 2)
		{
			sensor_init (s);
			strcpy (s->model, cand[i].th ? "LaCrosse-TX141TH" : "LaCrosse-TX141");
			s->id = cand[i].id; s->id_hex = 1; s->channel = cand[i].ch;
			s->has_temp = 1; s->temp_dC = cand[i].t10;
			s->humidity = cand[i].hum;
			s->battery_ok = cand[i].batt;
			return 1;
		}
	}
	return 0;
}

void sensor_init (sensor_t *s)
{
	memset (s, 0, sizeof *s);
	s->id = -1;
	s->channel = -1;
	s->humidity = -1;
	s->battery_ok = -1;
}

int ook_decode_data (const ook_packet_t *pkt, sensor_t *s)
{
	return decode_nexus (pkt, s) || decode_tfa_pool (pkt, s) || decode_tx141 (pkt, s);
}

int ook_decode (const ook_packet_t *pkt, char *out, int outlen)
{
	sensor_t s;
	if (!ook_decode_data (pkt, &s))
	{
		return 0;
	}
	sensor_format (&s, out, outlen);
	return 1;
}

/* ligne simple (fichiers log, tests) */
void sensor_format (const sensor_t *s, char *out, int outlen)
{
	int n = snprintf (out, outlen, "%s", s->model);
	if (s->id >= 0)
		n += snprintf (out + n, outlen - n, s->id_hex ? "  id=%lx" : "  id=%ld", s->id);
	if (s->channel >= 0)
		n += snprintf (out + n, outlen - n, "  canal=%d", s->channel);
	if (s->has_temp)
		n += snprintf (out + n, outlen - n, "  %d.%d C",
			       s->temp_dC / 10, (s->temp_dC < 0 ? -s->temp_dC : s->temp_dC) % 10);
	if (s->humidity >= 0)
		n += snprintf (out + n, outlen - n, "  %d%%", s->humidity);
	if (s->battery_ok >= 0)
		n += snprintf (out + n, outlen - n, "  pile=%s", s->battery_ok ? "ok" : "faible");
}

/* ligne en couleur, façon rtl_433 (heure cyan, modèle magenta, mesures vertes) */
void sensor_print (const sensor_t *s, unsigned sec)
{
	printf ("\x1b[36m[%4u s]\x1b[0m \x1b[35m%-16s\x1b[0m", sec, s->model);
	if (s->id >= 0)
		printf (s->id_hex ? "  id \x1b[37m%lx\x1b[0m" : "  id \x1b[37m%ld\x1b[0m", s->id);
	if (s->channel >= 0)
		printf ("  canal %d", s->channel);
	if (s->has_temp)
		printf ("  \x1b[32m%d.%d C\x1b[0m",
			s->temp_dC / 10, (s->temp_dC < 0 ? -s->temp_dC : s->temp_dC) % 10);
	if (s->humidity >= 0)
		printf ("  \x1b[32m%d%%\x1b[0m", s->humidity);
	if (s->battery_ok >= 0)
		printf ("  pile %s%s\x1b[0m", s->battery_ok ? "" : "\x1b[31m",
			s->battery_ok ? "ok" : "faible");
	printf ("\n");
}

/* ------------------------------------------------------------------ */
/* Affichage brut d'une rafale non reconnue                           */
/* ------------------------------------------------------------------ */
void ook_dbg_tx141 (const ook_packet_t *pkt, char *out, int outlen)
{
	int n = pkt->num, st = 0, found = 0, hp = 0;
	long psum = 0; int pn = 0;
	for (int i = 0; i < n; i++)
	{
		int pw = pkt->pulse_us[i], gw = pkt->gap_us[i];
		if (pw > 80 && pw <= 600 && gw > 80 && gw < 900) { psum += pw + gw; pn++; }
	}
	int period = pn >= 4 ? (int) (psum / pn) : 724;
	if (period < 400) period = 400;
	if (period > 1000) period = 1000;
	int mthr = period * 2 / 5;
	hp += snprintf (out + hp, outlen - hp, "TX141? per%d ", period);
	while (st + 4 < n && hp < outlen - 28)
	{
		int pre = 0;
		while (st + pre < n && pkt->pulse_us[st + pre] > 600) pre++;
		if (pre < 2) { st++; continue; }
		int d = st + pre, nb = 0, mg = 0;
		uint8_t bits[48];
		while (d < n && nb < 44)
		{
			int pw = pkt->pulse_us[d];
			int gw = pkt->gap_us[d];
			if (pw > 600)
			{
				if (d + 1 < n && pkt->pulse_us[d + 1] > 600) break;
				int span = (pw + gw + period / 2) / period;
				if (span < 2) span = 2;
				if (span > 4) span = 4;
				for (int k = 0; k < span - 1 && nb < 44; k++) bits[nb++] = 0;
				if (nb < 44) bits[nb++] = (pw - period) < mthr ? 1 : 0;
				mg++; d++;
				if (gw >= 900) break;
				continue;
			}
			bits[nb++] = pw < mthr ? 1 : 0;
			d++;
			if (gw >= 900) break;
		}
		st = d > st ? d : st + 1;
		found++;
		if (nb < 37) { hp += snprintf (out + hp, outlen - hp, "[pre%d nb%d f%d] ", pre, nb, mg); continue; }
		uint8_t b[5]; for (int i = 0; i < 5; i++) b[i] = (uint8_t) pack (bits, i * 8, 8);
		int id = b[0], t10 = (((b[1] & 0x0F) << 8) | b[2]) - 500;
		hp += snprintf (out + hp, outlen - hp, "[pre%d nb%d f%d id%02x t%d] ", pre, nb, mg, id, t10);
	}
	if (!found) snprintf (out + hp, outlen - hp, "(aucun preambule)");
}

void ook_dump (const ook_packet_t *pkt, char *out, int outlen)
{
	int hp = snprintf (out, outlen, "%d imp :", pkt->num);
	int n = pkt->num < 40 ? pkt->num : 40;		/* 40 premières paires */
	for (int i = 0; i < n && hp < outlen - 16; i++)
	{
		hp += snprintf (out + hp, outlen - hp, " %d/%d", pkt->pulse_us[i], pkt->gap_us[i]);
	}
}

void ook_raw (const ook_packet_t *pkt, char *out, int outlen)
{
	/* durées dominantes : moyennes des marques et des deux familles d'espaces */
	long psum = 0;
	int gmin = 1 << 30, gmax = 0;
	for (int i = 0; i < pkt->num; i++)
	{
		psum += pkt->pulse_us[i];
		if (pkt->gap_us[i] < gmin) gmin = pkt->gap_us[i];
		if (pkt->gap_us[i] > gmax && pkt->gap_us[i] < RESET_US) gmax = pkt->gap_us[i];
	}
	int pavg = pkt->num ? (int) (psum / pkt->num) : 0;
	int seuil = (gmin + gmax) / 2;

	/* bits : codage sur l'espace si les espaces varient plus que les marques,
	   sinon sur la marque */
	uint8_t bits[OOK_MAX_PULSES];
	int coding_gap = (gmax - gmin) > pavg / 2;
	int nb = pkt->num;
	for (int i = 0; i < nb; i++)
	{
		int v = coding_gap ? pkt->gap_us[i] : pkt->pulse_us[i];
		bits[i] = v > (coding_gap ? seuil : pavg) ? 1 : 0;
	}

	/* le dernier couple se termine par le silence de fin : on ne compte pas
	   ce bit-là s'il vient d'un espace de reset */
	if (nb > 0 && pkt->gap_us[nb - 1] >= RESET_US)
	{
		nb--;
	}

	/* tous les bits en quartets hexa (le dernier complété par des zéros) */
	char hex[72];
	int hp = 0;
	int nnib = (nb + 3) / 4;
	if (nnib > 32) nnib = 32;			/* trames très longues : on tronque */
	for (int nib = 0; nib < nnib && hp < (int) sizeof hex - 2; nib++)
	{
		unsigned v = 0;
		for (int bit = 0; bit < 4; bit++)
		{
			int idx = nib * 4 + bit;
			v = (v << 1) | (idx < nb ? (bits[idx] & 1) : 0);
		}
		hp += snprintf (hex + hp, sizeof hex - hp, "%x", v);
	}
	if ((nb + 3) / 4 > 32)
	{
		hp += snprintf (hex + hp, sizeof hex - hp, "..");
	}
	hex[hp] = '\0';

	snprintf (out, outlen,
		  "inconnu %d bits  marque %dus  espaces %d/%dus  (%s) %s",
		  nb, pavg, gmin, gmax, coding_gap ? "espace" : "marque", hex);
}
